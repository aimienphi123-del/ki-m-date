import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final AppLocalizations vi = AppLocalizations(const Locale('vi'));
  final AppLocalizations en = AppLocalizations(const Locale('en'));

  group('translation tables', () {
    test('both languages define exactly the same keys', () {
      expect(stringsVi.keys.toSet(), stringsEn.keys.toSet());
    });

    test('no string is left empty', () {
      for (final MapEntry<String, String> entry in stringsVi.entries) {
        expect(entry.value.trim(), isNotEmpty, reason: 'vi/${entry.key}');
      }
      for (final MapEntry<String, String> entry in stringsEn.entries) {
        expect(entry.value.trim(), isNotEmpty, reason: 'en/${entry.key}');
      }
    });

    test('both languages use the same placeholders in each string', () {
      final RegExp placeholder = RegExp(r'\{(\w+)\}');
      for (final String key in stringsVi.keys) {
        Set<String> namesIn(String template) => placeholder
            .allMatches(template)
            .map((RegExpMatch m) => m.group(1)!)
            .toSet();
        expect(
          namesIn(stringsVi[key]!),
          namesIn(stringsEn[key]!),
          reason: 'placeholders differ for "$key"',
        );
      }
    });
  });

  group('lookup', () {
    test('returns the Vietnamese string by default', () {
      expect(vi.t(K.navToday), 'Hôm nay');
      expect(en.t(K.navToday), 'Today');
    });

    test('substitutes placeholders', () {
      expect(
        vi.t(K.todayItemsToDestroy, <String, Object?>{'count': 17}),
        '17 sản phẩm cần huỷ',
      );
      expect(
        en.t(K.notifDigestBody, <String, Object?>{'count': 17}),
        'You have 17 products to destroy today.',
      );
    });

    test('leaves an unknown placeholder visible rather than blanking it', () {
      expect(
        vi.t(K.todayItemsToDestroy, <String, Object?>{'wrong': 1}),
        contains('{count}'),
      );
    });

    test('an unknown key returns the key, so a gap is obvious', () {
      expect(vi.t('does.not.exist'), 'does.not.exist');
    });

    test('an unsupported locale falls back to Vietnamese', () {
      final AppLocalizations other = AppLocalizations(const Locale('fr'));
      expect(other.t(K.navToday), 'Hôm nay');
    });
  });

  group('formatting', () {
    test('durations read naturally in both languages', () {
      const Duration span = Duration(days: 2, hours: 3, minutes: 15);
      expect(vi.duration(span), '2 ngày 3 giờ');
      expect(en.duration(span), '2 d 3 h');
    });

    test('a sub-minute span reads as "now"', () {
      expect(vi.duration(const Duration(seconds: 20)), 'ngay bây giờ');
    });

    test('a negative span is described by its magnitude', () {
      expect(vi.duration(const Duration(hours: -5)), '5 giờ');
    });

    test('long shelf lives read in months and years', () {
      expect(vi.shelfLife(const Duration(days: 400)), startsWith('1 năm'));
      expect(vi.shelfLife(const Duration(days: 90)), '3 tháng');
      expect(vi.shelfLife(const Duration(days: 5)), '5 ngày');
    });

    test('money uses the configured symbol on the local side of the number', () {
      expect(vi.money(15000, symbol: '₫'), endsWith('₫'));
      expect(en.money(15000, symbol: r'$'), startsWith(r'$'));
    });

    test('percentages are formatted for the locale', () {
      expect(vi.percent(0.125), contains('12'));
    });
  });

  group('delegate', () {
    test('supports Vietnamese and English only', () {
      expect(AppLocalizations.delegate.isSupported(const Locale('vi')), isTrue);
      expect(AppLocalizations.delegate.isSupported(const Locale('en')), isTrue);
      expect(AppLocalizations.delegate.isSupported(const Locale('fr')), isFalse);
    });
  });
}
