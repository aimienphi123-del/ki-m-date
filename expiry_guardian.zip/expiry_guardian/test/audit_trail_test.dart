import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/audit/audit_repository_impl.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'support/test_harness.dart';

void main() {
  late TestHarness harness;
  final DateTime now = DateTime(2026, 9, 6, 8);

  setUp(() async {
    harness = await TestHarness.create(now: now);
  });

  tearDown(() async => harness.dispose());

  Future<AuditEntry> append(String label, {AuditAction? action}) async {
    return (await harness.audit.append(
      AuditDraft(
        action: action ?? AuditAction.settingChanged,
        entity: Tables.settings,
        entityId: label,
        entityLabel: label,
        newValue: <String, Object?>{'value': label},
      ),
    ))
        .unwrap();
  }

  // The harness seeds the default notification stages and escalation rules,
  // and seeding is itself an audited operation - so the log is never empty at
  // the start of a test. That is the real shape of the app; the assertions
  // below are written relative to it rather than assuming sequence 1.

  group('hash chain', () {
    test('the very first entry starts from the genesis hash', () async {
      final List<AuditEntry> all =
          (await harness.audit.query(const AuditQuery(limit: 1000))).unwrap();
      final AuditEntry first = all.last;
      expect(first.previousHash, AuditRepositoryImpl.genesisHash);
      expect(first.hash, hasLength(64));
    });

    test('each entry links to the one before it', () async {
      final AuditEntry first = await append('one');
      final AuditEntry second = await append('two');
      final AuditEntry third = await append('three');

      expect(second.previousHash, first.hash);
      expect(third.previousHash, second.hash);
      expect(second.sequence, first.sequence + 1);
      expect(third.sequence, second.sequence + 1);
    });

    test('the hash actually covers the content', () async {
      final AuditEntry entry = await append('one');
      expect(
        AuditRepositoryImpl.computeHash(entry.previousHash, entry.hashedFields),
        entry.hash,
      );
      // A single changed field produces a different hash.
      final List<Object?> tampered = List<Object?>.of(entry.hashedFields)
        ..[5] = 'something else';
      expect(
        AuditRepositoryImpl.computeHash(entry.previousHash, tampered),
        isNot(entry.hash),
      );
    });

    test('a batch is chained inside one transaction', () async {
      final List<AuditEntry> entries = (await harness.audit.appendAll(<AuditDraft>[
        const AuditDraft(action: AuditAction.recordCreated, entity: 'a'),
        const AuditDraft(action: AuditAction.recordEdited, entity: 'b'),
        const AuditDraft(action: AuditAction.recordClosed, entity: 'c'),
      ]))
          .unwrap();

      expect(entries, hasLength(3));
      expect(entries[1].previousHash, entries[0].hash);
      expect(entries[2].previousHash, entries[1].hash);
    });
  });

  group('verifyChain', () {
    test('reports an untouched log as intact', () async {
      final int before = (await harness.audit.count(const AuditQuery())).unwrap();
      await append('one');
      await append('two');
      final AuditIntegrityReport report = (await harness.audit.verifyChain()).unwrap();
      expect(report.isIntact, isTrue);
      expect(report.entriesChecked, before + 2);
      expect(report.firstBrokenSequence, isNull);
    });

    test('the seeded log is intact before anything else happens', () async {
      final AuditIntegrityReport report = (await harness.audit.verifyChain()).unwrap();
      expect(report.isIntact, isTrue);
      expect(report.firstBrokenSequence, isNull);
    });

    test('detects a row edited behind the app back', () async {
      await append('one');
      final AuditEntry second = await append('two');
      await append('three');

      // Simulate somebody with a SQLite editor: drop the guard triggers first,
      // then rewrite the middle row. The triggers are the first line of
      // defence; the hash chain is what still catches this once they are gone.
      await harness.database.db
          .execute('DROP TRIGGER audit_log_is_append_only_update');
      await harness.database.db
          .execute('DROP TRIGGER audit_log_is_append_only_delete');
      await harness.database.db.update(
        Tables.auditLog,
        <String, Object?>{'entity_label': 'forged'},
        where: 'seq = ?',
        whereArgs: <Object?>[second.sequence],
      );

      final AuditIntegrityReport report = (await harness.audit.verifyChain()).unwrap();
      expect(report.isIntact, isFalse);
      expect(report.firstBrokenSequence, second.sequence);
    });
  });

  group('immutability', () {
    test('SQLite refuses an UPDATE on the log', () async {
      await append('one');
      await expectLater(
        harness.database.db.update(
          Tables.auditLog,
          <String, Object?>{'entity_label': 'forged'},
          where: 'seq = 1',
        ),
        throwsA(isA<DatabaseException>()),
      );
    });

    test('SQLite refuses a DELETE on the log', () async {
      await append('one');
      await expectLater(
        harness.database.db.delete(Tables.auditLog, where: 'seq = 1'),
        throwsA(isA<DatabaseException>()),
      );
    });

    test('the row is still there and still correct after both attempts', () async {
      final AuditEntry entry = await append('one');
      try {
        await harness.database.db.update(
          Tables.auditLog, <String, Object?>{'note': 'x'},
          where: 'seq = ?', whereArgs: <Object?>[entry.sequence],);
      } on DatabaseException {
        // expected
      }
      final AuditIntegrityReport report = (await harness.audit.verifyChain()).unwrap();
      expect(report.isIntact, isTrue);
      final List<AuditEntry> rows =
          (await harness.audit.query(const AuditQuery(limit: 1000))).unwrap();
      expect(rows.first.hash, entry.hash);
    });
  });

  group('query', () {
    test('filters by action', () async {
      await append('a', action: AuditAction.destroyConfirmed);
      await append('b', action: AuditAction.escalationRaised);
      await append('c', action: AuditAction.destroyConfirmed);

      final List<AuditEntry> found = (await harness.audit.query(
        const AuditQuery(actions: <AuditAction>{AuditAction.destroyConfirmed}),
      ))
          .unwrap();
      expect(found, hasLength(2));
      expect(
        found.every((AuditEntry e) => e.action == AuditAction.destroyConfirmed),
        isTrue,
      );
    });

    test('stamps the signed-in employee and this device', () async {
      await harness.auth.createInitialAdmin(
        username: 'quanly',
        displayName: 'Chị Lan',
        password: 'matkhau',
      );
      final AuditEntry entry = await append('one');
      expect(entry.actorName, 'Chị Lan');
      expect(entry.deviceId, harness.device.current.id);
    });
  });
}
