import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/disposal_calculator_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// The calculator standing in for the date picker on goods-in.
///
/// The contract that matters is what it hands back: the expiry as the label
/// prints it. Handing back the policy's expiry *instant* instead would store
/// 23:59:59.999 as the printed date and quietly disagree with the label.
void main() {
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create(
        now: DateTime(2026, 9, 13, 9),
      ),);
  tearDown(() async => harness.dispose());

  Future<void> settle(WidgetTester tester, {int frames = 10}) async {
    for (int i = 0; i < frames; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 25)),
      );
      await tester.pump();
    }
  }

  /// Mounts a screen whose only job is to open the picker and keep its answer.
  Future<CalculatorPick?> Function() mountPicker(
    WidgetTester tester, {
    DateTime? expiry,
    DateTime? manufacturing,
  }) {
    CalculatorPick? picked;
    late BuildContext hostContext;

    tester.view.physicalSize = const Size(412, 2000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    return () async {
      await tester.pumpWidget(
        ProviderScope(
          overrides: <Override>[
            dependenciesProvider.overrideWithValue(harness.asDependencies()),
          ],
          child: MaterialApp(
            locale: const Locale('vi'),
            supportedLocales: AppLocalizations.supportedLocales,
            localizationsDelegates: const <LocalizationsDelegate<Object>>[
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: Builder(builder: (BuildContext context) {
              hostContext = context;
              return const Scaffold(body: SizedBox.shrink());
            },),
          ),
        ),
      );
      await settle(tester);

      final Future<CalculatorPick?> pending = DisposalCalculatorPage.pick(
        hostContext,
        expiry: expiry,
        manufacturing: manufacturing,
      );
      await settle(tester);

      await tester.tap(find.text('Dùng hạn này'));
      await settle(tester);

      picked = await pending;
      return picked;
    };
  }

  testWidgets('opens on the printed-expiry mode and hands back that date',
      (WidgetTester tester) async {
    final CalculatorPick? pick = await mountPicker(tester)();

    expect(pick, isNotNull);
    // Today, as a plain date - not the end-of-day instant the policy works in.
    expect(pick!.expiry, DateTime(2026, 9, 13));
    expect(pick.hasTimeOfDay, isFalse);
    // Nothing was said about a production date, so none is invented.
    expect(pick.manufacturing, isNull);
  });

  testWidgets('a date the scan already read is offered back for confirmation',
      (WidgetTester tester) async {
    final CalculatorPick? pick =
        await mountPicker(tester, expiry: DateTime(2026, 12, 31))();

    expect(pick!.expiry, DateTime(2026, 12, 31));
  });

  testWidgets('a production date from the scan opens the two-date mode',
      (WidgetTester tester) async {
    final CalculatorPick? pick = await mountPicker(
      tester,
      expiry: DateTime(2026, 12, 31),
      manufacturing: DateTime(2026, 6, 30),
    )();

    expect(pick!.expiry, DateTime(2026, 12, 31));
    // Both dates were entered, so both come back and goods-in gets the pair.
    expect(pick.manufacturing, DateTime(2026, 6, 30));
  });

  testWidgets('the destroy deadline is shown before anything is saved',
      (WidgetTester tester) async {
    tester.view.physicalSize = const Size(412, 2000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(
      ProviderScope(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
        ],
        child: MaterialApp(
          locale: const Locale('vi'),
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const <LocalizationsDelegate<Object>>[
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: DisposalCalculatorPage(
            pickMode: true,
            initialExpiry: DateTime(2026, 12, 31),
            initialManufacturing: DateTime(2026, 6, 30),
          ),
        ),
      ),
    );
    await settle(tester);

    // Six months of shelf life is the 5-day band, so the deadline is the 26th.
    expect(find.textContaining('26/12/2026'), findsWidgets);
  });
}
