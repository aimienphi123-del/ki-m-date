import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/services/label_text_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const LabelTextParser parser = LabelTextParser();
  final DateTime now = DateTime(2026, 9, 6, 10, 0);

  LabelReading read(List<String> lines, {LabelTextParser? withParser}) =>
      (withParser ?? parser).parse(lines, now: now);

  group('Vietnamese labels', () {
    test('HSD with slashes', () {
      final LabelReading r = read(<String>['HSD: 20/12/2026']);
      expect(r.expiry?.value, DateTime(2026, 12, 20));
      expect(r.expiry?.kind, LabelDateKind.expiry);
    });

    test('NSX and HSD on separate lines', () {
      final LabelReading r = read(<String>[
        'NSX: 01/03/2026',
        'HSD: 01/03/2027',
      ]);
      expect(r.manufacturing?.value, DateTime(2026, 3, 1));
      expect(r.expiry?.value, DateTime(2027, 3, 1));
    });

    test('diacritics are folded', () {
      final LabelReading r = read(<String>['Hạn sử dụng: 15/11/2026']);
      expect(r.expiry?.value, DateTime(2026, 11, 15));
    });

    test('keyword alone carries to the next line', () {
      final LabelReading r = read(<String>['HAN SU DUNG', '31.12.2026']);
      expect(r.expiry?.value, DateTime(2026, 12, 31));
      expect(r.expiry?.kind, LabelDateKind.expiry);
    });

    test('NSX and HSD on one line', () {
      final LabelReading r = read(<String>['NSX 010326 HSD 010327']);
      expect(r.manufacturing?.value, DateTime(2026, 3, 1));
      expect(r.expiry?.value, DateTime(2027, 3, 1));
    });
  });

  group('English labels', () {
    test('EXP with a two digit year', () {
      final LabelReading r = read(<String>['EXP 20/12/26']);
      expect(r.expiry?.value, DateTime(2026, 12, 20));
    });

    test('BEST BEFORE with a month name', () {
      final LabelReading r = read(<String>['BEST BEFORE 20 DEC 2026']);
      expect(r.expiry?.value, DateTime(2026, 12, 20));
    });

    test('USE BY with a month only', () {
      final LabelReading r = read(<String>['USE BY 12/2026']);
      expect(r.expiry?.value, DateTime(2026, 12, 31));
      expect(r.warnings, contains(LabelWarning.onlyMonthPrinted));
    });

    test('MFG and EXP on one line', () {
      final LabelReading r = read(<String>['MFG 2026-01-15 EXP 2027-01-15']);
      expect(r.manufacturing?.value, DateTime(2026, 1, 15));
      expect(r.expiry?.value, DateTime(2027, 1, 15));
    });

    test('EXPRESS is not treated as EXP', () {
      final LabelReading r = read(<String>['EXPRESS DELIVERY 20/12/2026']);
      expect(r.expiry?.kind, LabelDateKind.expiry);
      // Resolved by the future-date rule, not by a keyword.
      expect(r.candidates.first.kind, LabelDateKind.unknown);
    });
  });

  group('ISO and compact formats', () {
    test('ISO date', () {
      final LabelReading r = read(<String>['EXP: 2026-12-20']);
      expect(r.expiry?.value, DateTime(2026, 12, 20));
    });

    test('compact YYYYMMDD', () {
      final LabelReading r = read(<String>['EXP 20261220']);
      expect(r.expiry?.value, DateTime(2026, 12, 20));
    });

    test('compact DDMMYY', () {
      final LabelReading r = read(<String>['HSD 201226']);
      expect(r.expiry?.value, DateTime(2026, 12, 20));
    });
  });

  group('day / month ambiguity', () {
    test('day first by default', () {
      final LabelReading r = read(<String>['EXP 03/04/2027']);
      expect(r.expiry?.value, DateTime(2027, 4, 3));
      expect(r.warnings, contains(LabelWarning.ambiguousDayMonth));
    });

    test('month first when configured', () {
      const LabelTextParser usParser =
          LabelTextParser(config: LabelParserConfig(dayFirst: false));
      final LabelReading r = read(<String>['EXP 03/04/2027'], withParser: usParser);
      expect(r.expiry?.value, DateTime(2027, 3, 4));
    });

    test('unambiguous when the day exceeds 12', () {
      final LabelReading r = read(<String>['EXP 25/04/2027']);
      expect(r.expiry?.value, DateTime(2027, 4, 25));
      expect(r.warnings, isNot(contains(LabelWarning.ambiguousDayMonth)));
    });
  });

  group('hourly expiry', () {
    test('time of day is captured', () {
      final LabelReading r = read(<String>['HSD 06/09/2026 21:30']);
      expect(r.expiry?.value, DateTime(2026, 9, 6, 21, 30));
      expect(r.expiry?.hasTime, isTrue);
    });
  });

  group('batch codes', () {
    test('LOT prefix', () {
      final LabelReading r = read(<String>['LOT: A2026-11', 'HSD 20/12/2026']);
      expect(r.batchCode, 'A2026-11');
    });

    test('Vietnamese so lo', () {
      final LabelReading r = read(<String>['Số lô: XY1234']);
      expect(r.batchCode, 'XY1234');
    });

    test('a date is never mistaken for a batch code', () {
      final LabelReading r = read(<String>['L 20/12/2026']);
      expect(r.batchCode, isNull);
    });
  });

  group('resolution without keywords', () {
    test('two bare dates become mfg and exp', () {
      final LabelReading r = read(<String>['01/03/2026', '01/03/2027']);
      expect(r.manufacturing?.value, DateTime(2026, 3, 1));
      expect(r.expiry?.value, DateTime(2027, 3, 1));
    });

    test('a single past date is treated as manufacturing', () {
      final LabelReading r = read(<String>['01/03/2025']);
      expect(r.manufacturing?.value, DateTime(2025, 3, 1));
      expect(r.expiry, isNull);
    });
  });

  group('warnings and rejects', () {
    test('no dates at all', () {
      final LabelReading r = read(<String>['SUA TUOI TIET TRUNG', 'KHONG DUONG']);
      expect(r.warnings, contains(LabelWarning.noDatesFound));
      expect(r.expiry, isNull);
      expect(r.needsReview, isTrue);
    });

    test('implausible year is rejected', () {
      final LabelReading r = read(<String>['EXP 20/12/2099']);
      expect(r.expiry, isNull);
    });

    test('expiry already passed is flagged', () {
      final LabelReading r = read(<String>['HSD 01/01/2026']);
      expect(r.warnings, contains(LabelWarning.expiryAlreadyPassed));
    });

    test('expiry before manufacturing is flagged', () {
      final LabelReading r = read(<String>['NSX 01/03/2027', 'HSD 01/03/2026']);
      expect(r.warnings, contains(LabelWarning.expiryBeforeManufacturing));
    });

    test('empty input', () {
      final LabelReading r = read(<String>[]);
      expect(r.warnings, contains(LabelWarning.noDatesFound));
    });
  });

  group('CJK imports', () {
    test('Chinese production and validity markers', () {
      final LabelReading r = read(<String>[
        '生产日期 2026-01-15',
        '有效期至 2027-01-14',
      ]);
      expect(r.manufacturing?.value, DateTime(2026, 1, 15));
      expect(r.expiry?.value, DateTime(2027, 1, 14));
    });
  });
}
