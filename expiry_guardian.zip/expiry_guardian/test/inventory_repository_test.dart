import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

void main() {
  late TestHarness harness;
  final DateTime now = DateTime(2026, 9, 6, 8);

  setUp(() async {
    harness = await TestHarness.create(now: now);
  });

  tearDown(() async => harness.dispose());

  Future<Product> newProduct({
    String name = 'Sữa tươi',
    String? barcode = '8934588063053',
    double? unitCost,
    ExpiryPrecision precision = ExpiryPrecision.day,
    String? shelfId,
  }) async {
    return (await harness.catalog.createProduct(
      Product(
        id: '',
        barcode: barcode,
        name: name,
        unit: 'hộp',
        unitCost: unitCost,
        defaultShelfId: shelfId,
        expiryPrecision: precision,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),
    ))
        .unwrap();
  }

  Future<Shelf> newShelf({String area = 'Quầy lạnh', String shelf = 'A2'}) async {
    final StoreArea created =
        (await harness.locations.createArea(name: area, sortOrder: 10)).unwrap();
    return (await harness.locations
            .createShelf(areaId: created.id, name: shelf, sortOrder: 10))
        .unwrap();
  }

  group('intake', () {
    test('applies the policy and stores the whole decision', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          manufacturedAt: DateTime(2026, 9, 6),
          quantity: 12,
        ),
      ))
          .unwrap();

      expect(record.code, startsWith('EG-260906-'));
      // 14 day shelf life -> "over 7 days and under 1 month" -> 1 day early.
      expect(record.leadTime, const Duration(days: 1));
      expect(record.destroyAt, DateTime(2026, 9, 19, 23, 59, 59, 999));
      expect(record.policyVersion, harness.policy.version);
      expect(record.policyRuleId, isNotNull);
      expect(record.quantityRemaining, 12);
      expect(record.status, InventoryStatus.active);
    });

    test('rejects a non-positive quantity', () async {
      final Product product = await newProduct();
      final dynamic result = await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 0,
        ),
      );
      expect(result.isErr, isTrue);
    });

    test('writes a created event carrying the policy explanation', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 1,
        ),
      ))
          .unwrap();

      final List<RecordEvent> history =
          (await harness.inventory.history(record.id)).unwrap();
      expect(history, hasLength(1));
      expect(history.first.type, RecordEventType.created);
      expect(history.first.payload['ruleId'], isNotNull);
      expect(history.first.payload['leadMinutes'], 1440);
    });

    test('inherits the product default shelf', () async {
      final Shelf shelf = await newShelf();
      final Product product = await newProduct(shelfId: shelf.id);
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 1,
        ),
      ))
          .unwrap();
      expect(record.shelfId, shelf.id);
      expect(record.areaId, isNotNull);
    });

    test('allocates unique codes for several lots on the same day', () async {
      final Product product = await newProduct();
      final Set<String> codes = <String>{};
      for (int i = 0; i < 5; i++) {
        final InventoryRecord record = (await harness.inventory.intake(
          IntakeDraft(
            productId: product.id,
            expiryAt: DateTime(2026, 10, 1),
            expiryPrecision: ExpiryPrecision.day,
            quantity: 1,
          ),
        ))
            .unwrap();
        codes.add(record.code);
      }
      expect(codes, hasLength(5));
    });
  });

  group('destruction', () {
    test('closes the lot and prices the loss', () async {
      final Product product = await newProduct(unitCost: 12000);
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 4,
        ),
      ))
          .unwrap();

      final Destruction destruction =
          (await harness.inventory.destroy(DestroyCommand(recordId: record.id))).unwrap();

      expect(destruction.quantity, 4);
      expect(destruction.lossAmount, 48000);
      expect(destruction.wasOverdue, isFalse);

      final InventoryRecord after = (await harness.inventory.findRecord(record.id)).unwrap()!;
      expect(after.status, InventoryStatus.destroyed);
      expect(after.quantityRemaining, 0);
      expect(after.closedAt, isNotNull);
    });

    test('a partial destruction leaves the lot open', () async {
      final Product product = await newProduct(unitCost: 1000);
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 10,
        ),
      ))
          .unwrap();

      final Destruction destruction = (await harness.inventory
              .destroy(DestroyCommand(recordId: record.id, quantity: 3)))
          .unwrap();

      expect(destruction.lossAmount, 3000);
      final InventoryRecord after = (await harness.inventory.findRecord(record.id)).unwrap()!;
      expect(after.status, InventoryStatus.active);
      expect(after.quantityRemaining, 7);
    });

    test('records no loss when the product has no cost price', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 2,
        ),
      ))
          .unwrap();
      final Destruction destruction =
          (await harness.inventory.destroy(DestroyCommand(recordId: record.id))).unwrap();
      expect(destruction.lossAmount, 0);
      expect(destruction.unitCost, isNull);
    });

    test('flags a destruction that happened after the deadline', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 8),
          expiryPrecision: ExpiryPrecision.day,
          manufacturedAt: DateTime(2026, 9, 6),
          quantity: 1,
        ),
      ))
          .unwrap();

      final Destruction destruction = (await harness.inventory.destroy(
        DestroyCommand(recordId: record.id, at: record.destroyAt.add(const Duration(hours: 5))),
      ))
          .unwrap();

      expect(destruction.wasOverdue, isTrue);
      expect(destruction.minutesLate, 300);
    });

    test('refuses to destroy more than is left', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 2,
        ),
      ))
          .unwrap();
      final dynamic result = await harness.inventory
          .destroy(DestroyCommand(recordId: record.id, quantity: 5));
      expect(result.isErr, isTrue);
    });

    test('refuses to destroy a closed lot twice', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 20),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 1,
        ),
      ))
          .unwrap();
      await harness.inventory.destroy(DestroyCommand(recordId: record.id));
      final dynamic second =
          await harness.inventory.destroy(DestroyCommand(recordId: record.id));
      expect(second.isErr, isTrue);
    });
  });

  group('daily destroy list', () {
    test('returns only lots due inside the window, most urgent first', () async {
      final Shelf shelf = await newShelf();
      final Product fresh = await newProduct(name: 'Bánh mì', barcode: '111');
      final Product dry = await newProduct(name: 'Mì gói', barcode: '222');

      // Due today.
      await harness.inventory.intake(IntakeDraft(
        productId: fresh.id,
        expiryAt: DateTime(2026, 9, 6, 20),
        expiryPrecision: ExpiryPrecision.hour,
        manufacturedAt: DateTime(2026, 9, 6, 5),
        quantity: 1,
        shelfId: shelf.id,
      ),);
      // Due in a year.
      await harness.inventory.intake(IntakeDraft(
        productId: dry.id,
        expiryAt: DateTime(2027, 9, 6),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 9, 6),
        quantity: 1,
        shelfId: shelf.id,
      ),);

      final List<InventoryItemView> list = (await harness.inventory
              .destroyList(until: DateTime(2026, 9, 7)))
          .unwrap();

      expect(list, hasLength(1));
      expect(list.first.product.name, 'Bánh mì');
      expect(list.first.priority.level, PriorityLevel.destroySoon);
      expect(list.first.locationLabel, 'Quầy lạnh · A2');
    });

    test('an expired lot is reported as expired, not merely overdue', () async {
      final Product product = await newProduct();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 1),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 8, 20),
        quantity: 1,
      ),);

      final List<InventoryItemView> list = (await harness.inventory
              .destroyList(until: DateTime(2026, 9, 7)))
          .unwrap();
      expect(list.single.priority.level, PriorityLevel.expired);
    });
  });

  group('summary', () {
    test('counts active, overdue, expired and today destructions', () async {
      final Product product = await newProduct(unitCost: 5000);
      final InventoryRecord due = (await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 6, 12),
        expiryPrecision: ExpiryPrecision.hour,
        manufacturedAt: DateTime(2026, 9, 6, 6),
        quantity: 2,
      ),))
          .unwrap();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2027, 1, 1),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 9, 6),
        quantity: 5,
      ),);
      await harness.inventory.destroy(DestroyCommand(recordId: due.id));

      final InventorySummary summary = (await harness.inventory.summary(
        dayStart: DateTime(2026, 9, 6),
        dayEnd: DateTime(2026, 9, 7),
      ))
          .unwrap();

      expect(summary.activeRecords, 1);
      expect(summary.activeUnits, 5);
      expect(summary.destroyedTodayRecords, 1);
      expect(summary.destroyedTodayUnits, 2);
      expect(summary.destroyedTodayLoss, 10000);
      expect(summary.activeStockValue, 25000);
      expect(summary.pricedProductsRatio, 1);
    });
  });

  group('policy changes', () {
    test('recalculating moves the destroy date of stock already on the shelf',
        () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 12, 6),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 9, 6),
        quantity: 1,
      ),))
          .unwrap();
      expect(record.leadTime, const Duration(days: 3));

      // Manager widens the 1-6 month band from 3 days to 10 days.
      final DestroyPolicy policy = (await harness.policies.getActivePolicy()).unwrap();
      final PolicyRule band = policy.rules
          .firstWhere((PolicyRule r) => r.nameEn.contains('1 month to under 6 months'));
      await harness.policies
          .upsertRule(policy.id, band.copyWith(leadTime: const Duration(days: 10)));

      final int changed = (await harness.inventory.recalculateOpenRecords()).unwrap();
      expect(changed, 1);

      final InventoryRecord after = (await harness.inventory.findRecord(record.id)).unwrap()!;
      expect(after.leadTime, const Duration(days: 10));
      expect(after.destroyAt, DateTime(2026, 11, 26, 23, 59, 59, 999));
      expect(after.policyVersion, greaterThan(record.policyVersion));

      final List<RecordEvent> history =
          (await harness.inventory.history(record.id)).unwrap();
      expect(
        history.any((RecordEvent e) => e.type == RecordEventType.policyRecalculated),
        isTrue,
      );
    });

    test('recalculating leaves untouched lots alone', () async {
      final Product product = await newProduct();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 12, 6),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 9, 6),
        quantity: 1,
      ),);
      final int changed = (await harness.inventory.recalculateOpenRecords()).unwrap();
      expect(changed, 0);
    });
  });

  group('search', () {
    test('finds a lot by product name, batch and record code', () async {
      final Product product = await newProduct(name: 'Trà sữa trân châu');
      final InventoryRecord record = (await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 20),
        expiryPrecision: ExpiryPrecision.day,
        batchCode: 'LOT-77',
        quantity: 1,
      ),))
          .unwrap();

      for (final String term in <String>['trân châu', 'LOT-77', record.code]) {
        final List<InventoryItemView> found =
            (await harness.inventory.search(InventoryQuery(text: term))).unwrap();
        expect(found, hasLength(1), reason: 'searching for "$term"');
      }
    });

    test('filters by status', () async {
      final Product product = await newProduct();
      final InventoryRecord record = (await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 20),
        expiryPrecision: ExpiryPrecision.day,
        quantity: 1,
      ),))
          .unwrap();
      await harness.inventory.destroy(DestroyCommand(recordId: record.id));

      final List<InventoryItemView> active =
          (await harness.inventory.search(const InventoryQuery())).unwrap();
      expect(active, isEmpty);

      final List<InventoryItemView> destroyed = (await harness.inventory.search(
        const InventoryQuery(statuses: <InventoryStatus>{InventoryStatus.destroyed}),
      ))
          .unwrap();
      expect(destroyed, hasLength(1));
    });
  });

  group('sync outbox', () {
    test('every write is queued for a future backend', () async {
      final Product product = await newProduct();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 20),
        expiryPrecision: ExpiryPrecision.day,
        quantity: 1,
      ),);
      expect(await harness.syncQueue.pendingCount(), greaterThan(0));
    });
  });
}
