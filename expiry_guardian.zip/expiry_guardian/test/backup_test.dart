import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:expiry_guardian/core/database/migrations.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/backup/data/repositories/backup_repository_impl.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/backup/domain/services/backup_codec.dart';
import 'package:expiry_guardian/features/backup/presentation/viewmodels/backup_view_model.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// A shop's data lives on exactly one phone, so the backup is the only thing
/// standing between a dropped handset and months of stock records. It has to
/// round-trip exactly, and a restore has to refuse anything it cannot vouch
/// for rather than half-applying it.
void main() {
  const BackupCodec codec = BackupCodec();
  final DateTime now = DateTime(2026, 9, 14, 18, 30);

  group('the codec refuses what it cannot vouch for', () {
    Failure? failureOf(Result<BackupData> r) =>
        r.fold((Failure f) => f, (BackupData _) => null);

    test('a round trip keeps every row and every value type', () {
      final BackupData original = BackupData(
        formatVersion: 1,
        schemaVersion: 3,
        appVersion: '1.3.0+4',
        createdAt: now,
        tables: <String, List<Map<String, Object?>>>{
          Tables.products: <Map<String, Object?>>[
            <String, Object?>{
              'id': 'p1',
              'name': 'Sữa chua Vinamilk',
              'barcode': '8934673605823',
              'quantity': 6,
              'price': 12500.5,
              'is_active': 1,
              'photo_path': null,
            },
          ],
        },
        photoNames: <String>['front.jpg'],
      );

      final Result<BackupData> read =
          codec.decode(codec.encode(original), currentSchemaVersion: 3);
      final BackupData back = read.unwrap();

      expect(back.schemaVersion, 3);
      expect(back.appVersion, '1.3.0+4');
      expect(back.photoNames, <String>['front.jpg']);
      final Map<String, Object?> row = back.tables[Tables.products]!.single;
      expect(row['name'], 'Sữa chua Vinamilk');
      expect(row['barcode'], '8934673605823');
      expect(row['quantity'], 6);
      expect(row['price'], 12500.5);
      expect(row['photo_path'], isNull);
    });

    test('a file that is not JSON at all', () {
      expect(
        failureOf(codec.decode('not a backup', currentSchemaVersion: 3))!.message,
        'backup_not_json',
      );
    });

    test('valid JSON from some other app', () {
      // Without the marker this would restore an empty shop over a full one.
      expect(
        failureOf(codec.decode('{"tables":{}}', currentSchemaVersion: 3))!.message,
        'backup_not_ours',
      );
    });

    test('a backup written by a newer build of the app', () {
      final String source = jsonEncode(<String, Object?>{
        'marker': BackupCodec.fileMarker,
        'formatVersion': 1,
        'schemaVersion': 9,
        'tables': <String, Object?>{},
      });
      final Failure failure =
          failureOf(codec.decode(source, currentSchemaVersion: 3))!;
      expect(failure.message, 'backup_too_new');
      // The screen tells the employee which build wrote it, so the fix
      // ("update this phone first") is obvious.
      expect(failure.context['backup'], 9);
      expect(failure.context['app'], 3);
    });

    test('a newer envelope format', () {
      final String source = jsonEncode(<String, Object?>{
        'marker': BackupCodec.fileMarker,
        'formatVersion': 99,
        'schemaVersion': 1,
        'tables': <String, Object?>{},
      });
      expect(
        failureOf(codec.decode(source, currentSchemaVersion: 3))!.message,
        'backup_too_new',
      );
    });

    test('a table that is not a list of rows', () {
      final String source = jsonEncode(<String, Object?>{
        'marker': BackupCodec.fileMarker,
        'formatVersion': 1,
        'schemaVersion': 1,
        'tables': <String, Object?>{'products': 'oops'},
      });
      final Failure failure =
          failureOf(codec.decode(source, currentSchemaVersion: 3))!;
      expect(failure.message, 'backup_table_corrupt');
      expect(failure.context['table'], 'products');
    });

    test('an older backup restores onto a newer schema', () {
      // The ordinary case once a shop has been running a while.
      final String source = jsonEncode(<String, Object?>{
        'marker': BackupCodec.fileMarker,
        'formatVersion': 1,
        'schemaVersion': 2,
        'tables': <String, Object?>{'products': <Object?>[]},
      });
      expect(
        codec.decode(source, currentSchemaVersion: 3).unwrap().schemaVersion,
        2,
      );
    });
  });

  group('rows are narrowed to what the live table can take', () {
    test('a column the backup has and this build does not is dropped', () {
      final Map<String, Object?> fitted = BackupCodec.fitToColumns(
        <String, Object?>{'id': 'p1', 'name': 'Sữa', 'retired_column': 'x'},
        <String>{'id', 'name'},
      );
      expect(fitted, <String, Object?>{'id': 'p1', 'name': 'Sữa'});
    });

    test('a column this build has and the backup does not is simply absent',
        () {
      final Map<String, Object?> fitted = BackupCodec.fitToColumns(
        <String, Object?>{'id': 'p1'},
        <String>{'id', 'barcode_photo_path'},
      );
      expect(fitted.containsKey('barcode_photo_path'), isFalse);
    });
  });

  group('the whole shop survives a round trip through a file', () {
    late TestHarness harness;
    late Directory documents;
    late BackupRepository backup;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      documents =
          await Directory.systemTemp.createTemp('expiry_guardian_backup_');
      backup = BackupRepositoryImpl(
        database: harness.database,
        clock: harness.clock,
        logger: harness.logger,
        documentsDirectory: () async => documents,
        appVersion: '1.3.0+4',
      );
    });

    tearDown(() async {
      await harness.dispose();
      if (documents.existsSync()) documents.deleteSync(recursive: true);
    });

    /// A small but real shop: an area with a shelf, a product with both
    /// photographs on disk, and three lots standing on that shelf.
    Future<Product> seed() async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quầy lạnh')).unwrap();
      final Shelf shelf = (await harness.locations
              .createShelf(areaId: area.id, name: 'Kệ 1'))
          .unwrap();

      final Directory captures = Directory('${documents.path}/captures');
      await captures.create(recursive: true);
      final File front = File('${captures.path}/front.jpg')
        ..writeAsBytesSync(<int>[1, 2, 3, 4]);
      final File code = File('${captures.path}/code.jpg')
        ..writeAsBytesSync(<int>[5, 6, 7, 8]);

      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8934673605823',
        name: 'Sữa chua Vinamilk',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        photoPath: front.path,
        barcodePhotoPath: code.path,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();

      for (int i = 0; i < 3; i++) {
        await harness.inventory.intake(IntakeDraft(
          productId: product.id,
          shelfId: shelf.id,
          expiryAt: DateTime(2026, 10, 1 + i),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 6,
        ),);
      }
      return product;
    }

    Future<int> countOf(String table) async {
      final List<Map<String, Object?>> rows = await harness.database.db
          .rawQuery('SELECT COUNT(*) AS n FROM $table');
      return rows.single['n']! as int;
    }

    test('export writes an archive holding the data and the photographs',
        () async {
      await seed();
      final String path = (await backup.export()).unwrap();

      expect(File(path).existsSync(), isTrue);
      expect(path, endsWith('kiem-date-2026-09-14_1830.zip'));

      final Archive archive =
          ZipDecoder().decodeBytes(File(path).readAsBytesSync());
      final Set<String> names =
          archive.files.map((ArchiveFile f) => f.name).toSet();
      expect(names, contains('backup.json'));
      // The photographs travel with the rows: a destruction record without
      // its evidence photograph is not a record of anything.
      expect(names, contains('photos/front.jpg'));
      expect(names, contains('photos/code.jpg'));
    });

    test('a wiped database is brought back exactly as it was', () async {
      final Product product = await seed();
      final String path = (await backup.export()).unwrap();
      final int lotsBefore = await countOf(Tables.inventoryRecords);
      expect(lotsBefore, 3);

      // The disaster: a new phone, or a reinstall that lost everything.
      for (final String table in <String>[
        Tables.inventoryRecords,
        Tables.products,
        Tables.shelves,
        Tables.areas,
      ]) {
        await harness.database.db.delete(table);
      }
      expect(await countOf(Tables.products), 0);

      final RestoreReport report = (await backup.restore(path)).unwrap();

      expect(await countOf(Tables.inventoryRecords), 3);
      expect(await countOf(Tables.shelves), 1);
      expect(await countOf(Tables.areas), 1);
      expect(report.rowsRestored, greaterThan(0));
      expect(report.photosRestored, 2);

      final Product? back =
          (await harness.catalog.findById(product.id)).unwrap();
      expect(back!.name, 'Sữa chua Vinamilk');
      expect(back.barcode, '8934673605823');
      // The paths were rewritten onto this phone's own folder, and the files
      // they name are really there.
      expect(File(back.photoPath!).existsSync(), isTrue);
      expect(File(back.barcodePhotoPath!).existsSync(), isTrue);
      expect(File(back.photoPath!).readAsBytesSync(), <int>[1, 2, 3, 4]);
      expect(File(back.barcodePhotoPath!).readAsBytesSync(), <int>[5, 6, 7, 8]);
    });

    test('restoring puts the data being replaced somewhere safe first',
        () async {
      await seed();
      final String path = (await backup.export()).unwrap();

      // A different shop's file, restored onto this one by mistake, is the
      // case this exists for.
      await harness.database.db.delete(Tables.inventoryRecords);
      harness.clock.instant = now.add(const Duration(minutes: 5));

      final RestoreReport report = (await backup.restore(path)).unwrap();
      expect(report.safetyCopyPath, isNotEmpty);
      expect(File(report.safetyCopyPath).existsSync(), isTrue);

      // And it really is the state from just before, not a copy of the file
      // that was restored: no lots, because they had been deleted.
      final BackupData safety =
          (await backup.inspect(report.safetyCopyPath)).unwrap();
      expect(safety.rowsIn(Tables.inventoryRecords), 0);
      expect(safety.rowsIn(Tables.products), 1);
    });

    test('restoring twice does not double the shop', () async {
      await seed();
      final String path = (await backup.export()).unwrap();

      await backup.restore(path);
      await backup.restore(path);

      expect(await countOf(Tables.inventoryRecords), 3);
      expect(await countOf(Tables.products), 1);
    });

    test('a file that is not an archive is refused, changing nothing',
        () async {
      await seed();
      final File junk = File('${documents.path}/notes.txt')
        ..writeAsStringSync('this is not a backup');

      final Result<RestoreReport> result = await backup.restore(junk.path);

      expect(result.fold((Failure f) => f.message, (RestoreReport _) => null),
          isNotNull,);
      // The shop is untouched.
      expect(await countOf(Tables.inventoryRecords), 3);
      expect(await countOf(Tables.products), 1);
    });

    test('a zip without our manifest is refused', () async {
      await seed();
      final Archive archive = Archive();
      final List<int> bytes = utf8.encode('hello');
      archive.addFile(ArchiveFile('readme.txt', bytes.length, bytes));
      final File fake = File('${documents.path}/other.zip')
        ..writeAsBytesSync(ZipEncoder().encode(archive));

      final Result<RestoreReport> result = await backup.restore(fake.path);
      expect(
        result.fold((Failure f) => f.message, (RestoreReport _) => null),
        'backup_not_ours',
      );
      expect(await countOf(Tables.products), 1);
    });

    test('the archive names the schema it came from', () async {
      await seed();
      final String path = (await backup.export()).unwrap();
      final BackupData data = (await backup.inspect(path)).unwrap();

      expect(data.schemaVersion, Migrations.latestVersion);
      expect(data.appVersion, '1.3.0+4');
      expect(data.createdAt, now);
      expect(data.rowsIn(Tables.products), 1);
      expect(data.rowsIn(Tables.inventoryRecords), 3);
    });

    test('two exports in the same minute do not replace each other', () async {
      await seed();
      final String first = (await backup.export()).unwrap();
      await harness.database.db.delete(Tables.inventoryRecords);
      final String second = (await backup.export()).unwrap();

      expect(second, isNot(first));
      // The first file still holds the three lots. Before the names were made
      // unique the second export silently overwrote it - and during a restore
      // the safety copy landed on the archive being restored, which destroyed
      // both the old data and the file meant to bring it back.
      expect(
        (await backup.inspect(first)).unwrap().rowsIn(Tables.inventoryRecords),
        3,
      );
      expect(
        (await backup.inspect(second)).unwrap().rowsIn(Tables.inventoryRecords),
        0,
      );
    });

    test('restoring a file taken this very minute still works', () async {
      // The clock does not move between the export and the restore here, which
      // is exactly how a worried shop uses this: back up, then immediately try
      // restoring to check that it works.
      await seed();
      final String path = (await backup.export()).unwrap();
      await harness.database.db.delete(Tables.inventoryRecords);

      final RestoreReport report = (await backup.restore(path)).unwrap();

      expect(report.photosRestored, 2);
      expect(await countOf(Tables.inventoryRecords), 3);
      expect(report.safetyCopyPath, isNot(path));
      expect(File(path).existsSync(), isTrue);
    });

    test('the sync queue is left out of the backup on purpose', () async {
      await seed();
      final String path = (await backup.export()).unwrap();
      final BackupData data = (await backup.inspect(path)).unwrap();

      // It is a queue of work for a backend that does not exist yet; replaying
      // one phone's queue onto another would be wrong rather than useless.
      expect(data.tables.containsKey(Tables.syncOutbox), isFalse);
      expect(await countOf(Tables.syncOutbox), greaterThan(0));
    });
  });

  group('the screen never replaces anything without being told twice', () {
    late TestHarness harness;
    late Directory documents;
    late BackupRepositoryImpl repository;
    late ProviderContainer container;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      documents =
          await Directory.systemTemp.createTemp('expiry_guardian_backup_ui_');
      repository = BackupRepositoryImpl(
        database: harness.database,
        clock: harness.clock,
        logger: harness.logger,
        documentsDirectory: () async => documents,
        appVersion: '1.3.0+4',
      );
      container = ProviderContainer(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
          backupRepositoryProvider.overrideWithValue(repository),
        ],
      );
    });

    tearDown(() async {
      container.dispose();
      await harness.dispose();
      if (documents.existsSync()) documents.deleteSync(recursive: true);
    });

    test('choosing a file reads it but changes nothing yet', () async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8934673605823',
        name: 'Sữa chua Vinamilk',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();

      final String path = (await repository.export()).unwrap();
      await harness.catalog.deleteProduct(product.id);

      final BackupController controller = container.read(backupProvider.notifier);
      await controller.choose(path);

      // Read and described, and the shop is still as it was: the employee has
      // not agreed to anything.
      final BackupState state = container.read(backupProvider);
      expect(state.pending, isNotNull);
      expect(state.pending!.rowsIn(Tables.products), 1);
      expect(state.report, isNull);
      expect(
        (await harness.catalog.findById(product.id)).unwrap()?.isActive ?? false,
        isFalse,
      );

      // Backing out leaves it that way.
      controller.discard();
      expect(container.read(backupProvider).pending, isNull);
    });

    test('confirming is what actually restores', () async {
      await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8934673605823',
        name: 'Sữa chua Vinamilk',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),);
      final String path = (await repository.export()).unwrap();
      await harness.database.db.delete(Tables.products);

      final BackupController controller = container.read(backupProvider.notifier);
      await controller.choose(path);
      final bool done = await controller.confirm();

      expect(done, isTrue);
      final BackupState state = container.read(backupProvider);
      expect(state.report, isNotNull);
      expect(state.pending, isNull);
      final List<Map<String, Object?>> rows =
          await harness.database.db.query(Tables.products);
      expect(rows.single['name'], 'Sữa chua Vinamilk');
    });

    test('a bad file surfaces a reason and holds nothing pending', () async {
      final File junk = File('${documents.path}/notes.txt')
        ..writeAsStringSync('nope');

      await container.read(backupProvider.notifier).choose(junk.path);

      final BackupState state = container.read(backupProvider);
      expect(state.pending, isNull);
      expect(state.failure, isNotNull);
      expect(state.busy, isFalse);
    });

    test('confirming with nothing chosen does nothing at all', () async {
      final bool done = await container.read(backupProvider.notifier).confirm();
      expect(done, isFalse);
      expect(container.read(backupProvider).report, isNull);
    });
  });
}
