import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/disposal_calculator_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// The calculator screen mounted against the real stack, so a screen that
/// would render an empty shell or crash on a phone fails here first.
void main() {
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create(
        now: DateTime(2026, 9, 12, 8),
      ),);
  tearDown(() async => harness.dispose());

  Future<void> settle(WidgetTester tester, {int frames = 10}) async {
    for (int i = 0; i < frames; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 25)),
      );
      await tester.pump();
    }
  }

  Future<void> pump(WidgetTester tester) async {
    // Tall on purpose: a ListView builds lazily, so a result card below the
    // fold would not exist in the tree for the finders to see.
    tester.view.physicalSize = const Size(412, 2000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(
      ProviderScope(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
        ],
        child: MaterialApp(
          locale: const Locale('vi'),
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const <LocalizationsDelegate<Object>>[
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const DisposalCalculatorPage(),
        ),
      ),
    );
    await settle(tester);
  }

  testWidgets('opens with a real answer already on screen, not an empty shell',
      (WidgetTester tester) async {
    await pump(tester);

    // It defaults to a 20 day shelf life ending today, which is the one-day
    // band - so the destroy date is the 11th.
    expect(find.textContaining('11/9/2026'), findsWidgets);
    // And it names the rule it used rather than just printing a date.
    expect(find.textContaining('trên 7 ngày'), findsWidgets);
  });

  testWidgets('switching to the SOP switch moves it into the two hour band',
      (WidgetTester tester) async {
    await pump(tester);

    final Finder sopSwitch = find.byType(SwitchListTile).last;
    await tester.tap(sopSwitch);
    await settle(tester);

    // The hourly rule wins whatever the shelf life, so the deadline is now
    // two hours before the end of the expiry day, on the same date.
    expect(find.textContaining('21:59'), findsWidgets);
  });

  testWidgets('the POS keys add up instead of replacing the number',
      (WidgetTester tester) async {
    await pump(tester);

    // Mode 2 is where the stated shelf life lives.
    await tester.tap(find.textContaining('Nhập 1 mốc'));
    await settle(tester);

    // Read the field itself rather than searching for loose text: "0" and
    // "20" turn up in dates and rule names all over this screen.
    String spanValue() {
      final TextField field = tester.widget<TextField>(find.byType(TextField));
      return field.controller!.text;
    }

    expect(spanValue(), '20');

    await tester.tap(find.text('+5'));
    await settle(tester, frames: 3);
    expect(spanValue(), '25', reason: 'the keys must add, not replace');

    await tester.tap(find.text('+10'));
    await settle(tester, frames: 3);
    expect(spanValue(), '35');

    await tester.tap(find.text('+1'));
    await settle(tester, frames: 3);
    expect(spanValue(), '36');

    final Finder clear = find.widgetWithText(OutlinedButton, 'Xóa');
    await tester.ensureVisible(clear);
    await tester.tap(clear);
    await settle(tester, frames: 3);
    expect(spanValue(), '0');
  });

  testWidgets('the answer recomputes as the stated shelf life changes',
      (WidgetTester tester) async {
    await pump(tester);
    await tester.tap(find.textContaining('Nhập 1 mốc'));
    await settle(tester);

    // 20 days back from today is the one-day band: destroy on the 11th.
    expect(find.textContaining('11/9/2026'), findsWidgets);

    // Push it to 70 days and the band becomes three days: the 9th.
    await tester.tap(find.text('+50'));
    await settle(tester, frames: 4);
    expect(find.textContaining('9/9/2026'), findsWidgets);
    expect(find.textContaining('1 tháng'), findsWidgets);
  });
}
