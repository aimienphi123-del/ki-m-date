import 'package:expiry_guardian/features/scan/domain/services/gs1_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const Gs1Parser parser = Gs1Parser();
  final DateTime reference = DateTime(2026, 9, 6);
  const String gs = Gs1Parser.groupSeparator;

  group('looksLikeGs1', () {
    test('rejects plain retail barcodes', () {
      expect(parser.looksLikeGs1('8934588063053'), isFalse); // EAN-13
      expect(parser.looksLikeGs1('12345670'), isFalse); // EAN-8
      expect(parser.looksLikeGs1('012345678905'), isFalse); // UPC-A
    });

    test('accepts element strings', () {
      expect(parser.looksLikeGs1('0108934588063053172612311012AB'), isTrue);
      expect(parser.looksLikeGs1(']C10108934588063053'), isTrue);
    });
  });

  group('fixed length identifiers', () {
    test('an incomplete date element is ignored', () {
      final Gs1Data data =
          parser.parse('01089345880630531726123', reference: reference);
      expect(data.gtin, '08934588063053');
      expect(data.expirationDate, isNull);
    });

    test('reads a complete GTIN + expiry pair', () {
      final Gs1Data data =
          parser.parse('010893458806305317261231', reference: reference);
      expect(data.gtin, '08934588063053');
      expect(data.expirationDate, DateTime(2026, 12, 31));
    });

    test('day 00 means end of month', () {
      final Gs1Data data = parser.parse('17270200', reference: reference);
      expect(data.expirationDate, DateTime(2027, 2, 28));
    });

    test('production date via AI 11', () {
      final Gs1Data data = parser.parse('11260901', reference: reference);
      expect(data.productionDate, DateTime(2026, 9, 1));
    });
  });

  group('variable length identifiers', () {
    test('batch terminated by the group separator', () {
      final Gs1Data data = parser.parse(
        '010893458806305310LOT-2026-A${gs}17261231',
        reference: reference,
      );
      expect(data.gtin, '08934588063053');
      expect(data.batchOrLot, 'LOT-2026-A');
      expect(data.expirationDate, DateTime(2026, 12, 31));
    });

    test('batch at the end of the payload', () {
      final Gs1Data data =
          parser.parse('0108934588063053172612311012AB34', reference: reference);
      expect(data.batchOrLot, '12AB34');
    });

    test('serial number via AI 21', () {
      final Gs1Data data =
          parser.parse('0108934588063053${gs}21SN0099', reference: reference);
      expect(data.serial, 'SN0099');
    });
  });

  group('AI 7003 expiry with time', () {
    test('parses date and time', () {
      final Gs1Data data = parser.parse('70032609062130', reference: reference);
      expect(data.expirationDateTime, DateTime(2026, 9, 6, 21, 30));
      expect(data.expiryHasTime, isTrue);
      expect(data.effectiveExpiry, DateTime(2026, 9, 6, 21, 30));
    });
  });

  group('symbology prefixes', () {
    test('strips ]C1', () {
      final Gs1Data data =
          parser.parse(']C1010893458806305317261231', reference: reference);
      expect(data.gtin, '08934588063053');
      expect(data.expirationDate, DateTime(2026, 12, 31));
    });

    test('accepts {GS} placeholder separators', () {
      final Gs1Data data = parser.parse(
        '010893458806305310BATCH1{GS}17261231',
        reference: reference,
      );
      expect(data.batchOrLot, 'BATCH1');
      expect(data.expirationDate, DateTime(2026, 12, 31));
    });
  });

  group('two digit year expansion', () {
    test('nearby years stay in the current century', () {
      expect(Gs1Parser.expandYear(26, DateTime(2026)), 2026);
      expect(Gs1Parser.expandYear(30, DateTime(2026)), 2030);
    });

    test('far future rolls back a century', () {
      expect(Gs1Parser.expandYear(99, DateTime(2026)), 1999);
    });

    test('far past rolls forward a century', () {
      expect(Gs1Parser.expandYear(0, DateTime(2075)), 2100);
    });
  });

  group('robustness', () {
    test('unknown identifier does not throw', () {
      final Gs1Data data = parser.parse('9912345678', reference: reference);
      expect(data.rawElements, isNotEmpty);
    });

    test('garbage returns an empty payload rather than throwing', () {
      final Gs1Data data = parser.parse('HELLO WORLD', reference: reference);
      expect(data.gtin, isNull);
      expect(data.effectiveExpiry, isNull);
    });

    test('invalid month is rejected', () {
      final Gs1Data data = parser.parse('17261331', reference: reference);
      expect(data.expirationDate, isNull);
    });
  });
}
