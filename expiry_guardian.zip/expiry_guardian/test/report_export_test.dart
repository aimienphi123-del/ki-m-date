import 'dart:io';
import 'dart:typed_data';

import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/reports/data/export/csv_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/html_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/pdf_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/unconfigured_google_docs_gateway.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_gateway.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/reports/domain/services/report_document_builder.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter/services.dart' show ByteData, rootBundle;
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

void main() {
  final DateTime now = DateTime(2026, 9, 10, 8);
  final AppLocalizations vi = AppLocalizations(const Locale('vi'));
  final AppLocalizations en = AppLocalizations(const Locale('en'));

  final DocumentHeader header = DocumentHeader(
    title: 'Báo cáo huỷ hàng ngày',
    company: 'Công ty TNHH Cửa Hàng Việt',
    store: 'Cửa hàng Nguyễn Trãi',
    storeCode: 'NT-01',
    generatedAt: now,
    generatedBy: 'Chị Lan',
    deviceLabel: 'Máy quầy 1 (abc12345)',
    periodLabel: '10/09/2026',
  );

  ReportDocument sampleDocument() => ReportDocument(
        template: ReportTemplate.dailyDestroy,
        header: header,
        sections: <DocumentSection>[
          const StatSection(
            heading: 'Thống kê',
            items: <StatItem>[
              StatItem(label: 'Số lô huỷ', value: '3'),
              StatItem(label: 'Thiệt hại', value: '120.000 ₫', caption: '2/3 lô có giá'),
            ],
          ),
          const TableSection(
            heading: 'Chi tiết',
            columns: <String>['Sản phẩm', 'Vị trí', 'Số lượng'],
            rows: <List<String>>[
              <String>['Sữa tươi "ít đường"', 'Quầy lạnh · A2', '6'],
              <String>['Bánh mì <ngọt>', 'Kệ khô · B1', '4'],
            ],
            numericColumns: <int>{2},
            totals: <String>['Tổng', '', '10'],
          ),
          const TextSection(
            heading: 'Ghi chú',
            paragraphs: <String>['Huỷ theo chính sách của cửa hàng.'],
          ),
        ],
        signatures: const <SignatureBlock>[
          SignatureBlock(role: 'Người lập', name: 'Chị Lan'),
          SignatureBlock(role: 'Người duyệt'),
        ],
        footerNote: 'Lập tự động bởi Expiry Guardian.',
      );

  group('HtmlDocumentRenderer', () {
    test('renders a complete page with the masthead and the table', () {
      final String html = const HtmlDocumentRenderer().render(sampleDocument());

      expect(html, startsWith('<!DOCTYPE html>'));
      expect(html, contains('<title>Báo cáo huỷ hàng ngày</title>'));
      expect(html, contains('Công ty TNHH Cửa Hàng Việt'));
      expect(html, contains('NT-01'));
      expect(html, contains('Máy quầy 1 (abc12345)'));
      expect(html, contains('<tfoot>'));
      expect(html, contains('Lập tự động bởi Expiry Guardian.'));
      expect(html, endsWith('</html>\n'));
    });

    test('escapes anything a product name might contain', () {
      final String html = const HtmlDocumentRenderer().render(sampleDocument());
      expect(html, contains('Sữa tươi &quot;ít đường&quot;'));
      expect(html, contains('Bánh mì &lt;ngọt&gt;'));
      expect(html, isNot(contains('<ngọt>')));
    });

    test('right-aligns the numeric column', () {
      final String html = const HtmlDocumentRenderer().render(sampleDocument());
      expect(html, contains('<td class="num">6</td>'));
    });

    test('says so when a table is empty instead of leaving a blank', () {
      final ReportDocument empty = ReportDocument(
        template: ReportTemplate.dailyDestroy,
        header: header,
        sections: const <DocumentSection>[
          TableSection(
            heading: 'Chi tiết',
            columns: <String>['A'],
            rows: <List<String>>[],
            emptyMessage: 'Không có dữ liệu trong kỳ này.',
          ),
        ],
      );
      final String html = const HtmlDocumentRenderer().render(empty);
      expect(html, contains('Không có dữ liệu trong kỳ này.'));
      expect(html, isNot(contains('<tbody>')));
    });
  });

  group('CsvDocumentRenderer', () {
    test('flattens the document in reading order', () {
      final String csv = const CsvDocumentRenderer().render(sampleDocument());
      final List<String> lines = csv.trim().split('\n');

      expect(lines.first, contains('Công ty TNHH Cửa Hàng Việt'));
      expect(csv, contains('Sản phẩm,Vị trí,Số lượng'));
      expect(csv, contains('Tổng,,10'));
    });

    test('quotes a field that contains a comma or a quote', () {
      final ReportDocument document = ReportDocument(
        template: ReportTemplate.inventory,
        header: header,
        sections: const <DocumentSection>[
          TableSection(
            heading: 'Chi tiết',
            columns: <String>['Sản phẩm'],
            rows: <List<String>>[
              <String>['Sữa, ít đường'],
              <String>['Bánh "mặn"'],
            ],
          ),
        ],
      );
      final String csv = const CsvDocumentRenderer().render(document);
      expect(csv, contains('"Sữa, ít đường"'));
      expect(csv, contains('"Bánh ""mặn"""'));
    });
  });

  group('bundled report fonts', () {
    testWidgets('load through rootBundle exactly as bootstrap loads them',
        (WidgetTester tester) async {
      // bootstrap.dart reads these two through rootBundle. If the pubspec asset
      // declaration ever drifts, PDF export silently turns itself off on the
      // phone - so the declaration is pinned here rather than assumed.
      final ByteData regular = await rootBundle.load('assets/fonts/Roboto-Regular.ttf');
      final ByteData bold = await rootBundle.load('assets/fonts/Roboto-Bold.ttf');

      expect(regular.lengthInBytes, greaterThan(10000));
      expect(bold.lengthInBytes, greaterThan(10000));

      // A real PDF can be produced from exactly those bytes.
      final PdfDocumentRenderer renderer = PdfDocumentRenderer(
        ReportFonts(
          regular: regular.buffer.asUint8List(),
          bold: bold.buffer.asUint8List(),
        ),
      );
      final Uint8List bytes = await renderer.render(sampleDocument());
      expect(String.fromCharCodes(bytes.take(5)), '%PDF-');
    });
  });

  group('PdfDocumentRenderer', () {
    late PdfDocumentRenderer renderer;

    setUpAll(() {
      renderer = PdfDocumentRenderer(
        ReportFonts(
          regular: File('assets/fonts/Roboto-Regular.ttf').readAsBytesSync(),
          bold: File('assets/fonts/Roboto-Bold.ttf').readAsBytesSync(),
        ),
      );
    });

    test('produces a real PDF file', () async {
      final Uint8List bytes = await renderer.render(sampleDocument());
      expect(bytes.length, greaterThan(1000));
      expect(String.fromCharCodes(bytes.take(5)), '%PDF-');
    });

    test('carries the Vietnamese text through as embedded font glyphs', () async {
      // The built-in PDF fonts have no diacritics; the bundled Roboto faces do.
      // A document that renders at all with these strings proves the subset
      // covers them - a missing glyph throws while building.
      final Uint8List bytes = await renderer.render(sampleDocument());
      expect(bytes, isNotEmpty);
    });

    test('skips a photo it cannot read rather than failing the report', () async {
      final ReportDocument withMissingPhoto = ReportDocument(
        template: ReportTemplate.dailyDestroy,
        header: header,
        sections: const <DocumentSection>[
          ImageSection(
            heading: 'Hình ảnh',
            images: <DocumentImage>[DocumentImage(path: '/nowhere/missing.jpg')],
          ),
        ],
      );
      final Uint8List bytes = await renderer.render(withMissingPhoto);
      expect(String.fromCharCodes(bytes.take(5)), '%PDF-');
    });
  });

  group('UnconfiguredGoogleDocsGateway', () {
    const UnconfiguredGoogleDocsGateway gateway = UnconfiguredGoogleDocsGateway();

    test('reports itself unavailable rather than pretending', () {
      expect(gateway.destination, ExportDestination.googleDocs);
      expect(gateway.isConfigured, isFalse);
      expect(gateway.unavailableReasonKey, 'export.googleNotConfigured');
      expect(vi.has(gateway.unavailableReasonKey!), isTrue);
    });

    test('every call throws with a localizable reason', () async {
      final ReportDocument document = ReportDocument(
        template: ReportTemplate.audit,
        header: header,
        sections: const <DocumentSection>[],
      );
      await expectLater(
        gateway.create(document),
        throwsA(isA<ExportUnavailableException>()),
      );
      await expectLater(
        gateway.update('doc', document),
        throwsA(isA<ExportUnavailableException>()),
      );
      await expectLater(gateway.shareLink('doc'), throwsA(isA<ExportUnavailableException>()));
      await expectLater(
        gateway.exportPdf('doc', document),
        throwsA(isA<ExportUnavailableException>()),
      );
    });
  });

  group('ReportDocumentBuilder', () {
    test('builds all six templates without inventing a single row', () {
      final ReportDocumentBuilder builder = ReportDocumentBuilder(vi);
      final ReportInputs empty = ReportInputs(
        period: ReportPeriod.day(now),
        header: header,
      );

      for (final ReportTemplate template in ReportTemplate.values) {
        final ReportDocument document =
            builder.build(template: template, inputs: empty);
        expect(document.template, template);
        expect(document.header.title, header.title);
        // Nothing was fabricated: every table is empty and says so.
        for (final TableSection table in document.tables) {
          expect(table.rows, isEmpty);
          expect(table.emptyMessage, isNotNull);
        }
      }
    });

    test('is bilingual', () {
      final ReportInputs inputs = ReportInputs(
        period: ReportPeriod.day(now),
        header: header,
      );
      final ReportDocument viDoc = ReportDocumentBuilder(vi)
          .build(template: ReportTemplate.inventory, inputs: inputs);
      final ReportDocument enDoc = ReportDocumentBuilder(en)
          .build(template: ReportTemplate.inventory, inputs: inputs);

      final TableSection viTable = viDoc.tables.first;
      final TableSection enTable = enDoc.tables.first;
      expect(viTable.columns, isNot(enTable.columns));
    });
  });

  group('end to end export', () {
    late TestHarness harness;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      await harness.settings.writeAll(<String, Object?>{
        SettingKeys.companyName: 'Công ty TNHH Cửa Hàng Việt',
        SettingKeys.storeName: 'Cửa hàng Nguyễn Trãi',
        SettingKeys.storeCode: 'NT-01',
      });
    });

    tearDown(() async => harness.dispose());

    Future<InventoryRecord> destroyOneLot() async {
      (await harness.auth.createInitialAdmin(
        username: 'ql',
        displayName: 'Chị Lan',
        password: 'matkhau',
      ))
          .unwrap();

      final Product product = (await harness.catalog.createProduct(
        Product(
          id: '',
          barcode: '8934588063053',
          name: 'Sữa tươi Vinamilk',
          unit: 'hộp',
          unitCost: 12000,
          expiryPrecision: ExpiryPrecision.day,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        ),
      ))
          .unwrap();

      final InventoryRecord record = (await harness.inventory.intake(
        IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 9),
          expiryPrecision: ExpiryPrecision.day,
          manufacturedAt: DateTime(2026, 8, 30),
          quantity: 6,
        ),
      ))
          .unwrap();

      (await harness.workflow
              .confirmDestruction(DestroyConfirmation(recordId: record.id)))
          .unwrap();
      return record;
    }

    test('writes a PDF the store can open and remembers where it went', () async {
      await destroyOneLot();

      final DocumentExport export = (await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.localPdf,
          period: ReportPeriod.day(now),
        ),
      ))
          .unwrap();

      expect(export.status, 'ready');
      expect(export.filePath, endsWith('.pdf'));
      final File file = File(export.filePath!);
      expect(file.existsSync(), isTrue);
      expect(file.lengthSync(), greaterThan(1000));

      final List<DocumentExport> history = (await harness.exports.history()).unwrap();
      expect(history.single.id, export.id);
    });

    test('the CSV carries the real destroyed rows and the company name', () async {
      await destroyOneLot();

      final DocumentExport export = (await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.localCsv,
          period: ReportPeriod.day(now),
        ),
      ))
          .unwrap();

      final String csv = File(export.filePath!).readAsStringSync();
      expect(csv, contains('Công ty TNHH Cửa Hàng Việt'));
      expect(csv, contains('NT-01'));
      expect(csv, contains('Sữa tươi Vinamilk'));
      expect(csv, contains('Chị Lan'));
    });

    test('the HTML export opens as a page and names the employee', () async {
      await destroyOneLot();

      final DocumentExport export = (await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.localHtml,
          period: ReportPeriod.day(now),
        ),
      ))
          .unwrap();

      final String html = File(export.filePath!).readAsStringSync();
      expect(html, startsWith('<!DOCTYPE html>'));
      expect(html, contains('Sữa tươi Vinamilk'));
      expect(html, contains('Chị Lan'));
    });

    test('an empty period produces a report that says so', () async {
      final DocumentExport export = (await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.localHtml,
          // A day on which nothing happened.
          period: ReportPeriod.day(DateTime(2026, 1, 1)),
        ),
      ))
          .unwrap();

      final String html = File(export.filePath!).readAsStringSync();
      expect(html, contains(vi.t('export.noData')));
    });

    test('every export writes an audit row', () async {
      await destroyOneLot();
      await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.audit,
          destination: ExportDestination.localHtml,
          period: ReportPeriod.day(now),
        ),
      );

      final int exported = (await harness.audit.count(
        const AuditQuery(actions: <AuditAction>{AuditAction.reportExported}),
      ))
          .unwrap();
      expect(exported, 1);
    });

    test('regenerating overwrites the same file rather than piling up', () async {
      await destroyOneLot();
      final DocumentExport first = (await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.localHtml,
          period: ReportPeriod.day(now),
        ),
      ))
          .unwrap();

      final DocumentExport again = (await harness.exports.regenerate(first.id)).unwrap();
      expect(again.id, first.id);
      expect(again.filePath, first.filePath);
      expect((await harness.exports.history()).unwrap(), hasLength(1));
    });

    test('the unconfigured Google Docs destination fails honestly', () async {
      expect(
        harness.exports.isDestinationConfigured(ExportDestination.googleDocs),
        isFalse,
      );

      final Result<DocumentExport> result = await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.googleDocs,
          period: ReportPeriod.day(now),
        ),
      );

      expect(result.isErr, isTrue);
      expect(result.failureOrNull!.message, 'export.googleNotConfigured');
      // Nothing was written and nothing was recorded as ready.
      expect((await harness.exports.history()).unwrap(), isEmpty);
    });

    test('an audit report can verify its own chain', () async {
      await destroyOneLot();
      final DocumentExport export = (await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.audit,
          destination: ExportDestination.localHtml,
          period: ReportPeriod.day(now),
        ),
      ))
          .unwrap();

      final String html = File(export.filePath!).readAsStringSync();
      expect(html, contains(vi.t('export.template.audit')));
      // The audit report states the chain verdict rather than just listing rows.
      expect(html, contains(vi.t('audit.immutableNote')));
    });
  });
}
