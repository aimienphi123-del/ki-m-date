import 'dart:typed_data';

import 'package:expiry_guardian/features/scan/data/services/image_barcode_variants.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:expiry_guardian/features/scan/domain/services/barcode_sweep.dart';
import 'package:expiry_guardian/features/scan/domain/services/camera_tuning.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;

/// The reported failure: real barcodes off a shop shelf, photographed by hand,
/// come out turned. These are the five the store actually sent - a Vinamilk
/// yoghurt lid shot upside down, two drinking yoghurts on curved bottles held
/// sideways, and two lids at a slight angle.
const Map<String, String> storeCodes = <String, String>{
  'Vinamilk sữa chua': '8934673605823',
  'Trà sữa hoa anh đào': '8936212182864',
  'TNT Foods': '8936176751106',
  'Betagen': '8850393991926',
  'COBI': '8935299646061',
};

/// A decoder that only reads a code when the file it is given carries the
/// orientation it likes - which is what a real 1D scanner does, and the whole
/// reason the sweep exists.
class OrientationBoundReader implements BarcodeReader {
  OrientationBoundReader({required this.readablePath, required this.value});

  final String readablePath;
  final String value;
  final List<String> seen = <String>[];

  @override
  Future<List<ScannedCode>> readFile(String imagePath) async {
    seen.add(imagePath);
    if (imagePath != readablePath) return const <ScannedCode>[];
    return <ScannedCode>[
      ScannedCode(rawValue: value, format: CodeFormat.ean13),
    ];
  }

  @override
  Future<List<ScannedCode>> readFrame(CameraFrame frame) async =>
      const <ScannedCode>[];

  @override
  Future<void> dispose() async {}
}

class ThrowingReader implements BarcodeReader {
  int calls = 0;

  @override
  Future<List<ScannedCode>> readFile(String imagePath) async {
    calls++;
    throw const FormatException('unreadable');
  }

  @override
  Future<List<ScannedCode>> readFrame(CameraFrame frame) async =>
      const <ScannedCode>[];

  @override
  Future<void> dispose() async {}
}

class FakeVariants implements BarcodeVariants {
  FakeVariants({this.rotationPaths = const <String>[], this.enhancedPaths = const <String>[]});

  final List<String> rotationPaths;
  final List<String> enhancedPaths;
  int rotationCalls = 0;
  int enhancedCalls = 0;

  @override
  Future<List<ScanAttempt>> rotations(String path) async {
    rotationCalls++;
    return <ScanAttempt>[
      for (final String p in rotationPaths) ScanAttempt('rot', p),
    ];
  }

  @override
  Future<List<ScanAttempt>> enhanced(String path) async {
    enhancedCalls++;
    return <ScanAttempt>[
      for (final String p in enhancedPaths) ScanAttempt('boosted', p),
    ];
  }
}

void main() {
  group('the sweep stops as soon as something reads', () {
    test('a code that falls out of the untouched still costs nothing extra',
        () async {
      final FakeVariants variants = FakeVariants();
      final OrientationBoundReader reader = OrientationBoundReader(
        readablePath: '/shot.jpg',
        value: '8934673605823',
      );

      final SweepResult result = await BarcodeSweep(
        reader: reader,
        variants: variants,
      ).read('/shot.jpg');

      expect(result.codes.single.rawValue, '8934673605823');
      expect(result.attempt, 'asStored');
      // The common case must not pay for the stubborn one.
      expect(variants.rotationCalls, 0);
      expect(variants.enhancedCalls, 0);
    });

    test('an upside-down lid is read after the half turn', () async {
      final FakeVariants variants = FakeVariants(
        rotationPaths: <String>['/rot180.jpg', '/rot90.jpg', '/rot270.jpg'],
      );
      final OrientationBoundReader reader = OrientationBoundReader(
        readablePath: '/rot180.jpg',
        value: '8934673605823',
      );

      final SweepResult result = await BarcodeSweep(
        reader: reader,
        variants: variants,
      ).read('/shot.jpg');

      expect(result.codes.single.rawValue, '8934673605823');
      expect(result.attempt, 'rot');
      // Upside down is tried first, so the quarter turns are never rendered.
      expect(reader.seen, <String>['/shot.jpg', '/rot180.jpg']);
      expect(variants.enhancedCalls, 0);
    });

    test('a bottle held sideways needs the quarter turns', () async {
      final FakeVariants variants = FakeVariants(
        rotationPaths: <String>['/rot180.jpg', '/rot90.jpg', '/rot270.jpg'],
      );
      final OrientationBoundReader reader = OrientationBoundReader(
        readablePath: '/rot270.jpg',
        value: '8850393991926',
      );

      final SweepResult result = await BarcodeSweep(
        reader: reader,
        variants: variants,
      ).read('/shot.jpg');

      expect(result.codes.single.rawValue, '8850393991926');
      expect(reader.seen.length, 4);
    });

    test('a faint print falls to the boosted pass', () async {
      final FakeVariants variants = FakeVariants(
        rotationPaths: <String>['/rot180.jpg', '/rot90.jpg', '/rot270.jpg'],
        enhancedPaths: <String>['/boost0.jpg', '/boost180.jpg'],
      );
      final OrientationBoundReader reader = OrientationBoundReader(
        readablePath: '/boost180.jpg',
        value: '8936212182864',
      );

      final SweepResult result = await BarcodeSweep(
        reader: reader,
        variants: variants,
      ).read('/shot.jpg');

      expect(result.codes.single.rawValue, '8936212182864');
      expect(result.attempt, 'boosted');
    });

    test('nothing anywhere reports empty rather than throwing', () async {
      final SweepResult result = await BarcodeSweep(
        reader: OrientationBoundReader(readablePath: '/never', value: 'x'),
        variants: FakeVariants(
          rotationPaths: <String>['/a.jpg'],
          enhancedPaths: <String>['/b.jpg'],
        ),
      ).read('/shot.jpg');

      expect(result.isEmpty, isTrue);
      expect(result.attempt, 'none');
    });

    test('a decoder that throws on one variant still tries the next', () async {
      // Before the sweep, one unreadable file ended the whole attempt. The
      // next orientation is exactly the one that might have worked.
      final ThrowingReader reader = ThrowingReader();
      final SweepResult result = await BarcodeSweep(
        reader: reader,
        variants: FakeVariants(
          rotationPaths: <String>['/a.jpg', '/b.jpg', '/c.jpg'],
          enhancedPaths: <String>['/d.jpg'],
        ),
      ).read('/shot.jpg');

      expect(result.isEmpty, isTrue);
      expect(reader.calls, 5);
    });

    test('an empty path is not worth a single decode', () async {
      final ThrowingReader reader = ThrowingReader();
      final SweepResult result =
          await BarcodeSweep(reader: reader, variants: FakeVariants()).read('');
      expect(result.isEmpty, isTrue);
      expect(reader.calls, 0);
    });
  });

  group('the renderings really differ', () {
    /// A black-on-white barcode-shaped strip: wide enough that a quarter turn
    /// is unmistakable in the output dimensions.
    Uint8List stripe() {
      final img.Image image = img.Image(width: 300, height: 100);
      img.fill(image, color: img.ColorRgb8(255, 255, 255));
      for (int x = 0; x < 300; x += 6) {
        img.fillRect(image, x1: x, y1: 10, x2: x + 2, y2: 90,
            color: img.ColorRgb8(0, 0, 0),);
      }
      return img.encodeJpg(image);
    }

    test('a quarter turn swaps the sides, a half turn does not', () {
      final List<Uint8List> out =
          renderBarcodeVariants(stripe(), <int>[180, 90, 270]);
      expect(out, hasLength(3));

      final img.Image half = img.decodeImage(out[0])!;
      expect(half.width, 300);
      expect(half.height, 100);

      for (final Uint8List quarter in <Uint8List>[out[1], out[2]]) {
        final img.Image turned = img.decodeImage(quarter)!;
        // This is the whole point: ML Kit sweeps scanlines across the buffer
        // it is handed, so the bars have to be presented the other way round.
        expect(turned.width, 100);
        expect(turned.height, 300);
      }
    });

    test('the boosted pass drops colour and pulls the contrast apart', () {
      // A washed-out blue print on cream, like the drinking-yoghurt bottle.
      final img.Image faint = img.Image(width: 120, height: 60);
      img.fill(faint, color: img.ColorRgb8(235, 228, 215));
      for (int x = 0; x < 120; x += 6) {
        img.fillRect(faint, x1: x, y1: 5, x2: x + 2, y2: 55,
            color: img.ColorRgb8(120, 140, 190),);
      }
      final Uint8List source = img.encodeJpg(faint);

      final img.Image plain =
          img.decodeImage(renderBarcodeVariants(source, <int>[0]).single)!;
      final img.Image boosted = img.decodeImage(
        renderBarcodeVariants(source, <int>[0], enhance: true).single,
      )!;

      double spread(img.Image image) {
        int low = 255;
        int high = 0;
        for (int y = 0; y < image.height; y++) {
          for (int x = 0; x < image.width; x++) {
            final img.Pixel p = image.getPixel(x, y);
            final int l = (0.299 * p.r + 0.587 * p.g + 0.114 * p.b).round();
            if (l < low) low = l;
            if (l > high) high = l;
          }
        }
        return (high - low).toDouble();
      }

      expect(spread(boosted), greaterThan(spread(plain)));
    });

    test('an unopenable file yields no variants rather than throwing', () {
      expect(
        renderBarcodeVariants(Uint8List.fromList(<int>[1, 2, 3]), <int>[90]),
        isEmpty,
      );
    });
  });

  group('the real store codes survive the round trip', () {
    // Not a decoder test - that needs ML Kit and a device. This pins the
    // arithmetic the app relies on: every code the store sent is a valid
    // EAN-13, so a failure to scan them is the camera's fault, not the data's.
    int checkDigit(String code) {
      int sum = 0;
      for (int i = 0; i < 12; i++) {
        sum += int.parse(code[i]) * (i.isEven ? 1 : 3);
      }
      return (10 - sum % 10) % 10;
    }

    for (final MapEntry<String, String> entry in storeCodes.entries) {
      test('${entry.key} is a well-formed EAN-13', () {
        expect(entry.value, hasLength(13));
        expect(checkDigit(entry.value), int.parse(entry.value[12]));
      });
    }
  });

  group('the camera zooms in to read print', () {
    test('two times when the hardware allows it', () {
      expect(readingZoomLevel(min: 1, max: 8), 2.0);
    });

    test('a fixed-zoom camera is left where it is', () {
      expect(readingZoomLevel(min: 1, max: 1), 1.0);
    });

    test('a camera that cannot reach two times goes as far as it can', () {
      expect(readingZoomLevel(min: 1, max: 1.5), 1.5);
    });

    test('an ultra-wide whose minimum is already past two stays legal', () {
      // Clamping the other way round would throw, which would take the whole
      // camera screen down on hardware that reports an unusual range.
      expect(readingZoomLevel(min: 3, max: 8), 3.0);
    });

    test('nonsense from the platform does not crash the camera', () {
      expect(readingZoomLevel(min: 1, max: double.nan), 1.0);
      expect(readingZoomLevel(min: 1, max: 0.5), 1.0);
    });
  });
}
