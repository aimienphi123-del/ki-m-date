import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/features/backup/data/repositories/backup_repository_impl.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_scope.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/backup/domain/services/backup_codec.dart';
import 'package:expiry_guardian/features/backup/presentation/viewmodels/backup_view_model.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Stock and rules are two separate halves of the shop. These tests pin the
/// property that was broken: bringing in one must never touch the other, and
/// a file that says nothing about a table must never empty it.
void main() {
  const BackupCodec codec = BackupCodec();
  final DateTime now = DateTime(2026, 9, 14, 18, 30);

  late TestHarness harness;
  late Directory documents;
  late BackupRepositoryImpl backup;

  setUp(() async {
    harness = await TestHarness.create(now: now);
    documents = await Directory.systemTemp.createTemp('expiry_guardian_scope_');
    backup = BackupRepositoryImpl(
      database: harness.database,
      clock: harness.clock,
      logger: harness.logger,
      documentsDirectory: () async => documents,
      appVersion: '1.5.0+6',
    );
  });

  tearDown(() async {
    await harness.dispose();
    if (documents.existsSync()) documents.deleteSync(recursive: true);
  });

  Future<int> countOf(String table) async {
    final List<Map<String, Object?>> rows = await harness.database.db
        .rawQuery('SELECT COUNT(*) AS n FROM $table');
    return rows.single['n']! as int;
  }

  Future<Product> seedStock({String barcode = '8934673605823'}) async {
    final StoreArea area =
        (await harness.locations.createArea(name: 'Quầy lạnh')).unwrap();
    final Shelf shelf = (await harness.locations
            .createShelf(areaId: area.id, name: 'Kệ 1'))
        .unwrap();
    final Product product = (await harness.catalog.createProduct(Product(
      id: '',
      barcode: barcode,
      name: 'Sữa chua Vinamilk',
      unit: 'hộp',
      expiryPrecision: ExpiryPrecision.day,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    ),))
        .unwrap();
    await harness.inventory.intake(IntakeDraft(
      productId: product.id,
      shelfId: shelf.id,
      expiryAt: DateTime(2026, 10, 1),
      expiryPrecision: ExpiryPrecision.day,
      quantity: 6,
    ),);
    return product;
  }

  /// Writes a hand-made archive, the way a spreadsheet conversion would.
  String handmade(
    Map<String, List<Map<String, Object?>>> tables, {
    int formatVersion = 2,
    BackupScope? scope,
    String name = 'handmade.zip',
  }) {
    final String json = codec.encode(BackupData(
      formatVersion: formatVersion,
      schemaVersion: 3,
      appVersion: 'test',
      createdAt: now,
      tables: tables,
      declaredScope: scope,
    ),);
    final List<int> bytes = utf8.encode(json);
    final Archive archive = Archive()
      ..addFile(ArchiveFile('backup.json', bytes.length, bytes));
    final File file = File('${documents.path}/$name')
      ..writeAsBytesSync(ZipEncoder().encode(archive));
    return file.path;
  }

  Failure? failureOf<T>(Result<T> r) => r.fold((Failure f) => f, (T _) => null);

  group('what each export carries', () {
    test('the rules archive holds the rulebook and no stock', () async {
      await seedStock();
      final BackupData data =
          (await backup.inspect((await backup.export(BackupScope.rules)).unwrap()))
              .unwrap();

      expect(data.declaredScope, BackupScope.rules);
      expect(data.carries(BackupScope.rules), isTrue);
      expect(data.carries(BackupScope.data), isFalse);
      expect(data.rowsIn(Tables.policies), greaterThan(0));
      expect(data.rowsIn(Tables.policyRules), greaterThan(0));
      expect(data.rowsIn(Tables.notificationStages), greaterThan(0));
      expect(data.rowsIn(Tables.escalationRules), greaterThan(0));
      expect(data.tables.containsKey(Tables.products), isFalse);
      expect(data.tables.containsKey(Tables.inventoryRecords), isFalse);
    });

    test('the data archive holds stock and no rules', () async {
      await seedStock();
      final BackupData data =
          (await backup.inspect((await backup.export(BackupScope.data)).unwrap()))
              .unwrap();

      expect(data.declaredScope, BackupScope.data);
      expect(data.carries(BackupScope.rules), isFalse);
      expect(data.rowsIn(Tables.products), 1);
      expect(data.rowsIn(Tables.inventoryRecords), 1);
      expect(data.tables.containsKey(Tables.policies), isFalse);
      expect(data.tables.containsKey(Tables.settings), isFalse);
    });

    test('credentials, alarms and this phone\'s identity are never exported',
        () async {
      await harness.settings.write(SettingKeys.deviceId, 'phone-A');
      await harness.settings.write(SettingKeys.notificationPermissionGranted, true);
      await harness.settings.write(SettingKeys.storeName, 'Cửa hàng Mai');

      for (final BackupScope scope in BackupScope.values) {
        final BackupData data =
            (await backup.inspect((await backup.export(scope)).unwrap())).unwrap();
        for (final String table in BackupRules.neverBackedUp) {
          expect(data.tables.containsKey(table), isFalse, reason: '$table in $scope');
        }
      }

      final BackupData rules =
          (await backup.inspect((await backup.export(BackupScope.rules)).unwrap()))
              .unwrap();
      final Set<Object?> keys = <Object?>{
        for (final Map<String, Object?> row in rules.tables[Tables.settings]!)
          row['key'],
      };
      expect(keys, contains(SettingKeys.storeName));
      expect(keys, isNot(contains(SettingKeys.deviceId)));
      expect(keys, isNot(contains(SettingKeys.notificationPermissionGranted)));
    });
  });

  group('the two halves never touch each other', () {
    test('replacing stock leaves the rulebook exactly as it was', () async {
      await seedStock();
      final String stock = (await backup.export(BackupScope.data)).unwrap();
      final int policies = await countOf(Tables.policies);
      final int policyRules = await countOf(Tables.policyRules);
      final int stages = await countOf(Tables.notificationStages);
      final int escalationRules = await countOf(Tables.escalationRules);
      final int settings = await countOf(Tables.settings);

      await backup.restore(stock, BackupScope.data, mode: ImportMode.replace);

      expect(await countOf(Tables.policies), policies);
      expect(await countOf(Tables.policyRules), policyRules);
      expect(await countOf(Tables.notificationStages), stages);
      expect(await countOf(Tables.escalationRules), escalationRules);
      expect(await countOf(Tables.settings), settings);
      expect(await countOf(Tables.products), 1);
    });

    test('loading rules leaves the stock exactly as it was', () async {
      await seedStock();
      final String rules = (await backup.export(BackupScope.rules)).unwrap();
      await harness.database.db.delete(Tables.notificationStages);

      await backup.restore(rules, BackupScope.rules);

      expect(await countOf(Tables.notificationStages), greaterThan(0));
      expect(await countOf(Tables.products), 1);
      expect(await countOf(Tables.inventoryRecords), 1);
      expect(await countOf(Tables.shelves), 1);
    });

    test('a stock file with no rules in it cannot wipe the rules', () async {
      // The original bug: a file converted from a printed report carried
      // products and lots and nothing else, and restoring it emptied the
      // rulebook because "replace" meant "replace everything".
      await seedStock();
      final BackupData full =
          (await backup.inspect((await backup.export(BackupScope.data)).unwrap()))
              .unwrap();
      final String legacy = handmade(
        <String, List<Map<String, Object?>>>{
          Tables.products: full.tables[Tables.products]!,
          Tables.inventoryRecords: full.tables[Tables.inventoryRecords]!,
        },
        formatVersion: 1,
      );
      final int policies = await countOf(Tables.policies);
      final int stages = await countOf(Tables.notificationStages);

      final RestoreReport report = (await backup.restore(
        legacy,
        BackupScope.data,
        mode: ImportMode.replace,
      ))
          .unwrap();

      expect(report.rowsRestored, greaterThan(0));
      expect(await countOf(Tables.policies), policies);
      expect(await countOf(Tables.notificationStages), stages);
      expect(await countOf(Tables.escalationRules), greaterThan(0));
    });

    test('a stock file offered as rules is refused and changes nothing',
        () async {
      await seedStock();
      final String stock = (await backup.export(BackupScope.data)).unwrap();
      final int policies = await countOf(Tables.policies);

      final Failure failure =
          failureOf(await backup.restore(stock, BackupScope.rules))!;

      expect(failure.message, 'backup_wrong_scope');
      expect(failure.context['wanted'], 'rules');
      expect(failure.context['has'], <String>['data']);
      expect(await countOf(Tables.policies), policies);
    });

    test('a rules file offered as stock is refused', () async {
      await seedStock();
      final String rules = (await backup.export(BackupScope.rules)).unwrap();

      final Failure failure =
          failureOf(await backup.restore(rules, BackupScope.data))!;

      expect(failure.message, 'backup_wrong_scope');
      expect(await countOf(Tables.products), 1);
    });

    test('a table the file does not mention is left alone', () async {
      await seedStock();
      final BackupData full =
          (await backup.inspect((await backup.export(BackupScope.data)).unwrap()))
              .unwrap();
      final String partial = handmade(
        <String, List<Map<String, Object?>>>{
          Tables.categories: full.tables[Tables.categories] ??
              <Map<String, Object?>>[],
        },
      );

      await backup.restore(partial, BackupScope.data, mode: ImportMode.replace);

      expect(await countOf(Tables.shelves), 1);
      expect(await countOf(Tables.areas), 1);
      expect(await countOf(Tables.products), 1);
      expect(await countOf(Tables.inventoryRecords), 1);
    });
  });

  group('loading the rulebook', () {
    test('the safety copy is the way back from loading the wrong rules',
        () async {
      // The user's situation: rules were lost, and an earlier backup of them
      // exists. Replace, then go back through the copy the app took.
      await harness.settings.write(SettingKeys.storeName, 'Cửa hàng Mai');
      final String good = (await backup.export(BackupScope.rules)).unwrap();

      await harness.settings.write(SettingKeys.storeName, 'Khác');
      await harness.database.db.delete(Tables.notificationStages);

      final RestoreReport report =
          (await backup.restore(good, BackupScope.rules)).unwrap();
      expect(report.safetyCopyPath, contains('truoc-khi-nap-quy-tac'));
      await harness.settings.load();
      expect(harness.settings.readString(SettingKeys.storeName, ''), 'Cửa hàng Mai');
      expect(await countOf(Tables.notificationStages), greaterThan(0));

      // Going back through the copy restores what was there before.
      await backup.restore(report.safetyCopyPath!, BackupScope.rules);
      await harness.settings.load();
      expect(harness.settings.readString(SettingKeys.storeName, ''), 'Khác');
      expect(await countOf(Tables.notificationStages), 0);
    });

    test('settings from the file do not overwrite this phone\'s identity',
        () async {
      await harness.settings.write(SettingKeys.deviceId, 'phone-A');
      final String file = handmade(
        <String, List<Map<String, Object?>>>{
          Tables.settings: <Map<String, Object?>>[
            <String, Object?>{
              'key': SettingKeys.deviceId,
              'value': 'phone-B',
              'updated_at': now.toIso8601String(),
            },
            <String, Object?>{
              'key': SettingKeys.storeName,
              'value': 'Cửa hàng Mai',
              'updated_at': now.toIso8601String(),
            },
          ],
        },
        scope: BackupScope.rules,
      );

      await backup.restore(file, BackupScope.rules);
      await harness.settings.load();

      expect(harness.settings.readString(SettingKeys.deviceId, ''), 'phone-A');
      expect(harness.settings.readString(SettingKeys.storeName, ''), 'Cửa hàng Mai');
    });

    test('an empty policy table is refused rather than leaving no policy',
        () async {
      final String file = handmade(
        <String, List<Map<String, Object?>>>{
          Tables.policies: <Map<String, Object?>>[],
          Tables.policyRules: <Map<String, Object?>>[],
        },
        scope: BackupScope.rules,
      );
      final int policies = await countOf(Tables.policies);
      final int rules = await countOf(Tables.policyRules);

      final Failure failure = failureOf(await backup.restore(file, BackupScope.rules))!;

      expect(failure.message, 'backup_rules_incomplete');
      expect(await countOf(Tables.policies), policies);
      expect(await countOf(Tables.policyRules), rules);
    });

    test('a rules import always replaces, whatever mode is asked for',
        () async {
      final String rules = (await backup.export(BackupScope.rules)).unwrap();
      final RestoreReport report = (await backup.restore(
        rules,
        BackupScope.rules,
        mode: ImportMode.merge,
      ))
          .unwrap();
      expect(report.mode, ImportMode.replace);
      expect(report.safetyCopyPath, isNotNull);
    });
  });

  group('loading stock', () {
    test('merge adds what is missing and deletes nothing', () async {
      final Product first = await seedStock();
      final String file = (await backup.export(BackupScope.data)).unwrap();
      // Something on the phone that is not in the file.
      final Product other =
          (await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8935318100093',
        name: 'Nước mắm',
        unit: 'chai',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
              .unwrap();

      final RestoreReport report =
          (await backup.restore(file, BackupScope.data)).unwrap();

      expect(report.mode, ImportMode.merge);
      expect(report.safetyCopyPath, isNull, reason: 'nothing was deleted');
      expect(report.rowsRestored, 0, reason: 'everything was already here');
      expect(report.rowsSkipped, greaterThan(0));
      expect((await harness.catalog.findById(first.id)).unwrap(), isNotNull);
      expect((await harness.catalog.findById(other.id)).unwrap(), isNotNull);
    });

    test('merge brings a missing product in without touching the rest',
        () async {
      final Product product = await seedStock();
      final String file = (await backup.export(BackupScope.data)).unwrap();
      await harness.database.db.delete(Tables.inventoryRecords);
      await harness.database.db.delete(Tables.products);

      final RestoreReport report =
          (await backup.restore(file, BackupScope.data)).unwrap();

      expect(report.rowsRestored, greaterThan(0));
      expect((await harness.catalog.findById(product.id)).unwrap()!.name,
          'Sữa chua Vinamilk',);
      expect(await countOf(Tables.inventoryRecords), 1);
    });

    test('rows that name a missing parent are skipped, not loaded broken',
        () async {
      await seedStock();
      final BackupData full =
          (await backup.inspect((await backup.export(BackupScope.data)).unwrap()))
              .unwrap();
      final Map<String, Object?> orphan =
          Map<String, Object?>.of(full.tables[Tables.inventoryRecords]!.single)
            ..['id'] = 'orphan-lot'
            ..['product_id'] = 'no-such-product';
      final String file = handmade(
        <String, List<Map<String, Object?>>>{
          Tables.inventoryRecords: <Map<String, Object?>>[orphan],
        },
      );

      final RestoreReport report =
          (await backup.restore(file, BackupScope.data)).unwrap();

      expect(report.rowsRestored, 0);
      expect(report.rowsSkipped, 1);
      expect(await countOf(Tables.inventoryRecords), 1);
    });

    test('a barcode that is already taken is skipped, not fatal', () async {
      await seedStock();
      final BackupData full =
          (await backup.inspect((await backup.export(BackupScope.data)).unwrap()))
              .unwrap();
      final Map<String, Object?> clash =
          Map<String, Object?>.of(full.tables[Tables.products]!.single)
            ..['id'] = 'different-id';
      final String file = handmade(
        <String, List<Map<String, Object?>>>{
          Tables.products: <Map<String, Object?>>[clash],
        },
      );

      final RestoreReport report =
          (await backup.restore(file, BackupScope.data)).unwrap();

      expect(report.rowsSkipped, 1);
      expect(await countOf(Tables.products), 1);
    });

    test('replace clears the stock closure and saves a copy first', () async {
      await seedStock();
      final String file = (await backup.export(BackupScope.data)).unwrap();
      await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8935318100093',
        name: 'Nước mắm',
        unit: 'chai',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),);
      expect(await countOf(Tables.products), 2);

      final RestoreReport report = (await backup.restore(
        file,
        BackupScope.data,
        mode: ImportMode.replace,
      ))
          .unwrap();

      expect(await countOf(Tables.products), 1);
      expect(report.safetyCopyPath, contains('truoc-khi-nap-du-lieu'));
      final BackupData safety =
          (await backup.inspect(report.safetyCopyPath!)).unwrap();
      expect(safety.rowsIn(Tables.products), 2);
    });

    test('the audit log on the phone is kept, never spliced', () async {
      await seedStock();
      final String file = (await backup.export(BackupScope.data)).unwrap();
      final int audit = await countOf(Tables.auditLog);
      expect(audit, greaterThan(0));

      final RestoreReport report = (await backup.restore(
        file,
        BackupScope.data,
        mode: ImportMode.replace,
      ))
          .unwrap();

      expect(report.auditKept, isTrue);
      expect(await countOf(Tables.auditLog), audit);
    });
  });

  group('the closure of what a replace clears', () {
    test('products take their lots and the lots\' history with them', () {
      final List<String> clear = BackupRules.tablesToClear(
        BackupScope.data,
        <String>{Tables.products},
      );
      expect(
        clear,
        containsAll(<String>[
          Tables.products,
          Tables.productBarcodes,
          Tables.inventoryRecords,
          Tables.recordEvents,
          Tables.destructions,
          Tables.escalations,
        ]),
      );
      expect(clear, isNot(contains(Tables.shelves)));
      expect(clear, isNot(contains(Tables.areas)));
    });

    test('never reaches across into the other scope', () {
      final List<String> clear = BackupRules.tablesToClear(
        BackupScope.rules,
        BackupScope.rules.tables.toSet(),
      );
      for (final String table in clear) {
        expect(BackupScope.rules.tables, contains(table));
      }
    });

    test('children are listed after their parents', () {
      final List<String> tables = BackupScope.data.tables;
      expect(tables.indexOf(Tables.products),
          lessThan(tables.indexOf(Tables.inventoryRecords)),);
      expect(tables.indexOf(Tables.inventoryRecords),
          lessThan(tables.indexOf(Tables.destructions)),);
      expect(tables.indexOf(Tables.areas), lessThan(tables.indexOf(Tables.shelves)));
    });
  });

  group('saved backups', () {
    test('are listed newest first', () async {
      final String older = (await backup.export(BackupScope.data)).unwrap();
      File(older).setLastModifiedSync(DateTime(2026, 9, 1));
      final String newer = (await backup.export(BackupScope.rules)).unwrap();

      final List<SavedBackup> saved = await backup.savedBackups();

      expect(saved.map((SavedBackup s) => s.path), <String>[newer, older]);
    });

    test('is empty before anything has been saved', () async {
      expect(await backup.savedBackups(), isEmpty);
    });
  });

  group('after an import the rest of the app is brought up to date', () {
    late ProviderContainer container;
    final List<BackupScope> refreshed = <BackupScope>[];

    setUp(() {
      refreshed.clear();
      container = ProviderContainer(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
          backupRepositoryProvider.overrideWithValue(backup),
          backupProvider.overrideWith(
            (Ref ref) => BackupController(
              backup,
              afterImport: (BackupScope scope) async => refreshed.add(scope),
            ),
          ),
        ],
      );
    });

    tearDown(() => container.dispose());

    test('the hook runs once, with the scope that was loaded', () async {
      final String file = (await backup.export(BackupScope.rules)).unwrap();
      final BackupController controller = container.read(backupProvider.notifier);

      await controller.choose(file, BackupScope.rules);
      expect(refreshed, isEmpty, reason: 'choosing changes nothing');
      expect(await controller.confirm(), isTrue);

      expect(refreshed, <BackupScope>[BackupScope.rules]);
    });

    test('choosing the wrong kind of file is refused before any dialog',
        () async {
      await seedStock();
      final String stock = (await backup.export(BackupScope.data)).unwrap();
      final BackupController controller = container.read(backupProvider.notifier);

      await controller.choose(stock, BackupScope.rules);

      final BackupState state = container.read(backupProvider);
      expect(state.pending, isNull);
      expect(state.failure!.message, 'backup_wrong_scope');
    });

    test('the dialog is given what the phone holds now', () async {
      await seedStock();
      final String stock = (await backup.export(BackupScope.data)).unwrap();
      final BackupController controller = container.read(backupProvider.notifier);

      await controller.choose(stock, BackupScope.data);

      expect(container.read(backupProvider).pendingLive[Tables.products], 1);
    });

    test('a failing refresh does not turn a good import into an error',
        () async {
      final ProviderContainer failing = ProviderContainer(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
          backupProvider.overrideWith(
            (Ref ref) => BackupController(
              backup,
              afterImport: (BackupScope scope) async => throw StateError('boom'),
            ),
          ),
        ],
      );
      addTearDown(failing.dispose);
      final String file = (await backup.export(BackupScope.rules)).unwrap();
      final BackupController controller = failing.read(backupProvider.notifier);

      await controller.choose(file, BackupScope.rules);

      expect(await controller.confirm(), isTrue);
      expect(failing.read(backupProvider).report, isNotNull);
    });
  });
}
