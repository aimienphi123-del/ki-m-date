import 'package:expiry_guardian/app.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/features/auth/presentation/pages/auth_pages.dart';
import 'package:expiry_guardian/features/inventory/presentation/pages/inventory_page.dart';
import 'package:expiry_guardian/features/tasks/presentation/pages/today_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

void main() {
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create());
  tearDown(() async => harness.dispose());

  /// A phone-shaped surface, so the layout under test is the one an employee
  /// actually sees rather than the 800x600 desktop default.
  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(412, 915);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
  }

  /// Two things rule out `pumpAndSettle` here:
  ///   * the loading state shows a [CircularProgressIndicator], whose
  ///     animation never ends, so settling would time out; and
  ///   * SQLite runs on a background isolate, so its futures only complete
  ///     inside [WidgetTester.runAsync].
  /// Interleaving real waits with frame pumps satisfies both.
  Future<void> settle(WidgetTester tester, {int frames = 10}) async {
    for (int i = 0; i < frames; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump();
    }
  }

  Future<void> pumpApp(WidgetTester tester) async {
    usePhoneViewport(tester);
    await tester.pumpWidget(
      ProviderScope(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
        ],
        child: const ExpiryGuardianApp(),
      ),
    );
    await settle(tester);
  }

  testWidgets('a brand new install asks for the first administrator', (WidgetTester tester) async {
    await pumpApp(tester);

    expect(find.byType(InitialSetupPage), findsOneWidget);
    expect(find.text('Tạo tài khoản quản trị'), findsOneWidget);
    // Nothing is invented: the form starts empty.
    expect(find.text('Expiry Guardian'), findsOneWidget);
  });

  testWidgets('creating the administrator lands on the empty task list',
      (WidgetTester tester) async {
    await pumpApp(tester);

    await tester.enterText(find.byType(TextFormField).at(0), 'Quản lý ca sáng');
    await tester.enterText(find.byType(TextFormField).at(1), 'ca_sang');
    await tester.enterText(find.byType(TextFormField).at(2), 'matkhau');
    await tester.enterText(find.byType(TextFormField).at(3), 'matkhau');
    await tester.ensureVisible(find.text('Tạo tài khoản'));
    await tester.pump();
    await tester.tap(find.text('Tạo tài khoản'));
    await settle(tester);

    expect(find.byType(AppShell), findsOneWidget);
    expect(find.byType(TodayPage), findsOneWidget);
    // An empty store says so instead of showing invented rows.
    expect(find.text('Không có sản phẩm nào cần huỷ hôm nay.'), findsOneWidget);
  });

  testWidgets('the stock tab opens and reports an empty store',
      (WidgetTester tester) async {
    // Repository calls touch SQLite on a background isolate, so they only
    // complete inside runAsync.
    await tester.runAsync(() async {
      await harness.auth.createInitialAdmin(
        username: 'ca_sang',
        displayName: 'Quản lý',
        password: 'matkhau',
      );
      await harness.auth.signIn(username: 'ca_sang', password: 'matkhau');
    });

    await pumpApp(tester);
    expect(find.byType(AppShell), findsOneWidget);

    await tester.tap(find.byIcon(Icons.inventory_2_outlined));
    await settle(tester);

    expect(find.byType(InventoryPage), findsOneWidget);
    expect(find.text('Chưa có lô hàng nào.'), findsOneWidget);
  });
}
