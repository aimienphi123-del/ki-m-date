import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/insights/domain/entities/insight_models.dart';
import 'package:expiry_guardian/features/insights/domain/services/prediction_engine.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';
import 'package:expiry_guardian/features/tasks/domain/entities/daily_plan.dart';
import 'package:expiry_guardian/features/tasks/domain/services/daily_plan_builder.dart';
import 'package:flutter_test/flutter_test.dart';

final DateTime now = DateTime(2026, 9, 6, 8);

StoreArea area(String name, int order) => StoreArea(
      id: 'area-$name',
      name: name,
      sortOrder: order,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    );

Shelf shelf(String name, String areaId, int order) => Shelf(
      id: 'shelf-$name',
      areaId: areaId,
      name: name,
      sortOrder: order,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    );

InventoryItemView item({
  required String productName,
  required PriorityLevel level,
  StoreArea? inArea,
  Shelf? onShelf,
  double quantity = 1,
  double? unitCost,
  Duration untilDestroy = const Duration(hours: 5),
}) {
  return InventoryItemView(
    record: InventoryRecord(
      id: 'rec-$productName-${level.name}',
      code: 'EG-1',
      productId: 'p-$productName',
      expiryAt: now.add(untilDestroy + const Duration(hours: 2)),
      expiryPrecision: ExpiryPrecision.day,
      expiryInstant: now.add(untilDestroy + const Duration(hours: 2)),
      destroyAt: now.add(untilDestroy),
      leadTime: const Duration(hours: 2),
      shelfLife: const Duration(days: 5),
      policyId: 'policy',
      policyVersion: 1,
      quantity: quantity,
      quantityRemaining: quantity,
      unit: 'pcs',
      unitCost: unitCost,
      receivedAt: now,
      status: InventoryStatus.active,
      source: IntakeSource.scan,
      createdAt: now,
      updatedAt: now,
      areaId: inArea?.id,
      shelfId: onShelf?.id,
    ),
    product: Product(
      id: 'p-$productName',
      name: productName,
      unit: 'pcs',
      unitCost: unitCost,
      expiryPrecision: ExpiryPrecision.day,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    ),
    priority: PriorityAssessment(
      level: level,
      timeUntilDestroy: untilDestroy,
      timeUntilExpiry: untilDestroy + const Duration(hours: 2),
    ),
    area: inArea,
    shelf: onShelf,
  );
}

void main() {
  group('DailyPlanBuilder', () {
    const DailyPlanBuilder builder = DailyPlanBuilder();

    test('an empty input produces an empty plan', () {
      final DailyDestroyPlan plan = builder.build(
        items: const <InventoryItemView>[],
        day: DateTime(2026, 9, 6),
        generatedAt: now,
      );
      expect(plan.isEmpty, isTrue);
      expect(plan.estimatedLoss, 0);
    });

    test('sorts by priority first, then by store walking order', () {
      final StoreArea cold = area('Quầy lạnh', 10);
      final StoreArea dry = area('Kho khô', 20);
      final Shelf a1 = shelf('A1', cold.id, 10);
      final Shelf a2 = shelf('A2', cold.id, 20);
      final Shelf b1 = shelf('B1', dry.id, 10);

      final DailyDestroyPlan plan = builder.build(
        items: <InventoryItemView>[
          item(productName: 'Mì', level: PriorityLevel.approaching, inArea: dry, onShelf: b1),
          item(productName: 'Sữa', level: PriorityLevel.destroyNow, inArea: dry, onShelf: b1),
          item(productName: 'Bánh', level: PriorityLevel.destroySoon, inArea: cold, onShelf: a2),
          item(productName: 'Kem', level: PriorityLevel.destroySoon, inArea: cold, onShelf: a1),
        ],
        day: DateTime(2026, 9, 6),
        generatedAt: now,
      );

      expect(
        plan.items.map((InventoryItemView i) => i.product.name).toList(),
        <String>['Sữa', 'Kem', 'Bánh', 'Mì'],
      );
    });

    test('groups by area and shelf in walking order', () {
      final StoreArea cold = area('Quầy lạnh', 10);
      final StoreArea dry = area('Kho khô', 20);

      final DailyDestroyPlan plan = builder.build(
        items: <InventoryItemView>[
          item(
            productName: 'Mì',
            level: PriorityLevel.destroySoon,
            inArea: dry,
            onShelf: shelf('B1', dry.id, 10),
          ),
          item(
            productName: 'Kem',
            level: PriorityLevel.destroySoon,
            inArea: cold,
            onShelf: shelf('A1', cold.id, 10),
          ),
        ],
        day: DateTime(2026, 9, 6),
        generatedAt: now,
      );

      expect(plan.areas.map((AreaTaskGroup a) => a.title).toList(),
          <String>['Quầy lạnh', 'Kho khô'],);
      expect(plan.areas.first.shelves.single.items.single.product.name, 'Kem');
    });

    test('counts each priority bucket', () {
      final DailyDestroyPlan plan = builder.build(
        items: <InventoryItemView>[
          item(productName: 'a', level: PriorityLevel.destroyNow),
          item(productName: 'b', level: PriorityLevel.destroyNow),
          item(productName: 'c', level: PriorityLevel.expired),
          item(productName: 'd', level: PriorityLevel.approaching),
        ],
        day: DateTime(2026, 9, 6),
        generatedAt: now,
      );
      expect(plan.countOf(PriorityLevel.destroyNow), 2);
      expect(plan.countOf(PriorityLevel.expired), 1);
      expect(plan.urgentCount, 3);
    });

    test('sums only the priced items and flags a partial figure', () {
      final DailyDestroyPlan plan = builder.build(
        items: <InventoryItemView>[
          item(productName: 'priced', level: PriorityLevel.destroyNow, quantity: 2, unitCost: 1500),
          item(productName: 'unpriced', level: PriorityLevel.destroyNow, quantity: 3),
        ],
        day: DateTime(2026, 9, 6),
        generatedAt: now,
      );
      expect(plan.estimatedLoss, 3000);
      expect(plan.pricedItemCount, 1);
      expect(plan.lossIsPartial, isTrue);
      expect(plan.totalUnits, 5);
    });

    test('items with no shelf still appear, at the end of their area', () {
      final DailyDestroyPlan plan = builder.build(
        items: <InventoryItemView>[
          item(productName: 'floating', level: PriorityLevel.destroyNow),
        ],
        day: DateTime(2026, 9, 6),
        generatedAt: now,
      );
      expect(plan.areas.single.title, '');
      expect(plan.areas.single.shelves.single.items.single.product.name, 'floating');
    });
  });

  group('PredictionEngine.wilsonLowerBound', () {
    test('is zero with no trials', () {
      expect(PredictionEngine.wilsonLowerBound(0, 0), 0);
    });

    test('a small sample is discounted heavily', () {
      final double small = PredictionEngine.wilsonLowerBound(1, 1);
      final double large = PredictionEngine.wilsonLowerBound(100, 100);
      expect(small, lessThan(large));
      expect(small, lessThan(0.3));
      expect(large, greaterThan(0.9));
    });

    test('never exceeds the observed rate', () {
      for (final (int, int) pair in <(int, int)>[(1, 4), (5, 10), (50, 100), (9, 10)]) {
        final double bound = PredictionEngine.wilsonLowerBound(pair.$1, pair.$2);
        expect(bound, lessThanOrEqualTo(pair.$1 / pair.$2));
        expect(bound, inInclusiveRange(0.0, 1.0));
      }
    });
  });

  group('PredictionEngine.rank', () {
    const PredictionEngine engine = PredictionEngine(
      config: PredictionConfig(minimumTotalSamples: 5, minimumSamplesPerEntry: 4),
    );

    WasteStats stats(String key, {required int intake, required int destroyed, int overdue = 0}) =>
        WasteStats(
          key: key,
          label: key,
          intakeRecords: intake,
          intakeUnits: intake.toDouble(),
          destroyedRecords: destroyed,
          destroyedUnits: destroyed.toDouble(),
          overdueRecords: overdue,
          expiredRecords: 0,
          loss: destroyed * 1000,
        );

    test('says so when the store has too little history', () {
      final RiskRanking ranking = engine.rank(
        <WasteStats>[stats('A', intake: 10, destroyed: 5)],
        totalDestructions: 2,
      );
      expect(ranking.isReady, isFalse);
      expect(ranking.availability, InsightAvailability.insufficientData);
      expect(ranking.sampleSize, 2);
    });

    test('drops entries with too few lots of their own', () {
      final RiskRanking ranking = engine.rank(
        <WasteStats>[
          stats('tiny', intake: 1, destroyed: 1),
          stats('real', intake: 20, destroyed: 4),
        ],
        totalDestructions: 20,
      );
      expect(ranking.entries.map((RiskEntry e) => e.key), <String>['real']);
    });

    test('ranks a consistently wasteful shelf above one unlucky lot', () {
      final RiskRanking ranking = engine.rank(
        <WasteStats>[
          stats('unlucky', intake: 4, destroyed: 3),
          stats('problem', intake: 60, destroyed: 40),
        ],
        totalDestructions: 43,
      );
      expect(ranking.entries.first.key, 'problem');
    });

    test('can rank by overdue destructions instead', () {
      final RiskRanking ranking = engine.rank(
        <WasteStats>[
          stats('forgotten', intake: 30, destroyed: 20, overdue: 18),
          stats('managed', intake: 30, destroyed: 20, overdue: 1),
        ],
        totalDestructions: 40,
        rankByOverdue: true,
      );
      expect(ranking.entries.first.key, 'forgotten');
    });
  });

  group('PredictionEngine.buildRoute', () {
    const PredictionEngine engine = PredictionEngine();

    test('is empty when nothing is due', () {
      final InspectionRoute route = engine.buildRoute(
        dueItems: const <InventoryItemView>[],
        shelfRisk: const RiskRanking.insufficient(
          sampleSize: 0,
          lookbackDays: 180,
          minimumSamples: 8,
        ),
        generatedAt: now,
      );
      expect(route.isEmpty, isTrue);
    });

    test('puts overdue stops first, then follows the walking order', () {
      final StoreArea cold = area('Quầy lạnh', 10);
      final StoreArea dry = area('Kho khô', 20);

      final InspectionRoute route = engine.buildRoute(
        dueItems: <InventoryItemView>[
          item(
            productName: 'a',
            level: PriorityLevel.approaching,
            inArea: cold,
            onShelf: shelf('A1', cold.id, 10),
          ),
          item(
            productName: 'b',
            level: PriorityLevel.destroyNow,
            inArea: dry,
            onShelf: shelf('B1', dry.id, 10),
          ),
        ],
        shelfRisk: const RiskRanking.insufficient(
          sampleSize: 0,
          lookbackDays: 180,
          minimumSamples: 8,
        ),
        generatedAt: now,
      );

      expect(route.stops.first.shelfName, 'B1');
      expect(route.totalItems, 2);
      expect(route.estimatedMinutes, greaterThan(0));
    });
  });

  group('PredictionEngine.forecast', () {
    const PredictionEngine engine =
        PredictionEngine(config: PredictionConfig(minimumTotalSamples: 5, forecastDays: 30));

    DestructionReport history({required int records, required double loss, int days = 30}) {
      return DestructionReport(
        period: ReportPeriod(
          from: now.subtract(Duration(days: days)),
          to: now,
          granularity: ReportGranularity.daily,
        ),
        totalRecords: records,
        totalUnits: records.toDouble(),
        totalLoss: loss,
        overdueRecords: 0,
        expiredOnDestroyRecords: 0,
        pricedRecords: records,
        byCategory: const <WasteSlice>[],
        byShelf: const <WasteSlice>[],
        byProduct: const <WasteSlice>[],
        byReason: const <WasteSlice>[],
        trend: const <TrendPoint>[],
      );
    }

    test('always reports the certain part, even with no history', () {
      final WasteForecast forecast = engine.forecast(
        scheduledItems: <InventoryItemView>[
          item(productName: 'a', level: PriorityLevel.approaching, quantity: 3, unitCost: 2000),
        ],
        history: history(records: 0, loss: 0),
        generatedAt: now,
      );
      expect(forecast.scheduledRecords, 1);
      expect(forecast.scheduledUnits, 3);
      expect(forecast.scheduledLoss, 6000);
      expect(forecast.isReady, isFalse);
      expect(forecast.projectedLoss, 0);
    });

    test('extrapolates the run rate once there is enough history', () {
      final WasteForecast forecast = engine.forecast(
        scheduledItems: const <InventoryItemView>[],
        history: history(records: 30, loss: 300000),
        generatedAt: now,
      );
      expect(forecast.isReady, isTrue);
      // 30 records over 30 days, projected over 30 days.
      expect(forecast.projectedRecords, closeTo(30, 0.001));
      expect(forecast.projectedLoss, closeTo(300000, 0.001));
    });

    test('flags a partial loss figure when some lots have no price', () {
      final WasteForecast forecast = engine.forecast(
        scheduledItems: <InventoryItemView>[
          item(productName: 'priced', level: PriorityLevel.safe, unitCost: 100),
          item(productName: 'unpriced', level: PriorityLevel.safe),
        ],
        history: history(records: 10, loss: 1000),
        generatedAt: now,
      );
      expect(forecast.scheduledLossIsPartial, isTrue);
    });
  });
}
