import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Android registers a bounded number of exact alarms, so a real shop reaches
/// the ceiling. What gets dropped then decides whether the app still does its
/// job: reminding a store about stock that is *about* to go out of date.
void main() {
  final DateTime now = DateTime(2026, 9, 14, 8);

  AppNotification at(DateTime when, {String id = 'x'}) => AppNotification(
        id: when.millisecondsSinceEpoch ~/ 1000,
        kind: NotificationKind.itemDue,
        title: id,
        body: id,
        scheduledFor: when,
      );

  group('spending the alarm budget', () {
    test('nothing is dropped while the plan fits', () {
      final List<AppNotification> kept = NotificationPlanner.fitToBudget(
        <List<AppNotification>>[
          <AppNotification>[at(now.add(const Duration(hours: 3)))],
          <AppNotification>[at(now.add(const Duration(hours: 1)))],
          <AppNotification>[at(now.add(const Duration(hours: 2)))],
        ],
        10,
      );
      expect(kept, hasLength(3));
      // And it comes back in the order the phone will fire it.
      expect(
        kept.map((AppNotification n) => n.scheduledFor),
        <DateTime>[
          now.add(const Duration(hours: 1)),
          now.add(const Duration(hours: 2)),
          now.add(const Duration(hours: 3)),
        ],
      );
    });

    test('a later tier never takes a slot from an earlier one', () {
      // Every repeat is sooner than every first alert, which is exactly the
      // shape that used to break it: sorting by time alone kept all the
      // repeats and none of the alerts.
      final List<AppNotification> repeats = <AppNotification>[
        for (int i = 1; i <= 8; i++) at(now.add(Duration(minutes: i)), id: 'repeat'),
      ];
      final List<AppNotification> alerts = <AppNotification>[
        for (int i = 1; i <= 4; i++) at(now.add(Duration(days: i)), id: 'alert'),
      ];

      final List<AppNotification> kept = NotificationPlanner.fitToBudget(
        <List<AppNotification>>[<AppNotification>[], alerts, repeats],
        5,
      );

      expect(kept.where((AppNotification n) => n.title == 'alert'), hasLength(4));
      expect(kept.where((AppNotification n) => n.title == 'repeat'), hasLength(1));
    });

    test('a tier that cannot fit whole keeps its soonest', () {
      final List<AppNotification> alerts = <AppNotification>[
        at(now.add(const Duration(days: 5)), id: 'late'),
        at(now.add(const Duration(hours: 2)), id: 'soon'),
        at(now.add(const Duration(days: 2)), id: 'mid'),
      ];
      final List<AppNotification> kept = NotificationPlanner.fitToBudget(
        <List<AppNotification>>[alerts],
        2,
      );
      expect(kept.map((AppNotification n) => n.title), <String>['soon', 'mid']);
    });

    test('a budget of nothing schedules nothing rather than throwing', () {
      expect(
        NotificationPlanner.fitToBudget(
          <List<AppNotification>>[
            <AppNotification>[at(now)],
          ],
          0,
        ),
        isEmpty,
      );
    });
  });

  group('a shop at the ceiling', () {
    late TestHarness harness;
    late NotificationPlanner planner;
    late List<NotificationStage> stages;
    late AppLocalizations vi;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      planner = harness.planner;
      stages = (await harness.notificationWorkflow.listStages()).unwrap();
      vi = await AppLocalizations.delegate.load(const Locale('vi'));
    });

    tearDown(() async => harness.dispose());

    Future<void> addLot({required String name, required DateTime expiry}) async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-$name',
        name: name,
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.hour,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: expiry,
        expiryPrecision: ExpiryPrecision.hour,
        manufacturedAt: now.subtract(const Duration(hours: 6)),
        quantity: 1,
      ),);
    }

    test('every lot is still warned about when the budget runs out', () async {
      // Two lots going out of date today, whose chase-ups repeat hourly for a
      // day, and eight more due over the coming week. Under a tight ceiling
      // the hourly repeats for the first two used to consume every slot,
      // because they are all sooner than anything else - so the shop heard
      // about the two lots it already knew about and nothing about the other
      // eight until they too were late.
      await addLot(name: 'Sữa chua', expiry: now.add(const Duration(hours: 2)));
      await addLot(name: 'Trà sữa', expiry: now.add(const Duration(hours: 3)));
      for (int i = 1; i <= 8; i++) {
        await addLot(name: 'Hàng $i', expiry: now.add(Duration(days: i)));
      }

      final List<InventoryItemView> items = (await harness.inventory
              .destroyList(until: now.add(const Duration(days: 30))))
          .unwrap();
      expect(items, hasLength(10));

      final NotificationPlan plan = planner.buildPlan(
        items: items,
        stages: stages,
        preferences: const NotificationPreferences(maxScheduled: 24),
        strings: vi,
        now: now,
      );

      expect(plan.truncated, isTrue);
      expect(plan.notifications.length, lessThanOrEqualTo(24));

      // The assertion that matters: nothing in the shop is left unmentioned.
      final Set<String> spokenFor = plan.notifications
          .map((AppNotification n) => n.recordId)
          .whereType<String>()
          .toSet();
      final Set<String> everyLot =
          items.map((InventoryItemView i) => i.record.id).toSet();
      expect(spokenFor, containsAll(everyLot),
          reason: 'every lot must keep at least one alert under the ceiling',);
    });

    test('the plan is handed over in the order it will fire', () async {
      await addLot(name: 'Sữa chua', expiry: now.add(const Duration(hours: 2)));
      for (int i = 1; i <= 5; i++) {
        await addLot(name: 'Hàng $i', expiry: now.add(Duration(days: i)));
      }

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: now.add(const Duration(days: 30))))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(maxScheduled: 20),
        strings: vi,
        now: now,
      );

      final List<DateTime> times = plan.notifications
          .map((AppNotification n) => n.scheduledFor)
          .toList();
      expect(times, orderedEquals(List<DateTime>.of(times)..sort()));
    });

    test('a generous ceiling still schedules the repeats', () async {
      await addLot(name: 'Sữa chua', expiry: now.add(const Duration(hours: 2)));

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: now.add(const Duration(days: 30))))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(),
        strings: vi,
        now: now,
      );

      // The fix must not quietly become "fewer reminders": with room to spare
      // the configured series is scheduled in full.
      expect(plan.truncated, isFalse);
      expect(plan.stageCount, greaterThan(20));
    });

    test('the counters describe what was kept, not what was wanted', () async {
      for (int i = 1; i <= 6; i++) {
        await addLot(name: 'Hàng $i', expiry: now.add(Duration(hours: i + 1)));
      }

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: now.add(const Duration(days: 30))))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(maxScheduled: 15),
        strings: vi,
        now: now,
      );

      expect(plan.notifications, hasLength(15));
      expect(
        plan.digestCount + plan.stageCount + plan.extraCount,
        plan.notifications.length,
      );
    });
  });
}
