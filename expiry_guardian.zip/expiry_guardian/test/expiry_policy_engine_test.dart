import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';
import 'package:expiry_guardian/features/policy/domain/services/default_policy_factory.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const DefaultExpiryPolicyEngine engine = DefaultExpiryPolicyEngine();
  final FixedClock clock = FixedClock(DateTime(2026, 9, 6, 8));
  final DestroyPolicy policy =
      DefaultPolicyFactory(SequentialIdGenerator('rule'), clock).build(policyId: 'policy-1');

  PolicyDecision decide({
    required DateTime expiry,
    DateTime? manufactured,
    DateTime? received,
    ExpiryPrecision precision = ExpiryPrecision.day,
    DestroyPolicy? withPolicy,
  }) {
    return engine.evaluate(
      withPolicy ?? policy,
      PolicyInput(
        expiry: expiry,
        receivedAt: received ?? DateTime(2026, 9, 6),
        precision: precision,
        manufacturedAt: manufactured,
      ),
    );
  }

  group('expiry instant resolution', () {
    test('a date label is good through the end of the day', () {
      final DateTime instant =
          engine.resolveExpiryInstant(policy, DateTime(2026, 12, 20), ExpiryPrecision.day);
      expect(instant, DateTime(2026, 12, 20, 23, 59, 59, 999));
    });

    test('an hourly label keeps its exact time', () {
      final DateTime instant = engine.resolveExpiryInstant(
        policy,
        DateTime(2026, 9, 6, 21, 30),
        ExpiryPrecision.hour,
      );
      expect(instant, DateTime(2026, 9, 6, 21, 30));
    });

    test('end-of-day can be switched off', () {
      final DestroyPolicy strict = policy.copyWith(dateExpiryAtEndOfDay: false);
      expect(
        engine.resolveExpiryInstant(strict, DateTime(2026, 12, 20), ExpiryPrecision.day),
        DateTime(2026, 12, 20),
      );
    });
  });

  group('default handbook - each band', () {
    test('hourly goods are destroyed two hours early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 6, 21, 30),
        manufactured: DateTime(2026, 9, 6, 6),
        precision: ExpiryPrecision.hour,
      );
      expect(d.leadTime, const Duration(hours: 2));
      expect(d.destroyAt, DateTime(2026, 9, 6, 19, 30));
      expect(d.matchedRule?.nameEn, 'Hourly goods or shelf life <= 7 days'.replaceAll('<=', '≤'));
    });

    test('a five day shelf life is destroyed two hours early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 10),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.leadTime, const Duration(hours: 2));
      expect(d.destroyAt, DateTime(2026, 9, 10, 21, 59, 59, 999));
    });

    test('a two week shelf life is destroyed one day early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 20),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.leadTime, const Duration(days: 1));
      expect(d.destroyAt, DateTime(2026, 9, 19, 23, 59, 59, 999));
    });

    test('a three month shelf life is destroyed three days early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 12, 6),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.leadTime, const Duration(days: 3));
      expect(d.destroyAt, DateTime(2026, 12, 3, 23, 59, 59, 999));
    });

    test('a nine month shelf life is destroyed five days early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2027, 6, 6),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.leadTime, const Duration(days: 5));
    });

    test('a two year shelf life is destroyed seven days early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2028, 9, 6),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.leadTime, const Duration(days: 7));
    });

    test('a four year shelf life is destroyed one month early', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2030, 9, 6),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.leadTime, const Duration(days: 30));
      expect(d.destroyAt, DateTime(2030, 8, 7, 23, 59, 59, 999));
    });
  });

  group('band boundaries', () {
    PolicyRule ruleNamed(String fragment) => policy.rules
        .firstWhere((PolicyRule r) => r.nameEn.toLowerCase().contains(fragment));

    test('exactly seven days belongs to the first band (inclusive max)', () {
      final PolicyRule first = ruleNamed('hourly');
      expect(first.containsShelfLife(const Duration(days: 7)), isTrue);
      expect(first.containsShelfLife(const Duration(days: 7, minutes: 1)), isFalse);
    });

    test('just over seven days belongs to the second band (exclusive min)', () {
      final PolicyRule second = ruleNamed('over 7 days');
      expect(second.containsShelfLife(const Duration(days: 7)), isFalse);
      expect(second.containsShelfLife(const Duration(days: 7, minutes: 1)), isTrue);
      expect(second.containsShelfLife(const Duration(days: 30)), isFalse);
    });

    test('exactly one month belongs to the third band (inclusive min)', () {
      final PolicyRule third = ruleNamed('1 month to under 6 months');
      expect(third.containsShelfLife(const Duration(days: 30)), isTrue);
      expect(third.containsShelfLife(const Duration(days: 180)), isFalse);
    });

    test('exactly three years belongs to the last band', () {
      final PolicyRule last = ruleNamed('3 years or more');
      expect(last.containsShelfLife(const Duration(days: 1095)), isTrue);
      expect(last.containsShelfLife(const Duration(days: 100000)), isTrue);
    });

    test('every band is reachable and the axis has no gap', () {
      for (int days = 0; days <= 1200; days++) {
        final List<PolicyRule> hits = policy.activeRulesInOrder
            .where((PolicyRule r) => r.containsShelfLife(Duration(days: days)))
            .toList();
        expect(hits, hasLength(1), reason: 'shelf life of $days days matched ${hits.length} rules');
      }
    });
  });

  group('shelf life basis', () {
    test('falls back to the intake date when no manufacturing date is known', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 20),
        received: DateTime(2026, 9, 6),
      );
      expect(d.basisUsed, ShelfLifeBasis.intakeToExpiry);
      expect(d.leadTime, const Duration(days: 1));
    });

    test('the fallback can be switched off', () {
      final DestroyPolicy strict = policy.copyWith(fallbackToIntakeBasis: false);
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 20),
        received: DateTime(2026, 9, 6),
        withPolicy: strict,
      );
      expect(d.basisUsed, ShelfLifeBasis.manufacturingToExpiry);
    });

    test('a negative span never produces a negative shelf life', () {
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 1, 1),
        manufactured: DateTime(2026, 9, 6),
      );
      expect(d.shelfLife, Duration.zero);
    });
  });

  group('policy safety rails', () {
    test('destroy is never later than expiry', () {
      final DestroyPolicy weird = policy.copyWith(
        rules: <PolicyRule>[
          PolicyRule(
            id: 'negative',
            policyId: policy.id,
            sortOrder: 1,
            nameVi: 'Am',
            nameEn: 'Negative lead',
            leadTime: const Duration(days: -5),
          ),
        ],
      );
      final PolicyDecision d = decide(expiry: DateTime(2026, 9, 20), withPolicy: weird);
      expect(d.destroyAt, d.expiryInstant);
    });

    test('the fallback lead time is used when nothing matches', () {
      final DestroyPolicy narrow = policy.copyWith(
        rules: <PolicyRule>[
          PolicyRule(
            id: 'only-long',
            policyId: policy.id,
            sortOrder: 1,
            nameVi: 'Dai',
            nameEn: 'Long only',
            minShelfLife: const Duration(days: 3650),
            leadTime: const Duration(days: 1),
          ),
        ],
        fallbackLeadTime: const Duration(hours: 6),
      );
      final PolicyDecision d = decide(expiry: DateTime(2026, 9, 20), withPolicy: narrow);
      expect(d.usedFallbackLeadTime, isTrue);
      expect(d.leadTime, const Duration(hours: 6));
    });

    test('an inactive rule is skipped', () {
      final List<PolicyRule> rules = policy.rules
          .map((PolicyRule r) => r.nameEn.contains('over 7 days') ? r.copyWith(isActive: false) : r)
          .toList();
      final DestroyPolicy edited = policy.copyWith(rules: rules, fallbackLeadTime: Duration.zero);
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 20),
        manufactured: DateTime(2026, 9, 6),
        withPolicy: edited,
      );
      expect(d.usedFallbackLeadTime, isTrue);
    });

    test('the destroy time of day can be normalised', () {
      final DestroyPolicy morning =
          policy.copyWith(normalizeDestroyTimeMinutes: 7 * 60);
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 12, 6),
        manufactured: DateTime(2026, 9, 6),
        withPolicy: morning,
      );
      expect(d.destroyAt, DateTime(2026, 12, 3, 7));
    });

    test('normalising never pushes a destroy instant later', () {
      final DestroyPolicy lateSnap =
          policy.copyWith(normalizeDestroyTimeMinutes: 23 * 60 + 59);
      final PolicyDecision d = decide(
        expiry: DateTime(2026, 9, 10, 6),
        manufactured: DateTime(2026, 9, 8),
        precision: ExpiryPrecision.day,
        withPolicy: lateSnap,
      );
      expect(d.destroyAt.isBefore(d.expiryInstant), isTrue);
    });
  });

  group('priority assessment', () {
    PriorityAssessment assess(DateTime now, DateTime destroyAt, DateTime expiryInstant) =>
        engine.assess(
          policy: policy,
          now: now,
          destroyAt: destroyAt,
          expiryInstant: expiryInstant,
        );

    final DateTime now = DateTime(2026, 9, 6, 8);

    test('green when far away', () {
      final PriorityAssessment a =
          assess(now, DateTime(2026, 9, 20), DateTime(2026, 9, 21));
      expect(a.level, PriorityLevel.safe);
    });

    test('yellow inside the approaching window', () {
      final PriorityAssessment a =
          assess(now, DateTime(2026, 9, 8), DateTime(2026, 9, 9));
      expect(a.level, PriorityLevel.approaching);
    });

    test('orange inside 24 hours', () {
      final PriorityAssessment a =
          assess(now, DateTime(2026, 9, 6, 20), DateTime(2026, 9, 7));
      expect(a.level, PriorityLevel.destroySoon);
    });

    test('red once the destroy instant has passed', () {
      final PriorityAssessment a =
          assess(now, DateTime(2026, 9, 6, 6), DateTime(2026, 9, 7));
      expect(a.level, PriorityLevel.destroyNow);
      expect(a.isOverdue, isTrue);
    });

    test('grey once the goods have expired', () {
      final PriorityAssessment a =
          assess(now, DateTime(2026, 9, 5), DateTime(2026, 9, 5, 23, 59));
      expect(a.level, PriorityLevel.expired);
      expect(a.isExpired, isTrue);
    });

    test('the windows are configurable', () {
      final DestroyPolicy wide = policy.copyWith(
        thresholds: const PriorityThresholds(
          destroySoonWindow: Duration(days: 2),
          approachingWindow: Duration(days: 10),
        ),
      );
      final PriorityAssessment a = engine.assess(
        policy: wide,
        now: now,
        destroyAt: DateTime(2026, 9, 7, 12),
        expiryInstant: DateTime(2026, 9, 8),
      );
      expect(a.level, PriorityLevel.destroySoon);
    });

    test('red sorts before grey, grey before orange', () {
      expect(PriorityLevel.destroyNow.rank, lessThan(PriorityLevel.expired.rank));
      expect(PriorityLevel.expired.rank, lessThan(PriorityLevel.destroySoon.rank));
      expect(PriorityLevel.destroySoon.rank, lessThan(PriorityLevel.approaching.rank));
      expect(PriorityLevel.approaching.rank, lessThan(PriorityLevel.safe.rank));
    });
  });
}
