import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/services/default_policy_factory.dart';
import 'package:expiry_guardian/features/policy/domain/services/shelf_life_calculator.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Regression cover for the third round of reported defects.
///
/// Every test below fails on the code as it stood before the matching fix, so
/// each one pins a real behaviour rather than restating the implementation.
void main() {
  final DateTime now = DateTime(2026, 9, 6, 8);
  final AppLocalizations vi = AppLocalizations(const Locale('vi'));

  group('a closed lot cannot be adjusted back open', () {
    late TestHarness harness;

    setUp(() async => harness = await TestHarness.create(now: now));
    tearDown(() async => harness.dispose());

    Future<InventoryRecord> intakeTen() async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-adjust',
        name: 'Sữa tươi',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      return (await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 20),
        expiryPrecision: ExpiryPrecision.day,
        quantity: 10,
      ),))
          .unwrap();
    }

    test('a destroyed lot is not resurrected, so stock is destroyed once', () async {
      final InventoryRecord record = await intakeTen();
      await harness.inventory.destroy(
        DestroyCommand(recordId: record.id, reason: DestructionReason.policy),
      );

      final Result<InventoryRecord> adjusted = await harness.inventory
          .adjustQuantity(recordId: record.id, newQuantityRemaining: 5);

      expect(adjusted.isErr, isTrue, reason: 'a destroyed lot is closed for good');

      final InventoryRecord after =
          (await harness.inventory.findRecord(record.id)).unwrap()!;
      expect(after.status, InventoryStatus.destroyed);
      expect(after.quantityRemaining, 0);

      // The decisive part: the loss report must not be able to count the same
      // ten units twice.
      final List<Destruction> destructions =
          (await harness.inventory.destructionsFor(record.id)).unwrap();
      expect(destructions.map((Destruction d) => d.quantity), <double>[10]);
    });

    test('an open lot is still adjustable', () async {
      final InventoryRecord record = await intakeTen();
      final Result<InventoryRecord> adjusted = await harness.inventory
          .adjustQuantity(recordId: record.id, newQuantityRemaining: 4);
      expect(adjusted.isOk, isTrue);
      expect(adjusted.unwrap().quantityRemaining, 4);
      expect(adjusted.unwrap().status, InventoryStatus.active);
    });
  });

  group('daily digest', () {
    late TestHarness harness;
    late NotificationPlanner planner;
    late List<NotificationStage> stages;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      planner = harness.planner;
      stages = (await harness.notificationWorkflow.listStages()).unwrap();
    });

    tearDown(() async => harness.dispose());

    Future<void> addLot({required String name, required DateTime expiry}) async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-$name',
        name: name,
        unit: 'cái',
        expiryPrecision: ExpiryPrecision.hour,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: expiry,
        expiryPrecision: ExpiryPrecision.hour,
        manufacturedAt: now.subtract(const Duration(hours: 6)),
        quantity: 1,
      ),);
    }

    NotificationPlan planFrom(List<dynamic> items, {required DateTime at}) {
      return planner.buildPlan(
        items: items.cast(),
        stages: stages,
        preferences: const NotificationPreferences(
          perItemEnabled: false,
          digestHorizonDays: 5,
        ),
        strings: vi,
        now: at,
      );
    }

    test('a morning with nothing due gets no summary at all', () async {
      // Due today and in three days - 07 and 08 September have nothing.
      await addLot(name: 'A', expiry: DateTime(2026, 9, 6, 18));
      await addLot(name: 'B', expiry: DateTime(2026, 9, 9, 18));

      final NotificationPlan plan = planFrom(
        (await harness.inventory.destroyList(until: DateTime(2026, 9, 20))).unwrap(),
        at: DateTime(2026, 9, 6, 5),
      );

      final List<DateTime> digestDays = plan
          .ofKind(NotificationKind.dailyDigest)
          .map((AppNotification n) => DateTime(
                n.scheduledFor.year,
                n.scheduledFor.month,
                n.scheduledFor.day,
              ),)
          .toList();

      expect(digestDays, <DateTime>[DateTime(2026, 9, 6), DateTime(2026, 9, 9)]);
    });

    test('a future summary counts its own day only', () async {
      await addLot(name: 'A', expiry: DateTime(2026, 9, 6, 18));
      await addLot(name: 'B', expiry: DateTime(2026, 9, 9, 18));

      final NotificationPlan plan = planFrom(
        (await harness.inventory.destroyList(until: DateTime(2026, 9, 20))).unwrap(),
        at: DateTime(2026, 9, 6, 5),
      );

      final AppNotification ninth = plan.ofKind(NotificationKind.dailyDigest).last;
      expect(ninth.scheduledFor, DateTime(2026, 9, 9, 7));
      // One lot on the 9th, not two: the lot from the 6th is not "due today".
      expect(ninth.body, contains('1'));
      expect(ninth.body, isNot(contains('2')));
    });

    test("today's summary still carries the overdue backlog", () async {
      // Deadline was yesterday and nobody confirmed it.
      await addLot(name: 'Quá hạn', expiry: now.subtract(const Duration(days: 2)));

      final NotificationPlan plan = planFrom(
        (await harness.inventory.destroyList(until: DateTime(2026, 9, 20))).unwrap(),
        at: DateTime(2026, 9, 6, 5),
      );

      final List<AppNotification> digests = plan.ofKind(NotificationKind.dailyDigest);
      expect(digests, hasLength(1), reason: 'only today, not every morning this week');
      expect(digests.single.scheduledFor, DateTime(2026, 9, 6, 7));
      expect(digests.single.body, contains('1'));
    });
  });

  group('an overdue lot keeps being chased', () {
    late TestHarness harness;
    late NotificationPlanner planner;
    late List<NotificationStage> stages;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      planner = harness.planner;
      stages = (await harness.notificationWorkflow.listStages()).unwrap();
    });

    tearDown(() async => harness.dispose());

    test('a lot whose whole chase-up series has elapsed still gets one alert', () async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-overdue',
        name: 'Bánh mì',
        unit: 'cái',
        expiryPrecision: ExpiryPrecision.hour,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      // Deadline was days ago, so all 24 hourly chase-ups are in the past.
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: now.subtract(const Duration(days: 4)),
        expiryPrecision: ExpiryPrecision.hour,
        quantity: 1,
      ),);

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: now.add(const Duration(days: 30))))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(dailyDigestEnabled: false),
        strings: vi,
        now: now,
      );

      expect(plan.stageCount, 1, reason: 'exactly one live chase-up, not a flood');
      final AppNotification chase = plan.notifications.single;
      expect(chase.kind, NotificationKind.itemOverdue);
      expect(chase.scheduledFor.isAfter(now), isTrue);
      expect(chase.recordId, isNotNull);
    });

    test('a lot still inside its series is untouched by the catch-up', () async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-future',
        name: 'Sữa chua',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.hour,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: now.add(const Duration(days: 5)),
        expiryPrecision: ExpiryPrecision.hour,
        quantity: 1,
      ),);

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: now.add(const Duration(days: 30))))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(dailyDigestEnabled: false),
        strings: vi,
        now: now,
      );

      // Three single stages plus the full 24-step chase-up series, all future.
      expect(plan.stageCount, 27);
    });
  });

  group('plan counters describe what was actually scheduled', () {
    late TestHarness harness;
    late NotificationPlanner planner;
    late List<NotificationStage> stages;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      planner = harness.planner;
      stages = (await harness.notificationWorkflow.listStages()).unwrap();
    });

    tearDown(() async => harness.dispose());

    test('the counters add up to the total after truncation', () async {
      for (int i = 0; i < 12; i++) {
        final Product product = (await harness.catalog.createProduct(Product(
          id: '',
          barcode: 'bc-$i',
          name: 'Lô $i',
          unit: 'cái',
          expiryPrecision: ExpiryPrecision.hour,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        ),))
            .unwrap();
        await harness.inventory.intake(IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 9, 10, 12).add(Duration(hours: i)),
          expiryPrecision: ExpiryPrecision.hour,
          quantity: 1,
        ),);
      }

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory.destroyList(until: DateTime(2026, 9, 20))).unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(maxScheduled: 20),
        strings: vi,
        now: DateTime(2026, 9, 6, 5),
      );

      expect(plan.truncated, isTrue);
      expect(plan.total, 20);
      expect(plan.digestCount + plan.stageCount + plan.extraCount, plan.total);
    });
  });

  group('a fractional shelf life lands on the date it says', () {
    const ShelfLifeCalculator calculator = ShelfLifeCalculator();
    late DestroyPolicy policy;

    setUp(() {
      policy = DefaultPolicyFactory(
        _SequentialIds(),
        FixedClock(DateTime(2026, 9, 12)),
      ).build();
    });

    DateTime expiryFor(double value, ShelfLifeUnit unit, DateTime from) {
      return calculator
          .evaluate(
            policy,
            ShelfLifeQuery.fromOneDateAndSpan(
              anchor: CalculatorAnchor.manufacturing,
              date: from,
              value: value,
              unit: unit,
            ),
          )
          .expiryInstant;
    }

    test('half a month is half a month, not a whole one', () {
      // January has 31 days, so half of it is 15 days and 12 hours; the
      // date-only convention then runs the expiry to the end of the 16th.
      expect(
        expiryFor(0.5, ShelfLifeUnit.month, DateTime(2026, 1, 1)),
        DateTime(2026, 1, 17).subtract(const Duration(milliseconds: 1)),
      );
    });

    test('one and a half months lands mid-February, not on 1 March', () {
      expect(
        expiryFor(1.5, ShelfLifeUnit.month, DateTime(2026, 1, 1)),
        DateTime(2026, 2, 16).subtract(const Duration(milliseconds: 1)),
      );
    });

    test('half a year is six calendar months', () {
      expect(
        expiryFor(0.5, ShelfLifeUnit.year, DateTime(2026, 1, 1)),
        DateTime(2026, 7, 2).subtract(const Duration(milliseconds: 1)),
      );
    });

    test('whole months still take the calendar path, clamped to month end', () {
      expect(
        expiryFor(1, ShelfLifeUnit.month, DateTime(2026, 1, 31)),
        DateTime(2026, 3, 1).subtract(const Duration(milliseconds: 1)),
      );
      expect(
        expiryFor(2, ShelfLifeUnit.year, DateTime(2026, 3, 15)),
        DateTime(2028, 3, 16).subtract(const Duration(milliseconds: 1)),
      );
    });

    test('a fraction works backwards from a printed expiry too', () {
      final ShelfLifeResult result = calculator.evaluate(
        policy,
        ShelfLifeQuery.fromOneDateAndSpan(
          anchor: CalculatorAnchor.expiry,
          date: DateTime(2026, 2, 16),
          value: 1.5,
          unit: ShelfLifeUnit.month,
        ),
      );
      // Half a month back from 16 January is half of *January* (31 days), so
      // the answer is 31 December, not the 1 January that the forward
      // direction started from. Calendar months are not invertible - the whole
      // month step has the same property (31 Jan + 1 month = 28 Feb, and back
      // again is 28 January) - and the screen prints this date-only anyway.
      expect(result.manufacturing, DateTime(2025, 12, 31, 12));
    });

    test('a whole-month span does round-trip exactly', () {
      final ShelfLifeResult back = calculator.evaluate(
        policy,
        ShelfLifeQuery.fromOneDateAndSpan(
          anchor: CalculatorAnchor.expiry,
          date: DateTime(2026, 3, 1),
          value: 2,
          unit: ShelfLifeUnit.month,
        ),
      );
      expect(back.manufacturing, DateTime(2026, 1, 1));
    });
  });
}

class _SequentialIds implements IdGenerator {
  int _next = 0;

  @override
  String newId() => 'id-${_next++}';
}
