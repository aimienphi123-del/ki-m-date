import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/services/escalation_engine.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

void main() {
  late TestHarness harness;
  // "Now" is well past the deadline of the lots created below, so the
  // escalation delay has genuinely elapsed rather than being faked.
  final DateTime now = DateTime(2026, 9, 10, 8);
  final AppLocalizations vi = AppLocalizations(const Locale('vi'));

  setUp(() async {
    harness = await TestHarness.create(now: now);
  });

  tearDown(() async => harness.dispose());

  Future<AppUser> signIn({UserRole role = UserRole.manager}) async {
    final AppUser admin = (await harness.auth.createInitialAdmin(
      username: 'nv1',
      displayName: 'Anh Tùng',
      password: 'matkhau',
    ))
        .unwrap();
    if (role == UserRole.admin) return admin;
    final AppUser user = (await harness.auth.createUser(
      username: role.name,
      displayName: role == UserRole.manager ? 'Chị Lan' : 'Bạn Nam',
      password: 'matkhau',
      role: role,
    ))
        .unwrap();
    (await harness.auth.signIn(username: role.name, password: 'matkhau')).unwrap();
    return user;
  }

  Future<InventoryRecord> addOverdueLot({
    String name = 'Sữa tươi',
    double quantity = 6,
    DateTime? expiry,
  }) async {
    final Product product = (await harness.catalog.createProduct(
      Product(
        id: '',
        barcode: 'bc-$name',
        name: name,
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),
    ))
        .unwrap();
    return (await harness.inventory.intake(
      IntakeDraft(
        productId: product.id,
        // Expired three days ago, so the destroy instant is well behind us.
        expiryAt: expiry ?? DateTime(2026, 9, 7),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 8, 25),
        quantity: quantity,
      ),
    ))
        .unwrap();
  }

  group('EscalationEngine', () {
    final DateTime destroyAt = DateTime(2026, 9, 8, 12);

    EscalationRule rule({
      int order = 1,
      Duration delay = const Duration(hours: 24),
      UserRole notify = UserRole.manager,
      EscalationSeverity severity = EscalationSeverity.critical,
      bool active = true,
      Duration? repeatEvery,
      int? maxRepeats,
    }) =>
        EscalationRule(
          id: 'rule-$order',
          sortOrder: order,
          nameVi: 'Quy tắc $order',
          nameEn: 'Rule $order',
          delayAfterDestroy: delay,
          notifyRole: notify,
          severity: severity,
          repeatEvery: repeatEvery,
          maxRepeats: maxRepeats,
          isActive: active,
          createdAt: destroyAt,
          updatedAt: destroyAt,
        );

    Future<InventoryItemView> view() async {
      await addOverdueLot();
      final List<InventoryItemView> items =
          (await harness.inventory.destroyList(until: now)).unwrap();
      return items.single;
    }

    test('raises nothing before the delay has elapsed', () async {
      final InventoryItemView item = await view();
      final List<EscalationCandidate> candidates = const EscalationEngine().candidates(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[rule(delay: const Duration(days: 30))],
        alreadyRaised: const <String>{},
        now: now,
      );
      expect(candidates, isEmpty);
    });

    test('raises once the delay has elapsed', () async {
      final InventoryItemView item = await view();
      final List<EscalationCandidate> candidates = const EscalationEngine().candidates(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[rule()],
        alreadyRaised: const <String>{},
        now: now,
      );
      expect(candidates, hasLength(1));
      expect(candidates.single.level, 1);
      expect(
        candidates.single.dueAt,
        item.record.destroyAt.add(const Duration(hours: 24)),
      );
    });

    test('never raises the same level twice', () async {
      final InventoryItemView item = await view();
      final List<EscalationCandidate> candidates = const EscalationEngine().candidates(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[rule()],
        alreadyRaised: <String>{EscalationEngine.key(item.record.id, 1)},
        now: now,
      );
      expect(candidates, isEmpty);
    });

    test('ignores a rule a manager switched off', () async {
      final InventoryItemView item = await view();
      final List<EscalationCandidate> candidates = const EscalationEngine().candidates(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[rule(active: false)],
        alreadyRaised: const <String>{},
        now: now,
      );
      expect(candidates, isEmpty);
    });

    test('numbers levels by rule order and sorts the worst first', () async {
      final InventoryItemView item = await view();
      final List<EscalationCandidate> candidates = const EscalationEngine().candidates(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[
          rule(order: 2, delay: const Duration(hours: 36), severity: EscalationSeverity.critical),
          rule(order: 1, delay: const Duration(hours: 12), severity: EscalationSeverity.warning),
        ],
        alreadyRaised: const <String>{},
        now: now,
      );
      expect(candidates.map((EscalationCandidate c) => c.level), <int>[2, 1]);
      expect(candidates.first.rule.severity, EscalationSeverity.critical);
    });

    test('alerts only the phone of somebody who holds the role', () async {
      final InventoryItemView item = await view();
      const EscalationEngine engine = EscalationEngine();

      final List<AppNotification> forEmployee = engine.notifications(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[rule()],
        viewerRole: UserRole.employee,
        strings: vi,
        now: item.record.destroyAt,
      );
      final List<AppNotification> forManager = engine.notifications(
        openOverdueItems: <InventoryItemView>[item],
        rules: <EscalationRule>[rule()],
        viewerRole: UserRole.manager,
        strings: vi,
        now: item.record.destroyAt,
      );

      expect(forEmployee, isEmpty);
      expect(forManager, hasLength(1));
      expect(forManager.single.kind, NotificationKind.escalation);
      expect(forManager.single.severity, NotificationSeverity.critical);
    });

    test('a nobody-signed-in phone gets no manager alerts at all', () async {
      final InventoryItemView item = await view();
      expect(
        const EscalationEngine().notifications(
          openOverdueItems: <InventoryItemView>[item],
          rules: <EscalationRule>[rule()],
          viewerRole: null,
          strings: vi,
          now: item.record.destroyAt,
        ),
        isEmpty,
      );
    });

    test('chase-ups follow the configured interval and cap', () {
      final EscalationRule chased =
          rule(repeatEvery: const Duration(hours: 12), maxRepeats: 3);
      final List<DateTime> times = chased.alertTimesFor(destroyAt);
      // The first alert plus three chase-ups.
      expect(times, hasLength(4));
      expect(times.first, destroyAt.add(const Duration(hours: 24)));
      expect(times.last, destroyAt.add(const Duration(hours: 24 + 36)));
    });
  });

  group('raiseDue', () {
    test('creates one alert per overdue lot and is idempotent', () async {
      await addOverdueLot(name: 'Sữa tươi');
      await addOverdueLot(name: 'Bánh mì');

      final List<Escalation> first = (await harness.escalations.raiseDue()).unwrap();
      expect(first, hasLength(2));

      // Running the scan again must not double up.
      final List<Escalation> second = (await harness.escalations.raiseDue()).unwrap();
      expect(second, isEmpty);
      expect((await harness.escalations.openCount()).unwrap(), 2);
    });

    test('writes an audit row for every alert raised', () async {
      await addOverdueLot();
      await harness.escalations.raiseDue();

      final List<AuditEntry> entries = (await harness.audit.query(
        const AuditQuery(actions: <AuditAction>{AuditAction.escalationRaised}),
      ))
          .unwrap();
      expect(entries, hasLength(1));
      expect(entries.single.entityId, isNotNull);
    });

    test('does nothing when the manager has switched escalation off', () async {
      await harness.settings.write(SettingKeys.escalationEnabled, false);
      await addOverdueLot();

      final WorkflowRefreshResult result =
          (await harness.workflow.refresh()).unwrap();
      expect(result.escalationsRaised, 0);
      expect((await harness.escalations.openCount()).unwrap(), 0);
    });
  });

  group('confirmDestruction', () {
    test('refuses when nobody is signed in', () async {
      final InventoryRecord record = await addOverdueLot();
      final Result<DestroyConfirmationResult> result = await harness.workflow
          .confirmDestruction(DestroyConfirmation(recordId: record.id));

      expect(result.isErr, isTrue);
      expect(result.failureOrNull!.message, 'destroy_needs_signed_in_employee');
    });

    test('refuses without a photo when the store requires one', () async {
      await signIn();
      await harness.settings.write(SettingKeys.requirePhotoOnDestroy, true);
      final InventoryRecord record = await addOverdueLot();

      final Result<DestroyConfirmationResult> result = await harness.workflow
          .confirmDestruction(DestroyConfirmation(recordId: record.id));
      expect(result.isErr, isTrue);
    });

    test('records the employee, the moment and this device', () async {
      final AppUser user = await signIn();
      final InventoryRecord record = await addOverdueLot();

      final DestroyConfirmationResult result = (await harness.workflow
              .confirmDestruction(DestroyConfirmation(recordId: record.id)))
          .unwrap();

      expect(result.destruction.actorId, user.id);
      expect(result.destruction.deviceId, harness.device.current.id);
      expect(result.destruction.confirmedAt, isNotNull);
      expect(result.destruction.isConfirmed, isTrue);
      expect(result.lotFullyClosed, isTrue);
    });

    test('a partial confirmation leaves the lot open and the reminders running',
        () async {
      await signIn();
      final InventoryRecord record = await addOverdueLot(quantity: 10);

      final DestroyConfirmationResult result = (await harness.workflow
              .confirmDestruction(DestroyConfirmation(recordId: record.id, quantity: 4)))
          .unwrap();

      expect(result.lotFullyClosed, isFalse);
      expect(result.remindersCancelled, 0);
      final InventoryRecord? after =
          (await harness.inventory.findRecord(record.id)).unwrap();
      expect(after!.quantityRemaining, 6);
      expect(after.status, InventoryStatus.active);
    });

    test('stops the chase-ups the moment the lot is fully confirmed', () async {
      await signIn();
      // A lot still ahead of its deadline, so there are future reminders to
      // cancel - the OS cannot hold an alarm for a moment that has passed.
      final InventoryRecord record = await addOverdueLot(expiry: DateTime(2026, 9, 15));

      // Build the schedule first, so there is something to cancel.
      await harness.workflow.refresh();
      final int pendingBefore = harness.notifications.scheduled
          .where((AppNotification n) => n.recordId == record.id)
          .length;
      expect(pendingBefore, greaterThan(0));

      final DestroyConfirmationResult result = (await harness.workflow
              .confirmDestruction(DestroyConfirmation(recordId: record.id)))
          .unwrap();

      expect(result.remindersCancelled, greaterThan(0));
      expect(
        harness.notifications.scheduled
            .where((AppNotification n) => n.recordId == record.id),
        isEmpty,
      );
    });

    test('closes any manager escalation the lot had raised', () async {
      await signIn();
      final InventoryRecord record = await addOverdueLot();
      (await harness.escalations.raiseDue()).unwrap();
      expect((await harness.escalations.openCount()).unwrap(), 1);

      final DestroyConfirmationResult result = (await harness.workflow
              .confirmDestruction(DestroyConfirmation(recordId: record.id)))
          .unwrap();

      expect(result.escalationsResolved, 1);
      expect((await harness.escalations.openCount()).unwrap(), 0);
      final List<EscalationView> resolved =
          (await harness.escalations.listResolved()).unwrap();
      expect(resolved.single.escalation.resolution, EscalationResolution.destroyed);
    });

    test('writes one audit row naming the employee, device and quantity', () async {
      final AppUser user = await signIn();
      final InventoryRecord record = await addOverdueLot(quantity: 6);

      await harness.workflow.confirmDestruction(
        DestroyConfirmation(recordId: record.id, note: 'Huỷ theo quy định'),
      );

      final List<AuditEntry> entries = (await harness.audit.query(
        const AuditQuery(actions: <AuditAction>{AuditAction.destroyConfirmed}),
      ))
          .unwrap();
      expect(entries, hasLength(1));
      final AuditEntry entry = entries.single;
      expect(entry.actorId, user.id);
      expect(entry.deviceId, harness.device.current.id);
      expect(entry.newValue!['quantity'], 6.0);
      expect(entry.note, 'Huỷ theo quy định');
    });
  });

  group('manager decisions', () {
    test('acknowledging keeps the alert but marks who took it', () async {
      final AppUser manager = await signIn();
      await addOverdueLot();
      final List<Escalation> raised = (await harness.escalations.raiseDue()).unwrap();

      final Escalation acknowledged = (await harness.workflow
              .acknowledge(escalationId: raised.single.id, note: 'Đang xử lý'))
          .unwrap();

      expect(acknowledged.isOpen, isFalse);
      expect(acknowledged.resolution, EscalationResolution.acknowledged);
      expect(acknowledged.acknowledgedBy, manager.id);
    });

    test('an override needs a signed-in manager and lands in the audit trail',
        () async {
      await addOverdueLot();
      final List<Escalation> raised = (await harness.escalations.raiseDue()).unwrap();

      // Nobody signed in yet.
      final Result<Escalation> refused = await harness.workflow
          .managerOverride(escalationId: raised.single.id, reason: 'Đã huỷ tay');
      expect(refused.isErr, isTrue);

      await signIn();
      final Escalation overridden = (await harness.workflow.managerOverride(
        escalationId: raised.single.id,
        reason: 'Đã huỷ tay, quên bấm xác nhận',
      ))
          .unwrap();

      expect(overridden.resolution, EscalationResolution.override);
      expect(overridden.note, 'Đã huỷ tay, quên bấm xác nhận');

      final List<AuditEntry> entries = (await harness.audit.query(
        const AuditQuery(actions: <AuditAction>{AuditAction.managerOverride}),
      ))
          .unwrap();
      expect(entries, hasLength(1));
    });
  });

  group('refresh', () {
    test('reports what it raised, scheduled and left open', () async {
      await signIn();
      await addOverdueLot(name: 'Sữa tươi');
      await addOverdueLot(name: 'Bánh mì');

      final WorkflowRefreshResult result = (await harness.workflow.refresh()).unwrap();
      expect(result.escalationsRaised, 2);
      expect(result.openEscalations, 2);
      expect(result.notificationsScheduled, greaterThan(0));
    });

    test('is safe to run repeatedly', () async {
      await signIn();
      await addOverdueLot();

      final WorkflowRefreshResult first = (await harness.workflow.refresh()).unwrap();
      final WorkflowRefreshResult second = (await harness.workflow.refresh()).unwrap();

      expect(first.escalationsRaised, 1);
      expect(second.escalationsRaised, 0);
      expect(second.openEscalations, 1);
      expect(second.notificationsScheduled, first.notificationsScheduled);
    });
  });
}
