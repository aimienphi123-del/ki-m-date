import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/audit/audit_repository_impl.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/di/dependencies.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/notifications/notification_workflow_repository.dart';
import 'package:expiry_guardian/core/session/current_user_holder.dart';
import 'package:expiry_guardian/core/storage/session_store.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/sync/remote_sync_gateway.dart';
import 'package:expiry_guardian/core/sync/sync_engine.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/sync/unconfigured_remote_gateway.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/auth/data/datasources/user_local_datasource.dart';
import 'package:expiry_guardian/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:expiry_guardian/features/auth/data/security/password_hasher.dart';
import 'package:expiry_guardian/features/auth/domain/repositories/auth_repository.dart';
import 'package:expiry_guardian/features/catalog/data/repositories/catalog_repository_impl.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/escalation/data/repositories/escalation_repository_impl.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/services/escalation_engine.dart';
import 'package:expiry_guardian/features/insights/data/repositories/insights_repository_impl.dart';
import 'package:expiry_guardian/features/insights/domain/repositories/insights_repository.dart';
import 'package:expiry_guardian/features/insights/domain/services/prediction_engine.dart';
import 'package:expiry_guardian/features/inventory/data/datasources/inventory_local_datasource.dart';
import 'package:expiry_guardian/features/inventory/data/repositories/inventory_repository_impl.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/inventory/domain/services/inventory_code_generator.dart';
import 'package:expiry_guardian/features/locations/data/repositories/location_repository_impl.dart';
import 'package:expiry_guardian/features/locations/domain/repositories/location_repository.dart';
import 'package:expiry_guardian/features/policy/data/datasources/policy_local_datasource.dart';
import 'package:expiry_guardian/features/policy/data/repositories/policy_repository_impl.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/repositories/policy_repository.dart';
import 'package:expiry_guardian/features/policy/domain/services/default_policy_factory.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:expiry_guardian/features/reports/data/datasources/export_local_datasource.dart';
import 'package:expiry_guardian/features/reports/data/export/csv_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/html_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/local_file_export_gateway.dart';
import 'package:expiry_guardian/features/reports/data/export/pdf_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/unconfigured_google_docs_gateway.dart';
import 'package:expiry_guardian/features/reports/data/repositories/analytics_repository_impl.dart';
import 'package:expiry_guardian/features/reports/data/repositories/document_export_repository_impl.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_gateway.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:expiry_guardian/features/scan/domain/services/scan_pipeline.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter/widgets.dart' show Locale;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Logger that keeps everything in memory so a failing test can print it.
class RecordingLogger implements AppLogger {
  final List<String> lines = <String>[];

  @override
  void log(LogLevel level, String tag, String message,
      {Object? error, StackTrace? stackTrace,}) {
    lines.add('[${level.name}] $tag: $message${error == null ? '' : ' <- $error'}');
  }
}

/// Notification gateway that records what would have been scheduled.
class FakeNotificationGateway implements NotificationGateway {
  final List<AppNotification> scheduled = <AppNotification>[];
  final List<AppNotification> shown = <AppNotification>[];
  bool cancelledAll = false;

  /// Whether this pretend phone allows notifications, and how many times the
  /// app asked - so a test can prove the employee is asked once rather than
  /// on every launch.
  bool permissionGranted = true;
  bool exactAlarmsAllowed = true;
  int permissionRequests = 0;
  int exactAlarmRequests = 0;
  int initialisations = 0;

  @override
  Future<bool> canScheduleExactAlarms() async => exactAlarmsAllowed;

  @override
  Future<void> cancel(int id) async => scheduled.removeWhere((AppNotification n) => n.id == id);

  @override
  Future<void> cancelAll() async {
    cancelledAll = true;
    scheduled.clear();
  }

  @override
  Future<bool> hasPermission() async => permissionGranted;

  @override
  Future<void> initialize() async => initialisations++;

  @override
  Future<List<int>> pendingIds() async =>
      scheduled.map((AppNotification n) => n.id).toList(growable: false);

  @override
  Future<bool> requestExactAlarmPermission() async {
    exactAlarmRequests++;
    return exactAlarmsAllowed;
  }

  @override
  Future<bool> requestPermission() async {
    permissionRequests++;
    return permissionGranted;
  }

  @override
  Future<void> schedule(AppNotification notification) async => scheduled.add(notification);

  @override
  Stream<String?> get selections => const Stream<String?>.empty();

  @override
  Future<void> showNow(AppNotification notification) async => shown.add(notification);
}

/// Barcode reader that returns whatever the test told it to.
class FakeBarcodeReader implements BarcodeReader {
  List<ScannedCode> nextResult = const <ScannedCode>[];
  final List<String> readPaths = <String>[];
  final List<CameraFrame> readFrames = <CameraFrame>[];

  @override
  Future<void> dispose() async {}

  @override
  Future<List<ScannedCode>> readFile(String imagePath) async {
    readPaths.add(imagePath);
    return nextResult;
  }

  @override
  Future<List<ScannedCode>> readFrame(CameraFrame frame) async {
    readFrames.add(frame);
    return nextResult;
  }
}

/// Text reader that returns whatever the test told it to.
class FakeTextReader implements TextReader {
  List<String> nextLines = const <String>[];
  final List<CameraFrame> readFrames = <CameraFrame>[];

  @override
  Future<void> dispose() async {}

  @override
  Future<List<RecognisedLine>> readFile(String imagePath) async =>
      nextLines.map((String text) => RecognisedLine(text: text)).toList();

  @override
  Future<List<RecognisedLine>> readFrame(CameraFrame frame) async {
    readFrames.add(frame);
    return nextLines.map((String text) => RecognisedLine(text: text)).toList();
  }
}

/// A fully wired, in-memory application stack: real SQLite, real repositories,
/// real policy engine. Only the clock, the ids and the platform gateways are
/// substituted.
class TestHarness {
  TestHarness._({
    required this.database,
    required this.clock,
    required this.ids,
    required this.logger,
    required this.syncQueue,
    required this.settings,
    required this.policies,
    required this.locations,
    required this.catalog,
    required this.inventory,
    required this.analytics,
    required this.insights,
    required this.auth,
    required this.currentUser,
    required this.device,
    required this.audit,
    required this.notificationWorkflow,
    required this.planner,
    required this.escalations,
    required this.workflow,
    required this.exports,
    required this.exportDirectory,
    required this.policy,
    required this.notifications,
    required this.barcodeReader,
    required this.textReader,
  });

  final AppDatabase database;
  final FixedClock clock;
  final IdGenerator ids;
  final RecordingLogger logger;
  final SyncQueue syncQueue;
  final SettingsStore settings;

  final PolicyRepository policies;
  final LocationRepository locations;
  final CatalogRepository catalog;
  final InventoryRepository inventory;
  final AnalyticsRepository analytics;
  final InsightsRepository insights;
  final AuthRepository auth;

  /// Phase X collaborators, wired exactly as `buildDependencies` wires them.
  final CurrentUserHolder currentUser;
  final DeviceIdentityProvider device;
  final AuditRepository audit;
  final NotificationWorkflowRepository notificationWorkflow;
  final NotificationPlanner planner;
  final EscalationRepository escalations;
  final OperationWorkflowService workflow;
  final DocumentExportRepository exports;

  /// Where the local export gateways write their files.
  final Directory exportDirectory;

  final FakeNotificationGateway notifications;
  final FakeBarcodeReader barcodeReader;
  final FakeTextReader textReader;

  /// The seeded default handbook.
  DestroyPolicy policy;

  /// The same object graph `buildDependencies` produces at runtime, with the
  /// platform edges replaced. Lets a widget test drive the real application.
  Dependencies asDependencies() {
    const RemoteSyncGateway remote = UnconfiguredRemoteGateway();
    return Dependencies(
      logger: logger,
      clock: clock,
      ids: ids,
      database: database,
      settings: settings,
      session: InMemorySessionStore(),
      currentUser: currentUser,
      syncQueue: syncQueue,
      remoteGateway: remote,
      syncEngine: SyncEngine(
        queue: syncQueue,
        gateway: remote,
        connectivity: Connectivity(),
        clock: clock,
        logger: logger,
      ),
      notificationGateway: notifications,
      notificationPlanner: planner,
      notificationWorkflowRepository: notificationWorkflow,
      deviceIdentity: device,
      auditRepository: audit,
      policyEngine: engine,
      authRepository: auth,
      policyRepository: policies,
      locationRepository: locations,
      catalogRepository: catalog,
      inventoryRepository: inventory,
      analyticsRepository: analytics,
      insightsRepository: insights,
      escalationRepository: escalations,
      documentExportRepository: exports,
      workflowService: workflow,
      barcodeReader: barcodeReader,
      textReader: textReader,
      scanPipeline: ScanPipeline(
        barcodeReader: barcodeReader,
        textReader: textReader,
        catalog: catalog,
        clock: clock,
        logger: logger,
      ),
      appVersion: '1.0.0',
      appBuild: '1',
    );
  }

  static const ExpiryPolicyEngine engine = DefaultExpiryPolicyEngine();

  static Future<TestHarness> create({DateTime? now}) async {
    sqfliteFfiInit();
    await AppLocalizations.ensureDateFormattingReady();

    final FixedClock clock = FixedClock(now ?? DateTime(2026, 9, 6, 8));
    final RecordingLogger logger = RecordingLogger();
    final IdGenerator ids = SequentialIdGenerator('t');

    final AppDatabase database = AppDatabase(
      factory: databaseFactoryFfi,
      databasePath: inMemoryDatabasePath,
      logger: logger,
    );
    await database.open();

    final SettingsStore settings = SettingsStore(database, clock);
    await settings.load();

    final SyncQueue syncQueue = SqfliteSyncQueue(database, clock);

    final PolicyLocalDataSource policyLocal = SqflitePolicyDataSource(database);
    final PolicyRepository policies = PolicyRepositoryImpl(
      local: policyLocal,
      database: database,
      clock: clock,
      syncQueue: syncQueue,
      logger: logger,
    );

    final DestroyPolicy seeded = DefaultPolicyFactory(ids, clock).build();
    await policyLocal.insertPolicy(seeded);
    await policyLocal.setActive(seeded.id);

    final CatalogRepository catalog = CatalogRepositoryImpl(
      database: database,
      clock: clock,
      ids: ids,
      syncQueue: syncQueue,
      logger: logger,
    );

    final LocationRepository locations = LocationRepositoryImpl(
      database: database,
      clock: clock,
      ids: ids,
      syncQueue: syncQueue,
      logger: logger,
    );

    final InventoryRepository inventory = InventoryRepositoryImpl(
      database: database,
      local: SqfliteInventoryDataSource(database),
      catalog: catalog,
      policies: policies,
      engine: engine,
      codes: const DatedSequenceCodeGenerator(),
      clock: clock,
      ids: ids,
      syncQueue: syncQueue,
      logger: logger,
    );

    final AnalyticsRepository analytics =
        AnalyticsRepositoryImpl(database: database, logger: logger);

    final InsightsRepository insights = InsightsRepositoryImpl(
      analytics: analytics,
      inventory: inventory,
      engine: const PredictionEngine(
        config: PredictionConfig(minimumTotalSamples: 3, minimumSamplesPerEntry: 2),
      ),
      clock: clock,
    );

    final CurrentUserHolder currentUser = CurrentUserHolder();

    final AuthRepository auth = AuthRepositoryImpl(
      local: SqfliteUserDataSource(database),
      // Low iteration count keeps the suite fast; production uses 120k.
      hasher: Pbkdf2PasswordHasher(defaultIterations: 1000),
      session: InMemorySessionStore(),
      currentUser: currentUser,
      clock: clock,
      ids: ids,
      syncQueue: syncQueue,
      logger: logger,
    );

    final DeviceIdentityProvider device = StaticDeviceIdentityProvider();

    final AuditRepository audit = AuditRepositoryImpl(
      database: database,
      clock: clock,
      ids: ids,
      device: device,
      actor: () => AuditActor(
        id: currentUser.id,
        name: currentUser.displayName,
        role: currentUser.user?.role.name,
      ),
      logger: logger,
    );

    final NotificationWorkflowRepository notificationWorkflow =
        NotificationWorkflowRepositoryImpl(
      database: database,
      clock: clock,
      newId: ids.newId,
      syncQueue: syncQueue,
      audit: audit,
      logger: logger,
    );
    for (final NotificationStage stage
        in DefaultNotificationStages.build(newId: ids.newId, now: clock.now())) {
      await notificationWorkflow.upsert(stage);
    }

    final FakeNotificationGateway notifications = FakeNotificationGateway();

    final NotificationPlanner planner = NotificationPlanner(
      inventory: inventory,
      workflow: notificationWorkflow,
      gateway: notifications,
      database: database,
      clock: clock,
      logger: logger,
    );

    const EscalationEngine escalationEngine = EscalationEngine();
    final EscalationRepository escalations = EscalationRepositoryImpl(
      database: database,
      inventory: inventory,
      engine: escalationEngine,
      clock: clock,
      ids: ids,
      syncQueue: syncQueue,
      audit: audit,
      logger: logger,
      currentUserId: () => currentUser.id,
    );
    for (final EscalationRule rule
        in DefaultEscalationRules.build(newId: ids.newId, now: clock.now())) {
      await escalations.upsertRule(rule);
    }

    AppLocalizations resolveStrings() => AppLocalizations(
          Locale(settings.readString(SettingKeys.locale, SettingDefaults.locale)),
        );

    final OperationWorkflowService workflow = OperationWorkflowService(
      inventory: inventory,
      escalations: escalations,
      escalationEngine: escalationEngine,
      planner: planner,
      audit: audit,
      device: device,
      settings: settings,
      clock: clock,
      logger: logger,
      currentUser: () => currentUser.user,
      strings: resolveStrings,
      preferences: () => NotificationPreferences.fromSettings(settings),
    );

    // Real files, in a throwaway folder that `dispose` deletes.
    final Directory exportDirectory =
        await Directory.systemTemp.createTemp('expiry_guardian_reports_');
    final PdfDocumentRenderer pdfRenderer = PdfDocumentRenderer(
      ReportFonts(
        regular: File('assets/fonts/Roboto-Regular.ttf').readAsBytesSync(),
        bold: File('assets/fonts/Roboto-Bold.ttf').readAsBytesSync(),
      ),
    );
    Future<Directory> exportDir() async => exportDirectory;

    final DocumentExportRepository exports = DocumentExportRepositoryImpl(
      dataSource: SqfliteExportDataSource(database),
      analytics: analytics,
      inventory: inventory,
      audit: audit,
      database: database,
      settings: settings,
      clock: clock,
      ids: ids,
      device: device,
      actor: () => AuditActor(
        id: currentUser.id,
        name: currentUser.displayName,
        role: currentUser.user?.role.name,
      ),
      strings: resolveStrings,
      gateways: <ExportDestination, DocumentExportGateway>{
        ExportDestination.localPdf: LocalFileExportGateway(
          destination: ExportDestination.localPdf,
          directory: exportDir,
          clock: clock,
          pdfRenderer: pdfRenderer,
        ),
        ExportDestination.localHtml: LocalFileExportGateway(
          destination: ExportDestination.localHtml,
          directory: exportDir,
          clock: clock,
          html: const HtmlDocumentRenderer(),
        ),
        ExportDestination.localCsv: LocalFileExportGateway(
          destination: ExportDestination.localCsv,
          directory: exportDir,
          clock: clock,
          csv: const CsvDocumentRenderer(),
        ),
        ExportDestination.googleDocs: const UnconfiguredGoogleDocsGateway(),
      },
      logger: logger,
    );

    return TestHarness._(
      database: database,
      clock: clock,
      ids: ids,
      logger: logger,
      syncQueue: syncQueue,
      settings: settings,
      policies: policies,
      locations: locations,
      catalog: catalog,
      inventory: inventory,
      analytics: analytics,
      insights: insights,
      auth: auth,
      currentUser: currentUser,
      device: device,
      audit: audit,
      notificationWorkflow: notificationWorkflow,
      planner: planner,
      escalations: escalations,
      workflow: workflow,
      exports: exports,
      exportDirectory: exportDirectory,
      policy: seeded,
      notifications: notifications,
      barcodeReader: FakeBarcodeReader(),
      textReader: FakeTextReader(),
    );
  }

  Future<void> dispose() async {
    // Confirming a destruction now rebuilds the reminder schedule off the
    // caller's tap, so a rebuild can still be in flight here. Let it finish
    // before the database goes away, otherwise teardown races it.
    await workflow.settleRefresh();
    await database.close();
    if (exportDirectory.existsSync()) {
      exportDirectory.deleteSync(recursive: true);
    }
  }
}
