import 'dart:io';

import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/services/scan_pipeline.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/barcode_scanner_page.dart';
import 'package:flutter/widgets.dart' show Locale;
import 'package:flutter_test/flutter_test.dart';
import 'package:mobile_scanner/mobile_scanner.dart' as ms;

import 'support/test_harness.dart';

/// Round four: reminders that never reached Android in a release build, the
/// barcode scanner rebuilt on mobile_scanner, and the new name and icon.
void main() {
  final DateTime now = DateTime(2026, 9, 6, 8);

  group('one refused reminder does not silence the rest', () {
    late TestHarness harness;

    setUp(() async => harness = await TestHarness.create(now: now));
    tearDown(() async => harness.dispose());

    Future<void> addLot(String name, DateTime expiry) async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-$name',
        name: name,
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.hour,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: expiry,
        expiryPrecision: ExpiryPrecision.hour,
        quantity: 1,
      ),);
    }

    test('the loop carries on past a failure and the table stays honest',
        () async {
      await addLot('Trà sữa', DateTime(2026, 9, 7, 18));
      await addLot('Bánh mì', DateTime(2026, 9, 8, 20));
      final FakeNotificationGateway gateway = harness.notifications;
      int calls = 0;
      // The first reminder is refused, as every one was in a release build
      // whose Gson had lost its type information.
      gateway.refuse = (AppNotification n) => calls++ == 0;

      final NotificationPlan plan = (await harness.planner.reschedule(
        preferences: const NotificationPreferences(),
        strings: AppLocalizations(const Locale('vi')),
      ))
          .unwrap();

      expect(plan.total, greaterThan(1));
      expect(gateway.scheduled, hasLength(plan.total - 1));
      final List<Map<String, Object?>> rows =
          await harness.database.db.query(Tables.scheduledNotifications);
      // The table lists only what Android actually accepted.
      expect(rows, hasLength(plan.total - 1));
      expect(
        harness.logger.lines.any((String l) => l.contains('refused 1 of')),
        isTrue,
      );
    });
  });

  group('the release build keeps what notifications need', () {
    String read(String path) => File(path).readAsStringSync();

    test('R8 keeps the Gson type information the plugin reads back', () {
      final String rules = read('android/app/proguard-rules.pro');
      expect(rules, contains('-keepattributes Signature'));
      expect(rules, contains('com.google.gson.reflect.TypeToken'));
      expect(rules, contains('-keep class com.dexterous.flutterlocalnotifications.** { *; }'));
    });

    test('the status-bar icon exists at every density and survives shrinking',
        () {
      for (final String density in <String>['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
        expect(
          File('android/app/src/main/res/drawable-$density/ic_stat_kiem_date.png').existsSync(),
          isTrue,
          reason: density,
        );
      }
      expect(read('android/app/src/main/res/raw/keep.xml'), contains('@drawable/ic_stat_kiem_date'));
    });

    test('notifications use that icon, never the adaptive launcher icon', () {
      final String gateway = read('lib/core/notifications/local_notification_gateway.dart');
      expect(gateway, contains("'@drawable/ic_stat_kiem_date'"));
      expect(gateway, isNot(contains("'@mipmap/ic_launcher'")));
    });

    test('the launcher icon is adaptive with a matching background', () {
      expect(read('android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml'),
          contains('@mipmap/ic_launcher_foreground'),);
      expect(read('android/app/src/main/res/values/ic_launcher_background.xml'),
          contains('#1E293B'),);
    });
  });

  group('the app is called Kiểm date', () {
    test('everywhere a person reads it', () {
      expect(AppLocalizations(const Locale('vi')).t(K.appName), 'Kiểm date');
      expect(AppLocalizations(const Locale('en')).t(K.appName), 'Kiểm date');
      expect(File('android/app/src/main/AndroidManifest.xml').readAsStringSync(),
          contains('android:label="Kiểm date"'),);
    });

    test('and CI does not put the old name back', () {
      // patch_android.py rewrites the label on every build.
      final String patch = File('tool/patch_android.py').readAsStringSync();
      expect(patch, contains('android:label="Kiểm date"'));
      expect(patch, isNot(contains('android:label="Expiry Guardian"')));
    });

    test('the package id is unchanged, so installing over the old app keeps its data',
        () {
      expect(File('android/app/build.gradle.kts').readAsStringSync(),
          contains('applicationId = "com.expiryguardian.expiry_guardian"'),);
    });
  });

  group('mobile_scanner results become the app\'s own codes', () {
    test('an EAN-13 keeps its value, format and box', () {
      final ScannedCode? code = scannedCodeFrom(const ms.Barcode(
        rawValue: '8935318100093',
        displayValue: '8935318100093',
        format: ms.BarcodeFormat.ean13,
        corners: <Offset>[Offset(10, 20), Offset(110, 22), Offset(108, 60), Offset(12, 58)],
      ),);
      expect(code!.rawValue, '8935318100093');
      expect(code.format, CodeFormat.ean13);
      expect(code.boundingBox!.left, 10);
      expect(code.boundingBox!.top, 20);
      expect(code.boundingBox!.right, 110);
      expect(code.boundingBox!.bottom, 60);
    });

    test('an empty read is no code at all', () {
      expect(scannedCodeFrom(const ms.Barcode(rawValue: '')), isNull);
      expect(scannedCodeFrom(const ms.Barcode()), isNull);
    });

    test('the scanner looks only for the formats a shop meets', () {
      expect(retailFormats, contains(ms.BarcodeFormat.ean13));
      expect(retailFormats, contains(ms.BarcodeFormat.code128));
      expect(retailFormats, isNot(contains(ms.BarcodeFormat.all)));
    });
  });

  group('a photo taken instead of a scan is still read', () {
    late TestHarness harness;
    late Directory dir;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      dir = await Directory.systemTemp.createTemp('round4_');
    });
    tearDown(() async {
      await harness.dispose();
      dir.deleteSync(recursive: true);
    });

    ScanPipeline pipeline() => ScanPipeline(
          barcodeReader: harness.barcodeReader,
          textReader: harness.textReader,
          catalog: harness.catalog,
          clock: harness.clock,
          logger: harness.logger,
        );

    test('the code in the still comes back', () async {
      final File still = File('${dir.path}/still.jpg')..writeAsBytesSync(<int>[1, 2, 3]);
      harness.barcodeReader.nextResult = const <ScannedCode>[
        ScannedCode(rawValue: '8934673605823', format: CodeFormat.ean13),
      ];

      final List<ScannedCode> codes = await pipeline().readBarcodes(still.path);

      expect(codes.single.rawValue, '8934673605823');
    });

    test('no photo, or a photo that is gone, is simply nothing read', () async {
      expect(await pipeline().readBarcodes(''), isEmpty);
      expect(await pipeline().readBarcodes('${dir.path}/missing.jpg'), isEmpty);
    });
  });
}
