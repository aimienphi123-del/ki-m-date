import 'dart:io';
import 'dart:typed_data';

import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scan_outcome.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Regressions for the four faults reported from the shop floor after the
/// first release, plus the optional product photo asked for at the same time.
///
/// Each test names the symptom the employee saw, so a change that brings the
/// symptom back fails here instead of on a phone in a shop.
void main() {
  final DateTime now = DateTime(2026, 9, 12, 8);
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create(now: now));
  tearDown(() async => harness.dispose());

  Future<void> signIn() async {
    (await harness.auth.createInitialAdmin(
      username: 'ql',
      displayName: 'Chi Lan',
      password: 'matkhau',
    ))
        .unwrap();
  }

  Future<InventoryRecord> addLot({
    String name = 'Sua tuoi',
    String? photoPath,
    DateTime? expiry,
  }) async {
    final Product product = (await harness.catalog.createProduct(
      Product(
        id: '',
        barcode: 'bc-$name',
        name: name,
        unit: 'hop',
        unitCost: 12000,
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),
    ))
        .unwrap();
    return (await harness.inventory.intake(
      IntakeDraft(
        productId: product.id,
        // Already past its deadline, so there is something to destroy.
        expiryAt: expiry ?? DateTime(2026, 9, 9),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 8, 30),
        quantity: 6,
        photoPath: photoPath,
      ),
    ))
        .unwrap();
  }

  // ---------------------------------------------------------------- bug 1
  group('reported: the barcode is never read', () {
    test('a code decoded from a live frame is trusted over the still',
        () async {
      // The still is deliberately useless, which proves the pipeline uses the
      // stream's result instead of quietly re-reading the photograph. On a
      // phone the photograph is the thing that kept failing.
      final File capture = File('${harness.exportDirectory.path}/frame.jpg')
        ..createSync(recursive: true)
        ..writeAsBytesSync(Uint8List.fromList(<int>[0xFF, 0xD8, 0xFF, 0xD9]));
      harness.barcodeReader.nextResult = const <ScannedCode>[];

      final Result<ScanOutcome> outcome =
          await harness.asDependencies().scanPipeline.process(
                capture.path,
                alreadyRead: const <ScannedCode>[
                  ScannedCode(
                    rawValue: '8934588063053',
                    format: CodeFormat.ean13,
                  ),
                ],
              );

      expect(outcome.isOk, isTrue);
      expect(outcome.unwrap().primaryBarcode, '8934588063053');
      expect(
        harness.barcodeReader.readPaths,
        isEmpty,
        reason: 'the still must not be re-read once the stream has a code',
      );
    });

    test('the reader takes live frames, not only files', () async {
      harness.barcodeReader.nextResult = const <ScannedCode>[
        ScannedCode(rawValue: '123', format: CodeFormat.ean13),
      ];
      final List<ScannedCode> codes = await harness.barcodeReader.readFrame(
        CameraFrame(
          bytes: Uint8List(12),
          width: 4,
          height: 3,
          rotationDegrees: 90,
          bytesPerRow: 4,
          format: CameraFrameFormat.nv21,
        ),
      );
      expect(codes.single.rawValue, '123');
      // Rotation has to survive the trip: a sideways buffer decodes as nothing.
      expect(harness.barcodeReader.readFrames.single.rotationDegrees, 90);
    });
  });

  // ---------------------------------------------------------------- bug 2
  group('reported: confirming a destruction hangs', () {
    test('confirming returns without waiting for the schedule rebuild',
        () async {
      await signIn();
      final InventoryRecord record = await addLot();

      final Result<DestroyConfirmationResult> result = await harness.workflow
          .confirmDestruction(DestroyConfirmation(recordId: record.id));

      expect(result.isOk, isTrue, reason: '${result.failureOrNull?.message}');
      // The reminders for this lot must be gone immediately - that part cannot
      // be deferred, or an alarm fires for stock already destroyed.
      expect(
        harness.notifications.scheduled
            .where((AppNotification n) => n.recordId == record.id),
        isEmpty,
      );
      // And the deferred rebuild really does happen afterwards.
      await harness.workflow.settleRefresh();
    });

    test('overlapping rebuild requests collapse into one', () async {
      await signIn();
      await addLot();
      harness.workflow
        ..requestRefresh()
        ..requestRefresh()
        ..requestRefresh();
      // A queue that grew per call would never drain; reaching the assertion
      // at all is the point.
      await harness.workflow.settleRefresh();
      expect(harness.notifications.cancelledAll, isTrue);
    });

    test('the alarm ceiling is configurable and stays inside what Android allows',
        () async {
      expect(
        const NotificationPreferences().maxScheduled,
        SettingDefaults.maxScheduledNotifications,
      );

      await harness.settings.write(SettingKeys.maxScheduledNotifications, 9000);
      expect(
        NotificationPreferences.fromSettings(harness.settings).maxScheduled,
        450,
        reason: 'Android holds only about 500 exact alarms per app',
      );

      await harness.settings.write(SettingKeys.maxScheduledNotifications, 60);
      expect(
        NotificationPreferences.fromSettings(harness.settings).maxScheduled,
        60,
      );
    });
  });

  // ---------------------------------------------------------------- bug 3
  group('reported: a new shelf cannot be created', () {
    test('an area and then a shelf both save and come back', () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quay mat')).unwrap();
      final Shelf shelf =
          (await harness.locations.createShelf(areaId: area.id, name: 'Ke A1'))
              .unwrap();

      final List<ShelfLocation> all =
          (await harness.locations.listShelfLocations()).unwrap();
      expect(all.single.area.id, area.id);
      expect(all.single.shelf.id, shelf.id);
    });

    test('an empty name is refused with a reason, not dropped in silence',
        () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quay mat')).unwrap();
      final Result<Shelf> result =
          await harness.locations.createShelf(areaId: area.id, name: '   ');

      // The screen now shows this reason; before, the failure was discarded
      // and the employee saw a button that appeared to do nothing.
      expect(result.isErr, isTrue);
      expect(result.failureOrNull!.message, 'name_required');
    });

    test('each new shelf lands after the previous one in the walking route',
        () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quay mat')).unwrap();
      final Shelf first =
          (await harness.locations.createShelf(areaId: area.id, name: 'A'))
              .unwrap();
      final Shelf second =
          (await harness.locations.createShelf(areaId: area.id, name: 'B'))
              .unwrap();
      expect(second.sortOrder, greaterThan(first.sortOrder));
    });
  });

  // ---------------------------------------------------------------- bug 4
  group('reported: no report file comes out', () {
    test('the export folder is a real absolute path, not an un-expanded one',
        () {
      // The fault was Directory('\\\$documentsPath/...') - an escaped dollar,
      // so every export wrote to a relative folder literally named
      // "\$documentsPath", which Android refuses to create.
      final String path = harness.exportDirectory.path;
      expect(path.contains(r'$'), isFalse);
      expect(Directory(path).isAbsolute, isTrue);
    });

    test('exporting writes a file that exists and has content', () async {
      await signIn();
      final InventoryRecord record = await addLot();
      (await harness.workflow
              .confirmDestruction(DestroyConfirmation(recordId: record.id)))
          .unwrap();

      final Result<DocumentExport> result = await harness.exports.generate(
        ExportRequest(
          template: ReportTemplate.dailyDestroy,
          destination: ExportDestination.localHtml,
          period: ReportPeriod.day(now),
        ),
      );

      expect(result.isOk, isTrue, reason: '${result.failureOrNull?.message}');
      final DocumentExport export = result.unwrap();
      expect(export.status, 'ready');
      expect(export.filePath, isNotNull);

      final File written = File(export.filePath!);
      expect(written.existsSync(), isTrue);
      expect(written.lengthSync(), greaterThan(0));
      expect(written.path, startsWith(harness.exportDirectory.path));
    });
  });

  // ------------------------------------------------------------- new feature
  group('requested: an optional photo of the product front', () {
    test('a lot keeps the photo it was given', () async {
      await signIn();
      final InventoryRecord record = await addLot(photoPath: '/tmp/front.jpg');
      final InventoryRecord? stored =
          (await harness.inventory.findRecord(record.id)).unwrap();
      expect(stored!.photoPath, '/tmp/front.jpg');
    });

    test('and saves perfectly well without one, because it is optional',
        () async {
      await signIn();
      final InventoryRecord record = await addLot(name: 'Banh mi');
      final InventoryRecord? stored =
          (await harness.inventory.findRecord(record.id)).unwrap();
      expect(stored!.photoPath, isNull);
    });
  });
}
