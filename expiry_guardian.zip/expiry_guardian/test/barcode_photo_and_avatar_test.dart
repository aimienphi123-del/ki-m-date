import 'dart:io';

import 'package:expiry_guardian/core/database/migrations.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/presentation/widgets/inventory_item_tile.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/scan/presentation/viewmodels/scan_flow_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// A barcode no scanner can read is still legible to a person, so the still has
/// to survive the scan and end up on the product.
void main() {
  final DateTime now = DateTime(2026, 9, 13, 9);

  group('the barcode still survives a scan that decodes nothing', () {
    late TestHarness harness;
    late ProviderContainer container;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      container = ProviderContainer(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
        ],
      );
    });

    tearDown(() async {
      container.dispose();
      await harness.dispose();
    });

    test('a capture that reads no code still keeps its photo', () async {
      final Directory dir =
          await Directory.systemTemp.createTemp('expiry_guardian_scan_');
      addTearDown(() => dir.deleteSync(recursive: true));
      final File capture = File('${dir.path}/barcode.jpg')
        ..writeAsBytesSync(<int>[0, 1, 2, 3]);

      await container
          .read(scanFlowProvider.notifier)
          .processBarcodeCapture(capture.path);

      final ScanFlowState state = container.read(scanFlowProvider);
      // Nothing decoded - which is the case this whole path exists for.
      expect(state.hasBarcode, isFalse);
      // ...but the picture is still there to read the number off.
      expect(state.barcodePhotoPath, capture.path);
    });

    test('typing the number in by hand does not discard the photo', () async {
      final Directory dir =
          await Directory.systemTemp.createTemp('expiry_guardian_scan_');
      addTearDown(() => dir.deleteSync(recursive: true));
      final File capture = File('${dir.path}/barcode2.jpg')
        ..writeAsBytesSync(<int>[0, 1, 2, 3]);

      final ScanFlowController flow = container.read(scanFlowProvider.notifier);
      await flow.processBarcodeCapture(capture.path);
      flow.setBarcodeManually('8934673001234');

      final ScanFlowState state = container.read(scanFlowProvider);
      expect(state.barcode, '8934673001234');
      expect(state.barcodePhotoPath, capture.path);
    });
  });

  group('a product carries both pictures', () {
    late TestHarness harness;

    setUp(() async => harness = await TestHarness.create(now: now));
    tearDown(() async => harness.dispose());

    test('the avatar and the barcode photo round-trip through the database',
        () async {
      final Product created = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8934673001234',
        name: 'Sữa tươi',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        photoPath: '/photos/front.jpg',
        barcodePhotoPath: '/photos/code.jpg',
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();

      final Product? reread =
          (await harness.catalog.findById(created.id)).unwrap();
      expect(reread!.photoPath, '/photos/front.jpg');
      expect(reread.barcodePhotoPath, '/photos/code.jpg');
    });

    test('either picture can be cleared again', () async {
      final Product created = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: '8934673009999',
        name: 'Bánh mì',
        unit: 'cái',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        photoPath: '/photos/front.jpg',
        barcodePhotoPath: '/photos/code.jpg',
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();

      await harness.catalog.updateProduct(
        created.copyWith(clearPhoto: true, clearBarcodePhoto: true),
      );

      final Product? reread =
          (await harness.catalog.findById(created.id)).unwrap();
      expect(reread!.photoPath, isNull);
      expect(reread.barcodePhotoPath, isNull);
    });
  });

  test('the schema carries the barcode photo column', () {
    expect(Migrations.latestVersion, 3);
    final bool declared = Migrations.all
        .expand((Migration m) => m.statements)
        .any((String sql) => sql.contains('barcode_photo_path'));
    expect(declared, isTrue);
  });

  group('the stock list shows what identifies a lot', () {
    // The tile reads the currency symbol from the app's dependencies, so the
    // real ones are supplied - but the row itself is built in memory.
    late TestHarness harness;

    setUp(() async => harness = await TestHarness.create(now: now));
    tearDown(() async => harness.dispose());

    // Built in memory on purpose: these assertions are about the row, not the
    // database, and a widget test that also drives real async storage spends
    // its time waiting rather than checking.
    InventoryItemView lot({
      String? photoPath,
      String? barcode = '8934673001234',
    }) {
      final Product product = Product(
        id: 'p1',
        barcode: barcode,
        name: 'Sữa chua nếp cẩm',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        photoPath: photoPath,
        createdAt: now,
        updatedAt: now,
      );
      final DateTime destroyAt = DateTime(2026, 9, 20);
      return InventoryItemView(
        record: InventoryRecord(
          id: 'r1',
          code: 'A-001',
          productId: product.id,
          expiryAt: destroyAt,
          expiryPrecision: ExpiryPrecision.day,
          expiryInstant: destroyAt,
          destroyAt: destroyAt,
          leadTime: const Duration(days: 1),
          shelfLife: const Duration(days: 30),
          policyId: 'policy',
          policyVersion: 1,
          quantity: 4,
          quantityRemaining: 4,
          unit: 'hộp',
          receivedAt: now,
          status: InventoryStatus.active,
          source: IntakeSource.scan,
          createdAt: now,
          updatedAt: now,
        ),
        product: product,
        priority: const PriorityAssessment(
          level: PriorityLevel.safe,
          timeUntilDestroy: Duration(days: 7),
          timeUntilExpiry: Duration(days: 7),
        ),
      );
    }

    Future<void> pumpTile(WidgetTester tester, InventoryItemView item) async {
      tester.view.physicalSize = const Size(412, 1200);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(
        ProviderScope(
          overrides: <Override>[
            dependenciesProvider.overrideWithValue(harness.asDependencies()),
          ],
          child: MaterialApp(
            locale: const Locale('vi'),
            supportedLocales: AppLocalizations.supportedLocales,
            localizationsDelegates: const <LocalizationsDelegate<Object>>[
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: Scaffold(body: InventoryItemTile(item: item)),
          ),
        ),
      );
      await tester.pump();
    }

    testWidgets('the row carries the name, the barcode and the deadline',
        (WidgetTester tester) async {
      await pumpTile(tester, lot());

      expect(find.text('Sữa chua nếp cẩm'), findsOneWidget);
      expect(find.text('8934673001234'), findsOneWidget);
      expect(find.textContaining('20/9/2026'), findsWidgets);
    });

    testWidgets('a product with no photo falls back to its initials',
        (WidgetTester tester) async {
      await pumpTile(tester, lot());
      // "Sữa chua nếp cẩm" -> S + C.
      expect(find.text('SC'), findsOneWidget);
    });

    testWidgets('a product with no barcode says so rather than showing nothing',
        (WidgetTester tester) async {
      await pumpTile(tester, lot(barcode: null));
      expect(find.text('Chưa có mã vạch'), findsOneWidget);
    });
  });
}
