import 'dart:io';
import 'dart:typed_data';

import 'package:expiry_guardian/bootstrap.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scan_outcome.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// The second round of shop-floor reports: text recognition as dead as the
/// barcode was, the destroy sheet spinning for ever, no notification ever
/// arriving, and a scanned barcode forgetting the shelf it belongs on.
void main() {
  final DateTime now = DateTime(2026, 9, 12, 8);
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create(now: now));
  tearDown(() async => harness.dispose());

  Future<Product> addProduct({String name = 'Sua tuoi', String? shelfId}) async {
    return (await harness.catalog.createProduct(
      Product(
        id: '',
        barcode: 'bc-$name',
        name: name,
        unit: 'hop',
        unitCost: 12000,
        defaultShelfId: shelfId,
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),
    ))
        .unwrap();
  }

  Future<InventoryRecord> addLot(Product product, {String? shelfId}) async {
    return (await harness.inventory.intake(
      IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 9, 9),
        expiryPrecision: ExpiryPrecision.day,
        manufacturedAt: DateTime(2026, 8, 30),
        quantity: 6,
        shelfId: shelfId,
      ),
    ))
        .unwrap();
  }

  File writeCapture(String name) {
    return File('${harness.exportDirectory.path}/$name')
      ..createSync(recursive: true)
      ..writeAsBytesSync(Uint8List.fromList(<int>[0xFF, 0xD8, 0xFF, 0xD9]));
  }

  // ---------------------------------------------------------------- bug 1
  group('reported: the camera reads neither text nor barcodes', () {
    test('the text reader takes live frames and keeps the rotation', () async {
      harness.textReader.nextLines = <String>['NSX 010326 HSD 010327'];
      final List<RecognisedLine> lines = await harness.textReader.readFrame(
        CameraFrame(
          bytes: Uint8List(12),
          width: 4,
          height: 3,
          rotationDegrees: 270,
          bytesPerRow: 4,
          format: CameraFrameFormat.nv21,
        ),
      );
      expect(lines.single.text, 'NSX 010326 HSD 010327');
      // A sideways buffer recognises nothing at all, so this is load-bearing.
      expect(harness.textReader.readFrames.single.rotationDegrees, 270);
    });

    test('dates read from the stream are used instead of re-reading the still',
        () async {
      final File capture = writeCapture('label.jpg');
      // The still would yield nothing; the live pass already has the date.
      harness.textReader.nextLines = const <String>[];

      final Result<ScanOutcome> outcome =
          await harness.asDependencies().scanPipeline.process(
                capture.path,
                alreadyReadLines: const <RecognisedLine>[
                  RecognisedLine(text: 'HSD 20/12/2026'),
                ],
              );

      expect(outcome.isOk, isTrue);
      expect(outcome.unwrap().expiry.value, DateTime(2026, 12, 20));
    });

    test('a reading survives a still that failed to save', () async {
      // The code or the date is the valuable part. Losing the souvenir
      // photograph must not lose the scan with it.
      final Result<ScanOutcome> outcome =
          await harness.asDependencies().scanPipeline.process(
                '',
                alreadyRead: const <ScannedCode>[
                  ScannedCode(rawValue: '8934588063053', format: CodeFormat.ean13),
                ],
                alreadyReadLines: const <RecognisedLine>[
                  RecognisedLine(text: 'EXP 20/12/2026'),
                ],
              );

      expect(outcome.isOk, isTrue, reason: '${outcome.failureOrNull?.message}');
      expect(outcome.unwrap().primaryBarcode, '8934588063053');
      expect(outcome.unwrap().expiry.value, DateTime(2026, 12, 20));
      expect(outcome.unwrap().photoPath, isNull);
    });

    test('nothing at all is still reported as nothing, never invented',
        () async {
      final Result<ScanOutcome> outcome =
          await harness.asDependencies().scanPipeline.process('');
      expect(outcome.isErr, isTrue);
      expect(outcome.failureOrNull!.message, 'capture_missing');
    });
  });

  // ---------------------------------------------------------------- bug 2
  group('reported: the destroy sheet spins for ever', () {
    test('a thrown error comes back as a failure, never as a rejected future',
        () async {
      // No signed-in employee is the cheapest way to reach the guard; the
      // point is the shape of the answer, not this particular cause.
      final Result<DestroyConfirmationResult> result = await harness.workflow
          .confirmDestruction(const DestroyConfirmation(recordId: 'nope'));
      expect(result.isErr, isTrue);
    });

    test('a missing record fails instead of hanging', () async {
      (await harness.auth.createInitialAdmin(
        username: 'ql',
        displayName: 'Chi Lan',
        password: 'matkhau',
      ))
          .unwrap();

      final Result<DestroyConfirmationResult> result = await harness.workflow
          .confirmDestruction(const DestroyConfirmation(recordId: 'khong-co'));

      expect(result.isErr, isTrue);
      expect(result.failureOrNull, isNotNull);
    });

    test('the audit log refuses updates, and nothing in the app attempts one',
        () async {
      // The append-only triggers are real, so a stray UPDATE would abort the
      // transaction and surface as a hang. Prove the trigger bites, so that if
      // anyone ever writes that UPDATE this test is what tells them.
      await expectLater(
        harness.database.db.update(
          'audit_log',
          <String, Object?>{'note': 'tampered'},
        ),
        throwsA(anything),
      );
    });
  });

  // ---------------------------------------------------------------- bug 3
  group('reported: no reminder ever appears on the phone', () {
    test('start-up asks for permission before building any schedule', () async {
      expect(
        harness.settings.readBool(SettingKeys.notificationPermissionAsked, false),
        isFalse,
      );

      final bool granted =
          await ensureNotificationPermission(harness.asDependencies());

      expect(granted, isTrue);
      expect(
        harness.settings.readBool(SettingKeys.notificationPermissionGranted, false),
        isTrue,
        reason: 'the answer has to be recorded so the UI can state it',
      );
    });

    test('a blocked phone is recorded as blocked rather than failing quietly',
        () async {
      harness.notifications.permissionGranted = false;

      final bool granted =
          await ensureNotificationPermission(harness.asDependencies());

      expect(granted, isFalse);
      expect(
        harness.settings.readBool(SettingKeys.notificationPermissionGranted, true),
        isFalse,
      );
      expect(harness.notifications.permissionRequests, 1);
    });

    test('the employee is asked once, not on every launch', () async {
      harness.notifications.permissionGranted = false;
      await ensureNotificationPermission(harness.asDependencies());
      await ensureNotificationPermission(harness.asDependencies());
      await ensureNotificationPermission(harness.asDependencies());
      expect(harness.notifications.permissionRequests, 1);
    });

    test('reminders are still scheduled on a blocked phone', () async {
      // Scheduling anyway is deliberate: the moment the employee allows
      // notifications the whole timeline is already in place.
      harness.notifications.permissionGranted = false;
      (await harness.auth.createInitialAdmin(
        username: 'ql',
        displayName: 'Chi Lan',
        password: 'matkhau',
      ))
          .unwrap();
      final Product product = await addProduct();
      await addLot(product);

      await ensureNotificationPermission(harness.asDependencies());
      (await harness.workflow.refresh()).unwrap();

      expect(harness.notifications.scheduled, isNotEmpty);
    });
  });

  // ---------------------------------------------------------------- bug 4
  group('reported: a known barcode forgets its product and shelf', () {
    test('a known barcode returns the product with its remembered shelf',
        () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quay mat')).unwrap();
      final Shelf shelf =
          (await harness.locations.createShelf(areaId: area.id, name: 'Ke A1'))
              .unwrap();
      final Product product = await addProduct(shelfId: shelf.id);

      final File capture = writeCapture('code.jpg');
      final Result<ScanOutcome> outcome =
          await harness.asDependencies().scanPipeline.process(
                capture.path,
                alreadyRead: <ScannedCode>[
                  ScannedCode(rawValue: product.barcode!, format: CodeFormat.ean13),
                ],
              );

      final ScanOutcome value = outcome.unwrap();
      expect(value.product?.id, product.id);
      expect(
        value.product?.defaultShelfId,
        shelf.id,
        reason: 'the shelf has to travel with the product, or it is not '
            'remembered at all',
      );
      expect(value.product?.unit, 'hop');
      expect(value.product?.unitCost, 12000);
    });

    test('an unknown barcode reports itself unknown rather than guessing',
        () async {
      final File capture = writeCapture('unknown.jpg');
      final Result<ScanOutcome> outcome =
          await harness.asDependencies().scanPipeline.process(
                capture.path,
                alreadyRead: const <ScannedCode>[
                  ScannedCode(rawValue: '0000000000000', format: CodeFormat.ean13),
                ],
              );
      final ScanOutcome value = outcome.unwrap();
      expect(value.primaryBarcode, '0000000000000');
      expect(value.product, isNull);
    });

    test('a product with no home learns the shelf it was first put on',
        () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quay mat')).unwrap();
      final Shelf shelf =
          (await harness.locations.createShelf(areaId: area.id, name: 'Ke A1'))
              .unwrap();
      final Product product = await addProduct();
      expect(product.defaultShelfId, isNull);

      // What the goods-in flow does once the lot is saved.
      (await harness.catalog
              .updateProduct(product.copyWith(defaultShelfId: shelf.id)))
          .unwrap();

      final Product? again =
          (await harness.catalog.findByBarcode(product.barcode!)).unwrap();
      expect(again?.defaultShelfId, shelf.id);
    });

    test('a product that already has a home keeps it', () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quay mat')).unwrap();
      final Shelf usual =
          (await harness.locations.createShelf(areaId: area.id, name: 'Ke A1'))
              .unwrap();
      final Product product = await addProduct(shelfId: usual.id);

      // A one-off placement elsewhere must not overwrite the usual shelf; the
      // flow only records a default when the product has none.
      expect(product.defaultShelfId, usual.id);
      final Product? again =
          (await harness.catalog.findByBarcode(product.barcode!)).unwrap();
      expect(again?.defaultShelfId, usual.id);
    });
  });
}
