import 'dart:io';

import 'package:expiry_guardian/core/database/migrations.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'support/test_harness.dart';

/// Upgrading the installed APK must not lose a single row.
///
/// These tests build a database at schema v1 - exactly what a phone running the
/// Phase 1 build has on it - put real data in, then reopen it at the current
/// version and check that the Phase X tables arrived and the old rows survived.
void main() {
  late Directory workspace;

  setUpAll(sqfliteFfiInit);

  // An in-memory database is a fresh database on every open, so an upgrade
  // cannot be observed there. These tests need a real file that survives being
  // closed and reopened, exactly like the one on a phone.
  setUp(() async {
    workspace = await Directory.systemTemp.createTemp('expiry_guardian_migration_');
  });

  tearDown(() {
    if (workspace.existsSync()) workspace.deleteSync(recursive: true);
  });

  String newDatabasePath() => '${workspace.path}/expiry_guardian.db';

  /// Opens [path] with only the migrations up to [version], the way an older
  /// build of the app would have created it.
  Future<Database> openAtVersion(String path, int version) {
    return databaseFactoryFfi.openDatabase(
      path,
      options: OpenDatabaseOptions(
        version: version,
        onConfigure: (Database db) => db.execute('PRAGMA foreign_keys = ON'),
        onCreate: (Database db, int _) async {
          for (final Migration migration in Migrations.all) {
            if (migration.version > version) continue;
            for (final String statement in migration.statements) {
              await db.execute(statement);
            }
            await migration.onUpgrade?.call(db);
          }
        },
      ),
    );
  }

  Future<Database> reopenAtLatest(String path) {
    return databaseFactoryFfi.openDatabase(
      path,
      options: OpenDatabaseOptions(
        version: Migrations.latestVersion,
        onConfigure: (Database db) => db.execute('PRAGMA foreign_keys = ON'),
        onUpgrade: (Database db, int from, int to) async {
          for (final Migration migration in Migrations.all) {
            if (migration.version > from && migration.version <= to) {
              for (final String statement in migration.statements) {
                await db.execute(statement);
              }
              await migration.onUpgrade?.call(db);
            }
          }
        },
      ),
    );
  }

  test('the migration list is ordered and starts at 1', () {
    expect(Migrations.all.first.version, 1);
    for (int i = 1; i < Migrations.all.length; i++) {
      expect(
        Migrations.all[i].version,
        Migrations.all[i - 1].version + 1,
        reason: 'migration versions must be consecutive',
      );
    }
    expect(Migrations.latestVersion, Migrations.all.last.version);
  });

  test('a v1 database upgrades to the current schema without losing rows', () async {
    final String path = newDatabasePath();

    // --- what a phone running the Phase 1 build has ---
    final Database old = await openAtVersion(path, 1);
    await old.insert(Tables.policies, <String, Object?>{
      'id': 'pol1',
      'name': 'Chính sách mặc định',
      'version': 1,
      'basis': 'manufacturedToExpiry',
      'is_active': 1,
      'created_at': 1,
      'updated_at': 1,
    });
    await old.insert(Tables.products, <String, Object?>{
      'id': 'p1',
      'barcode': '8934588063053',
      'name': 'Sữa tươi Vinamilk',
      'unit': 'hộp',
      'expiry_precision': 'day',
      'is_active': 1,
      'created_at': 1,
      'updated_at': 1,
    });
    await old.insert(Tables.inventoryRecords, <String, Object?>{
      'id': 'r1',
      'code': 'EG-260906-0001',
      'product_id': 'p1',
      'expiry_at': 2000,
      'expiry_precision': 'day',
      'expiry_instant': 2000,
      'destroy_at': 1900,
      'lead_time_minutes': 120,
      'shelf_life_minutes': 1440,
      'policy_id': 'pol1',
      'policy_version': 1,
      'quantity': 6,
      'quantity_remaining': 6,
      'unit': 'hộp',
      'received_at': 1,
      'status': 'active',
      'source': 'scan',
      'created_at': 1,
      'updated_at': 1,
    });
    await old.insert(Tables.destructions, <String, Object?>{
      'id': 'd1',
      'record_id': 'r1',
      'product_id': 'p1',
      'quantity': 2,
      'loss_amount': 0,
      'reason': 'policy',
      'was_overdue': 0,
      'minutes_late': 0,
      'destroyed_at': 1500,
      'created_at': 1500,
    });

    // The Phase X tables genuinely do not exist yet.
    final List<Map<String, Object?>> before = await old.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table'",
    );
    final Set<String> beforeNames =
        before.map((Map<String, Object?> r) => r['name']! as String).toSet();
    expect(beforeNames, isNot(contains(Tables.auditLog)));
    expect(beforeNames, isNot(contains(Tables.escalations)));
    await old.close();

    // --- the user installs the Phase X APK ---
    final Database upgraded = await reopenAtLatest(path);

    final Set<String> afterNames = (await upgraded.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table'",
    ))
        .map((Map<String, Object?> r) => r['name']! as String)
        .toSet();
    for (final String table in <String>[
      Tables.notificationStages,
      Tables.escalationRules,
      Tables.escalations,
      Tables.auditLog,
      Tables.documentExports,
    ]) {
      expect(afterNames, contains(table), reason: '$table should exist after the upgrade');
    }

    // Nothing the store had recorded was lost.
    expect(
      (await upgraded.query(Tables.products)).single['name'],
      'Sữa tươi Vinamilk',
    );
    expect((await upgraded.query(Tables.inventoryRecords)).single['code'], 'EG-260906-0001');

    // The old destruction row is still there, with the new columns empty -
    // it was recorded before confirmations carried a device.
    final Map<String, Object?> destruction =
        (await upgraded.query(Tables.destructions)).single;
    expect(destruction['quantity'], 2.0);
    expect(destruction.containsKey('device_id'), isTrue);
    expect(destruction['device_id'], isNull);
    expect(destruction['confirmed_at'], isNull);

    await upgraded.close();
  });

  test('the append-only triggers exist after an upgrade, not just a fresh install',
      () async {
    final String path = newDatabasePath();
    final Database old = await openAtVersion(path, 1);
    await old.close();

    final Database upgraded = await reopenAtLatest(path);
    await upgraded.insert(Tables.auditLog, <String, Object?>{
      'id': 'a1',
      'occurred_at': 1,
      'action': 'settingChanged',
      'entity': 'app_settings',
      'previous_hash': '0' * 64,
      'hash': 'x' * 64,
    });

    await expectLater(
      upgraded.update(Tables.auditLog, <String, Object?>{'note': 'forged'}, where: 'seq = 1'),
      throwsA(isA<DatabaseException>()),
    );
    await expectLater(
      upgraded.delete(Tables.auditLog, where: 'seq = 1'),
      throwsA(isA<DatabaseException>()),
    );
    await upgraded.close();
  });

  test('a fresh install lands on the same schema as an upgraded one', () async {
    final TestHarness harness = await TestHarness.create();
    addTearDown(harness.dispose);

    final Set<String> fresh = (await harness.database.db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type IN ('table', 'trigger', 'index')",
    ))
        .map((Map<String, Object?> r) => r['name']! as String)
        .where((String name) => !name.startsWith('sqlite_'))
        .toSet();

    final String path = newDatabasePath();
    final Database old = await openAtVersion(path, 1);
    await old.close();
    final Database upgraded = await reopenAtLatest(path);
    final Set<String> migrated = (await upgraded.rawQuery(
      "SELECT name FROM sqlite_master WHERE type IN ('table', 'trigger', 'index')",
    ))
        .map((Map<String, Object?> r) => r['name']! as String)
        .where((String name) => !name.startsWith('sqlite_'))
        .toSet();
    await upgraded.close();

    expect(migrated, fresh);
  });
}
