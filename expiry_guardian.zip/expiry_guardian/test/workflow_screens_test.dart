import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/features/audit/presentation/pages/audit_trail_page.dart';
import 'package:expiry_guardian/features/escalation/presentation/pages/escalation_rules_page.dart';
import 'package:expiry_guardian/features/escalation/presentation/pages/manager_dashboard_page.dart';
import 'package:expiry_guardian/features/reports/presentation/pages/export_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/notification_workflow_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Each Phase X screen is mounted against the real stack - real SQLite, the
/// seeded stages and rules, the real repositories - so a screen that would
/// crash or render an empty shell on a phone fails here first.
void main() {
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create());
  tearDown(() async => harness.dispose());

  void usePhoneViewport(WidgetTester tester) {
    tester.view.physicalSize = const Size(412, 915);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
  }

  Future<void> settle(WidgetTester tester, {int frames = 12}) async {
    for (int i = 0; i < frames; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump();
    }
  }

  Future<void> signInAsAdmin() async {
    await harness.auth.createInitialAdmin(
      username: 'ql',
      displayName: 'Chị Lan',
      password: 'matkhau',
    );
    await harness.auth.signIn(username: 'ql', password: 'matkhau');
  }

  Future<void> pumpScreen(WidgetTester tester, Widget screen) async {
    usePhoneViewport(tester);
    await tester.runAsync(signInAsAdmin);
    await tester.pumpWidget(
      ProviderScope(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
        ],
        child: MaterialApp(
          locale: const Locale('vi'),
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const <LocalizationsDelegate<Object>>[
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: screen,
        ),
      ),
    );
    await settle(tester);
  }

  testWidgets('the reminder workflow screen lists the four seeded stages',
      (WidgetTester tester) async {
    await pumpScreen(tester, const NotificationWorkflowPage());

    expect(find.text('Quy trình nhắc nhở'), findsWidgets);
    expect(find.text('Cảnh báo sớm'), findsOneWidget);
    expect(find.text('Nhắc lần cuối'), findsOneWidget);
    expect(find.text('Bắt buộc huỷ'), findsOneWidget);
    expect(find.text('Nhắc lại tới khi xác nhận'), findsOneWidget);
    // Each stage says when it fires, in words, not as a raw duration.
    expect(find.textContaining('Trước hạn huỷ'), findsWidgets);
    expect(find.text('Đúng lúc tới hạn huỷ'), findsOneWidget);
  });

  testWidgets('the escalation rules screen shows the seeded 24-hour rule',
      (WidgetTester tester) async {
    await pumpScreen(tester, const EscalationRulesPage());

    expect(find.text('Báo quản lý sau 24 giờ'), findsOneWidget);
    expect(find.textContaining('Báo lên sau hạn huỷ'), findsOneWidget);
    expect(find.textContaining('Báo cho vai trò'), findsOneWidget);
  });

  testWidgets('the manager dashboard says the store is clear when it is',
      (WidgetTester tester) async {
    await pumpScreen(tester, const ManagerDashboardPage());

    expect(find.text('Bảng quản lý'), findsOneWidget);
    expect(find.text('Đang chờ xử lý'), findsOneWidget);
    // No invented alerts on an empty store.
    expect(find.text('Không có cảnh báo nào.'), findsOneWidget);
  });

  testWidgets('the audit screen opens with the seeded, verifiable log',
      (WidgetTester tester) async {
    await pumpScreen(tester, const AuditTrailPage());

    expect(find.text('Nhật ký kiểm toán'), findsOneWidget);
    expect(
      find.textContaining('Mỗi bản ghi mang mã băm của bản ghi trước'),
      findsOneWidget,
    );
    // Seeding the stages and rules is itself audited, so there are real rows.
    expect(find.text('Chưa có thao tác nào được ghi.'), findsNothing);
  });

  testWidgets('the export screen offers the six templates and greys out Google Docs',
      (WidgetTester tester) async {
    await pumpScreen(tester, const ExportPage());

    expect(find.text('Xuất báo cáo'), findsWidgets);
    expect(find.text('Báo cáo huỷ hàng ngày'), findsOneWidget);
    expect(find.text('Báo cáo kiểm toán'), findsOneWidget);
    expect(find.text('Báo cáo hàng quá hạn'), findsOneWidget);

    // The unavailable destination is visible but honest about itself.
    expect(find.text('Google Docs'), findsOneWidget);
    await tester.tap(find.text('Google Docs'));
    await settle(tester);
    expect(find.textContaining('Chưa cấu hình Google Docs'), findsOneWidget);
  });
}
