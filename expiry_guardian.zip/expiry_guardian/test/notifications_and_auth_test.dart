import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/features/auth/data/security/password_hasher.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

void main() {
  final DateTime now = DateTime(2026, 9, 6, 8);
  final AppLocalizations vi = AppLocalizations(const Locale('vi'));
  final AppLocalizations en = AppLocalizations(const Locale('en'));

  group('NotificationPreferences quiet hours', () {
    const NotificationPreferences overnight = NotificationPreferences(
      quietStartMinutes: 22 * 60,
      quietEndMinutes: 6 * 60,
    );

    test('recognises a window that wraps past midnight', () {
      expect(overnight.isQuiet(DateTime(2026, 9, 6, 23)), isTrue);
      expect(overnight.isQuiet(DateTime(2026, 9, 6, 3)), isTrue);
      expect(overnight.isQuiet(DateTime(2026, 9, 6, 12)), isFalse);
    });

    test('a digest inside quiet hours is pushed to the end of the window', () {
      final DateTime adjusted =
          overnight.adjust(DateTime(2026, 9, 6, 23, 30), moveLater: true);
      expect(adjusted, DateTime(2026, 9, 7, 6));
    });

    test('an item alert inside quiet hours is pulled before the window', () {
      final DateTime adjusted =
          overnight.adjust(DateTime(2026, 9, 6, 23, 30), moveLater: false);
      expect(adjusted, DateTime(2026, 9, 6, 22));
    });

    test('a moment outside the window is untouched', () {
      final DateTime moment = DateTime(2026, 9, 6, 12);
      expect(overnight.adjust(moment, moveLater: true), moment);
    });
  });

  group('NotificationPlanner ids', () {
    test('are stable, positive and distinct per lot and lead time', () {
      final int a = NotificationPlanner.notificationId('due', 'record-1', 120);
      final int b = NotificationPlanner.notificationId('due', 'record-1', 120);
      final int c = NotificationPlanner.notificationId('due', 'record-1', 0);
      final int d = NotificationPlanner.notificationId('due', 'record-2', 120);

      expect(a, b);
      expect(a, isNot(c));
      expect(a, isNot(d));
      for (final int id in <int>[a, c, d]) {
        expect(id, greaterThan(0));
        expect(id, lessThanOrEqualTo(0x7fffffff));
      }
    });
  });

  group('NotificationPlanner planning', () {
    late TestHarness harness;
    late NotificationPlanner planner;
    late FakeNotificationGateway gateway;
    late List<NotificationStage> stages;

    setUp(() async {
      harness = await TestHarness.create(now: now);
      gateway = harness.notifications;
      planner = harness.planner;
      stages = (await harness.notificationWorkflow.listStages()).unwrap();
    });

    tearDown(() async => harness.dispose());

    Future<void> addLot({
      required String name,
      required DateTime expiry,
      ExpiryPrecision precision = ExpiryPrecision.hour,
      DateTime? manufactured,
    }) async {
      final Product product = (await harness.catalog.createProduct(
        Product(
          id: '',
          barcode: 'bc-$name',
          name: name,
          unit: 'pcs',
          expiryPrecision: precision,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        ),
      ))
          .unwrap();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: expiry,
        expiryPrecision: precision,
        manufacturedAt: manufactured ?? now.subtract(const Duration(hours: 6)),
        quantity: 1,
      ),);
    }

    test('schedules nothing when the store has no due stock', () async {
      final NotificationPlan plan = (await planner.reschedule(
        preferences: const NotificationPreferences(),
        strings: vi,
      ))
          .unwrap();
      expect(plan.total, 0);
      expect(gateway.cancelledAll, isTrue);
    });

    test('builds a morning digest carrying the real count', () async {
      await addLot(name: 'Trà sữa', expiry: DateTime(2026, 9, 6, 18));
      await addLot(name: 'Bánh mì', expiry: DateTime(2026, 9, 6, 20));

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: DateTime(2026, 9, 13)))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(perItemEnabled: false),
        strings: vi,
        // Before the 07:00 digest so today's summary is still in the future.
        now: DateTime(2026, 9, 6, 5),
      );

      final AppNotification digest = plan.notifications
          .firstWhere((AppNotification n) => n.kind == NotificationKind.dailyDigest);
      expect(digest.body, contains('2'));
      expect(digest.scheduledFor, DateTime(2026, 9, 6, 7));
      expect(digest.payload, 'today');
    });

    test('the digest is bilingual', () async {
      await addLot(name: 'Trà sữa', expiry: DateTime(2026, 9, 6, 18));
      final List<dynamic> due = (await harness.inventory
              .destroyList(until: DateTime(2026, 9, 13)))
          .unwrap();

      final NotificationPlan viPlan = planner.buildPlan(
        items: due.cast(),
        stages: stages,
        preferences: const NotificationPreferences(perItemEnabled: false),
        strings: vi,
        now: DateTime(2026, 9, 6, 5),
      );
      final NotificationPlan enPlan = planner.buildPlan(
        items: due.cast(),
        stages: stages,
        preferences: const NotificationPreferences(perItemEnabled: false),
        strings: en,
        now: DateTime(2026, 9, 6, 5),
      );

      expect(viPlan.notifications.first.body, contains('sản phẩm'));
      expect(enPlan.notifications.first.body, contains('products'));
    });

    test('fires each configured stage at its own offset from the deadline', () async {
      // A lot due in five days, so every stage - including the two-day early
      // warning - still lies in the future.
      await addLot(name: 'Trà sữa', expiry: DateTime(2026, 9, 11, 18));
      final DateTime destroyAt = (await harness.inventory
              .destroyList(until: DateTime(2026, 9, 20)))
          .unwrap()
          .single
          .record
          .destroyAt;

      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: DateTime(2026, 9, 20)))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(dailyDigestEnabled: false),
        strings: vi,
        now: now,
      );

      final List<DateTime> fired = plan.notifications
          .map((AppNotification n) => n.scheduledFor)
          .toList();
      expect(fired, contains(destroyAt.subtract(const Duration(days: 2))));
      expect(fired, contains(destroyAt.subtract(const Duration(days: 1))));
      expect(fired, contains(destroyAt));
      // Plus the hourly chase-ups that keep going until somebody confirms.
      expect(fired, contains(destroyAt.add(const Duration(hours: 1))));
      expect(fired, contains(destroyAt.add(const Duration(hours: 2))));
      expect(plan.stageCount, greaterThan(3));
    });

    test('the repeat stage stops at its configured maximum', () async {
      final NotificationStage repeat = stages.firstWhere(
        (NotificationStage s) => s.kind == NotificationStageKind.repeatUntilConfirmed,
      );
      expect(repeat.maxRepeats, 24);
      expect(repeat.repeatEvery, const Duration(hours: 1));

      final DateTime destroyAt = DateTime(2026, 9, 6, 16);
      final List<DateTime> occurrences = repeat.occurrencesFor(destroyAt);
      expect(occurrences, hasLength(24));
      expect(occurrences.first, destroyAt.add(const Duration(hours: 1)));
      expect(occurrences.last, destroyAt.add(const Duration(hours: 24)));
    });

    test('never schedules an alert in the past', () async {
      await addLot(name: 'Đã trễ', expiry: DateTime(2026, 9, 6, 7));
      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: DateTime(2026, 9, 13)))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(dailyDigestEnabled: false),
        strings: vi,
        now: now,
      );
      for (final AppNotification notification in plan.notifications) {
        expect(notification.scheduledFor.isAfter(now), isTrue);
      }
    });

    test('chases up after the deadline until it is confirmed', () async {
      await addLot(name: 'Trà sữa', expiry: DateTime(2026, 9, 6, 18));
      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: DateTime(2026, 9, 13)))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(dailyDigestEnabled: false),
        strings: vi,
        now: now,
      );
      // Destroy instant is 16:00 (two hours before an 18:00 expiry).
      final AppNotification overdue = plan.notifications
          .firstWhere((AppNotification n) => n.kind == NotificationKind.itemOverdue);
      expect(overdue.scheduledFor, DateTime(2026, 9, 6, 16));
      expect(overdue.recordId, isNotNull);
      expect(
        plan.notifications
            .where((AppNotification n) => n.kind == NotificationKind.itemOverdue)
            .length,
        greaterThan(1),
      );
    });

    test('caps the schedule and reports that it did', () async {
      for (int i = 0; i < 12; i++) {
        await addLot(
          name: 'Lô $i',
          expiry: DateTime(2026, 9, 6, 12).add(Duration(hours: i)),
        );
      }
      final NotificationPlan plan = planner.buildPlan(
        items: (await harness.inventory
                .destroyList(until: DateTime(2026, 9, 13)))
            .unwrap(),
        stages: stages,
        preferences: const NotificationPreferences(maxScheduled: 5),
        strings: vi,
        now: now,
      );
      expect(plan.truncated, isTrue);
      expect(plan.notifications, hasLength(5));
    });

    test('reschedule hands the plan to the platform and records it', () async {
      await addLot(name: 'Trà sữa', expiry: DateTime(2026, 9, 6, 18));
      final NotificationPlan plan = (await planner.reschedule(
        preferences: const NotificationPreferences(),
        strings: vi,
      ))
          .unwrap();
      expect(gateway.scheduled, hasLength(plan.total));
      expect(await gateway.pendingIds(), hasLength(plan.total));
    });
  });

  group('Pbkdf2PasswordHasher', () {
    final PasswordHasher hasher = Pbkdf2PasswordHasher(defaultIterations: 1000);

    test('accepts the right password and rejects the wrong one', () {
      final PasswordHash stored = hasher.hash('mật khẩu 123');
      expect(hasher.verify('mật khẩu 123', stored), isTrue);
      expect(hasher.verify('mat khau 123', stored), isFalse);
      expect(hasher.verify('', stored), isFalse);
    });

    test('salts every hash, so identical passwords differ on disk', () {
      final PasswordHash a = hasher.hash('same');
      final PasswordHash b = hasher.hash('same');
      expect(a.salt, isNot(b.salt));
      expect(a.hash, isNot(b.hash));
    });

    test('is deterministic for a given salt', () {
      final PasswordHash first = hasher.hash('abc');
      final PasswordHash again =
          hasher.hash('abc', salt: first.salt, iterations: first.iterations);
      expect(again.hash, first.hash);
    });
  });

  group('role permissions', () {
    test('an employee may scan and destroy but not edit the policy', () {
      final Set<Permission> allowed = RolePermissions.of(UserRole.employee);
      expect(allowed, contains(Permission.scanGoods));
      expect(allowed, contains(Permission.destroyStock));
      expect(allowed, isNot(contains(Permission.editPolicy)));
      expect(allowed, isNot(contains(Permission.manageUsers)));
    });

    test('a manager may edit the policy but not manage users', () {
      final Set<Permission> allowed = RolePermissions.of(UserRole.manager);
      expect(allowed, contains(Permission.editPolicy));
      expect(allowed, contains(Permission.viewReports));
      expect(allowed, isNot(contains(Permission.manageUsers)));
    });

    test('an administrator may do everything', () {
      expect(RolePermissions.of(UserRole.admin), hasLength(Permission.values.length));
    });

    test('a disabled account may do nothing', () {
      final AppUser disabled = AppUser(
        id: 'u1',
        username: 'nv1',
        displayName: 'Nhân viên',
        role: UserRole.admin,
        isActive: false,
        createdAt: now,
        updatedAt: now,
      );
      expect(disabled.can(Permission.scanGoods), isFalse);
    });
  });

  group('auth repository', () {
    late TestHarness harness;

    setUp(() async => harness = await TestHarness.create(now: now));
    tearDown(() async => harness.dispose());

    test('the first run needs an administrator', () async {
      expect((await harness.auth.needsInitialSetup()).unwrap(), isTrue);
      await harness.auth.createInitialAdmin(
        username: 'admin',
        displayName: 'Quản trị',
        password: 'secret',
      );
      expect((await harness.auth.needsInitialSetup()).unwrap(), isFalse);
    });

    test('sign-in restores across a restart', () async {
      await harness.auth.createInitialAdmin(
        username: 'admin',
        displayName: 'Quản trị',
        password: 'secret',
      );
      final AppUser user =
          (await harness.auth.signIn(username: 'admin', password: 'secret')).unwrap();
      expect(user.role, UserRole.admin);
      expect((await harness.auth.restoreSession()).unwrap()?.id, user.id);

      await harness.auth.signOut();
      expect((await harness.auth.restoreSession()).unwrap(), isNull);
    });

    test('rejects a duplicate username, case-insensitively', () async {
      await harness.auth.createInitialAdmin(
        username: 'Admin',
        displayName: 'Quản trị',
        password: 'secret',
      );
      final dynamic second = await harness.auth.createUser(
        username: 'admin',
        displayName: 'Khác',
        password: 'secret',
        role: UserRole.employee,
      );
      expect(second.isErr, isTrue);
    });

    test('a disabled account cannot sign in', () async {
      final AppUser admin = (await harness.auth.createInitialAdmin(
        username: 'admin',
        displayName: 'Quản trị',
        password: 'secret',
      ))
          .unwrap();
      await harness.auth.setActive(userId: admin.id, isActive: false);
      final dynamic result =
          await harness.auth.signIn(username: 'admin', password: 'secret');
      expect(result.isErr, isTrue);
    });

    test('a short password is refused', () async {
      final dynamic result = await harness.auth.createInitialAdmin(
        username: 'admin',
        displayName: 'Quản trị',
        password: 'ab',
      );
      expect(result.isErr, isTrue);
    });
  });
}
