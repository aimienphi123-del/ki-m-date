import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// The reported gap: a product entered by mistake could not be got rid of.
/// The repository could always do it - no screen ever asked.
void main() {
  final DateTime now = DateTime(2026, 9, 15, 9);
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create(now: now));
  tearDown(() async => harness.dispose());

  Future<Product> makeProduct({String name = 'Sữa chua Vinamilk'}) async {
    return (await harness.catalog.createProduct(Product(
      id: '',
      barcode: '8934673605823',
      name: name,
      unit: 'hộp',
      expiryPrecision: ExpiryPrecision.day,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    ),))
        .unwrap();
  }

  Future<int> rowsIn(String table) async {
    final List<Map<String, Object?>> rows =
        await harness.database.db.rawQuery('SELECT COUNT(*) AS n FROM $table');
    return rows.single['n']! as int;
  }

  group('removing a product', () {
    test('one that never carried stock is deleted outright', () async {
      final Product product = await makeProduct();
      expect(await rowsIn(Tables.products), 1);

      final ProductRemoval how =
          (await harness.catalog.deleteProduct(product.id)).unwrap();

      expect(how, ProductRemoval.deleted);
      expect(await rowsIn(Tables.products), 0);
    });

    test('one with history is retired, not deleted', () async {
      final Product product = await makeProduct();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 10, 1),
        expiryPrecision: ExpiryPrecision.day,
        quantity: 4,
      ),);

      final ProductRemoval how =
          (await harness.catalog.deleteProduct(product.id)).unwrap();

      // Deleting the row would take this product's name off every destruction
      // record already written against it, which a shop may have to show.
      expect(how, ProductRemoval.retired);
      expect(await rowsIn(Tables.products), 1);
      expect(await rowsIn(Tables.inventoryRecords), 1);
    });

    test('a retired product leaves the catalog even though the row stays',
        () async {
      final Product product = await makeProduct();
      await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 10, 1),
        expiryPrecision: ExpiryPrecision.day,
        quantity: 4,
      ),);
      await harness.catalog.deleteProduct(product.id);

      // This is what makes the retirement read as a deletion on the shop
      // floor: the catalog stops listing it.
      final List<Product> listed =
          (await harness.catalog.search(const ProductQuery())).unwrap();
      expect(listed, isEmpty);

      // And it is still reachable for the records that name it.
      final List<Product> withRetired = (await harness.catalog
              .search(const ProductQuery(includeInactive: true)))
          .unwrap();
      expect(withRetired.single.id, product.id);
    });

    test('the lot count is reported before anything is removed', () async {
      final Product product = await makeProduct();
      expect((await harness.catalog.countLotsFor(product.id)).unwrap(), 0);

      for (int i = 0; i < 3; i++) {
        await harness.inventory.intake(IntakeDraft(
          productId: product.id,
          expiryAt: DateTime(2026, 10, 1 + i),
          expiryPrecision: ExpiryPrecision.day,
          quantity: 2,
        ),);
      }

      expect((await harness.catalog.countLotsFor(product.id)).unwrap(), 3);
      // Counting must not have removed anything.
      expect(await rowsIn(Tables.products), 1);
    });
  });

  group('what the confirmation will say', () {
    // The dialog is the only place the shop is told which of the two things
    // the button does, so the sentences and the count in them are worth
    // pinning even though the screen itself is not mounted here.
    late AppLocalizations vi;
    late AppLocalizations en;

    setUp(() async {
      vi = await AppLocalizations.delegate.load(const Locale('vi'));
      en = await AppLocalizations.delegate.load(const Locale('en'));
    });

    test('the retire sentence carries the real number of lots', () {
      final String text =
          vi.t(K.catalogRetireBody, <String, Object?>{'count': 7});
      expect(text, contains('7'));
      // A placeholder that survived into the sentence would read as gibberish
      // on the shop floor.
      expect(text, isNot(contains('{count}')));
      expect(en.t(K.catalogRetireBody, <String, Object?>{'count': 7}),
          contains('7'),);
    });

    test('deleting and retiring do not share wording', () {
      expect(vi.t(K.catalogDeleteBody), isNot(vi.t(K.catalogRetireBody)));
      expect(vi.t(K.catalogDeleted), isNot(vi.t(K.catalogRetired)));
      // The button has to say what it really does.
      expect(vi.t(K.catalogRetireAction), isNot(vi.t(K.commonDelete)));
    });

    test('every new string is translated in both languages', () {
      for (final String key in <String>[
        K.catalogDeleteProduct,
        K.catalogDeleteTitle,
        K.catalogDeleteBody,
        K.catalogRetireAction,
        K.catalogDeleted,
        K.catalogRetired,
      ]) {
        expect(vi.t(key), isNot(key), reason: 'missing Vietnamese for $key');
        expect(en.t(key), isNot(key), reason: 'missing English for $key');
        expect(vi.t(key), isNot(en.t(key)), reason: 'untranslated: $key');
      }
    });
  });
}
