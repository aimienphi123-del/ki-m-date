import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/presentation/pages/product_picker_page.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/scan_page.dart';
import 'package:expiry_guardian/features/scan/presentation/viewmodels/scan_flow_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Goods-in has two jobs that look nothing alike - a product the store has had
/// before needs one tap, a new one needs a name, a photo and a shelf - and the
/// screen now says so up front.
void main() {
  final DateTime now = DateTime(2026, 9, 14, 9);
  late TestHarness harness;

  setUp(() async => harness = await TestHarness.create(now: now));
  tearDown(() async => harness.dispose());

  Future<void> settle(WidgetTester tester, {int frames = 16}) async {
    for (int i = 0; i < frames; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump();
    }
  }

  Future<Product> makeProduct(
    WidgetTester tester, {
    required String name,
    required String barcode,
  }) async {
    return (await tester.runAsync(() async =>
        (await harness.catalog.createProduct(Product(
          id: '',
          barcode: barcode,
          name: name,
          unit: 'hộp',
          expiryPrecision: ExpiryPrecision.day,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        ),))
            .unwrap(),))! ;
  }

  late ProviderContainer container;

  Future<void> pumpScan(WidgetTester tester) async {
    tester.view.physicalSize = const Size(412, 2400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);
    await tester.pumpWidget(
      ProviderScope(
        overrides: <Override>[
          dependenciesProvider.overrideWithValue(harness.asDependencies()),
        ],
        child: Consumer(builder: (BuildContext c, WidgetRef ref, Widget? _) {
          container = ProviderScope.containerOf(c);
          return MaterialApp(
            locale: const Locale('vi'),
            supportedLocales: AppLocalizations.supportedLocales,
            localizationsDelegates: const <LocalizationsDelegate<Object>>[
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: const ScanPage(),
          );
        },),
      ),
    );
    await settle(tester);
  }

  testWidgets('the first screen offers both paths by name',
      (WidgetTester tester) async {
    await pumpScan(tester);

    expect(find.text('Sản phẩm đã có'), findsOneWidget);
    expect(find.text('Sản phẩm mới'), findsOneWidget);
  });

  testWidgets('picking an existing product goes straight to review',
      (WidgetTester tester) async {
    await makeProduct(tester, name: 'Sữa tươi Vinamilk', barcode: '8934673001234');
    await pumpScan(tester);

    await tester.tap(find.text('Sản phẩm đã có'));
    await settle(tester);

    // The picker lists what the store already has, with no code to type.
    expect(find.byType(ProductPickerPage), findsOneWidget);
    expect(find.text('Sữa tươi Vinamilk'), findsOneWidget);
    expect(find.text('8934673001234'), findsOneWidget);

    await tester.tap(find.text('Sữa tươi Vinamilk'));
    await settle(tester);

    expect(container.read(scanFlowProvider).step, ScanStep.review);
    expect(container.read(scanFlowProvider).product?.name, 'Sữa tươi Vinamilk');
  });

  testWidgets('the picker searches by name and by barcode',
      (WidgetTester tester) async {
    await makeProduct(tester, name: 'Sữa tươi', barcode: '8934673001234');
    await makeProduct(tester, name: 'Bánh mì', barcode: '8934673009999');
    await pumpScan(tester);

    await tester.tap(find.text('Sản phẩm đã có'));
    await settle(tester);
    expect(find.text('Sữa tươi'), findsOneWidget);
    expect(find.text('Bánh mì'), findsOneWidget);

    await tester.enterText(find.byType(TextField).first, 'Bánh');
    await settle(tester);
    expect(find.text('Bánh mì'), findsOneWidget);
    expect(find.text('Sữa tươi'), findsNothing);

    await tester.enterText(find.byType(TextField).first, '8934673001234');
    await settle(tester);
    expect(find.text('Sữa tươi'), findsOneWidget);
    expect(find.text('Bánh mì'), findsNothing);
  });

  group('the shelf picker', () {
    testWidgets('lays the shelves out instead of hiding them in a dropdown',
        (WidgetTester tester) async {
      final StoreArea area = (await tester.runAsync(() async =>
          (await harness.locations.createArea(name: 'Quầy lạnh')).unwrap(),))!;
      await tester.runAsync(() async =>
          harness.locations.createShelf(areaId: area.id, name: 'Kệ A'),);
      await tester.runAsync(() async =>
          harness.locations.createShelf(areaId: area.id, name: 'Kệ B'),);
      final Product product =
          await makeProduct(tester, name: 'Sữa tươi', barcode: '8934673001234');

      await pumpScan(tester);
      container.read(scanFlowProvider.notifier).attachProduct(product);
      await settle(tester);

      // This is the reported bug: both shelves are on screen without tapping
      // anything. The dropdown showed only "Không có" until it was opened.
      expect(find.text('Quầy lạnh · Kệ A'), findsOneWidget);
      expect(find.text('Quầy lạnh · Kệ B'), findsOneWidget);

      await tester.tap(find.text('Quầy lạnh · Kệ B'));
      await settle(tester);
      final String? chosen = container.read(scanFlowProvider).shelfId;
      expect(chosen, isNotNull);
    });

    testWidgets('a store with no shelves is told so, not shown an empty box',
        (WidgetTester tester) async {
      final Product product =
          await makeProduct(tester, name: 'Sữa tươi', barcode: '8934673001234');
      await pumpScan(tester);
      container.read(scanFlowProvider.notifier).attachProduct(product);
      await settle(tester);

      expect(find.textContaining('Chưa có kệ nào'), findsOneWidget);
      expect(find.text('Tạo kệ ngay'), findsOneWidget);
    });

    testWidgets('an area with no shelf in it gets its own sentence',
        (WidgetTester tester) async {
      // The reported case: "Nước" was created as an *area*, so the locations
      // screen looked finished while goods-in correctly had no shelf to offer.
      // "Chưa có kệ nào" sends the employee back to a screen where everything
      // appears done, so the two situations must not share a message.
      await tester.runAsync(() async =>
          harness.locations.createArea(name: 'Nước'),);
      final Product product =
          await makeProduct(tester, name: 'Sữa tươi', barcode: '8934673001234');
      await pumpScan(tester);
      container.read(scanFlowProvider.notifier).attachProduct(product);
      await settle(tester);

      expect(find.textContaining('Khu vực đã có nhưng chưa có kệ nào'),
          findsOneWidget,);
      expect(find.textContaining('Chưa có kệ nào.'), findsNothing);
    });

    testWidgets('the shelf can be created without leaving goods-in',
        (WidgetTester tester) async {
      await tester.runAsync(() async =>
          harness.locations.createArea(name: 'Nước'),);
      final Product product =
          await makeProduct(tester, name: 'Sữa tươi', barcode: '8934673001234');
      await pumpScan(tester);
      container.read(scanFlowProvider.notifier).attachProduct(product);
      await settle(tester);

      await tester.tap(find.text('Tạo kệ ngay'));
      await settle(tester);

      await tester.enterText(
        find.widgetWithText(TextFormField, 'Tên kệ (ví dụ: Kệ 1)'),
        'Kệ 1',
      );
      await settle(tester, frames: 4);
      await tester.tap(find.widgetWithText(FilledButton, 'Lưu'));
      await settle(tester);

      // The new shelf is on screen and already chosen for this lot.
      expect(find.text('Nước · Kệ 1'), findsOneWidget);
      expect(container.read(scanFlowProvider).shelfId, isNotNull);
    });
  });

  testWidgets('an existing product can be given a photo from the review step',
      (WidgetTester tester) async {
    final Product product =
        await makeProduct(tester, name: 'Sữa tươi', barcode: '8934673001234');
    expect(product.photoPath, isNull);

    await pumpScan(tester);
    container.read(scanFlowProvider.notifier).attachProduct(product);
    await settle(tester);

    // The catalog form is only reached when a product is *created*, so this
    // button is the only way an existing item ever gets a face.
    expect(find.text('Thêm ảnh sản phẩm'), findsOneWidget);
  });
}
