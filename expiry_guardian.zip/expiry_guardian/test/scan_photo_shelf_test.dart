import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/scan/domain/services/frame_rotation.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/test_harness.dart';

/// Cover for the reported defects in scanning, photo capture and shelves.
void main() {
  final DateTime now = DateTime(2026, 9, 13, 9);

  group('camera frame rotation', () {
    int rotation({
      int sensor = 90,
      DeviceTurn turn = DeviceTurn.portraitUp,
      bool front = false,
      bool ios = false,
    }) {
      return frameRotationDegrees(
        sensorOrientation: sensor,
        deviceTurn: turn,
        isFrontFacing: front,
        isIOS: ios,
      );
    }

    test('portrait is the sensor orientation, as before', () {
      expect(rotation(), 90);
    });

    test('turning the phone sideways is compensated for', () {
      // The bug: every one of these used to come back as 90, so a label held
      // in landscape reached the recogniser a quarter turn out and no date was
      // ever found.
      expect(rotation(turn: DeviceTurn.landscapeLeft), 0);
      expect(rotation(turn: DeviceTurn.portraitDown), 270);
      expect(rotation(turn: DeviceTurn.landscapeRight), 180);
    });

    test('a front camera is mirrored, so it adds instead of subtracting', () {
      expect(rotation(turn: DeviceTurn.landscapeLeft, front: true), 180);
      expect(rotation(turn: DeviceTurn.landscapeRight, front: true), 0);
    });

    test('the answer always stays inside one turn', () {
      for (final int sensor in <int>[0, 90, 180, 270]) {
        for (final DeviceTurn turn in DeviceTurn.values) {
          for (final bool front in <bool>[true, false]) {
            final int value = rotation(sensor: sensor, turn: turn, front: front);
            expect(value, inInclusiveRange(0, 270));
            expect(value % 90, 0);
          }
        }
      }
    });

    test('iOS frames arrive oriented, so nothing is compensated', () {
      expect(rotation(turn: DeviceTurn.landscapeLeft, ios: true), 90);
      expect(rotation(turn: DeviceTurn.portraitDown, ios: true), 90);
    });
  });

  group('shelf dropdown values', () {
    final StoreArea area = StoreArea(
      id: 'area-1',
      name: 'Quầy lạnh',
      sortOrder: 10,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    );
    final ShelfLocation kitted = ShelfLocation(
      area: area,
      shelf: Shelf(
        id: 'shelf-1',
        areaId: area.id,
        name: 'Kệ A',
        sortOrder: 10,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),
    );

    test('a shelf that is on the list is kept', () {
      expect(selectableShelfId('shelf-1', <ShelfLocation>[kitted]), 'shelf-1');
    });

    test('a shelf missing from the list falls back to none', () {
      // This is the crash: a product carries a default shelf, the shelf list
      // has not loaded yet (or the shelf was deactivated), and the dropdown
      // asserts that its value matches exactly one item.
      expect(selectableShelfId('shelf-1', const <ShelfLocation>[]), isNull);
      expect(selectableShelfId('gone', <ShelfLocation>[kitted]), isNull);
    });

    test('no shelf stays no shelf', () {
      expect(selectableShelfId(null, <ShelfLocation>[kitted]), isNull);
    });
  });

  group('deleting a shelf refreshes the stock list', () {
    late TestHarness harness;

    setUp(() async => harness = await TestHarness.create(now: now));
    tearDown(() async => harness.dispose());

    Future<InventoryRecord> stockOnShelf(String shelfId) async {
      final Product product = (await harness.catalog.createProduct(Product(
        id: '',
        barcode: 'bc-shelf',
        name: 'Sữa chua',
        unit: 'hộp',
        expiryPrecision: ExpiryPrecision.day,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      ),))
          .unwrap();
      return (await harness.inventory.intake(IntakeDraft(
        productId: product.id,
        expiryAt: DateTime(2026, 10, 1),
        expiryPrecision: ExpiryPrecision.day,
        quantity: 3,
        shelfId: shelfId,
      ),))
          .unwrap();
    }

    test('the record loses its shelf and the inventory stream is told', () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Quầy lạnh')).unwrap();
      final Shelf shelf = (await harness.locations
              .createShelf(areaId: area.id, name: 'Kệ A'))
          .unwrap();
      final InventoryRecord record = await stockOnShelf(shelf.id);
      expect(record.shelfId, shelf.id);

      final Future<void> notified =
          harness.inventory.watchInventory().first.timeout(
                const Duration(seconds: 5),
              );

      final Result<void> deleted = await harness.locations.deleteShelf(shelf.id);
      expect(deleted.isOk, isTrue);

      // Without the fix this times out: the stock list went on showing a shelf
      // that no longer exists until the app was restarted.
      await notified;

      final InventoryRecord after =
          (await harness.inventory.findRecord(record.id)).unwrap()!;
      expect(after.shelfId, isNull);
    });

    test('deleting the area does the same through the cascade', () async {
      final StoreArea area =
          (await harness.locations.createArea(name: 'Kho khô')).unwrap();
      final Shelf shelf = (await harness.locations
              .createShelf(areaId: area.id, name: 'Kệ B'))
          .unwrap();
      final InventoryRecord record = await stockOnShelf(shelf.id);

      final Future<void> notified =
          harness.inventory.watchInventory().first.timeout(
                const Duration(seconds: 5),
              );
      expect((await harness.locations.deleteArea(area.id)).isOk, isTrue);
      await notified;

      final InventoryRecord after =
          (await harness.inventory.findRecord(record.id)).unwrap()!;
      expect(after.shelfId, isNull);
      expect(after.areaId, isNull);
    });
  });
}
