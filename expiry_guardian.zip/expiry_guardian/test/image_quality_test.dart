import 'dart:math' as math;
import 'dart:typed_data';

import 'package:expiry_guardian/features/scan/data/services/image_enhancer.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;

/// Builds a synthetic "label" - dark text bars on a light background.
img.Image syntheticLabel({int width = 320, int height = 200, int background = 235, int ink = 25}) {
  final img.Image image = img.Image(width: width, height: height);
  img.fill(image, color: img.ColorRgb8(background, background, background));
  for (int band = 0; band < 6; band++) {
    final int top = 20 + band * 28;
    img.fillRect(
      image,
      x1: 24,
      y1: top,
      x2: width - 24,
      y2: top + 12,
      color: img.ColorRgb8(ink, ink, ink),
    );
  }
  return image;
}

img.Image darken(img.Image source, double factor) {
  final img.Image out = img.Image.from(source);
  for (int y = 0; y < out.height; y++) {
    for (int x = 0; x < out.width; x++) {
      final img.Pixel p = out.getPixel(x, y);
      out.setPixelRgb(x, y, p.r * factor, p.g * factor, p.b * factor);
    }
  }
  return out;
}

void main() {
  const ImageQualityAnalyzer analyzer = ImageQualityAnalyzer();

  group('laplacian variance', () {
    test('a flat frame has almost no high frequency energy', () {
      final GrayFrame flat = GrayFrame(
        pixels: Uint8List.fromList(List<int>.filled(64 * 64, 128)),
        width: 64,
        height: 64,
      );
      expect(ImageQualityAnalyzer.laplacianVariance(flat), lessThan(1));
    });

    test('a sharp checkerboard scores far higher than a blurred one', () {
      final img.Image sharp = syntheticLabel();
      final img.Image blurred = img.gaussianBlur(img.Image.from(sharp), radius: 4);
      final double sharpScore =
          ImageQualityAnalyzer.laplacianVariance(ImageEnhancer.toGrayFrame(sharp));
      final double blurScore =
          ImageQualityAnalyzer.laplacianVariance(ImageEnhancer.toGrayFrame(blurred));
      expect(sharpScore, greaterThan(blurScore * 3));
    });
  });

  group('exposure', () {
    test('a dark frame is reported as too dark', () {
      final img.Image dark = darken(syntheticLabel(), 0.2);
      final ImageQualityReport report = analyzer.analyze(ImageEnhancer.toGrayFrame(dark));
      expect(report.isTooDark, isTrue);
      expect(report.isUsable, isFalse);
    });

    test('a normal frame is usable', () {
      final ImageQualityReport report =
          analyzer.analyze(ImageEnhancer.toGrayFrame(syntheticLabel()));
      expect(report.isTooDark, isFalse);
      expect(report.isTooBright, isFalse);
      expect(report.isBlurry, isFalse);
    });
  });

  group('percentile bounds', () {
    test('a full-range frame stretches to the extremes', () {
      final Uint8List ramp = Uint8List.fromList(List<int>.generate(256, (int i) => i));
      final ({int high, int low}) bounds = ImageQualityAnalyzer.percentileBounds(ramp);
      expect(bounds.low, lessThan(10));
      expect(bounds.high, greaterThan(245));
    });

    test('a compressed frame reports a narrow band', () {
      final Uint8List narrow =
          Uint8List.fromList(List<int>.generate(1000, (int i) => 100 + (i % 20)));
      final ({int high, int low}) bounds = ImageQualityAnalyzer.percentileBounds(narrow);
      expect(bounds.high - bounds.low, lessThan(40));
    });
  });

  group('enhancement pipeline', () {
    test('low light is brightened towards the middle of the range', () {
      final img.Image dark = darken(syntheticLabel(), 0.18);
      final EnhanceResult? result = ImageEnhancer.enhanceSync(
        EnhanceRequest(bytes: Uint8List.fromList(img.encodeJpg(dark, quality: 95))),
      );
      expect(result, isNotNull);
      expect(result!.before.isTooDark, isTrue);
      expect(result.after.brightness, greaterThan(result.before.brightness));
      expect(result.appliedSteps.any((String s) => s.startsWith('lowLight')), isTrue);
    });

    test('contrast is stretched on a washed out frame', () {
      final img.Image washed = syntheticLabel(background: 180, ink: 140);
      final EnhanceResult? result = ImageEnhancer.enhanceSync(
        EnhanceRequest(bytes: Uint8List.fromList(img.encodeJpg(washed, quality: 95))),
      );
      expect(result, isNotNull);
      expect(result!.after.contrast, greaterThan(result.before.contrast));
      expect(result.appliedSteps.any((String s) => s.startsWith('contrastStretch')), isTrue);
    });

    test('a soft frame gets an unsharp mask and measurably sharper edges', () {
      final img.Image soft = img.gaussianBlur(syntheticLabel(), radius: 2);
      final EnhanceResult? result = ImageEnhancer.enhanceSync(
        EnhanceRequest(bytes: Uint8List.fromList(img.encodeJpg(soft, quality: 95))),
      );
      expect(result, isNotNull);
      expect(result!.appliedSteps, contains('unsharpMask'));
      expect(result.after.sharpness, greaterThan(result.before.sharpness));
    });

    test('cropping to the detected region keeps only that region', () {
      final img.Image label = syntheticLabel(width: 400, height: 400);
      final EnhanceResult? result = ImageEnhancer.enhanceSync(
        EnhanceRequest(
          bytes: Uint8List.fromList(img.encodeJpg(label, quality: 95)),
          cropTo: const ScanBox(100, 100, 300, 200),
          cropPadding: 0,
        ),
      );
      expect(result, isNotNull);
      expect(result!.width, 200);
      expect(result.height, 100);
      expect(result.appliedSteps, contains('crop'));
    });

    test('undecodable bytes return null instead of throwing', () {
      final EnhanceResult? result = ImageEnhancer.enhanceSync(
        EnhanceRequest(bytes: Uint8List.fromList(<int>[1, 2, 3, 4, 5])),
      );
      expect(result, isNull);
    });

    test('a very large frame is resized down', () {
      final img.Image big = syntheticLabel(width: 3000, height: 400);
      final EnhanceResult? result = ImageEnhancer.enhanceSync(
        EnhanceRequest(
          bytes: Uint8List.fromList(img.encodeJpg(big, quality: 80)),
          maxWidth: 1200,
        ),
      );
      expect(result!.width, 1200);
      expect(result.appliedSteps, contains('resize'));
    });
  });

  group('quality score', () {
    test('is higher for a clean frame than for a dark blurry one', () {
      final img.Image good = syntheticLabel();
      final img.Image bad = img.gaussianBlur(darken(syntheticLabel(), 0.2), radius: 4);
      final double goodScore = analyzer.analyze(ImageEnhancer.toGrayFrame(good)).score;
      final double badScore = analyzer.analyze(ImageEnhancer.toGrayFrame(bad)).score;
      expect(goodScore, greaterThan(badScore));
      expect(goodScore, inInclusiveRange(0.0, 1.0));
      expect(badScore, inInclusiveRange(0.0, 1.0));
    });
  });

  test('gray conversion matches the luminance formula', () {
    final img.Image image = img.Image(width: 2, height: 1);
    image.setPixelRgb(0, 0, 255, 0, 0);
    image.setPixelRgb(1, 0, 0, 255, 0);
    final GrayFrame frame = ImageEnhancer.toGrayFrame(image, targetWidth: 2);
    expect(frame.at(0, 0), (0.299 * 255).round());
    expect(frame.at(1, 0), (0.587 * 255).round());
    expect(math.max(frame.at(0, 0), frame.at(1, 0)), frame.at(1, 0));
  });
}
