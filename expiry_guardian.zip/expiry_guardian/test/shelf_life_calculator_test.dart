import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/services/default_policy_factory.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:expiry_guardian/features/policy/domain/services/shelf_life_calculator.dart';
import 'package:flutter_test/flutter_test.dart';

/// The destruction calculator, checked against the handbook bands the store
/// already runs on.
///
/// Every expectation below is the answer the shop's own POS-style calculator
/// gives for the same input, so the screen in the app and the sheet on the
/// wall cannot disagree.
void main() {
  const ShelfLifeCalculator calculator = ShelfLifeCalculator();
  const ExpiryPolicyEngine engine = DefaultExpiryPolicyEngine();

  late DestroyPolicy policy;

  setUp(() {
    policy = DefaultPolicyFactory(
      _SequentialIds(),
      FixedClock(DateTime(2026, 9, 12)),
    ).build();
  });

  ShelfLifeResult fromDates(
    DateTime nsx,
    DateTime hsd, {
    bool hasTime = false,
    bool sop = false,
  }) {
    return calculator.evaluate(
      policy,
      ShelfLifeQuery.fromBothDates(
        manufacturing: nsx,
        expiry: hsd,
        hasTimeOfDay: hasTime,
        isHourlyGoods: sop,
      ),
    );
  }

  ShelfLifeResult fromSpan({
    required CalculatorAnchor anchor,
    required DateTime date,
    required double value,
    required ShelfLifeUnit unit,
    bool hasTime = false,
    bool sop = false,
  }) {
    return calculator.evaluate(
      policy,
      ShelfLifeQuery.fromOneDateAndSpan(
        anchor: anchor,
        date: date,
        value: value,
        unit: unit,
        hasTimeOfDay: hasTime,
        isHourlyGoods: sop,
      ),
    );
  }

  group('the six handbook bands', () {
    test('a five day shelf life is destroyed two hours early', () {
      final ShelfLifeResult r =
          fromDates(DateTime(2026, 9, 7), DateTime(2026, 9, 12));
      expect(r.leadTime, const Duration(hours: 2));
      // Date-only labels are good through the printed day, so the deadline is
      // two hours before the end of it.
      expect(r.destroyAt, DateTime(2026, 9, 12, 21, 59, 59, 999));
    });

    test('a twenty day shelf life loses one day', () {
      final ShelfLifeResult r =
          fromDates(DateTime(2026, 8, 23), DateTime(2026, 9, 12));
      expect(r.leadTime, const Duration(days: 1));
      expect(r.destroyAt, DateTime(2026, 9, 11, 23, 59, 59, 999));
    });

    test('two months loses three days', () {
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 2,
        unit: ShelfLifeUnit.month,
      );
      expect(r.leadTime, const Duration(days: 3));
      expect(r.manufacturing, DateTime(2026, 7, 12));
      expect(r.destroyAt, DateTime(2026, 9, 9, 23, 59, 59, 999));
    });

    test('eight months loses five days', () {
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 8,
        unit: ShelfLifeUnit.month,
      );
      expect(r.leadTime, const Duration(days: 5));
      expect(r.destroyAt, DateTime(2026, 9, 7, 23, 59, 59, 999));
    });

    test('two years loses seven days', () {
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 2,
        unit: ShelfLifeUnit.year,
      );
      expect(r.leadTime, const Duration(days: 7));
      expect(r.manufacturing, DateTime(2024, 9, 12));
      expect(r.destroyAt, DateTime(2026, 9, 5, 23, 59, 59, 999));
    });

    test('three years or more loses a month', () {
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 3,
        unit: ShelfLifeUnit.year,
      );
      expect(r.leadTime, const Duration(days: 30));
      expect(r.destroyAt, DateTime(2026, 8, 13, 23, 59, 59, 999));
    });
  });

  group('band boundaries', () {
    test('exactly seven days is still the two hour band', () {
      // The first rule is inclusive at seven days, so a lot stated as a week
      // must not slip into the one-day band.
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 7,
        unit: ShelfLifeUnit.day,
      );
      expect(r.leadTime, const Duration(hours: 2));
    });

    test('one month is the three day band even in February', () {
      // February supplies 28 real days. Classifying by what the calendar
      // happened to give would drop a product whose label clearly says
      // "1 month" into the under-a-month band and destroy it two days late.
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.manufacturing,
        date: DateTime(2027, 2, 1),
        value: 1,
        unit: ShelfLifeUnit.month,
      );
      // 1 Feb 00:00 to 1 Mar 23:59:59.999 is 28 real days - short of the
      // 30-day threshold, which is exactly why the nominal span decides.
      expect(r.measuredShelfLife!.inDays, 28);
      expect(r.leadTime, const Duration(days: 3));
      expect(r.manufacturing, DateTime(2027, 2, 1));
      expect(r.expiryInstant, DateTime(2027, 3, 1, 23, 59, 59, 999));
    });

    test('one year is the seven day band, not the five day one', () {
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 1,
        unit: ShelfLifeUnit.year,
      );
      expect(r.leadTime, const Duration(days: 7));
    });
  });

  group('SOP goods', () {
    test('always lose two hours however long the shelf life', () {
      final ShelfLifeResult r = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12, 22),
        value: 2,
        unit: ShelfLifeUnit.year,
        hasTime: true,
        sop: true,
      );
      expect(r.isHourlyGoods, isTrue);
      expect(r.leadTime, const Duration(hours: 2));
      expect(r.destroyAt, DateTime(2026, 9, 12, 20));
    });

    test('need no shelf life at all to be answerable', () {
      // A tray of steamed buns has a printed sell-by moment and nothing else.
      final ShelfLifeResult r = calculator.evaluate(
        policy,
        ShelfLifeQuery.fromBothDates(
          manufacturing: DateTime(2026, 9, 12, 6),
          expiry: DateTime(2026, 9, 12, 18),
          hasTimeOfDay: true,
          isHourlyGoods: true,
        ),
      );
      expect(r.destroyAt, DateTime(2026, 9, 12, 16));
    });
  });

  group('calendar arithmetic', () {
    test('one month after 31 January is 28 February, not 3 March', () {
      expect(
        ShelfLifeCalculator.addCalendarMonths(DateTime(2027, 1, 31), 1),
        DateTime(2027, 2, 28),
      );
    });

    test('and 29 February in a leap year', () {
      expect(
        ShelfLifeCalculator.addCalendarMonths(DateTime(2028, 1, 31), 1),
        DateTime(2028, 2, 29),
      );
    });

    test('a year after 29 February clamps to 28 February', () {
      expect(
        ShelfLifeCalculator.addCalendarMonths(DateTime(2028, 2, 29), 12),
        DateTime(2029, 2, 28),
      );
    });

    test('going back across a year boundary works', () {
      expect(
        ShelfLifeCalculator.addCalendarMonths(DateTime(2026, 2, 15), -3),
        DateTime(2025, 11, 15),
      );
    });

    test('the time of day is carried through', () {
      expect(
        ShelfLifeCalculator.addCalendarMonths(DateTime(2026, 3, 15, 22, 30), 1),
        DateTime(2026, 4, 15, 22, 30),
      );
    });
  });

  group('working forwards and backwards agree', () {
    test('twenty days back from an expiry, then forwards again', () {
      final ShelfLifeResult back = fromSpan(
        anchor: CalculatorAnchor.expiry,
        date: DateTime(2026, 9, 12),
        value: 20,
        unit: ShelfLifeUnit.day,
      );
      expect(back.manufacturing, DateTime(2026, 8, 23));

      final ShelfLifeResult forward = fromSpan(
        anchor: CalculatorAnchor.manufacturing,
        date: DateTime(2026, 8, 23),
        value: 20,
        unit: ShelfLifeUnit.day,
      );
      expect(forward.expiryInstant, back.expiryInstant);
      expect(forward.destroyAt, back.destroyAt);
    });
  });

  group('honesty about what it does not know', () {
    test('an expiry with no shelf life refuses to guess a destroy time', () {
      // The wall calculator answers "two hours" here, by treating an unknown
      // shelf life as zero. That is a confidently wrong number on a
      // safety-critical field, so this one says it cannot tell instead.
      final ShelfLifeResult r = calculator.evaluate(
        policy,
        ShelfLifeQuery.fromOneDateAndSpan(
          anchor: CalculatorAnchor.expiry,
          date: DateTime(2026, 9, 12),
          value: 0,
          unit: ShelfLifeUnit.day,
        ),
      );
      // Zero *stated* days is a real answer - the ≤7 day band.
      expect(r.leadTime, const Duration(hours: 2));

      final ShelfLifeResult unknown = calculator.evaluate(
        policy,
        ShelfLifeQuery.expiryOnly(expiry: DateTime(2026, 9, 12)),
      );
      expect(unknown.isComplete, isFalse);
      expect(unknown.destroyAt, isNull);
      expect(unknown.manufacturing, isNull);
      // The expiry is still reported, because that much *is* known.
      expect(unknown.expiryInstant, DateTime(2026, 9, 12, 23, 59, 59, 999));
    });

    test('an expiry before the production date reports a zero shelf life', () {
      final ShelfLifeResult r =
          fromDates(DateTime(2026, 9, 20), DateTime(2026, 9, 12));
      expect(r.measuredShelfLife, Duration.zero);
      expect(r.leadTime, const Duration(hours: 2));
    });
  });

  group('it stays in step with the live engine', () {
    test('a date-only lot gets the same destroy instant as the real engine',
        () {
      // This is the test that matters most: if the calculator and the engine
      // that actually schedules destructions ever disagree, an employee gets
      // two different answers for one product.
      for (final int days in <int>[3, 7, 12, 45, 200, 400, 1200]) {
        final DateTime nsx = DateTime(2026, 1, 1);
        final DateTime hsd = nsx.add(Duration(days: days));

        final ShelfLifeResult fromCalculator = fromDates(nsx, hsd);
        final PolicyDecision fromEngine = engine.evaluate(
          policy,
          PolicyInput(
            expiry: hsd,
            receivedAt: nsx,
            precision: ExpiryPrecision.day,
            manufacturedAt: nsx,
          ),
        );

        expect(
          fromCalculator.destroyAt,
          fromEngine.destroyAt,
          reason: 'disagreed at a $days day shelf life',
        );
        expect(fromCalculator.leadTime, fromEngine.leadTime);
      }
    });

    test('every band comes from the policy rows, not from the calculator', () {
      // Halve every lead time and the calculator must follow, or it is
      // carrying its own private copy of the handbook.
      final DestroyPolicy halved = policy.copyWith(
        rules: policy.rules
            .map((r) => r.copyWith(leadTime: Duration(minutes: r.leadTime.inMinutes ~/ 2)))
            .toList(),
      );
      final ShelfLifeResult r = calculator.evaluate(
        halved,
        ShelfLifeQuery.fromBothDates(
          manufacturing: DateTime(2026, 8, 23),
          expiry: DateTime(2026, 9, 12),
        ),
      );
      expect(r.leadTime, const Duration(hours: 12));
    });
  });
}

class _SequentialIds implements IdGenerator {
  int _next = 0;

  @override
  String newId() => 'id-${_next++}';
}
