# Expiry Guardian

Quét hàng khi nhập, camera đọc hạn sử dụng, và một bộ quy tắc **do quản lý tự
cấu hình** quyết định chính xác lúc nào từng lô hàng phải rời kệ.
Chạy hoàn toàn offline. Dành cho cửa hàng tiện lợi, siêu thị và tạp hoá.

*Scan goods on arrival, read the expiry dates with the camera, and let a
configurable policy engine decide exactly when every lot must be destroyed.
Fully offline. Built for convenience stores, supermarkets and grocers.*

---

## Bắt đầu từ đâu / Where to start

| Bạn muốn | Đọc file |
|---|---|
| **Chạy app trên điện thoại** — từ file zip đến app cài xong, từng bước một | [`docs/HUONG_DAN_CHAY_TREN_DIEN_THOAI.md`](docs/HUONG_DAN_CHAY_TREN_DIEN_THOAI.md) |
| Hướng dẫn dùng cho nhân viên và quản lý cửa hàng | [`docs/HUONG_DAN_SU_DUNG.md`](docs/HUONG_DAN_SU_DUNG.md) |
| Kiến trúc mã nguồn | [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) |
| Cách bộ quy tắc huỷ hàng hoạt động | [`docs/POLICY_ENGINE.md`](docs/POLICY_ENGINE.md) |
| Quy trình vận hành: nhắc nhiều mốc, xác nhận huỷ, báo lên quản lý, nhật ký | [`docs/OPERATION_WORKFLOW.md`](docs/OPERATION_WORKFLOW.md) |
| Xuất báo cáo và hợp đồng nối Google Docs | [`docs/EXPORT.md`](docs/EXPORT.md) |
| Thử tính năng ngay trong trình duyệt, không cần build | [`tool/web_demo/`](tool/web_demo/) |
| Nối máy chủ đồng bộ sau này | [`docs/SYNC_CONTRACT.md`](docs/SYNC_CONTRACT.md) |

---

## Làm được gì

**Nhập hàng trong 3 chạm** — quét mã vạch → chụp hạn sử dụng → lưu. Mã vạch
GS1 trên thùng và khay thực phẩm tươi đã chứa sẵn hạn dùng và số lô, app đọc
thẳng và bỏ qua bước chụp.

**Nhận diện bằng camera** — mã vạch 1D/2D (ML Kit), OCR nhãn (chữ Latinh và
chữ Hán), tự cắt vùng chữ và chụp lại khi lần đọc đầu không ra ngày, tự đo độ
nét, tự sáng ảnh thiếu sáng, tự kéo tương phản, tự làm nét ảnh mờ.

**Bộ quy tắc huỷ hàng cấu hình toàn bộ** — 6 quy tắc mặc định theo tuổi thọ
sản phẩm, sửa được từng mốc, từng khoảng, từng thời gian huỷ trước hạn. App tự
kiểm tra và cảnh báo nếu chính sách có khoảng bị bỏ sót hoặc chồng lấn.

**Danh sách huỷ mỗi sáng** — tự sinh, sắp theo mức ưu tiên → khu vực → kệ →
sản phẩm, kèm màu và biểu tượng cảnh báo.

**Quy trình nhắc bốn mốc** — trước hạn huỷ 2 ngày (cảnh báo sớm), trước 1 ngày
(nhắc lần cuối), đúng lúc tới hạn (bắt buộc huỷ), rồi nhắc lại mỗi 1 giờ tối đa
24 lần **cho tới khi nhân viên xác nhận đã huỷ**. Mọi mốc và khoảng thời gian
đều sửa được trong app. Chạy offline, không cần dịch vụ nền.

**Xác nhận huỷ hàng** — mỗi lô huỷ đều phải có người xác nhận: nhân viên, thời
điểm, số lượng, ghi chú và ảnh (tuỳ chọn), và mã thiết bị. Xác nhận xong là
dừng nhắc ngay và đóng cảnh báo quản lý.

**Tự báo lên quản lý** — quá hạn huỷ 24 giờ mà chưa ai xác nhận thì tự tạo
cảnh báo cho quản lý, có bảng riêng, có mức nghiêm trọng, nhắc lại theo chu kỳ.
Quản lý tiếp nhận hoặc xử lý thay (bắt buộc ghi lý do). Toàn bộ quy tắc sửa
được.

**Nhật ký kiểm toán không sửa được** — mọi thao tác đều ghi lại kèm thời điểm,
người làm, thiết bị, giá trị cũ và mới. Các bản ghi móc xích với nhau bằng mã
băm SHA-256, cộng với trigger SQLite chặn mọi UPDATE/DELETE — sửa một dòng là
app phát hiện ra ngay.

**Xuất báo cáo ra file** — 6 mẫu (huỷ hàng ngày, tuần, tháng, kiểm toán, tồn
kho, hàng quá hạn) xuất ra PDF, HTML hoặc CSV rồi chia sẻ qua Zalo, Drive,
email. PDF dùng font đóng kèm nên dấu tiếng Việt in đúng.

**Báo cáo và dự báo** — thiệt hại, tỷ lệ huỷ đúng hạn, ngành hàng lãng phí
nhất, kệ hay quên hàng, lộ trình kiểm tra gợi ý, dự báo lãng phí tách rõ phần
chắc chắn và phần ước tính.

**Song ngữ** — tiếng Việt và English, đổi ngay trong app.

**Phân quyền** — Nhân viên / Quản lý / Quản trị.

---

## Không có dữ liệu giả

Đây là nguyên tắc xuyên suốt cả ứng dụng:

- Danh mục sản phẩm bắt đầu **rỗng**. Mã vạch lạ thì nhân viên nhập tên một
  lần; app không gọi ra ngoài và không bịa tên sản phẩm.
- OCR không đọc được ngày thì app **nói rõ là không đọc được** và yêu cầu nhập
  tay, thay vì đoán bừa.
- Chưa nhập giá vốn thì thiệt hại ghi nhận bằng 0, và mọi màn hình đều ghi rõ
  con số chỉ tính trên bao nhiêu lô có giá.
- Chưa đủ lịch sử thì phần dự báo hiển thị **"Chưa đủ dữ liệu"** kèm số mẫu
  hiện có, thay vì một tỷ lệ vô nghĩa.
- Bản offline dùng `UnconfiguredRemoteGateway` — nó **từ chối** thay vì giả vờ
  đồng bộ thành công, nên không thay đổi nào bị mất.
- Đích xuất Google Docs chưa nối thì **báo thẳng là chưa cấu hình** và không
  cho bấm, thay vì hiện thông báo "đã xuất" cho một tài liệu chưa từng tồn tại.
- Kỳ báo cáo không có dữ liệu thì file ghi rõ "Không có dữ liệu trong kỳ này" —
  không độn dòng mẫu.

---

## Công nghệ

| | |
|---|---|
| Giao diện | Flutter 3.47 / Dart 3.13, Material 3 |
| Trạng thái + DI | Riverpod (dùng làm container DI và host cho view model) |
| Cơ sở dữ liệu | SQLite (`sqflite`), migrations viết tay |
| Mã vạch | Google ML Kit Barcode Scanning + bộ phân tích GS1 tự viết |
| OCR | Google ML Kit Text Recognition (Latin + Chinese) |
| Xử lý ảnh | `package:image`, chạy trên isolate riêng |
| Thông báo | `flutter_local_notifications` (đặt lịch cục bộ, chạy offline) |
| Nhật ký kiểm toán | Chuỗi băm SHA-256 (`crypto`) + trigger SQLite chặn sửa/xoá |
| Xuất báo cáo | `package:pdf` + font Roboto đóng kèm; HTML và CSV tự viết |
| Kiến trúc | Clean Architecture, SOLID, Repository, MVVM |

---

## Chạy trên máy có Flutter

```bash
flutter pub get
flutter analyze          # 0 lỗi, 0 cảnh báo
flutter test             # 236 test
flutter run
```

Nếu thư mục `android/` bị thiếu hoặc lệch phiên bản Flutter:

```bash
flutter create --platforms=android --org com.expiryguardian --project-name expiry_guardian .
python3 tool/patch_android.py     # quyền, receiver thông báo, minSdk, desugaring
python3 tool/generate_icons.py    # vẽ lại icon (cần Pillow)
flutter build apk --release
```

Cả hai script đều chạy lại được nhiều lần mà không hỏng gì.

### Bàn thử trong trình duyệt

`tool/web_demo/` biên dịch các bộ máy quyết định thuần Dart — quy tắc huỷ hàng,
đọc nhãn, đọc mã GS1, lịch nhắc — sang JavaScript và gói thành **một file HTML
tự chứa**, mở bằng trình duyệt nào cũng chạy, không cần mạng:

```bash
dart compile js -O2 -o tool/web_demo/demo.js tool/web_demo/demo.dart
python3 tool/web_demo/build_page.py     # -> tool/web_demo/expiry_guardian_demo.html
node tool/web_demo/verify.mjs           # 33 phép kiểm, chốt theo đúng bộ test Dart
```

Đây là **cầu nối**, không phải bản viết lại: sửa quy tắc trong `lib/` thì trang
thử đổi theo, không có bản sao logic nào để lệch nhau.

---

## Yêu cầu thiết bị

- Android 7.0 (API 24) trở lên
- Camera sau
- Android 12+: cần cấp thêm quyền "Báo thức và nhắc nhở" để nhắc đúng phút
- Cần tắt tối ưu pin cho app, nếu không Android sẽ chặn thông báo nhắc huỷ —
  cách làm theo từng hãng máy có trong
  [`docs/HUONG_DAN_CHAY_TREN_DIEN_THOAI.md`](docs/HUONG_DAN_CHAY_TREN_DIEN_THOAI.md)

---

## Ký APK

Bản release được ký bằng khoá nằm sẵn trong `android/keystore/`, mật khẩu ghi
trong `tool/patch_android.py`. Cố ý như vậy: Android từ chối cài bản cập nhật
ký bằng khoá khác với bản đang cài, mà máy chủ CI thì sinh khoá debug mới mỗi
lần build — không có khoá cố định thì **file APK thứ hai một cửa hàng build ra
sẽ không cài đè được lên file thứ nhất**, và cách duy nhất là gỡ app, tức là
xoá sạch dữ liệu. Giữ kho ở chế độ Private thì không ai ngoài chủ kho build
được bản cập nhật mà điện thoại chịu nhận.
