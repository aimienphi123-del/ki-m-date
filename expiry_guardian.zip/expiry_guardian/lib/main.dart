import 'dart:async';

import 'package:expiry_guardian/app.dart';
import 'package:expiry_guardian/bootstrap.dart';
import 'package:expiry_guardian/core/di/dependencies.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

Future<void> main() async {
  final WidgetsBinding binding = WidgetsFlutterBinding.ensureInitialized();

  // Keep the platform splash up while the database opens and the policy is
  // seeded, so the first frame is the real app rather than a spinner.
  binding.deferFirstFrame();

  // Dates are formatted before any localization delegate loads - by the
  // reminder planner and by the report builder - so the symbols come first.
  await AppLocalizations.ensureDateFormattingReady();

  final Dependencies dependencies = await buildDependencies();
  final ProviderContainer container = ProviderContainer(
    overrides: <Override>[dependenciesProvider.overrideWithValue(dependencies)],
  );

  FlutterError.onError = (FlutterErrorDetails details) {
    dependencies.logger.e(
      'FlutterError',
      details.exceptionAsString(),
      error: details.exception,
      stackTrace: details.stack,
    );
    FlutterError.presentError(details);
  };

  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const ExpiryGuardianApp(),
    ),
  );

  binding.allowFirstFrame();

  // Reminders and background sync start after the UI is on screen.
  unawaited(() async {
    final AppLocalizations strings = container.read(stringsProvider);
    await scheduleRemindersAfterStartup(dependencies, strings);
    await dependencies.syncEngine.start();
  }());
}
