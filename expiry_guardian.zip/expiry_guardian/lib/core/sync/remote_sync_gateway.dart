import 'package:expiry_guardian/core/sync/sync_queue.dart';

/// Result of pushing one batch upstream.
class SyncPushResult {
  const SyncPushResult({required this.acceptedIds, this.rejected = const <int, String>{}});

  const SyncPushResult.allAccepted(this.acceptedIds) : rejected = const <int, String>{};

  final List<int> acceptedIds;

  /// Outbox id -> reason. Rejected entries stay queued with a back-off.
  final Map<int, String> rejected;
}

/// The seam between the local-first store and any future backend.
///
/// Expiry Guardian ships in offline-only mode: [UnconfiguredRemoteGateway] is
/// wired in and reports honestly that no backend exists. Adding Supabase,
/// Firebase or a company server later means implementing this one interface -
/// no repository, view model or screen changes.
abstract interface class RemoteSyncGateway {
  /// Human-readable name shown on the sync screen.
  String get displayName;

  /// False when no backend has been configured for this installation.
  bool get isConfigured;

  /// Cheap reachability probe. Never throws.
  Future<bool> isReachable();

  /// Pushes a batch of local changes upstream, in queue order.
  Future<SyncPushResult> push(List<OutboxEntry> batch);

  /// Pulls changes made on other devices since [since].
  /// Returns the entities that changed so the caller can refresh caches.
  Future<List<RemoteChange>> pull({DateTime? since});
}

class RemoteChange {
  const RemoteChange({
    required this.entity,
    required this.entityId,
    required this.updatedAt,
    required this.deleted,
    this.payload = const <String, Object?>{},
  });

  final String entity;
  final String entityId;
  final DateTime updatedAt;
  final bool deleted;
  final Map<String, Object?> payload;
}

/// Raised by a gateway when the remote refuses the whole batch.
class RemoteSyncException implements Exception {
  const RemoteSyncException(this.message, {this.retryable = true});
  final String message;
  final bool retryable;

  @override
  String toString() => 'RemoteSyncException($message, retryable=$retryable)';
}
