import 'package:expiry_guardian/core/sync/remote_sync_gateway.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';

/// The gateway used when the installation has no backend.
///
/// It is deliberately *not* a stub that pretends to succeed: it accepts
/// nothing, so the outbox keeps every change until a real backend is wired in.
/// The sync screen reads [isConfigured] and tells the user plainly that the
/// app is running in offline-only mode.
class UnconfiguredRemoteGateway implements RemoteSyncGateway {
  const UnconfiguredRemoteGateway();

  @override
  String get displayName => 'offline_only';

  @override
  bool get isConfigured => false;

  @override
  Future<bool> isReachable() async => false;

  @override
  Future<SyncPushResult> push(List<OutboxEntry> batch) async {
    throw const RemoteSyncException('No remote backend configured', retryable: false);
  }

  @override
  Future<List<RemoteChange>> pull({DateTime? since}) async {
    throw const RemoteSyncException('No remote backend configured', retryable: false);
  }
}
