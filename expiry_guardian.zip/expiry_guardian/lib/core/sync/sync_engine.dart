import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/sync/remote_sync_gateway.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';

enum SyncPhase { idle, checking, pushing, pulling, backingOff, offlineOnly, error }

class SyncStatus {
  const SyncStatus({
    required this.phase,
    required this.pendingChanges,
    required this.remoteConfigured,
    this.online = false,
    this.lastSuccessAt,
    this.lastAttemptAt,
    this.lastError,
  });

  final SyncPhase phase;
  final int pendingChanges;
  final bool remoteConfigured;
  final bool online;
  final DateTime? lastSuccessAt;
  final DateTime? lastAttemptAt;
  final String? lastError;

  SyncStatus copyWith({
    SyncPhase? phase,
    int? pendingChanges,
    bool? remoteConfigured,
    bool? online,
    DateTime? lastSuccessAt,
    DateTime? lastAttemptAt,
    String? lastError,
    bool clearError = false,
  }) {
    return SyncStatus(
      phase: phase ?? this.phase,
      pendingChanges: pendingChanges ?? this.pendingChanges,
      remoteConfigured: remoteConfigured ?? this.remoteConfigured,
      online: online ?? this.online,
      lastSuccessAt: lastSuccessAt ?? this.lastSuccessAt,
      lastAttemptAt: lastAttemptAt ?? this.lastAttemptAt,
      lastError: clearError ? null : (lastError ?? this.lastError),
    );
  }
}

/// Drains the outbox whenever connectivity returns.
///
/// The engine never blocks the UI: all writes have already been committed to
/// SQLite by the time it runs. If the push fails the entries stay queued with
/// exponential back-off.
class SyncEngine {
  SyncEngine({
    required SyncQueue queue,
    required RemoteSyncGateway gateway,
    required Connectivity connectivity,
    required Clock clock,
    required AppLogger logger,
    this.batchSize = 100,
    this.baseBackoff = const Duration(seconds: 30),
    this.maxBackoff = const Duration(hours: 6),
  })  : _queue = queue,
        _gateway = gateway,
        _connectivity = connectivity,
        _clock = clock,
        _logger = logger;

  final SyncQueue _queue;
  final RemoteSyncGateway _gateway;
  final Connectivity _connectivity;
  final Clock _clock;
  final AppLogger _logger;
  final int batchSize;
  final Duration baseBackoff;
  final Duration maxBackoff;

  static const String _tag = 'SyncEngine';

  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  Timer? _periodicTimer;
  bool _running = false;

  final StreamController<SyncStatus> _statusController =
      StreamController<SyncStatus>.broadcast();
  SyncStatus _status = const SyncStatus(
    phase: SyncPhase.idle,
    pendingChanges: 0,
    remoteConfigured: false,
  );

  Stream<SyncStatus> get status => _statusController.stream;
  SyncStatus get currentStatus => _status;

  Future<void> start({Duration interval = const Duration(minutes: 15)}) async {
    _emit(_status.copyWith(
      remoteConfigured: _gateway.isConfigured,
      phase: _gateway.isConfigured ? SyncPhase.idle : SyncPhase.offlineOnly,
      pendingChanges: await _queue.pendingCount(),
    ),);

    if (!_gateway.isConfigured) {
      _logger.i(_tag, 'Offline-only mode: no remote gateway configured.');
      return;
    }

    _connectivitySub = _connectivity.onConnectivityChanged.listen((List<ConnectivityResult> r) {
      final bool online = r.any((ConnectivityResult c) => c != ConnectivityResult.none);
      _emit(_status.copyWith(online: online));
      if (online) unawaited(syncNow());
    });
    _periodicTimer = Timer.periodic(interval, (_) => unawaited(syncNow()));
    await syncNow();
  }

  Future<void> stop() async {
    await _connectivitySub?.cancel();
    _connectivitySub = null;
    _periodicTimer?.cancel();
    _periodicTimer = null;
  }

  Future<void> dispose() async {
    await stop();
    await _statusController.close();
  }

  /// Refreshes the pending counter without contacting anything.
  Future<void> refreshPendingCount() async {
    _emit(_status.copyWith(pendingChanges: await _queue.pendingCount()));
  }

  Future<SyncStatus> syncNow() async {
    if (_running) return _status;
    if (!_gateway.isConfigured) {
      _emit(_status.copyWith(
        phase: SyncPhase.offlineOnly,
        pendingChanges: await _queue.pendingCount(),
      ),);
      return _status;
    }
    _running = true;
    _emit(_status.copyWith(phase: SyncPhase.checking, lastAttemptAt: _clock.now()));
    try {
      final bool reachable = await _gateway.isReachable();
      _emit(_status.copyWith(online: reachable));
      if (!reachable) {
        _emit(_status.copyWith(phase: SyncPhase.idle));
        return _status;
      }

      _emit(_status.copyWith(phase: SyncPhase.pushing));
      int pushed = 0;
      while (true) {
        final List<OutboxEntry> batch = await _queue.peek(limit: batchSize);
        if (batch.isEmpty) break;
        final SyncPushResult result = await _gateway.push(batch);
        await _queue.markSynced(result.acceptedIds);
        pushed += result.acceptedIds.length;
        for (final MapEntry<int, String> rejection in result.rejected.entries) {
          final OutboxEntry entry =
              batch.firstWhere((OutboxEntry e) => e.id == rejection.key);
          await _queue.markFailed(
            entry.id,
            rejection.value,
            retryAt: _clock.now().add(_backoffFor(entry.attempts + 1)),
          );
        }
        if (result.acceptedIds.isEmpty) break;
      }

      _emit(_status.copyWith(phase: SyncPhase.pulling));
      await _gateway.pull(since: _status.lastSuccessAt);

      _emit(_status.copyWith(
        phase: SyncPhase.idle,
        pendingChanges: await _queue.pendingCount(),
        lastSuccessAt: _clock.now(),
        clearError: true,
      ),);
      _logger.i(_tag, 'Sync finished, pushed $pushed change(s).');
    } on RemoteSyncException catch (e) {
      _logger.w(_tag, 'Sync failed: ${e.message}');
      _emit(_status.copyWith(
        phase: e.retryable ? SyncPhase.backingOff : SyncPhase.error,
        lastError: e.message,
        pendingChanges: await _queue.pendingCount(),
      ),);
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Unexpected sync failure', error: error, stackTrace: stackTrace);
      _emit(_status.copyWith(
        phase: SyncPhase.error,
        lastError: error.toString(),
        pendingChanges: await _queue.pendingCount(),
      ),);
    } finally {
      _running = false;
    }
    return _status;
  }

  Duration _backoffFor(int attempts) {
    final int factor = 1 << (attempts.clamp(1, 10) - 1);
    final Duration candidate = baseBackoff * factor;
    return candidate > maxBackoff ? maxBackoff : candidate;
  }

  void _emit(SyncStatus next) {
    _status = next;
    if (!_statusController.isClosed) _statusController.add(next);
  }
}
