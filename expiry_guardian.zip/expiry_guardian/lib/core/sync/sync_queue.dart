import 'dart:convert';

import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/utils/clock.dart';

enum SyncOperation { upsert, delete }

/// One durable change waiting to be pushed to a remote backend.
class OutboxEntry {
  const OutboxEntry({
    required this.id,
    required this.entity,
    required this.entityId,
    required this.operation,
    required this.payload,
    required this.createdAt,
    required this.attempts,
    this.lastError,
    this.nextAttemptAt,
  });

  final int id;
  final String entity;
  final String entityId;
  final SyncOperation operation;
  final Map<String, Object?> payload;
  final DateTime createdAt;
  final int attempts;
  final String? lastError;
  final DateTime? nextAttemptAt;
}

/// Append-only queue of local changes.
///
/// Every repository write goes through here. With no backend configured the
/// queue simply grows (it is small - a few hundred bytes per change) and the
/// app is fully usable; the moment a backend is configured the same entries
/// are replayed in order, so nothing captured offline is ever lost.
abstract interface class SyncQueue {
  Future<void> enqueueUpsert({
    required String entity,
    required String entityId,
    required Map<String, Object?> payload,
  });

  Future<void> enqueueDelete({required String entity, required String entityId});

  Future<List<OutboxEntry>> peek({int limit = 100, DateTime? readyAt});

  Future<void> markSynced(List<int> ids);

  Future<void> markFailed(int id, String error, {DateTime? retryAt});

  Future<int> pendingCount();

  Future<void> clear();
}

class SqfliteSyncQueue implements SyncQueue {
  const SqfliteSyncQueue(this._database, this._clock);

  final AppDatabase _database;
  final Clock _clock;

  @override
  Future<void> enqueueUpsert({
    required String entity,
    required String entityId,
    required Map<String, Object?> payload,
  }) =>
      _enqueue(entity, entityId, SyncOperation.upsert, payload);

  @override
  Future<void> enqueueDelete({required String entity, required String entityId}) =>
      _enqueue(entity, entityId, SyncOperation.delete, const <String, Object?>{});

  Future<void> _enqueue(
    String entity,
    String entityId,
    SyncOperation operation,
    Map<String, Object?> payload,
  ) async {
    await _database.db.insert(Tables.syncOutbox, <String, Object?>{
      'entity': entity,
      'entity_id': entityId,
      'operation': operation.name,
      'payload': jsonEncode(payload),
      'created_at': _clock.now().millisecondsSinceEpoch,
      'attempts': 0,
    });
    _database.notifyChanged(<String>[Tables.syncOutbox]);
  }

  @override
  Future<List<OutboxEntry>> peek({int limit = 100, DateTime? readyAt}) async {
    final int now = (readyAt ?? _clock.now()).millisecondsSinceEpoch;
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.syncOutbox,
      where: 'next_attempt_at IS NULL OR next_attempt_at <= ?',
      whereArgs: <Object?>[now],
      orderBy: 'id ASC',
      limit: limit,
    );
    return rows.map(_fromRow).toList();
  }

  OutboxEntry _fromRow(Map<String, Object?> row) {
    final Object? decoded = jsonDecode(row.str('payload'));
    return OutboxEntry(
      id: row.integer('id'),
      entity: row.str('entity'),
      entityId: row.str('entity_id'),
      operation: row.str('operation') == 'delete' ? SyncOperation.delete : SyncOperation.upsert,
      payload: decoded is Map<String, Object?> ? decoded : <String, Object?>{},
      createdAt: row.dateTime('created_at'),
      attempts: row.integer('attempts'),
      lastError: row.strOrNull('last_error'),
      nextAttemptAt: row.dateTimeOrNull('next_attempt_at'),
    );
  }

  @override
  Future<void> markSynced(List<int> ids) async {
    if (ids.isEmpty) return;
    final ({List<Object?> args, String clause}) where = inClause('id', ids);
    await _database.db.delete(Tables.syncOutbox, where: where.clause, whereArgs: where.args);
    _database.notifyChanged(<String>[Tables.syncOutbox]);
  }

  @override
  Future<void> markFailed(int id, String error, {DateTime? retryAt}) async {
    await _database.db.rawUpdate(
      'UPDATE ${Tables.syncOutbox} SET attempts = attempts + 1, last_error = ?, next_attempt_at = ? WHERE id = ?',
      <Object?>[error, retryAt?.millisecondsSinceEpoch, id],
    );
    _database.notifyChanged(<String>[Tables.syncOutbox]);
  }

  @override
  Future<int> pendingCount() =>
      countOf(_database.db, 'SELECT COUNT(*) FROM ${Tables.syncOutbox}');

  @override
  Future<void> clear() async {
    await _database.db.delete(Tables.syncOutbox);
    _database.notifyChanged(<String>[Tables.syncOutbox]);
  }
}

/// In-memory queue used by unit tests and by the "policy preview" sandbox.
class InMemorySyncQueue implements SyncQueue {
  InMemorySyncQueue(this._clock);

  final Clock _clock;
  final List<OutboxEntry> _entries = <OutboxEntry>[];
  int _nextId = 1;

  List<OutboxEntry> get entries => List<OutboxEntry>.unmodifiable(_entries);

  @override
  Future<void> enqueueUpsert({
    required String entity,
    required String entityId,
    required Map<String, Object?> payload,
  }) async {
    _entries.add(OutboxEntry(
      id: _nextId++,
      entity: entity,
      entityId: entityId,
      operation: SyncOperation.upsert,
      payload: payload,
      createdAt: _clock.now(),
      attempts: 0,
    ),);
  }

  @override
  Future<void> enqueueDelete({required String entity, required String entityId}) async {
    _entries.add(OutboxEntry(
      id: _nextId++,
      entity: entity,
      entityId: entityId,
      operation: SyncOperation.delete,
      payload: const <String, Object?>{},
      createdAt: _clock.now(),
      attempts: 0,
    ),);
  }

  @override
  Future<List<OutboxEntry>> peek({int limit = 100, DateTime? readyAt}) async =>
      _entries.take(limit).toList();

  @override
  Future<void> markSynced(List<int> ids) async =>
      _entries.removeWhere((OutboxEntry e) => ids.contains(e.id));

  @override
  Future<void> markFailed(int id, String error, {DateTime? retryAt}) async {}

  @override
  Future<int> pendingCount() async => _entries.length;

  @override
  Future<void> clear() async => _entries.clear();
}
