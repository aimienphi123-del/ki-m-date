import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:flutter/material.dart';

/// The colour language of the whole app.
///
/// Urgency is carried by colour **and** by an icon plus a text label, so the
/// app stays usable for colour-blind staff and in the bright light of a shop
/// floor.
class PriorityColors {
  const PriorityColors({
    required this.foreground,
    required this.background,
    required this.border,
    required this.onForeground,
  });

  final Color foreground;
  final Color background;
  final Color border;
  final Color onForeground;
}

abstract final class PriorityPalette {
  static const Map<PriorityLevel, PriorityColors> light = <PriorityLevel, PriorityColors>{
    PriorityLevel.safe: PriorityColors(
      foreground: Color(0xFF2E7D32),
      background: Color(0xFFE8F5E9),
      border: Color(0xFFA5D6A7),
      onForeground: Colors.white,
    ),
    PriorityLevel.approaching: PriorityColors(
      foreground: Color(0xFFB58100),
      background: Color(0xFFFFF8E1),
      border: Color(0xFFFFE082),
      onForeground: Colors.white,
    ),
    PriorityLevel.destroySoon: PriorityColors(
      foreground: Color(0xFFE65100),
      background: Color(0xFFFFF3E0),
      border: Color(0xFFFFCC80),
      onForeground: Colors.white,
    ),
    PriorityLevel.destroyNow: PriorityColors(
      foreground: Color(0xFFC62828),
      background: Color(0xFFFFEBEE),
      border: Color(0xFFEF9A9A),
      onForeground: Colors.white,
    ),
    PriorityLevel.expired: PriorityColors(
      foreground: Color(0xFF455A64),
      background: Color(0xFFECEFF1),
      border: Color(0xFFB0BEC5),
      onForeground: Colors.white,
    ),
  };

  static const Map<PriorityLevel, PriorityColors> dark = <PriorityLevel, PriorityColors>{
    PriorityLevel.safe: PriorityColors(
      foreground: Color(0xFF81C784),
      background: Color(0xFF14261A),
      border: Color(0xFF2E7D32),
      onForeground: Color(0xFF06210C),
    ),
    PriorityLevel.approaching: PriorityColors(
      foreground: Color(0xFFFFD54F),
      background: Color(0xFF2A2413),
      border: Color(0xFF8D6E00),
      onForeground: Color(0xFF241C00),
    ),
    PriorityLevel.destroySoon: PriorityColors(
      foreground: Color(0xFFFFB74D),
      background: Color(0xFF2E1F10),
      border: Color(0xFFB35400),
      onForeground: Color(0xFF2B1400),
    ),
    PriorityLevel.destroyNow: PriorityColors(
      foreground: Color(0xFFEF9A9A),
      background: Color(0xFF2E1516),
      border: Color(0xFFB71C1C),
      onForeground: Color(0xFF2A0407),
    ),
    PriorityLevel.expired: PriorityColors(
      foreground: Color(0xFFB0BEC5),
      background: Color(0xFF1E262A),
      border: Color(0xFF546E7A),
      onForeground: Color(0xFF0C1417),
    ),
  };

  static PriorityColors of(BuildContext context, PriorityLevel level) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Map<PriorityLevel, PriorityColors> table = isDark ? dark : light;
    return table[level] ?? table[PriorityLevel.safe]!;
  }

  static IconData iconOf(PriorityLevel level) => switch (level) {
        PriorityLevel.safe => Icons.check_circle_outline,
        PriorityLevel.approaching => Icons.schedule,
        PriorityLevel.destroySoon => Icons.warning_amber_rounded,
        PriorityLevel.destroyNow => Icons.local_fire_department_outlined,
        PriorityLevel.expired => Icons.block,
      };
}
