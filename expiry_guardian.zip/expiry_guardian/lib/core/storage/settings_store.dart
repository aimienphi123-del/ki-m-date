import 'dart:async';
import 'dart:convert';

import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:sqflite/sqflite.dart';

/// Typed access to the `app_settings` key/value table.
///
/// Anything a manager can configure that is not a policy rule lives here:
/// notification times, currency, working hours, feature toggles. Values are
/// stored as JSON so a setting can grow from a bool into an object without a
/// migration.
class SettingsStore {
  SettingsStore(this._database, this._clock);

  final AppDatabase _database;
  final Clock _clock;

  final Map<String, Object?> _cache = <String, Object?>{};
  bool _loaded = false;

  Future<void> load() async {
    final List<Map<String, Object?>> rows = await _database.db.query(Tables.settings);
    _cache.clear();
    for (final Map<String, Object?> row in rows) {
      _cache[row.str('key')] = _decode(row.str('value'));
    }
    _loaded = true;
  }

  Object? _decode(String raw) {
    try {
      return jsonDecode(raw);
    } on FormatException {
      return raw;
    }
  }

  void _assertLoaded() {
    if (!_loaded) throw StateError('SettingsStore.load() must be awaited first.');
  }

  T read<T>(String key, T fallback) {
    _assertLoaded();
    final Object? value = _cache[key];
    return value is T ? value : fallback;
  }

  int readInt(String key, int fallback) {
    _assertLoaded();
    final Object? value = _cache[key];
    if (value is int) return value;
    if (value is num) return value.toInt();
    return fallback;
  }

  double readDouble(String key, double fallback) {
    _assertLoaded();
    final Object? value = _cache[key];
    return value is num ? value.toDouble() : fallback;
  }

  bool readBool(String key, bool fallback) {
    _assertLoaded();
    final Object? value = _cache[key];
    if (value is bool) return value;
    if (value is num) return value != 0;
    return fallback;
  }

  String readString(String key, String fallback) {
    _assertLoaded();
    final Object? value = _cache[key];
    return value is String ? value : fallback;
  }

  List<int> readIntList(String key, List<int> fallback) {
    _assertLoaded();
    final Object? value = _cache[key];
    if (value is List) {
      return value.whereType<num>().map((num n) => n.toInt()).toList();
    }
    return fallback;
  }

  Future<void> write(String key, Object? value) async {
    _assertLoaded();
    _cache[key] = value;
    await _database.db.insert(
      Tables.settings,
      <String, Object?>{
        'key': key,
        'value': jsonEncode(value),
        'updated_at': _clock.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    _database.notifyChanged(<String>[Tables.settings]);
  }

  Future<void> writeAll(Map<String, Object?> values) async {
    _assertLoaded();
    final int now = _clock.now().millisecondsSinceEpoch;
    await _database.write(<String>{Tables.settings}, (Transaction txn) async {
      for (final MapEntry<String, Object?> entry in values.entries) {
        _cache[entry.key] = entry.value;
        await txn.insert(
          Tables.settings,
          <String, Object?>{
            'key': entry.key,
            'value': jsonEncode(entry.value),
            'updated_at': now,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  Map<String, Object?> snapshot() => Map<String, Object?>.unmodifiable(_cache);
}

/// Canonical setting keys with their shipped defaults.
abstract final class SettingKeys {
  static const String locale = 'app.locale';
  static const String themeMode = 'app.themeMode';
  static const String currencyCode = 'store.currency';
  static const String currencySymbol = 'store.currencySymbol';
  static const String storeName = 'store.name';
  static const String companyName = 'store.company';
  static const String storeCode = 'store.code';
  static const String deviceId = 'device.id';
  static const String deviceLabel = 'device.label';

  static const String dailyDigestMinutes = 'notifications.dailyDigestMinutes';
  static const String dailyDigestEnabled = 'notifications.dailyDigestEnabled';
  static const String digestHorizonDays = 'notifications.digestHorizonDays';
  static const String perItemAlertsEnabled = 'notifications.perItemEnabled';
  static const String maxScheduledNotifications = 'notifications.maxScheduled';

  /// Whether the employee has already been asked, so they are not nagged on
  /// every launch, and whether the answer was yes - which is what lets the app
  /// say out loud that reminders cannot be shown instead of failing quietly.
  static const String notificationPermissionAsked = 'notifications.permissionAsked';
  static const String notificationPermissionGranted = 'notifications.permissionGranted';
  static const String exactAlarmPermissionAsked = 'notifications.exactAlarmAsked';
  static const String quietHoursStartMinutes = 'notifications.quietStart';
  static const String quietHoursEndMinutes = 'notifications.quietEnd';

  static const String scanAutoAdvance = 'scan.autoAdvance';
  static const String scanEnhanceImages = 'scan.enhanceImages';
  static const String scanBlurThreshold = 'scan.blurThreshold';
  static const String scanLowLightThreshold = 'scan.lowLightThreshold';
  static const String scanDayFirstDates = 'scan.dayFirstDates';
  static const String scanMaxFutureYears = 'scan.maxFutureYears';
  static const String scanKeepPhotos = 'scan.keepPhotos';

  static const String insightsMinimumSamples = 'insights.minimumSamples';
  static const String insightsLookbackDays = 'insights.lookbackDays';
  static const String insightsForecastDays = 'insights.forecastDays';

  static const String defaultQuantity = 'intake.defaultQuantity';
  static const String requirePhotoOnDestroy = 'destroy.requirePhoto';
  static const String requireReasonOnDestroy = 'destroy.requireReason';

  static const String escalationEnabled = 'escalation.enabled';
  static const String escalationScanOnStart = 'escalation.scanOnStart';

  static const String exportIncludePhotos = 'export.includePhotos';
  static const String exportIncludeSignatures = 'export.includeSignatures';
  static const String exportIncludeStatistics = 'export.includeStatistics';
  static const String exportDefaultDestination = 'export.destination';
  static const String googleDocsClientId = 'export.googleDocsClientId';
  static const String googleDocsFolderId = 'export.googleDocsFolderId';
}

abstract final class SettingDefaults {
  static const String locale = 'vi';
  static const String themeMode = 'system';
  static const String currencyCode = 'VND';
  static const String currencySymbol = '₫';

  static const int dailyDigestMinutes = 7 * 60;
  static const bool dailyDigestEnabled = true;
  static const int digestHorizonDays = 7;
  static const bool perItemAlertsEnabled = true;

  /// Registering an OS alarm is a platform call, so this number is also the
  /// worst-case length of a reschedule. 180 covers the full hourly chase-up
  /// timeline for several simultaneously overdue lots and still finishes
  /// quickly on a low-end phone. Raise it in Settings if a store runs a much
  /// bigger catalogue and accepts the slower rebuild.
  static const int maxScheduledNotifications = 180;

  static const bool scanAutoAdvance = true;
  static const bool scanEnhanceImages = true;
  static const double scanBlurThreshold = 90;
  static const double scanLowLightThreshold = 70;
  static const bool scanDayFirstDates = true;
  static const int scanMaxFutureYears = 10;
  static const bool scanKeepPhotos = true;

  static const int insightsMinimumSamples = 8;
  static const int insightsLookbackDays = 180;
  static const int insightsForecastDays = 30;

  static const double defaultQuantity = 1;
  static const bool requirePhotoOnDestroy = false;
  static const bool requireReasonOnDestroy = false;

  static const bool escalationEnabled = true;
  static const bool escalationScanOnStart = true;

  static const bool exportIncludePhotos = false;
  static const bool exportIncludeSignatures = true;
  static const bool exportIncludeStatistics = true;
  static const String exportDefaultDestination = 'localPdf';
}
