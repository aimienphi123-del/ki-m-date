import 'package:shared_preferences/shared_preferences.dart';

/// Remembers who was signed in, so an employee is not asked for a password
/// every time the phone screen locks in the middle of a goods-in run.
abstract interface class SessionStore {
  Future<String?> readUserId();
  Future<void> writeUserId(String userId);
  Future<void> clear();
}

class PreferencesSessionStore implements SessionStore {
  const PreferencesSessionStore(this._preferences);

  final SharedPreferences _preferences;
  static const String _key = 'session.userId';

  @override
  Future<String?> readUserId() async => _preferences.getString(_key);

  @override
  Future<void> writeUserId(String userId) async =>
      _preferences.setString(_key, userId);

  @override
  Future<void> clear() async => _preferences.remove(_key);
}

class InMemorySessionStore implements SessionStore {
  String? _userId;

  @override
  Future<String?> readUserId() async => _userId;

  @override
  Future<void> writeUserId(String userId) async => _userId = userId;

  @override
  Future<void> clear() async => _userId = null;
}
