/// How precisely an expiry instant is known for a unit of stock.
///
/// * [day] - the label carries a calendar date only ("BBE 20/12/2026").
/// * [hour] - the label (or the store's own kitchen ticket) carries a time of
///   day as well. Fresh food, bubble tea, bakery, sushi, cut fruit.
enum ExpiryPrecision {
  day,
  hour;

  bool get isHourly => this == ExpiryPrecision.hour;

  static ExpiryPrecision fromName(String? value) => switch (value) {
        'hour' => ExpiryPrecision.hour,
        _ => ExpiryPrecision.day,
      };
}
