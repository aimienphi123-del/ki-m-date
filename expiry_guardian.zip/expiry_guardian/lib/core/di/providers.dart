import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/di/dependencies.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_workflow_repository.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/sync/sync_engine.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/auth/domain/repositories/auth_repository.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/insights/domain/repositories/insights_repository.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/repositories/location_repository.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/repositories/policy_repository.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:expiry_guardian/features/scan/domain/services/scan_pipeline.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Riverpod is used purely as the dependency-injection container plus the
/// view-model host: every provider below returns an interface built by
/// `buildDependencies`, never a concrete implementation created inline.
final Provider<Dependencies> dependenciesProvider = Provider<Dependencies>(
  (Ref ref) => throw UnimplementedError(
    'dependenciesProvider must be overridden in ProviderScope at startup.',
  ),
);

final Provider<Clock> clockProvider =
    Provider<Clock>((Ref ref) => ref.watch(dependenciesProvider).clock);

final Provider<SettingsStore> settingsStoreProvider =
    Provider<SettingsStore>((Ref ref) => ref.watch(dependenciesProvider).settings);

/// [SettingsStore] is a mutable cache rather than immutable state, so screens
/// watch this counter to know a setting changed. `writeSetting` bumps it.
final NotifierProvider<SettingsRevision, int> settingsRevisionProvider =
    NotifierProvider<SettingsRevision, int>(SettingsRevision.new);

class SettingsRevision extends Notifier<int> {
  @override
  int build() => 0;

  void bump() => state = state + 1;
}

/// Writes one setting and notifies every screen that reads settings.
Future<void> writeSetting(Ref ref, String key, Object? value) async {
  await ref.read(settingsStoreProvider).write(key, value);
  ref.read(settingsRevisionProvider.notifier).bump();
}

/// Writes several settings at once (one transaction, one notification).
Future<void> writeSettings(Ref ref, Map<String, Object?> values) async {
  await ref.read(settingsStoreProvider).writeAll(values);
  ref.read(settingsRevisionProvider.notifier).bump();
}

/// The same two helpers, called from a widget. Riverpod's `Ref` and `WidgetRef`
/// share no supertype, so the two-line body is repeated rather than casting one
/// into the other.
Future<void> writeSettingFrom(WidgetRef ref, String key, Object? value) async {
  await ref.read(settingsStoreProvider).write(key, value);
  ref.read(settingsRevisionProvider.notifier).bump();
}

Future<void> writeSettingsFrom(WidgetRef ref, Map<String, Object?> values) async {
  await ref.read(settingsStoreProvider).writeAll(values);
  ref.read(settingsRevisionProvider.notifier).bump();
}

final Provider<AuthRepository> authRepositoryProvider =
    Provider<AuthRepository>((Ref ref) => ref.watch(dependenciesProvider).authRepository);

final Provider<PolicyRepository> policyRepositoryProvider =
    Provider<PolicyRepository>((Ref ref) => ref.watch(dependenciesProvider).policyRepository);

final Provider<LocationRepository> locationRepositoryProvider =
    Provider<LocationRepository>((Ref ref) => ref.watch(dependenciesProvider).locationRepository);

final Provider<CatalogRepository> catalogRepositoryProvider =
    Provider<CatalogRepository>((Ref ref) => ref.watch(dependenciesProvider).catalogRepository);

final Provider<InventoryRepository> inventoryRepositoryProvider =
    Provider<InventoryRepository>((Ref ref) => ref.watch(dependenciesProvider).inventoryRepository);

final Provider<AnalyticsRepository> analyticsRepositoryProvider =
    Provider<AnalyticsRepository>((Ref ref) => ref.watch(dependenciesProvider).analyticsRepository);

final Provider<InsightsRepository> insightsRepositoryProvider =
    Provider<InsightsRepository>((Ref ref) => ref.watch(dependenciesProvider).insightsRepository);

final Provider<ExpiryPolicyEngine> policyEngineProvider =
    Provider<ExpiryPolicyEngine>((Ref ref) => ref.watch(dependenciesProvider).policyEngine);

final Provider<ScanPipeline> scanPipelineProvider =
    Provider<ScanPipeline>((Ref ref) => ref.watch(dependenciesProvider).scanPipeline);

/// Emits whenever any inventory row changes, so lists refresh without polling.
final StreamProvider<void> inventoryChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(inventoryRepositoryProvider).watchInventory(),
);

final StreamProvider<void> catalogChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(catalogRepositoryProvider).watchCatalog(),
);

final StreamProvider<void> locationChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(locationRepositoryProvider).watchLocations(),
);

final StreamProvider<DestroyPolicy> activePolicyProvider = StreamProvider<DestroyPolicy>(
  (Ref ref) => ref.watch(policyRepositoryProvider).watchActivePolicy(),
);

final StreamProvider<SyncStatus> syncStatusProvider = StreamProvider<SyncStatus>((Ref ref) {
  final SyncEngine engine = ref.watch(dependenciesProvider).syncEngine;
  return engine.status;
});

/// UI language. Defaults to Vietnamese and is persisted in `app_settings`.
class LocaleController extends Notifier<Locale> {
  @override
  Locale build() {
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    return Locale(settings.readString(SettingKeys.locale, SettingDefaults.locale));
  }

  Future<void> setLocale(Locale locale) async {
    await writeSetting(ref, SettingKeys.locale, locale.languageCode);
    state = locale;
  }
}

final NotifierProvider<LocaleController, Locale> localeProvider =
    NotifierProvider<LocaleController, Locale>(LocaleController.new);

class ThemeModeController extends Notifier<ThemeMode> {
  @override
  ThemeMode build() {
    ref.watch(settingsRevisionProvider);
    final String stored = ref
        .watch(settingsStoreProvider)
        .readString(SettingKeys.themeMode, SettingDefaults.themeMode);
    return switch (stored) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
  }

  Future<void> setMode(ThemeMode mode) async {
    await writeSetting(ref, SettingKeys.themeMode, mode.name);
    state = mode;
  }
}

final NotifierProvider<ThemeModeController, ThemeMode> themeModeProvider =
    NotifierProvider<ThemeModeController, ThemeMode>(ThemeModeController.new);

/// Localised strings outside the widget tree (used by the notification
/// planner, which builds its text before any BuildContext exists).
final Provider<AppLocalizations> stringsProvider =
    Provider<AppLocalizations>((Ref ref) => AppLocalizations(ref.watch(localeProvider)));

final Provider<NotificationPreferences> notificationPreferencesProvider =
    Provider<NotificationPreferences>((Ref ref) {
  ref.watch(settingsRevisionProvider);
  return NotificationPreferences.fromSettings(ref.watch(settingsStoreProvider));
});

/// Currency symbol used by every money label.
final Provider<String> currencySymbolProvider = Provider<String>((Ref ref) {
  ref.watch(settingsRevisionProvider);
  return ref
      .watch(settingsStoreProvider)
      .readString(SettingKeys.currencySymbol, SettingDefaults.currencySymbol);
});

// ------------------------------------------------------------- Phase X

final Provider<DeviceIdentityProvider> deviceIdentityProvider =
    Provider<DeviceIdentityProvider>((Ref ref) => ref.watch(dependenciesProvider).deviceIdentity);

final Provider<AuditRepository> auditRepositoryProvider =
    Provider<AuditRepository>((Ref ref) => ref.watch(dependenciesProvider).auditRepository);

final Provider<NotificationWorkflowRepository> notificationWorkflowRepositoryProvider =
    Provider<NotificationWorkflowRepository>(
  (Ref ref) => ref.watch(dependenciesProvider).notificationWorkflowRepository,
);

final Provider<EscalationRepository> escalationRepositoryProvider =
    Provider<EscalationRepository>((Ref ref) => ref.watch(dependenciesProvider).escalationRepository);

final Provider<BackupRepository> backupRepositoryProvider =
    Provider<BackupRepository>((Ref ref) => ref.watch(dependenciesProvider).backupRepository);

final Provider<DocumentExportRepository> documentExportRepositoryProvider =
    Provider<DocumentExportRepository>(
  (Ref ref) => ref.watch(dependenciesProvider).documentExportRepository,
);

/// The single owner of confirm -> cancel reminders -> resolve escalation.
final Provider<OperationWorkflowService> workflowServiceProvider =
    Provider<OperationWorkflowService>((Ref ref) => ref.watch(dependenciesProvider).workflowService);

/// The code reader, for the viewfinder's live scanning.
final Provider<BarcodeReader> barcodeReaderProvider =
    Provider<BarcodeReader>((Ref ref) => ref.watch(dependenciesProvider).barcodeReader);

/// The text recogniser, for reading printed dates off the viewfinder.
final Provider<TextReader> textReaderProvider =
    Provider<TextReader>((Ref ref) => ref.watch(dependenciesProvider).textReader);

final Provider<AppLogger> loggerProvider =
    Provider<AppLogger>((Ref ref) => ref.watch(dependenciesProvider).logger);

final StreamProvider<void> notificationStageChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(notificationWorkflowRepositoryProvider).watch(),
);

final StreamProvider<void> escalationChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(escalationRepositoryProvider).watch(),
);

final StreamProvider<void> auditChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(auditRepositoryProvider).watch(),
);

final StreamProvider<void> exportChangesProvider = StreamProvider<void>(
  (Ref ref) => ref.watch(documentExportRepositoryProvider).watch(),
);

/// How many escalations are open right now - drives the badge on the manager
/// tab. Recomputed whenever an escalation row changes.
final FutureProvider<int> openEscalationCountProvider = FutureProvider<int>((Ref ref) async {
  ref.watch(escalationChangesProvider);
  final Result<int> result = await ref.watch(escalationRepositoryProvider).openCount();
  return result.valueOrNull ?? 0;
});
