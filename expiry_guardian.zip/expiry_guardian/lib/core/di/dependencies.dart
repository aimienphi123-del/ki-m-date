import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_workflow_repository.dart';
import 'package:expiry_guardian/core/session/current_user_holder.dart';
import 'package:expiry_guardian/core/storage/session_store.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/sync/remote_sync_gateway.dart';
import 'package:expiry_guardian/core/sync/sync_engine.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/auth/domain/repositories/auth_repository.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/insights/domain/repositories/insights_repository.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/repositories/location_repository.dart';
import 'package:expiry_guardian/features/policy/domain/repositories/policy_repository.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:expiry_guardian/features/scan/domain/services/scan_pipeline.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';

/// The composition root's output: every collaborator the UI layer may need,
/// already wired, and exposed only through its interface.
///
/// Nothing above this class knows which database, which OCR engine or which
/// sync backend is in use - which is what makes the offline-only build and a
/// future server-backed build the same application.
class Dependencies {
  const Dependencies({
    required this.logger,
    required this.clock,
    required this.ids,
    required this.database,
    required this.settings,
    required this.session,
    required this.currentUser,
    required this.syncQueue,
    required this.remoteGateway,
    required this.syncEngine,
    required this.notificationGateway,
    required this.notificationPlanner,
    required this.notificationWorkflowRepository,
    required this.deviceIdentity,
    required this.auditRepository,
    required this.policyEngine,
    required this.authRepository,
    required this.policyRepository,
    required this.locationRepository,
    required this.catalogRepository,
    required this.inventoryRepository,
    required this.analyticsRepository,
    required this.insightsRepository,
    required this.escalationRepository,
    required this.documentExportRepository,
    required this.backupRepository,
    required this.workflowService,
    required this.scanPipeline,
    required this.barcodeReader,
    required this.textReader,
    required this.appVersion,
    required this.appBuild,
  });

  final AppLogger logger;
  final Clock clock;
  final IdGenerator ids;
  final AppDatabase database;
  final SettingsStore settings;
  final SessionStore session;

  /// Who is signed in, for the layers that write audit rows outside the tree.
  final CurrentUserHolder currentUser;

  final SyncQueue syncQueue;
  final RemoteSyncGateway remoteGateway;
  final SyncEngine syncEngine;

  final NotificationGateway notificationGateway;
  final NotificationPlanner notificationPlanner;

  /// Phase X: the configurable reminder timeline, the append-only log and the
  /// identity this handset stamps on everything it records.
  final NotificationWorkflowRepository notificationWorkflowRepository;
  final DeviceIdentityProvider deviceIdentity;
  final AuditRepository auditRepository;

  final ExpiryPolicyEngine policyEngine;

  final AuthRepository authRepository;
  final PolicyRepository policyRepository;
  final LocationRepository locationRepository;
  final CatalogRepository catalogRepository;
  final InventoryRepository inventoryRepository;
  final AnalyticsRepository analyticsRepository;
  final InsightsRepository insightsRepository;
  final EscalationRepository escalationRepository;
  final DocumentExportRepository documentExportRepository;
  final BackupRepository backupRepository;

  /// The single owner of the confirm -> cancel reminders -> resolve escalation
  /// sequence. The UI calls this, never the repositories directly.
  final OperationWorkflowService workflowService;

  final ScanPipeline scanPipeline;

  /// Exposed on its own as well as inside [scanPipeline] because the
  /// viewfinder reads codes straight off the live stream, before there is
  /// any still for the pipeline to work on.
  final BarcodeReader barcodeReader;

  /// Exposed for the same reason as [barcodeReader]: the viewfinder reads
  /// printed dates off the live stream, before any still exists.
  final TextReader textReader;

  final String appVersion;
  final String appBuild;
}
