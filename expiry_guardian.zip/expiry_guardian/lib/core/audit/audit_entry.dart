/// Every operation the app records. Adding a value here is the only thing
/// needed to make a new kind of action auditable.
enum AuditAction {
  // Inventory lifecycle
  productCreated,
  productUpdated,
  productDeleted,
  recordCreated,
  recordScanned,
  recordEdited,
  recordMoved,
  quantityAdjusted,
  recordClosed,

  // Destruction workflow
  destroyReminderScheduled,
  destroyReminderFired,
  destroyConfirmed,

  // Escalation
  escalationRaised,
  escalationNotified,
  escalationAcknowledged,
  escalationResolved,
  managerOverride,

  // Configuration
  policyEdited,
  policyRuleEdited,
  policyRecalculated,
  notificationStageEdited,
  escalationRuleEdited,
  locationEdited,
  settingChanged,

  // Access
  userCreated,
  userUpdated,
  userSignedIn,
  userSignedOut,
  passwordChanged,

  // Reporting
  reportExported,
  dataReset;

  static AuditAction fromName(String? value) => AuditAction.values.firstWhere(
        (AuditAction a) => a.name == value,
        orElse: () => AuditAction.settingChanged,
      );
}

/// One immutable line of the audit trail.
///
/// Rows are chained: each carries the hash of the previous row plus its own
/// hash over (previousHash + its own content). Changing or removing any row
/// therefore breaks every hash after it, which
/// [AuditRepository.verifyChain] detects. The table additionally has SQLite
/// triggers that abort any UPDATE or DELETE.
class AuditEntry {
  const AuditEntry({
    required this.id,
    required this.sequence,
    required this.occurredAt,
    required this.action,
    required this.entity,
    required this.previousHash,
    required this.hash,
    this.entityId,
    this.entityLabel,
    this.actorId,
    this.actorName,
    this.actorRole,
    this.deviceId,
    this.previousValue,
    this.newValue,
    this.imagePath,
    this.note,
  });

  final String id;

  /// Monotonic position in the chain (SQLite AUTOINCREMENT).
  final int sequence;

  final DateTime occurredAt;
  final AuditAction action;

  /// Table or concept the action applies to, e.g. `inventory_records`.
  final String entity;
  final String? entityId;

  /// Human-readable name of the thing, captured at the time, so the log still
  /// reads correctly after the product is renamed.
  final String? entityLabel;

  final String? actorId;
  final String? actorName;
  final String? actorRole;
  final String? deviceId;

  /// JSON of the fields before and after. `null` for creations / deletions.
  final Map<String, Object?>? previousValue;
  final Map<String, Object?>? newValue;

  final String? imagePath;
  final String? note;

  final String previousHash;
  final String hash;

  /// The fields that go into the hash, in a fixed order.
  List<Object?> get hashedFields => <Object?>[
        id,
        occurredAt.millisecondsSinceEpoch,
        action.name,
        entity,
        entityId,
        entityLabel,
        actorId,
        actorName,
        actorRole,
        deviceId,
        previousValue,
        newValue,
        imagePath,
        note,
      ];

  @override
  String toString() => 'AuditEntry(#$sequence ${action.name} $entity/$entityId)';
}

/// A request to append to the trail. The repository fills in the id, the
/// sequence, the hashes and - unless overridden - the actor and device.
class AuditDraft {
  const AuditDraft({
    required this.action,
    required this.entity,
    this.entityId,
    this.entityLabel,
    this.previousValue,
    this.newValue,
    this.imagePath,
    this.note,
    this.occurredAt,
    this.actorId,
    this.actorName,
    this.actorRole,
  });

  final AuditAction action;
  final String entity;
  final String? entityId;
  final String? entityLabel;
  final Map<String, Object?>? previousValue;
  final Map<String, Object?>? newValue;
  final String? imagePath;
  final String? note;
  final DateTime? occurredAt;
  final String? actorId;
  final String? actorName;
  final String? actorRole;
}

/// Filter for the audit screen and for the audit report.
class AuditQuery {
  const AuditQuery({
    this.from,
    this.to,
    this.actions = const <AuditAction>{},
    this.entity,
    this.entityId,
    this.actorId,
    this.text,
    this.limit = 200,
    this.offset = 0,
  });

  final DateTime? from;
  final DateTime? to;
  final Set<AuditAction> actions;
  final String? entity;
  final String? entityId;
  final String? actorId;
  final String? text;
  final int limit;
  final int offset;

  AuditQuery copyWith({
    DateTime? from,
    bool clearFrom = false,
    DateTime? to,
    bool clearTo = false,
    Set<AuditAction>? actions,
    String? entity,
    bool clearEntity = false,
    String? entityId,
    String? actorId,
    bool clearActor = false,
    String? text,
    bool clearText = false,
    int? limit,
    int? offset,
  }) {
    return AuditQuery(
      from: clearFrom ? null : (from ?? this.from),
      to: clearTo ? null : (to ?? this.to),
      actions: actions ?? this.actions,
      entity: clearEntity ? null : (entity ?? this.entity),
      entityId: entityId ?? this.entityId,
      actorId: clearActor ? null : (actorId ?? this.actorId),
      text: clearText ? null : (text ?? this.text),
      limit: limit ?? this.limit,
      offset: offset ?? this.offset,
    );
  }
}

/// Result of re-hashing the whole chain.
class AuditIntegrityReport {
  const AuditIntegrityReport({
    required this.entriesChecked,
    required this.isIntact,
    required this.checkedAt,
    this.firstBrokenSequence,
    this.detail,
  });

  final int entriesChecked;
  final bool isIntact;
  final DateTime checkedAt;

  /// Where the chain first stops matching, if it does.
  final int? firstBrokenSequence;
  final String? detail;
}
