import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/result/result.dart';

/// Append-only, tamper-evident record of everything that happens.
///
/// There is deliberately no update or delete method: the interface itself
/// makes the log immutable, and the SQLite triggers enforce it even against
/// hand-written SQL.
abstract interface class AuditRepository {
  /// Appends one entry and returns it, complete with its chain hashes.
  Future<Result<AuditEntry>> append(AuditDraft draft);

  /// Appends several entries as one atomic chain extension.
  Future<Result<List<AuditEntry>>> appendAll(List<AuditDraft> drafts);

  Future<Result<List<AuditEntry>>> query(AuditQuery query);

  Future<Result<int>> count(AuditQuery query);

  /// Re-computes every hash and reports where, if anywhere, the chain breaks.
  Future<Result<AuditIntegrityReport>> verifyChain();

  /// Emits whenever a new entry is appended.
  Stream<void> watch();
}
