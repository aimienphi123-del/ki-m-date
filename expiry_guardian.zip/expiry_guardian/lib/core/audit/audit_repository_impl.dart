import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:sqflite/sqflite.dart';

/// Who is acting right now. Supplied by the session so the repository does not
/// depend on the auth feature.
class AuditActor {
  const AuditActor({this.id, this.name, this.role});

  const AuditActor.system() : id = null, name = 'system', role = 'system';

  final String? id;
  final String? name;
  final String? role;
}

typedef AuditActorResolver = AuditActor Function();

class AuditRepositoryImpl implements AuditRepository {
  AuditRepositoryImpl({
    required AppDatabase database,
    required Clock clock,
    required IdGenerator ids,
    required DeviceIdentityProvider device,
    required AuditActorResolver actor,
    required AppLogger logger,
  })  : _database = database,
        _clock = clock,
        _ids = ids,
        _device = device,
        _actor = actor,
        _logger = logger;

  final AppDatabase _database;
  final Clock _clock;
  final IdGenerator _ids;
  final DeviceIdentityProvider _device;
  final AuditActorResolver _actor;
  final AppLogger _logger;

  static const String _tag = 'AuditRepository';

  /// Hash of the (empty) entry zero. Every chain starts here.
  static const String genesisHash =
      '0000000000000000000000000000000000000000000000000000000000000000';

  @override
  Future<Result<AuditEntry>> append(AuditDraft draft) async {
    final Result<List<AuditEntry>> result = await appendAll(<AuditDraft>[draft]);
    return result.map((List<AuditEntry> entries) => entries.single);
  }

  @override
  Future<Result<List<AuditEntry>>> appendAll(List<AuditDraft> drafts) async {
    if (drafts.isEmpty) return const Result<List<AuditEntry>>.ok(<AuditEntry>[]);
    try {
      final AuditActor actor = _actor();
      final String deviceId = _device.current.id;
      final List<AuditEntry> written = <AuditEntry>[];

      await _database.write(<String>{Tables.auditLog}, (Transaction txn) async {
        String previousHash = await _headHash(txn);
        for (final AuditDraft draft in drafts) {
          final String id = _ids.newId();
          final DateTime at = draft.occurredAt ?? _clock.now();
          final AuditEntry unhashed = AuditEntry(
            id: id,
            sequence: 0,
            occurredAt: at,
            action: draft.action,
            entity: draft.entity,
            entityId: draft.entityId,
            entityLabel: draft.entityLabel,
            actorId: draft.actorId ?? actor.id,
            actorName: draft.actorName ?? actor.name,
            actorRole: draft.actorRole ?? actor.role,
            deviceId: deviceId,
            previousValue: draft.previousValue,
            newValue: draft.newValue,
            imagePath: draft.imagePath,
            note: draft.note,
            previousHash: previousHash,
            hash: '',
          );
          final String hash = computeHash(previousHash, unhashed.hashedFields);

          final int sequence = await txn.insert(Tables.auditLog, <String, Object?>{
            'id': id,
            'occurred_at': at.millisecondsSinceEpoch,
            'action': draft.action.name,
            'entity': draft.entity,
            'entity_id': draft.entityId,
            'entity_label': draft.entityLabel,
            'actor_id': unhashed.actorId,
            'actor_name': unhashed.actorName,
            'actor_role': unhashed.actorRole,
            'device_id': deviceId,
            'previous_value': _encode(draft.previousValue),
            'new_value': _encode(draft.newValue),
            'image_path': draft.imagePath,
            'note': draft.note,
            'previous_hash': previousHash,
            'hash': hash,
          });

          written.add(AuditEntry(
            id: id,
            sequence: sequence,
            occurredAt: at,
            action: draft.action,
            entity: draft.entity,
            entityId: draft.entityId,
            entityLabel: draft.entityLabel,
            actorId: unhashed.actorId,
            actorName: unhashed.actorName,
            actorRole: unhashed.actorRole,
            deviceId: deviceId,
            previousValue: draft.previousValue,
            newValue: draft.newValue,
            imagePath: draft.imagePath,
            note: draft.note,
            previousHash: previousHash,
            hash: hash,
          ),);
          previousHash = hash;
        }
      });
      return Result<List<AuditEntry>>.ok(written);
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Could not append to the audit trail',
          error: error, stackTrace: stackTrace,);
      return Result<List<AuditEntry>>.err(
        Failure.database('audit_append_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  Future<String> _headHash(DatabaseExecutor txn) async {
    final List<Map<String, Object?>> rows = await txn.rawQuery(
      'SELECT hash FROM ${Tables.auditLog} ORDER BY seq DESC LIMIT 1',
    );
    return rows.isEmpty ? genesisHash : rows.first.str('hash');
  }

  /// SHA-256 over the previous hash plus a canonical encoding of the fields.
  static String computeHash(String previousHash, List<Object?> fields) {
    final String canonical = jsonEncode(<Object?>[previousHash, ...fields]);
    return sha256.convert(utf8.encode(canonical)).toString();
  }

  static String? _encode(Map<String, Object?>? value) =>
      value == null ? null : jsonEncode(value);

  static Map<String, Object?>? _decode(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    final Object? decoded = jsonDecode(raw);
    return decoded is Map<String, Object?> ? decoded : null;
  }

  @override
  Future<Result<List<AuditEntry>>> query(AuditQuery query) async {
    return _guard(() async {
      final ({List<Object?> args, String where}) filter = _buildWhere(query);
      final List<Map<String, Object?>> rows = await _database.db.rawQuery(
        'SELECT * FROM ${Tables.auditLog} ${filter.where} '
        'ORDER BY seq DESC LIMIT ? OFFSET ?',
        <Object?>[...filter.args, query.limit, query.offset],
      );
      return rows.map(_fromRow).toList(growable: false);
    });
  }

  @override
  Future<Result<int>> count(AuditQuery query) async {
    return _guard(() async {
      final ({List<Object?> args, String where}) filter = _buildWhere(query);
      return countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.auditLog} ${filter.where}',
        filter.args,
      );
    });
  }

  ({String where, List<Object?> args}) _buildWhere(AuditQuery query) {
    final List<String> clauses = <String>[];
    final List<Object?> args = <Object?>[];

    if (query.from != null) {
      clauses.add('occurred_at >= ?');
      args.add(query.from!.millisecondsSinceEpoch);
    }
    if (query.to != null) {
      clauses.add('occurred_at < ?');
      args.add(query.to!.millisecondsSinceEpoch);
    }
    if (query.actions.isNotEmpty) {
      final ({List<Object?> args, String clause}) inList = inClause(
        'action',
        query.actions.map((AuditAction a) => a.name).toList(),
      );
      clauses.add(inList.clause);
      args.addAll(inList.args);
    }
    if (query.entity != null) {
      clauses.add('entity = ?');
      args.add(query.entity);
    }
    if (query.entityId != null) {
      clauses.add('entity_id = ?');
      args.add(query.entityId);
    }
    if (query.actorId != null) {
      clauses.add('actor_id = ?');
      args.add(query.actorId);
    }
    final String? text = query.text?.trim();
    if (text != null && text.isNotEmpty) {
      clauses.add(
        r"(entity_label LIKE ? ESCAPE '\' OR actor_name LIKE ? ESCAPE '\'"
        r" OR note LIKE ? ESCAPE '\')",
      );
      final String like = likeArgument(text);
      args.addAll(<Object?>[like, like, like]);
    }
    return (
      where: clauses.isEmpty ? '' : 'WHERE ${clauses.join(' AND ')}',
      args: args,
    );
  }

  AuditEntry _fromRow(Map<String, Object?> row) => AuditEntry(
        id: row.str('id'),
        sequence: row.integer('seq'),
        occurredAt: row.dateTime('occurred_at'),
        action: AuditAction.fromName(row.strOrNull('action')),
        entity: row.str('entity'),
        entityId: row.strOrNull('entity_id'),
        entityLabel: row.strOrNull('entity_label'),
        actorId: row.strOrNull('actor_id'),
        actorName: row.strOrNull('actor_name'),
        actorRole: row.strOrNull('actor_role'),
        deviceId: row.strOrNull('device_id'),
        previousValue: _decode(row.strOrNull('previous_value')),
        newValue: _decode(row.strOrNull('new_value')),
        imagePath: row.strOrNull('image_path'),
        note: row.strOrNull('note'),
        previousHash: row.str('previous_hash'),
        hash: row.str('hash'),
      );

  @override
  Future<Result<AuditIntegrityReport>> verifyChain() async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db
          .rawQuery('SELECT * FROM ${Tables.auditLog} ORDER BY seq ASC');

      String expectedPrevious = genesisHash;
      int checked = 0;

      for (final Map<String, Object?> row in rows) {
        final AuditEntry entry = _fromRow(row);
        checked++;
        if (entry.previousHash != expectedPrevious) {
          return AuditIntegrityReport(
            entriesChecked: checked,
            isIntact: false,
            checkedAt: _clock.now(),
            firstBrokenSequence: entry.sequence,
            detail: 'previous_hash does not match the entry before it',
          );
        }
        final String recomputed = computeHash(entry.previousHash, entry.hashedFields);
        if (recomputed != entry.hash) {
          return AuditIntegrityReport(
            entriesChecked: checked,
            isIntact: false,
            checkedAt: _clock.now(),
            firstBrokenSequence: entry.sequence,
            detail: 'content does not match the stored hash',
          );
        }
        expectedPrevious = entry.hash;
      }

      return AuditIntegrityReport(
        entriesChecked: checked,
        isIntact: true,
        checkedAt: _clock.now(),
      );
    });
  }

  @override
  Stream<void> watch() =>
      _database.changes.where((String table) => table == Tables.auditLog);

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Audit query failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('audit_query_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
