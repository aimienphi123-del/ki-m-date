import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';

/// Who is signed in, readable from outside the widget tree.
///
/// The audit trail, the escalation repository and the workflow service all need
/// to stamp an actor on what they write, and they run in places where no
/// `BuildContext` and no Riverpod `Ref` exists - a notification callback, a
/// background reschedule. Rather than pass the session through every
/// constructor, the composition root builds one holder and the session
/// view-model keeps it current.
///
/// It holds a reference only. Nothing is persisted here; the durable session
/// still lives in [SessionStore].
class CurrentUserHolder {
  CurrentUserHolder([this.user]);

  AppUser? user;

  String? get id => user?.id;

  String? get displayName => user?.displayName;

  void clear() => user = null;
}
