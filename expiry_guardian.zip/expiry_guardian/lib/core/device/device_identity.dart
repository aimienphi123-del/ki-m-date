import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/utils/id.dart';

/// Which phone an action was performed on.
///
/// Destruction confirmations and audit entries record this so a manager can
/// tell two employees' handsets apart, and so a lost or replaced device can be
/// traced through the log. It is a random id generated on first launch - no
/// hardware identifier is read, so nothing here can identify a person.
class DeviceIdentity {
  const DeviceIdentity({required this.id, required this.label});

  final String id;

  /// Editable in Settings, e.g. "Máy quầy 1". Empty until someone names it.
  final String label;

  String get shortId => id.length <= 8 ? id : id.substring(0, 8);

  String get displayName => label.isEmpty ? shortId : '$label ($shortId)';
}

abstract interface class DeviceIdentityProvider {
  DeviceIdentity get current;
  Future<void> rename(String label);
}

class SettingsDeviceIdentityProvider implements DeviceIdentityProvider {
  SettingsDeviceIdentityProvider(this._settings, this._id);

  final SettingsStore _settings;
  final String _id;

  /// Reads the stored id, creating one on first launch.
  static Future<SettingsDeviceIdentityProvider> resolve(
    SettingsStore settings,
    IdGenerator ids,
  ) async {
    String id = settings.readString(SettingKeys.deviceId, '');
    if (id.isEmpty) {
      id = ids.newId();
      await settings.write(SettingKeys.deviceId, id);
    }
    return SettingsDeviceIdentityProvider(settings, id);
  }

  /// Read through to the settings store rather than cached, so a rename made
  /// anywhere - this class, or the settings screen writing the key directly -
  /// shows up in the very next audit row.
  @override
  DeviceIdentity get current => DeviceIdentity(
        id: _id,
        label: _settings.readString(SettingKeys.deviceLabel, ''),
      );

  @override
  Future<void> rename(String label) async =>
      _settings.write(SettingKeys.deviceLabel, label.trim());
}

/// Fixed identity for tests.
class StaticDeviceIdentityProvider implements DeviceIdentityProvider {
  StaticDeviceIdentityProvider([
    this._identity = const DeviceIdentity(id: 'test-device', label: 'Test'),
  ]);

  DeviceIdentity _identity;

  @override
  DeviceIdentity get current => _identity;

  @override
  Future<void> rename(String label) async =>
      _identity = DeviceIdentity(id: _identity.id, label: label);
}
