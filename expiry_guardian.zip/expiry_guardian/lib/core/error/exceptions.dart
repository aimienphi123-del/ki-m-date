/// Thrown by data sources when a row that must exist cannot be found.
class RecordNotFoundException implements Exception {
  const RecordNotFoundException(this.entity, this.id);
  final String entity;
  final String id;

  @override
  String toString() => 'RecordNotFoundException($entity, $id)';
}

/// Thrown by data sources when a uniqueness constraint would be violated.
class DuplicateRecordException implements Exception {
  const DuplicateRecordException(this.entity, this.field, this.value);
  final String entity;
  final String field;
  final String value;

  @override
  String toString() => 'DuplicateRecordException($entity.$field = $value)';
}

/// Thrown when a caller lacks the role required for an operation.
class NotAuthorizedException implements Exception {
  const NotAuthorizedException(this.action);
  final String action;

  @override
  String toString() => 'NotAuthorizedException($action)';
}

/// Thrown when the camera pipeline cannot start or produce a frame.
class CameraPipelineException implements Exception {
  const CameraPipelineException(this.message, [this.cause]);
  final String message;
  final Object? cause;

  @override
  String toString() => 'CameraPipelineException($message)';
}
