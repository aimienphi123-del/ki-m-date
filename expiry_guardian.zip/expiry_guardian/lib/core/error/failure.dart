/// Machine-readable failure codes.
///
/// The UI never renders [Failure.message] directly for known codes; it maps
/// [FailureCode] onto a localized string so the app stays fully bilingual.
enum FailureCode {
  unknown,
  database,
  notFound,
  duplicate,
  validation,
  permissionDenied,
  unauthenticated,
  cameraUnavailable,
  recognitionFailed,
  remoteUnavailable,
  remoteNotConfigured,
  conflict,
  io,
}

/// Domain-level error. Never thrown across layer boundaries - it is carried
/// inside [Result].
class Failure {
  const Failure({
    required this.code,
    required this.message,
    this.cause,
    this.stackTrace,
    this.context = const <String, Object?>{},
  });

  const Failure.database(String message, {Object? cause, StackTrace? stackTrace})
      : this(code: FailureCode.database, message: message, cause: cause, stackTrace: stackTrace);

  const Failure.notFound(String message) : this(code: FailureCode.notFound, message: message);

  const Failure.duplicate(String message) : this(code: FailureCode.duplicate, message: message);

  const Failure.validation(String message, {Map<String, Object?> context = const <String, Object?>{}})
      : this(code: FailureCode.validation, message: message, context: context);

  const Failure.permissionDenied(String message)
      : this(code: FailureCode.permissionDenied, message: message);

  const Failure.unauthenticated(String message)
      : this(code: FailureCode.unauthenticated, message: message);

  const Failure.unknown(String message, {Object? cause, StackTrace? stackTrace})
      : this(code: FailureCode.unknown, message: message, cause: cause, stackTrace: stackTrace);

  const Failure.io(String message, {Object? cause, StackTrace? stackTrace})
      : this(code: FailureCode.io, message: message, cause: cause, stackTrace: stackTrace);

  /// A destination the store has not connected yet. [message] carries a
  /// localization key so the reason reaches the shop floor in its own language.
  const Failure.notConfigured(String message)
      : this(code: FailureCode.remoteNotConfigured, message: message);

  final FailureCode code;
  final String message;
  final Object? cause;
  final StackTrace? stackTrace;
  final Map<String, Object?> context;

  @override
  String toString() => 'Failure(${code.name}: $message${cause == null ? '' : ' <- $cause'})';
}
