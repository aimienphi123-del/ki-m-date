import 'dart:developer' as developer;

enum LogLevel { debug, info, warning, error }

/// Thin logging seam. Everything in the app logs through this interface so a
/// crash reporter can be attached later without touching call sites.
abstract interface class AppLogger {
  void log(LogLevel level, String tag, String message, {Object? error, StackTrace? stackTrace});
}

extension AppLoggerShortcuts on AppLogger {
  void d(String tag, String message) => log(LogLevel.debug, tag, message);
  void i(String tag, String message) => log(LogLevel.info, tag, message);
  void w(String tag, String message, {Object? error}) =>
      log(LogLevel.warning, tag, message, error: error);
  void e(String tag, String message, {Object? error, StackTrace? stackTrace}) =>
      log(LogLevel.error, tag, message, error: error, stackTrace: stackTrace);
}

class DeveloperLogLogger implements AppLogger {
  const DeveloperLogLogger({this.minimumLevel = LogLevel.debug});
  final LogLevel minimumLevel;

  @override
  void log(LogLevel level, String tag, String message, {Object? error, StackTrace? stackTrace}) {
    if (level.index < minimumLevel.index) return;
    developer.log(
      message,
      name: 'ExpiryGuardian/$tag',
      level: switch (level) {
        LogLevel.debug => 500,
        LogLevel.info => 800,
        LogLevel.warning => 900,
        LogLevel.error => 1000,
      },
      error: error,
      stackTrace: stackTrace,
    );
  }
}
