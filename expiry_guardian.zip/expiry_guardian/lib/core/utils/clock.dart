/// Injectable time source.
///
/// Every module reads "now" through a [Clock] so that the policy engine,
/// notification scheduler and reports are deterministically testable.
abstract interface class Clock {
  DateTime now();
  DateTime today();
}

class SystemClock implements Clock {
  const SystemClock();

  @override
  DateTime now() => DateTime.now();

  @override
  DateTime today() {
    final DateTime n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }
}

/// Fixed clock used by tests and by "preview a policy change" screens.
class FixedClock implements Clock {
  FixedClock(this._now);
  DateTime _now;

  set instant(DateTime value) => _now = value;

  @override
  DateTime now() => _now;

  @override
  DateTime today() => DateTime(_now.year, _now.month, _now.day);
}
