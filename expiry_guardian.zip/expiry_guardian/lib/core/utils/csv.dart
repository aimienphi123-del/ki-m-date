import 'dart:convert';
import 'dart:io';

/// Minimal, correct CSV writer.
///
/// Excel on a Vietnamese Windows install opens UTF-8 CSV correctly only when
/// the file starts with a byte-order mark, so [writeCsvFile] emits one.
abstract final class Csv {
  static const String _bom = '﻿';

  static String escapeField(Object? value) {
    final String text = value?.toString() ?? '';
    final bool needsQuotes =
        text.contains(',') || text.contains('"') || text.contains('\n') || text.contains('\r');
    if (!needsQuotes) return text;
    return '"${text.replaceAll('"', '""')}"';
  }

  static String build({
    required List<String> header,
    required List<List<Object?>> rows,
  }) {
    final StringBuffer buffer = StringBuffer();
    buffer.writeln(header.map(escapeField).join(','));
    for (final List<Object?> row in rows) {
      buffer.writeln(row.map(escapeField).join(','));
    }
    return buffer.toString();
  }

  static Future<File> writeCsvFile({
    required String path,
    required List<String> header,
    required List<List<Object?>> rows,
  }) async {
    final File file = File(path);
    await file.writeAsString(
      '$_bom${build(header: header, rows: rows)}',
      encoding: utf8,
      flush: true,
    );
    return file;
  }
}
