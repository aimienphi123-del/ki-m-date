import 'package:uuid/uuid.dart';

/// Injectable identifier generator (tests substitute a deterministic one).
abstract interface class IdGenerator {
  String newId();
}

class UuidGenerator implements IdGenerator {
  const UuidGenerator(this._uuid);
  final Uuid _uuid;

  factory UuidGenerator.create() => const UuidGenerator(Uuid());

  @override
  String newId() => _uuid.v4();
}

/// Deterministic generator for tests: `prefix-1`, `prefix-2`, ...
class SequentialIdGenerator implements IdGenerator {
  SequentialIdGenerator([this.prefix = 'id']);
  final String prefix;
  int _counter = 0;

  @override
  String newId() => '$prefix-${++_counter}';
}
