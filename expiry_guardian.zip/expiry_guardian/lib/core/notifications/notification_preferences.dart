import 'package:expiry_guardian/core/storage/settings_store.dart';

/// User-editable notification behaviour.
class NotificationPreferences {
  const NotificationPreferences({
    this.dailyDigestEnabled = SettingDefaults.dailyDigestEnabled,
    this.dailyDigestMinutes = SettingDefaults.dailyDigestMinutes,
    this.digestHorizonDays = SettingDefaults.digestHorizonDays,
    this.perItemEnabled = SettingDefaults.perItemAlertsEnabled,
    this.quietStartMinutes,
    this.quietEndMinutes,
    this.maxScheduled = SettingDefaults.maxScheduledNotifications,
  });

  factory NotificationPreferences.fromSettings(SettingsStore settings) {
    final int quietStart = settings.readInt(SettingKeys.quietHoursStartMinutes, -1);
    final int quietEnd = settings.readInt(SettingKeys.quietHoursEndMinutes, -1);
    return NotificationPreferences(
      dailyDigestEnabled:
          settings.readBool(SettingKeys.dailyDigestEnabled, SettingDefaults.dailyDigestEnabled),
      dailyDigestMinutes:
          settings.readInt(SettingKeys.dailyDigestMinutes, SettingDefaults.dailyDigestMinutes),
      digestHorizonDays:
          settings.readInt(SettingKeys.digestHorizonDays, SettingDefaults.digestHorizonDays),
      perItemEnabled: settings.readBool(
        SettingKeys.perItemAlertsEnabled,
        SettingDefaults.perItemAlertsEnabled,
      ),
      quietStartMinutes: quietStart < 0 ? null : quietStart,
      quietEndMinutes: quietEnd < 0 ? null : quietEnd,
      maxScheduled: settings
          .readInt(
            SettingKeys.maxScheduledNotifications,
            SettingDefaults.maxScheduledNotifications,
          )
          .clamp(20, 450),
    );
  }

  final bool dailyDigestEnabled;

  /// Minutes from midnight.
  final int dailyDigestMinutes;

  /// How many days of morning summaries to pre-schedule. Destroy instants are
  /// known in advance, so the counts in those summaries are real numbers, not
  /// placeholders - which is what lets the app work with no background worker.
  final int digestHorizonDays;

  /// Master switch for per-lot reminders. *When* they fire is no longer a
  /// setting here - Phase X moved that to the editable notification stages, so
  /// there is exactly one place that decides the timeline.
  final bool perItemEnabled;

  final int? quietStartMinutes;
  final int? quietEndMinutes;

  /// How many OS alarms the app is allowed to hold at once.
  ///
  /// Two hard limits meet here. Android refuses to keep more than roughly 500
  /// exact alarms per app, and every single one costs a platform call to
  /// register - so a ceiling that is too generous turns "confirm a
  /// destruction" into a visible freeze on a cheap handset. The plan is sorted
  /// by time before it is truncated, so the alarms that survive are always the
  /// soonest ones; anything dropped is picked up by the next reschedule long
  /// before it would have fired.
  final int maxScheduled;

  bool get hasQuietHours => quietStartMinutes != null && quietEndMinutes != null;

  bool isQuiet(DateTime moment) {
    final int? start = quietStartMinutes;
    final int? end = quietEndMinutes;
    if (start == null || end == null || start == end) return false;
    final int minutes = moment.hour * 60 + moment.minute;
    if (start < end) return minutes >= start && minutes < end;
    // Window wraps past midnight (e.g. 22:00 -> 07:00).
    return minutes >= start || minutes < end;
  }

  /// Digests are pushed to just after the quiet window; item alerts are pulled
  /// to just before it, because they must never arrive after the deadline.
  DateTime adjust(DateTime moment, {required bool moveLater}) {
    if (!isQuiet(moment)) return moment;
    final int start = quietStartMinutes!;
    final int end = quietEndMinutes!;
    if (moveLater) {
      final DateTime sameDay =
          DateTime(moment.year, moment.month, moment.day, end ~/ 60, end % 60);
      return sameDay.isAfter(moment) ? sameDay : sameDay.add(const Duration(days: 1));
    }
    final DateTime sameDay =
        DateTime(moment.year, moment.month, moment.day, start ~/ 60, start % 60);
    return sameDay.isBefore(moment) ? sameDay : sameDay.subtract(const Duration(days: 1));
  }

  NotificationPreferences copyWith({
    bool? dailyDigestEnabled,
    int? dailyDigestMinutes,
    int? digestHorizonDays,
    bool? perItemEnabled,
    int? quietStartMinutes,
    bool clearQuietStart = false,
    int? quietEndMinutes,
    bool clearQuietEnd = false,
    int? maxScheduled,
  }) {
    return NotificationPreferences(
      dailyDigestEnabled: dailyDigestEnabled ?? this.dailyDigestEnabled,
      dailyDigestMinutes: dailyDigestMinutes ?? this.dailyDigestMinutes,
      digestHorizonDays: digestHorizonDays ?? this.digestHorizonDays,
      perItemEnabled: perItemEnabled ?? this.perItemEnabled,
      quietStartMinutes: clearQuietStart ? null : (quietStartMinutes ?? this.quietStartMinutes),
      quietEndMinutes: clearQuietEnd ? null : (quietEndMinutes ?? this.quietEndMinutes),
      maxScheduled: maxScheduled ?? this.maxScheduled,
    );
  }

  Map<String, Object?> toSettings() => <String, Object?>{
        SettingKeys.dailyDigestEnabled: dailyDigestEnabled,
        SettingKeys.dailyDigestMinutes: dailyDigestMinutes,
        SettingKeys.digestHorizonDays: digestHorizonDays,
        SettingKeys.perItemAlertsEnabled: perItemEnabled,
        SettingKeys.quietHoursStartMinutes: quietStartMinutes ?? -1,
        SettingKeys.quietHoursEndMinutes: quietEndMinutes ?? -1,
        SettingKeys.maxScheduledNotifications: maxScheduled,
      };
}
