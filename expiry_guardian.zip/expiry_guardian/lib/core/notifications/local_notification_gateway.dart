import 'dart:async';
import 'dart:ui' show Color;

import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// `flutter_local_notifications` implementation of [NotificationGateway].
class LocalNotificationGateway implements NotificationGateway {
  LocalNotificationGateway({
    required AppLogger logger,
    FlutterLocalNotificationsPlugin? plugin,
  })  : _logger = logger,
        _plugin = plugin ?? FlutterLocalNotificationsPlugin();

  final AppLogger _logger;
  final FlutterLocalNotificationsPlugin _plugin;
  final StreamController<String?> _selections = StreamController<String?>.broadcast();

  bool _initialized = false;

  static const String _tag = 'Notifications';

  /// The white status-bar silhouette, written by `tool/generate_icons.py` and
  /// kept from resource shrinking by `res/raw/keep.xml`. Not the launcher
  /// icon: that is an adaptive icon now, which Android 8 refuses as a small
  /// icon - the notification is then never shown at all.
  static const String _smallIcon = '@drawable/ic_stat_kiem_date';

  /// The logo's green, for the icon tint and the accent in the shade.
  static const Color _accent = Color(0xFF22C55E);

  static const AndroidNotificationChannel _dailyChannel = AndroidNotificationChannel(
    'expiry_guardian_daily',
    'Danh sách huỷ hàng ngày',
    description: 'Tóm tắt số sản phẩm cần huỷ trong ngày.',
    importance: Importance.high,
  );

  static const AndroidNotificationChannel _itemChannel = AndroidNotificationChannel(
    'expiry_guardian_items',
    'Cảnh báo từng sản phẩm',
    description: 'Nhắc trước khi một lô hàng đến hạn huỷ.',
    importance: Importance.max,
  );

  static const AndroidNotificationChannel _escalationChannel = AndroidNotificationChannel(
    'expiry_guardian_escalation',
    'Cảnh báo cho quản lý',
    description: 'Lô hàng quá hạn mà chưa ai xác nhận huỷ.',
    importance: Importance.max,
  );

  @override
  Stream<String?> get selections => _selections.stream;

  @override
  Future<void> initialize() async {
    if (_initialized) return;

    tz_data.initializeTimeZones();
    try {
      final String name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (error) {
      _logger.w(_tag, 'Falling back to UTC: could not resolve the device time zone',
          error: error,);
      tz.setLocalLocation(tz.getLocation('UTC'));
    }

    await _plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings(_smallIcon),
        iOS: DarwinInitializationSettings(
          requestAlertPermission: false,
          requestBadgePermission: false,
          requestSoundPermission: false,
        ),
      ),
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        _selections.add(response.payload);
      },
    );

    final AndroidFlutterLocalNotificationsPlugin? android = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(_dailyChannel);
    await android?.createNotificationChannel(_itemChannel);
    await android?.createNotificationChannel(_escalationChannel);

    _initialized = true;
  }

  @override
  Future<bool> requestPermission() async {
    final AndroidFlutterLocalNotificationsPlugin? android = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      return await android.requestNotificationsPermission() ?? false;
    }
    final IOSFlutterLocalNotificationsPlugin? ios = _plugin
        .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
    return await ios?.requestPermissions(alert: true, badge: true, sound: true) ?? false;
  }

  @override
  Future<bool> hasPermission() async {
    final AndroidFlutterLocalNotificationsPlugin? android = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      return await android.areNotificationsEnabled() ?? false;
    }
    return true;
  }

  @override
  Future<bool> canScheduleExactAlarms() async {
    final AndroidFlutterLocalNotificationsPlugin? android = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return true;
    return await android.canScheduleExactNotifications() ?? false;
  }

  @override
  Future<bool> requestExactAlarmPermission() async {
    final AndroidFlutterLocalNotificationsPlugin? android = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (android == null) return true;
    return await android.requestExactAlarmsPermission() ?? false;
  }

  @override
  Future<void> schedule(AppNotification notification) async {
    await initialize();
    final tz.TZDateTime when = tz.TZDateTime.from(notification.scheduledFor, tz.local);
    if (!when.isAfter(tz.TZDateTime.now(tz.local))) return;

    final bool exact = await canScheduleExactAlarms();
    await _plugin.zonedSchedule(
      notification.id,
      notification.title,
      notification.body,
      when,
      _detailsFor(notification),
      androidScheduleMode: exact
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: notification.payload,
    );
  }

  @override
  Future<void> showNow(AppNotification notification) async {
    await initialize();
    await _plugin.show(
      notification.id,
      notification.title,
      notification.body,
      _detailsFor(notification),
      payload: notification.payload,
    );
  }

  NotificationDetails _detailsFor(AppNotification notification) {
    final NotificationKind kind = notification.kind;
    final AndroidNotificationChannel channel = switch (kind) {
      NotificationKind.dailyDigest => _dailyChannel,
      NotificationKind.escalation => _escalationChannel,
      _ => _itemChannel,
    };
    return NotificationDetails(
      android: AndroidNotificationDetails(
        channel.id,
        channel.name,
        channelDescription: channel.description,
        importance: channel.importance,
        icon: _smallIcon,
        color: _accent,
        priority: kind == NotificationKind.itemOverdue ||
                kind == NotificationKind.escalation
            ? Priority.max
            : Priority.high,
        category: kind == NotificationKind.escalation
            ? AndroidNotificationCategory.alarm
            : AndroidNotificationCategory.reminder,
        // The body has to be repeated here. An empty big-text style blanks the
        // message the moment the user expands the notification, hiding exactly
        // the part that says which product and which shelf.
        styleInformation: BigTextStyleInformation(notification.body),
      ),
      iOS: const DarwinNotificationDetails(),
    );
  }

  @override
  Future<void> cancel(int id) => _plugin.cancel(id);

  @override
  Future<void> cancelAll() => _plugin.cancelAll();

  @override
  Future<List<int>> pendingIds() async {
    final List<PendingNotificationRequest> pending =
        await _plugin.pendingNotificationRequests();
    return pending.map((PendingNotificationRequest r) => r.id).toList(growable: false);
  }

  Future<void> dispose() async => _selections.close();
}
