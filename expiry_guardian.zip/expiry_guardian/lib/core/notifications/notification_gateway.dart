/// What a scheduled notification is about.
enum NotificationKind {
  /// The morning summary: "You have 17 products to destroy today."
  dailyDigest,

  /// A single lot approaching its destroy instant.
  itemDue,

  /// A single lot that is now past its destroy instant.
  itemOverdue,

  /// A lot nobody confirmed in time, raised to a manager.
  escalation,

  /// Free-form message triggered from the app.
  manual,
}

class AppNotification {
  const AppNotification({
    required this.id,
    required this.kind,
    required this.title,
    required this.body,
    required this.scheduledFor,
    this.recordId,
    this.payload,
    this.severity = NotificationSeverity.normal,
  });

  final int id;
  final NotificationKind kind;
  final String title;
  final String body;
  final DateTime scheduledFor;
  final String? recordId;
  final String? payload;
  final NotificationSeverity severity;
}

/// How loudly a notification should present itself.
enum NotificationSeverity { normal, high, critical }

/// Platform seam for notifications.
///
/// Expiry Guardian schedules everything locally, because destroy instants are
/// known in advance and the store must be reminded even with no connectivity.
/// A push backend (FCM) can be added later behind this same interface for
/// messages that originate on a server.
abstract interface class NotificationGateway {
  Future<void> initialize();

  /// Returns true when the user granted notification permission.
  Future<bool> requestPermission();

  Future<bool> hasPermission();

  /// True when the OS lets the app fire notifications at an exact minute.
  /// Android 12+ requires a separate grant for this; without it the reminders
  /// still arrive but may be delayed by the system.
  Future<bool> canScheduleExactAlarms();

  Future<bool> requestExactAlarmPermission();

  Future<void> schedule(AppNotification notification);

  Future<void> showNow(AppNotification notification);

  Future<void> cancel(int id);

  Future<void> cancelAll();

  Future<List<int>> pendingIds();

  Stream<String?> get selections;
}
