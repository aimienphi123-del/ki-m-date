import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:sqflite/sqflite.dart';

/// Stores and edits the reminder timeline.
abstract interface class NotificationWorkflowRepository {
  Future<Result<List<NotificationStage>>> listStages({bool includeInactive = true});
  Future<Result<NotificationStage>> upsert(NotificationStage stage);
  Future<Result<void>> delete(String stageId);
  Future<Result<void>> restoreDefaults();
  Future<Result<int>> count();
  Stream<void> watch();
}

abstract final class NotificationStageMapper {
  static NotificationStage fromRow(Map<String, Object?> row) => NotificationStage(
        id: row.str('id'),
        sortOrder: row.integer('sort_order'),
        kind: NotificationStageKind.fromName(row.strOrNull('kind')),
        nameVi: row.str('name_vi'),
        nameEn: row.str('name_en'),
        offset: Duration(minutes: row.integer('offset_minutes')),
        repeatEvery: row.durationOrNull('repeat_every_minutes'),
        maxRepeats: row.intOrNull('max_repeats'),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
      );

  static Map<String, Object?> toRow(NotificationStage stage) => <String, Object?>{
        'id': stage.id,
        'sort_order': stage.sortOrder,
        'kind': stage.kind.name,
        'name_vi': stage.nameVi,
        'name_en': stage.nameEn,
        'offset_minutes': stage.offset.inMinutes,
        'repeat_every_minutes': stage.repeatEvery?.inMinutes,
        'max_repeats': stage.maxRepeats,
        'is_active': boolToInt(stage.isActive),
        'created_at': stage.createdAt.millisecondsSinceEpoch,
        'updated_at': stage.updatedAt.millisecondsSinceEpoch,
      };
}

class NotificationWorkflowRepositoryImpl implements NotificationWorkflowRepository {
  const NotificationWorkflowRepositoryImpl({
    required AppDatabase database,
    required Clock clock,
    required String Function() newId,
    required SyncQueue syncQueue,
    required AuditRepository audit,
    required AppLogger logger,
  })  : _database = database,
        _clock = clock,
        _newId = newId,
        _syncQueue = syncQueue,
        _audit = audit,
        _logger = logger;

  final AppDatabase _database;
  final Clock _clock;
  final String Function() _newId;
  final SyncQueue _syncQueue;
  final AuditRepository _audit;
  final AppLogger _logger;

  static const String _tag = 'NotificationWorkflow';

  @override
  Future<Result<List<NotificationStage>>> listStages({bool includeInactive = true}) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.notificationStages,
        where: includeInactive ? null : 'is_active = 1',
        orderBy: 'sort_order ASC',
      );
      return rows.map(NotificationStageMapper.fromRow).toList(growable: false);
    });
  }

  @override
  Future<Result<int>> count() =>
      _guard(() => countOf(_database.db, 'SELECT COUNT(*) FROM ${Tables.notificationStages}'));

  @override
  Future<Result<NotificationStage>> upsert(NotificationStage stage) async {
    return _guard(() async {
      final List<Map<String, Object?>> existing = await _database.db.query(
        Tables.notificationStages,
        where: 'id = ?',
        whereArgs: <Object?>[stage.id],
        limit: 1,
      );
      final NotificationStage saved = stage.copyWith(updatedAt: _clock.now());
      await _database.write(<String>{Tables.notificationStages}, (Transaction txn) async {
        await txn.insert(
          Tables.notificationStages,
          NotificationStageMapper.toRow(saved),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.notificationStages,
        entityId: saved.id,
        payload: NotificationStageMapper.toRow(saved),
      );
      await _audit.append(AuditDraft(
        action: AuditAction.notificationStageEdited,
        entity: Tables.notificationStages,
        entityId: saved.id,
        entityLabel: saved.nameVi,
        previousValue:
            existing.isEmpty ? null : NotificationStageMapper.toRow(
                NotificationStageMapper.fromRow(existing.first),),
        newValue: NotificationStageMapper.toRow(saved),
      ),);
      return saved;
    });
  }

  @override
  Future<Result<void>> delete(String stageId) async {
    return _guard(() async {
      final List<Map<String, Object?>> existing = await _database.db.query(
        Tables.notificationStages,
        where: 'id = ?',
        whereArgs: <Object?>[stageId],
        limit: 1,
      );
      await _database.write(<String>{Tables.notificationStages}, (Transaction txn) async {
        await txn.delete(Tables.notificationStages, where: 'id = ?', whereArgs: <Object?>[stageId]);
      });
      await _syncQueue.enqueueDelete(entity: Tables.notificationStages, entityId: stageId);
      if (existing.isNotEmpty) {
        await _audit.append(AuditDraft(
          action: AuditAction.notificationStageEdited,
          entity: Tables.notificationStages,
          entityId: stageId,
          entityLabel: existing.first.strOrNull('name_vi'),
          previousValue: NotificationStageMapper.toRow(
              NotificationStageMapper.fromRow(existing.first),),
          note: 'deleted',
        ),);
      }
    });
  }

  @override
  Future<Result<void>> restoreDefaults() async {
    return _guard(() async {
      final DateTime now = _clock.now();
      final List<NotificationStage> stages =
          DefaultNotificationStages.build(newId: _newId, now: now);
      await _database.write(<String>{Tables.notificationStages}, (Transaction txn) async {
        await txn.delete(Tables.notificationStages);
        for (final NotificationStage stage in stages) {
          await txn.insert(Tables.notificationStages, NotificationStageMapper.toRow(stage));
        }
      });
      _logger.i(_tag, 'Restored the default reminder timeline (${stages.length} stages)');
      await _audit.append(const AuditDraft(
        action: AuditAction.notificationStageEdited,
        entity: Tables.notificationStages,
        note: 'restored defaults',
      ),);
    });
  }

  @override
  Stream<void> watch() =>
      _database.changes.where((String table) => table == Tables.notificationStages);

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Stage operation failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('stage_operation_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
