/// The four moments of the destruction reminder workflow.
///
/// The *shape* of the workflow is fixed (warn, remind, demand, chase); every
/// *number* in it is a row in `notification_stages` that a manager edits.
enum NotificationStageKind {
  /// Well before the deadline, so the shelf can be rotated or the stock moved.
  earlyWarning,

  /// The day before. Last chance to plan the morning round.
  finalReminder,

  /// The destroy instant itself. This one is not optional in practice.
  mandatory,

  /// Repeats after the deadline until someone confirms the destruction.
  repeatUntilConfirmed;

  static NotificationStageKind fromName(String? value) =>
      NotificationStageKind.values.firstWhere(
        (NotificationStageKind k) => k.name == value,
        orElse: () => NotificationStageKind.mandatory,
      );

  bool get isRepeating => this == NotificationStageKind.repeatUntilConfirmed;
}

/// One configurable step of the reminder timeline.
class NotificationStage {
  const NotificationStage({
    required this.id,
    required this.sortOrder,
    required this.kind,
    required this.nameVi,
    required this.nameEn,
    required this.offset,
    required this.createdAt,
    required this.updatedAt,
    this.repeatEvery,
    this.maxRepeats,
    this.isActive = true,
  });

  final String id;
  final int sortOrder;
  final NotificationStageKind kind;
  final String nameVi;
  final String nameEn;

  /// Signed offset from the destroy instant.
  /// Negative = before, `Duration.zero` = exactly at, positive = after.
  final Duration offset;

  /// Only meaningful for [NotificationStageKind.repeatUntilConfirmed].
  final Duration? repeatEvery;
  final int? maxRepeats;

  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isBeforeDeadline => offset.isNegative;
  bool get isAfterDeadline => offset > Duration.zero;

  /// How many notifications this stage produces for one lot.
  int get occurrences {
    if (!kind.isRepeating) return 1;
    final int? max = maxRepeats;
    if (max == null || max <= 0) return 1;
    return max;
  }

  /// The instants this stage fires at for a lot due at [destroyAt].
  List<DateTime> occurrencesFor(DateTime destroyAt) {
    if (!kind.isRepeating) return <DateTime>[destroyAt.add(offset)];
    final Duration every = repeatEvery ?? const Duration(hours: 1);
    if (every <= Duration.zero) return <DateTime>[destroyAt.add(offset)];
    return List<DateTime>.generate(
      occurrences,
      (int i) => destroyAt.add(offset + every * i),
    );
  }

  NotificationStage copyWith({
    int? sortOrder,
    NotificationStageKind? kind,
    String? nameVi,
    String? nameEn,
    Duration? offset,
    Duration? repeatEvery,
    bool clearRepeatEvery = false,
    int? maxRepeats,
    bool clearMaxRepeats = false,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return NotificationStage(
      id: id,
      sortOrder: sortOrder ?? this.sortOrder,
      kind: kind ?? this.kind,
      nameVi: nameVi ?? this.nameVi,
      nameEn: nameEn ?? this.nameEn,
      offset: offset ?? this.offset,
      repeatEvery: clearRepeatEvery ? null : (repeatEvery ?? this.repeatEvery),
      maxRepeats: clearMaxRepeats ? null : (maxRepeats ?? this.maxRepeats),
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() => 'NotificationStage(${kind.name}, offset=$offset)';
}

/// The timeline the app ships with. Written to the database on first launch
/// and editable from that moment on; nothing reads this class again.
abstract final class DefaultNotificationStages {
  static List<NotificationStage> build({
    required String Function() newId,
    required DateTime now,
  }) {
    return <NotificationStage>[
      NotificationStage(
        id: newId(),
        sortOrder: 10,
        kind: NotificationStageKind.earlyWarning,
        nameVi: 'Cảnh báo sớm',
        nameEn: 'Early warning',
        offset: const Duration(days: -2),
        createdAt: now,
        updatedAt: now,
      ),
      NotificationStage(
        id: newId(),
        sortOrder: 20,
        kind: NotificationStageKind.finalReminder,
        nameVi: 'Nhắc lần cuối',
        nameEn: 'Final reminder',
        offset: const Duration(days: -1),
        createdAt: now,
        updatedAt: now,
      ),
      NotificationStage(
        id: newId(),
        sortOrder: 30,
        kind: NotificationStageKind.mandatory,
        nameVi: 'Bắt buộc huỷ',
        nameEn: 'Mandatory destroy',
        offset: Duration.zero,
        createdAt: now,
        updatedAt: now,
      ),
      NotificationStage(
        id: newId(),
        sortOrder: 40,
        kind: NotificationStageKind.repeatUntilConfirmed,
        nameVi: 'Nhắc lại tới khi xác nhận',
        nameEn: 'Repeat until confirmed',
        offset: const Duration(hours: 1),
        repeatEvery: const Duration(hours: 1),
        maxRepeats: 24,
        createdAt: now,
        updatedAt: now,
      ),
    ];
  }
}
