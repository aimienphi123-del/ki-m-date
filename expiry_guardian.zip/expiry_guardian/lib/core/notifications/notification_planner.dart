import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/notifications/notification_workflow_repository.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:sqflite/sqflite.dart';

class NotificationPlan {
  const NotificationPlan({
    required this.notifications,
    required this.digestCount,
    required this.stageCount,
    required this.extraCount,
    required this.truncated,
  });

  final List<AppNotification> notifications;
  final int digestCount;

  /// Alerts produced by the multi-stage workflow (early warning, final
  /// reminder, mandatory, and the repeats after the deadline).
  final int stageCount;

  /// Manager escalation alerts handed in by the workflow service.
  final int extraCount;

  /// True when the plan hit [NotificationPreferences.maxScheduled] and the
  /// furthest-out alerts were dropped. The next reschedule picks them up.
  final bool truncated;

  int get total => notifications.length;

  List<AppNotification> ofKind(NotificationKind kind) =>
      notifications.where((AppNotification n) => n.kind == kind).toList(growable: false);
}

/// Decides exactly which reminders should exist right now.
///
/// Because every destroy instant is already computed and stored, the whole
/// schedule - including the counts inside each morning summary and every
/// repeat after a missed deadline - can be worked out in advance and handed to
/// the OS. That is what makes the workflow run with the app closed, the phone
/// offline, and no background service.
///
/// The repeats stop the moment a destruction is confirmed, because a confirmed
/// lot is no longer an open record and therefore no longer produces any stage
/// notification on the next reschedule; [cancelForRecord] additionally clears
/// the already-scheduled ones straight away.
class NotificationPlanner {
  const NotificationPlanner({
    required InventoryRepository inventory,
    required NotificationWorkflowRepository workflow,
    required NotificationGateway gateway,
    required AppDatabase database,
    required Clock clock,
    required AppLogger logger,
  })  : _inventory = inventory,
        _workflow = workflow,
        _gateway = gateway,
        _database = database,
        _clock = clock,
        _logger = logger;

  final InventoryRepository _inventory;
  final NotificationWorkflowRepository _workflow;
  final NotificationGateway _gateway;
  final AppDatabase _database;
  final Clock _clock;
  final AppLogger _logger;

  static const String _tag = 'NotificationPlanner';

  /// Rebuilds the whole schedule. Cheap enough to call after every change that
  /// can move a destroy instant or close a lot.
  Future<Result<NotificationPlan>> reschedule({
    required NotificationPreferences preferences,
    required AppLocalizations strings,
    List<AppNotification> extraNotifications = const <AppNotification>[],
  }) async {
    final DateTime now = _clock.now();

    final Result<List<NotificationStage>> stagesResult =
        await _workflow.listStages(includeInactive: false);
    if (stagesResult.isErr) {
      return Result<NotificationPlan>.err(stagesResult.failureOrNull!);
    }
    final List<NotificationStage> stages = stagesResult.unwrap();

    // Look far enough ahead to cover the earliest stage as well as the digest
    // horizon, so an "early warning" two days out is scheduled in time.
    final int lookAheadDays = <int>[
      preferences.digestHorizonDays,
      ...stages.map((NotificationStage s) => s.offset.isNegative ? -s.offset.inDays + 1 : 1),
    ].reduce((int a, int b) => a > b ? a : b);

    final Result<List<InventoryItemView>> due = await _inventory.destroyList(
      until: now.add(Duration(days: lookAheadDays.clamp(1, 90))),
    );
    if (due.isErr) return Result<NotificationPlan>.err(due.failureOrNull!);

    final NotificationPlan plan = buildPlan(
      items: due.unwrap(),
      stages: stages,
      preferences: preferences,
      strings: strings,
      now: now,
      extraNotifications: extraNotifications,
    );

    await _gateway.cancelAll();
    await _database.db.delete(Tables.scheduledNotifications);

    await _database.write(<String>{Tables.scheduledNotifications}, (Transaction txn) async {
      for (final AppNotification notification in plan.notifications) {
        await txn.insert(
          Tables.scheduledNotifications,
          <String, Object?>{
            'id': notification.id,
            'kind': notification.kind.name,
            'record_id': notification.recordId,
            'scheduled_for': notification.scheduledFor.millisecondsSinceEpoch,
            'created_at': now.millisecondsSinceEpoch,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });

    for (final AppNotification notification in plan.notifications) {
      await _gateway.schedule(notification);
    }

    _logger.i(
      _tag,
      'Scheduled ${plan.total} reminders '
      '(${plan.digestCount} digests, ${plan.stageCount} stage alerts, '
      '${plan.extraCount} escalations)',
    );
    return Result<NotificationPlan>.ok(plan);
  }

  /// Cancels every pending reminder for one lot. Called the instant a
  /// destruction is confirmed, so the repeats stop immediately rather than at
  /// the next reschedule.
  Future<Result<int>> cancelForRecord(String recordId) async {
    try {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.scheduledNotifications,
        columns: <String>['id'],
        where: 'record_id = ?',
        whereArgs: <Object?>[recordId],
      );
      for (final Map<String, Object?> row in rows) {
        await _gateway.cancel(row.integer('id'));
      }
      await _database.db.delete(
        Tables.scheduledNotifications,
        where: 'record_id = ?',
        whereArgs: <Object?>[recordId],
      );
      _database.notifyChanged(<String>[Tables.scheduledNotifications]);
      return Result<int>.ok(rows.length);
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Could not cancel reminders for $recordId',
          error: error, stackTrace: stackTrace,);
      return const Result<int>.ok(0);
    }
  }

  /// Pure planning step - unit tested without touching the platform.
  NotificationPlan buildPlan({
    required List<InventoryItemView> items,
    required List<NotificationStage> stages,
    required NotificationPreferences preferences,
    required AppLocalizations strings,
    required DateTime now,
    List<AppNotification> extraNotifications = const <AppNotification>[],
  }) {
    final List<AppNotification> planned = <AppNotification>[];

    if (preferences.dailyDigestEnabled) {
      _appendDigests(planned, items, preferences, strings, now);
    }

    final List<NotificationStage> ordered = stages
        .where((NotificationStage s) => s.isActive)
        .toList()
      ..sort((NotificationStage a, NotificationStage b) =>
          a.sortOrder.compareTo(b.sortOrder),);

    if (preferences.perItemEnabled && ordered.isNotEmpty) {
      final List<InventoryItemView> sorted = List<InventoryItemView>.of(items)
        ..sort((InventoryItemView a, InventoryItemView b) =>
            a.record.destroyAt.compareTo(b.record.destroyAt),);

      for (final InventoryItemView item in sorted) {
        for (final NotificationStage stage in ordered) {
          final List<DateTime> occurrences = stage.occurrencesFor(item.record.destroyAt);
          bool scheduledAny = false;
          for (int index = 0; index < occurrences.length; index++) {
            // Reminders due before the deadline are pulled out of quiet hours,
            // never pushed past it; chase-ups afterwards are pushed later.
            final DateTime fireAt = preferences.adjust(
              occurrences[index],
              moveLater: stage.isAfterDeadline,
            );
            if (!fireAt.isAfter(now)) continue;

            planned.add(_stageNotification(
              item: item,
              stage: stage,
              repeatIndex: index,
              fireAt: fireAt,
              strings: strings,
            ),);
            scheduledAny = true;
          }

          // A lot that is still open once its whole chase-up series has
          // elapsed would otherwise go silent for good: every occurrence sits
          // in the past, so every one of them is skipped above. The stage
          // exists to keep asking until somebody confirms, so keep one live
          // chase-up armed. It is re-armed by the next reschedule, which is
          // why one is enough and the phone is not flooded.
          if (!scheduledAny &&
              stage.kind.isRepeating &&
              item.record.destroyAt.isBefore(now)) {
            final Duration every = stage.repeatEvery ?? const Duration(hours: 1);
            final DateTime fireAt = preferences.adjust(
              now.add(every > Duration.zero ? every : const Duration(hours: 1)),
              moveLater: true,
            );
            planned.add(_stageNotification(
              item: item,
              stage: stage,
              // Continues the attempt numbering past the configured series,
              // and keeps the notification id stable across reschedules.
              repeatIndex: occurrences.length,
              fireAt: fireAt,
              strings: strings,
            ),);
          }
        }
      }
    }

    for (final AppNotification extra in extraNotifications) {
      if (extra.scheduledFor.isAfter(now)) planned.add(extra);
    }

    planned.sort((AppNotification a, AppNotification b) =>
        a.scheduledFor.compareTo(b.scheduledFor),);

    final bool truncated = planned.length > preferences.maxScheduled;
    final List<AppNotification> kept = truncated
        ? planned.take(preferences.maxScheduled).toList(growable: false)
        : planned;

    // Count what actually survived the truncation. Reporting the pre-truncation
    // totals made the log line and the audit entry claim more alerts than the
    // plan holds ("Scheduled 20 reminders (3 digests, 324 stage alerts)").
    return NotificationPlan(
      notifications: kept,
      digestCount: kept
          .where((AppNotification n) => n.kind == NotificationKind.dailyDigest)
          .length,
      stageCount: kept
          .where((AppNotification n) =>
              n.kind == NotificationKind.itemDue ||
              n.kind == NotificationKind.itemOverdue,)
          .length,
      extraCount: kept
          .where((AppNotification n) => n.kind == NotificationKind.escalation)
          .length,
      truncated: truncated,
    );
  }

  void _appendDigests(
    List<AppNotification> planned,
    List<InventoryItemView> items,
    NotificationPreferences preferences,
    AppLocalizations strings,
    DateTime now,
  ) {
    for (int dayOffset = 0; dayOffset < preferences.digestHorizonDays; dayOffset++) {
      final DateTime day =
          DateTime(now.year, now.month, now.day).add(Duration(days: dayOffset));
      DateTime fireAt = DateTime(
        day.year,
        day.month,
        day.day,
        preferences.dailyDigestMinutes ~/ 60,
        preferences.dailyDigestMinutes % 60,
      );
      fireAt = preferences.adjust(fireAt, moveLater: true);
      if (!fireAt.isAfter(now)) continue;

      final DateTime dayEnd = day.add(const Duration(days: 1));
      // The summary says "to destroy today", so it must count that day only.
      // Today's summary additionally carries the backlog - a lot that is
      // already past its deadline is still work for this morning - but a
      // future day must not inherit it, or every morning for a week reports
      // the same lot as due "today".
      final List<InventoryItemView> dueThatDay = items
          .where((InventoryItemView i) =>
              i.record.destroyAt.isBefore(dayEnd) &&
              (dayOffset == 0 || !i.record.destroyAt.isBefore(day)),)
          .toList(growable: false);
      if (dueThatDay.isEmpty) continue;

      final int urgent = dueThatDay
          .where((InventoryItemView i) => !i.record.destroyAt.isAfter(fireAt))
          .length;

      planned.add(AppNotification(
        id: notificationId('digest', day.toIso8601String(), 0),
        kind: NotificationKind.dailyDigest,
        title: strings.t(K.notifDigestTitle),
        body: urgent > 0
            ? strings.t(K.notifDigestBodyWithUrgent, <String, Object?>{
                'count': dueThatDay.length,
                'urgent': urgent,
              })
            : strings.t(K.notifDigestBody, <String, Object?>{'count': dueThatDay.length}),
        scheduledFor: fireAt,
        payload: 'today',
      ),);
    }
  }

  AppNotification _stageNotification({
    required InventoryItemView item,
    required NotificationStage stage,
    required int repeatIndex,
    required DateTime fireAt,
    required AppLocalizations strings,
  }) {
    final String location = item.locationLabel;
    final String product = item.product.displayName;
    final Duration lead = -stage.offset;

    final (String title, String body) = switch (stage.kind) {
      NotificationStageKind.earlyWarning => (
          strings.t(K.notifStageEarlyTitle),
          strings.t(K.notifStageEarlyBody, <String, Object?>{
            'product': product,
            'location': location.isEmpty ? strings.t(K.todayNoShelf) : location,
            'duration': strings.duration(lead),
          }),
        ),
      NotificationStageKind.finalReminder => (
          strings.t(K.notifStageFinalTitle),
          strings.t(K.notifStageFinalBody, <String, Object?>{
            'product': product,
            'location': location.isEmpty ? strings.t(K.todayNoShelf) : location,
            'duration': strings.duration(lead),
          }),
        ),
      NotificationStageKind.mandatory => (
          strings.t(K.notifStageMandatoryTitle),
          strings.t(K.notifStageMandatoryBody, <String, Object?>{
            'product': product,
            'location': location.isEmpty ? strings.t(K.todayNoShelf) : location,
          }),
        ),
      NotificationStageKind.repeatUntilConfirmed => (
          strings.t(K.notifStageRepeatTitle),
          strings.t(K.notifStageRepeatBody, <String, Object?>{
            'product': product,
            'location': location.isEmpty ? strings.t(K.todayNoShelf) : location,
            'attempt': repeatIndex + 1,
          }),
        ),
    };

    return AppNotification(
      id: notificationId('stage:${stage.id}', item.record.id, repeatIndex),
      kind: stage.kind == NotificationStageKind.repeatUntilConfirmed ||
              stage.kind == NotificationStageKind.mandatory
          ? NotificationKind.itemOverdue
          : NotificationKind.itemDue,
      title: title,
      body: body,
      scheduledFor: fireAt,
      recordId: item.record.id,
      payload: 'record:${item.record.id}',
    );
  }

  Future<void> cancelAll() async {
    await _gateway.cancelAll();
    await _database.db.delete(Tables.scheduledNotifications);
    _database.notifyChanged(<String>[Tables.scheduledNotifications]);
  }

  /// Deterministic, stable, positive 31-bit id so a reschedule replaces the
  /// previous alert for the same lot instead of duplicating it.
  static int notificationId(String kind, String key, int variant) {
    int hash = 0x811c9dc5;
    for (final int unit in '$kind|$key|$variant'.codeUnits) {
      hash ^= unit;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }
}
