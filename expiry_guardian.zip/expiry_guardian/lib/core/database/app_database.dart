import 'dart:async';

import 'package:expiry_guardian/core/database/migrations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Owns the single SQLite connection and applies migrations.
///
/// Everything in Expiry Guardian is written here first; the sync engine later
/// replays the outbox to a remote backend. That ordering is what makes the app
/// work with no connectivity at all.
class AppDatabase {
  AppDatabase({
    required DatabaseFactory factory,
    required String databasePath,
    required AppLogger logger,
  })  : _factory = factory,
        _databasePath = databasePath,
        _logger = logger;

  final DatabaseFactory _factory;
  final String _databasePath;
  final AppLogger _logger;

  Database? _db;
  final StreamController<String> _changes = StreamController<String>.broadcast();

  static const String _tag = 'AppDatabase';

  /// Fires the name of a table whenever a write touches it, so view models can
  /// refresh without polling.
  Stream<String> get changes => _changes.stream;

  Database get db {
    final Database? database = _db;
    if (database == null) {
      throw StateError('AppDatabase.open() must be awaited before use.');
    }
    return database;
  }

  bool get isOpen => _db != null;

  Future<Database> open() async {
    if (_db != null) return _db!;
    _logger.i(_tag, 'Opening database at $_databasePath (v${Migrations.latestVersion})');
    final Database database = await _factory.openDatabase(
      _databasePath,
      options: OpenDatabaseOptions(
        version: Migrations.latestVersion,
        onConfigure: (Database db) async {
          await db.execute('PRAGMA foreign_keys = ON');
        },
        onCreate: (Database db, int version) async {
          for (final Migration migration in Migrations.all) {
            await _apply(db, migration);
          }
        },
        onUpgrade: (Database db, int from, int to) async {
          for (final Migration migration in Migrations.all) {
            if (migration.version > from && migration.version <= to) {
              await _apply(db, migration);
            }
          }
        },
      ),
    );
    _db = database;
    return database;
  }

  Future<void> _apply(Database db, Migration migration) async {
    _logger.i(_tag, 'Applying migration v${migration.version}');
    for (final String statement in migration.statements) {
      await db.execute(statement);
    }
    await migration.onUpgrade?.call(db);
  }

  /// Runs [action] inside a transaction and notifies [changes] afterwards.
  Future<T> write<T>(
    Set<String> touchedTables,
    Future<T> Function(Transaction txn) action,
  ) async {
    final T result = await db.transaction<T>(action);
    for (final String table in touchedTables) {
      _changes.add(table);
    }
    return result;
  }

  void notifyChanged(Iterable<String> tables) {
    for (final String table in tables) {
      _changes.add(table);
    }
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
    await _changes.close();
  }

  /// Deletes every row while keeping the schema. Used by the "reset store data"
  /// maintenance action, which requires an admin confirmation in the UI.
  Future<void> wipeOperationalData() async {
    await db.transaction((Transaction txn) async {
      for (final String table in <String>[
        'scheduled_notifications',
        'sync_outbox',
        'destructions',
        'record_events',
        'inventory_records',
      ]) {
        await txn.delete(table);
      }
    });
    notifyChanged(<String>[
      'inventory_records',
      'record_events',
      'destructions',
      'sync_outbox',
      'scheduled_notifications',
    ]);
  }

  static Future<String> defaultPath(String directory) async {
    return p.join(directory, 'expiry_guardian.db');
  }
}
