import 'package:sqflite/sqflite.dart';

/// A single forward migration step.
class Migration {
  const Migration(this.version, this.statements, {this.onUpgrade});

  final int version;
  final List<String> statements;

  /// Optional imperative step (data backfill) run after [statements].
  final Future<void> Function(Database db)? onUpgrade;
}

/// Ordered list of schema migrations.
///
/// `AppDatabase.schemaVersion` is derived from the last entry, so adding a new
/// [Migration] to the end of this list is the only change required to evolve
/// the schema.
abstract final class Migrations {
  static const List<Migration> all = <Migration>[_v1, _v2];

  static int get latestVersion => all.last.version;

  static const Migration _v1 = Migration(1, <String>[
    '''
    CREATE TABLE users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      password_iterations INTEGER NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      last_login_at INTEGER
    )
    ''',
    'CREATE UNIQUE INDEX idx_users_username ON users (username COLLATE NOCASE)',
    '''
    CREATE TABLE store_areas (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    )
    ''',
    '''
    CREATE TABLE shelves (
      id TEXT PRIMARY KEY,
      area_id TEXT NOT NULL,
      name TEXT NOT NULL,
      code TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (area_id) REFERENCES store_areas (id) ON DELETE CASCADE
    )
    ''',
    'CREATE INDEX idx_shelves_area ON shelves (area_id)',
    '''
    CREATE TABLE categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      parent_id TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
    )
    ''',
    '''
    CREATE TABLE products (
      id TEXT PRIMARY KEY,
      barcode TEXT,
      name TEXT NOT NULL,
      brand TEXT,
      category_id TEXT,
      unit TEXT NOT NULL DEFAULT 'pcs',
      default_shelf_id TEXT,
      expiry_precision TEXT NOT NULL DEFAULT 'day',
      default_shelf_life_minutes INTEGER,
      unit_cost REAL,
      photo_path TEXT,
      notes TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL,
      FOREIGN KEY (default_shelf_id) REFERENCES shelves (id) ON DELETE SET NULL
    )
    ''',
    'CREATE UNIQUE INDEX idx_products_barcode ON products (barcode) WHERE barcode IS NOT NULL',
    'CREATE INDEX idx_products_name ON products (name COLLATE NOCASE)',
    'CREATE INDEX idx_products_category ON products (category_id)',
    '''
    CREATE TABLE product_barcodes (
      id TEXT PRIMARY KEY,
      product_id TEXT NOT NULL,
      barcode TEXT NOT NULL,
      kind TEXT NOT NULL DEFAULT 'unit',
      created_at INTEGER NOT NULL,
      FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
    )
    ''',
    'CREATE UNIQUE INDEX idx_product_barcodes_code ON product_barcodes (barcode)',
    'CREATE INDEX idx_product_barcodes_product ON product_barcodes (product_id)',
    '''
    CREATE TABLE inventory_records (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL,
      product_id TEXT NOT NULL,
      batch_code TEXT,
      manufactured_at INTEGER,
      expiry_at INTEGER NOT NULL,
      expiry_precision TEXT NOT NULL,
      expiry_instant INTEGER NOT NULL,
      destroy_at INTEGER NOT NULL,
      lead_time_minutes INTEGER NOT NULL,
      shelf_life_minutes INTEGER NOT NULL,
      policy_id TEXT NOT NULL,
      policy_version INTEGER NOT NULL,
      policy_rule_id TEXT,
      area_id TEXT,
      shelf_id TEXT,
      quantity REAL NOT NULL,
      quantity_remaining REAL NOT NULL,
      unit TEXT NOT NULL DEFAULT 'pcs',
      unit_cost REAL,
      received_at INTEGER NOT NULL,
      status TEXT NOT NULL,
      photo_path TEXT,
      source TEXT NOT NULL DEFAULT 'scan',
      note TEXT,
      created_by TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      closed_at INTEGER,
      FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT,
      FOREIGN KEY (shelf_id) REFERENCES shelves (id) ON DELETE SET NULL,
      FOREIGN KEY (area_id) REFERENCES store_areas (id) ON DELETE SET NULL
    )
    ''',
    'CREATE UNIQUE INDEX idx_records_code ON inventory_records (code)',
    'CREATE INDEX idx_records_destroy_at ON inventory_records (status, destroy_at)',
    'CREATE INDEX idx_records_expiry ON inventory_records (status, expiry_instant)',
    'CREATE INDEX idx_records_product ON inventory_records (product_id)',
    'CREATE INDEX idx_records_shelf ON inventory_records (shelf_id)',
    'CREATE INDEX idx_records_batch ON inventory_records (batch_code)',
    '''
    CREATE TABLE record_events (
      id TEXT PRIMARY KEY,
      record_id TEXT NOT NULL,
      type TEXT NOT NULL,
      occurred_at INTEGER NOT NULL,
      actor_id TEXT,
      quantity_delta REAL,
      note TEXT,
      payload TEXT,
      FOREIGN KEY (record_id) REFERENCES inventory_records (id) ON DELETE CASCADE
    )
    ''',
    'CREATE INDEX idx_events_record ON record_events (record_id, occurred_at)',
    'CREATE INDEX idx_events_time ON record_events (occurred_at)',
    '''
    CREATE TABLE destructions (
      id TEXT PRIMARY KEY,
      record_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      category_id TEXT,
      area_id TEXT,
      shelf_id TEXT,
      quantity REAL NOT NULL,
      unit_cost REAL,
      loss_amount REAL NOT NULL DEFAULT 0,
      reason TEXT NOT NULL DEFAULT 'policy',
      was_overdue INTEGER NOT NULL DEFAULT 0,
      minutes_late INTEGER NOT NULL DEFAULT 0,
      destroyed_at INTEGER NOT NULL,
      actor_id TEXT,
      photo_path TEXT,
      note TEXT,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (record_id) REFERENCES inventory_records (id) ON DELETE CASCADE
    )
    ''',
    'CREATE INDEX idx_destructions_time ON destructions (destroyed_at)',
    'CREATE INDEX idx_destructions_product ON destructions (product_id)',
    'CREATE INDEX idx_destructions_shelf ON destructions (shelf_id)',
    '''
    CREATE TABLE policies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 0,
      basis TEXT NOT NULL,
      fallback_to_intake_basis INTEGER NOT NULL DEFAULT 1,
      date_expiry_at_end_of_day INTEGER NOT NULL DEFAULT 1,
      normalize_destroy_time_minutes INTEGER,
      fallback_lead_minutes INTEGER NOT NULL DEFAULT 0,
      destroy_soon_window_minutes INTEGER NOT NULL DEFAULT 1440,
      approaching_window_minutes INTEGER NOT NULL DEFAULT 4320,
      notes TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    )
    ''',
    '''
    CREATE TABLE policy_rules (
      id TEXT PRIMARY KEY,
      policy_id TEXT NOT NULL,
      sort_order INTEGER NOT NULL,
      name_vi TEXT NOT NULL,
      name_en TEXT NOT NULL,
      lead_minutes INTEGER NOT NULL,
      min_minutes INTEGER,
      min_inclusive INTEGER NOT NULL DEFAULT 1,
      max_minutes INTEGER,
      max_inclusive INTEGER NOT NULL DEFAULT 0,
      matches_hourly INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (policy_id) REFERENCES policies (id) ON DELETE CASCADE
    )
    ''',
    'CREATE INDEX idx_policy_rules_policy ON policy_rules (policy_id, sort_order)',
    '''
    CREATE TABLE app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    )
    ''',
    '''
    CREATE TABLE sync_outbox (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entity TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      operation TEXT NOT NULL,
      payload TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      next_attempt_at INTEGER
    )
    ''',
    'CREATE INDEX idx_outbox_entity ON sync_outbox (entity, entity_id)',
    '''
    CREATE TABLE scheduled_notifications (
      id INTEGER PRIMARY KEY,
      kind TEXT NOT NULL,
      record_id TEXT,
      scheduled_for INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    )
    ''',
    'CREATE INDEX idx_notifications_record ON scheduled_notifications (record_id)',
  ]);

  /// Phase X - operation workflow: the multi-stage reminder schedule, manager
  /// escalation, the immutable audit trail and report exports.
  static const Migration _v2 = Migration(2, <String>[
    '''
    CREATE TABLE notification_stages (
      id TEXT PRIMARY KEY,
      sort_order INTEGER NOT NULL,
      kind TEXT NOT NULL,
      name_vi TEXT NOT NULL,
      name_en TEXT NOT NULL,
      offset_minutes INTEGER NOT NULL,
      repeat_every_minutes INTEGER,
      max_repeats INTEGER,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    )
    ''',
    'CREATE INDEX idx_stages_order ON notification_stages (sort_order)',
    '''
    CREATE TABLE escalation_rules (
      id TEXT PRIMARY KEY,
      sort_order INTEGER NOT NULL,
      name_vi TEXT NOT NULL,
      name_en TEXT NOT NULL,
      delay_after_destroy_minutes INTEGER NOT NULL,
      notify_role TEXT NOT NULL,
      severity TEXT NOT NULL,
      repeat_every_minutes INTEGER,
      max_repeats INTEGER,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    )
    ''',
    'CREATE INDEX idx_escalation_rules_order ON escalation_rules (sort_order)',
    '''
    CREATE TABLE escalations (
      id TEXT PRIMARY KEY,
      record_id TEXT NOT NULL,
      rule_id TEXT,
      level INTEGER NOT NULL,
      severity TEXT NOT NULL,
      notify_role TEXT NOT NULL,
      due_at INTEGER NOT NULL,
      raised_at INTEGER NOT NULL,
      resolved_at INTEGER,
      resolution TEXT,
      acknowledged_by TEXT,
      note TEXT,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (record_id) REFERENCES inventory_records (id) ON DELETE CASCADE
    )
    ''',
    'CREATE UNIQUE INDEX idx_escalation_unique ON escalations (record_id, level)',
    'CREATE INDEX idx_escalation_open ON escalations (resolved_at, severity, due_at)',
    '''
    CREATE TABLE audit_log (
      seq INTEGER PRIMARY KEY AUTOINCREMENT,
      id TEXT NOT NULL,
      occurred_at INTEGER NOT NULL,
      action TEXT NOT NULL,
      entity TEXT NOT NULL,
      entity_id TEXT,
      entity_label TEXT,
      actor_id TEXT,
      actor_name TEXT,
      actor_role TEXT,
      device_id TEXT,
      previous_value TEXT,
      new_value TEXT,
      image_path TEXT,
      note TEXT,
      previous_hash TEXT NOT NULL,
      hash TEXT NOT NULL
    )
    ''',
    'CREATE UNIQUE INDEX idx_audit_id ON audit_log (id)',
    'CREATE INDEX idx_audit_time ON audit_log (occurred_at)',
    'CREATE INDEX idx_audit_entity ON audit_log (entity, entity_id)',
    'CREATE INDEX idx_audit_action ON audit_log (action)',
    '''
    CREATE TRIGGER audit_log_is_append_only_update
    BEFORE UPDATE ON audit_log
    BEGIN
      SELECT RAISE(ABORT, 'audit_log is append-only');
    END
    ''',
    '''
    CREATE TRIGGER audit_log_is_append_only_delete
    BEFORE DELETE ON audit_log
    BEGIN
      SELECT RAISE(ABORT, 'audit_log is append-only');
    END
    ''',
    '''
    CREATE TABLE document_exports (
      id TEXT PRIMARY KEY,
      template TEXT NOT NULL,
      destination TEXT NOT NULL,
      title TEXT NOT NULL,
      document_id TEXT,
      url TEXT,
      file_path TEXT,
      period_from INTEGER,
      period_to INTEGER,
      created_by TEXT,
      device_id TEXT,
      status TEXT NOT NULL,
      error TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    )
    ''',
    'CREATE INDEX idx_exports_time ON document_exports (created_at)',
    'ALTER TABLE destructions ADD COLUMN device_id TEXT',
    'ALTER TABLE destructions ADD COLUMN confirmed_at INTEGER',
  ]);
}
