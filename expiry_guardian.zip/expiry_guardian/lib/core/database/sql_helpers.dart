import 'package:sqflite/sqflite.dart';

/// Small helpers shared by every DAO. Keeps mapping code honest and stops
/// silent type coercion bugs when a column is null.
extension RowReader on Map<String, Object?> {
  String str(String key) {
    final Object? v = this[key];
    if (v is String) return v;
    throw StateError('Column "$key" is not a String (got ${v.runtimeType})');
  }

  String? strOrNull(String key) {
    final Object? v = this[key];
    return v is String ? v : null;
  }

  int integer(String key) {
    final Object? v = this[key];
    if (v is int) return v;
    if (v is num) return v.toInt();
    throw StateError('Column "$key" is not an int (got ${v.runtimeType})');
  }

  int? intOrNull(String key) {
    final Object? v = this[key];
    if (v is int) return v;
    if (v is num) return v.toInt();
    return null;
  }

  double number(String key) {
    final Object? v = this[key];
    if (v is num) return v.toDouble();
    throw StateError('Column "$key" is not a number (got ${v.runtimeType})');
  }

  double? numberOrNull(String key) {
    final Object? v = this[key];
    return v is num ? v.toDouble() : null;
  }

  bool boolean(String key) => (intOrNull(key) ?? 0) != 0;

  DateTime dateTime(String key) =>
      DateTime.fromMillisecondsSinceEpoch(integer(key));

  DateTime? dateTimeOrNull(String key) {
    final int? v = intOrNull(key);
    return v == null ? null : DateTime.fromMillisecondsSinceEpoch(v);
  }

  Duration duration(String key) => Duration(minutes: integer(key));

  Duration? durationOrNull(String key) {
    final int? v = intOrNull(key);
    return v == null ? null : Duration(minutes: v);
  }
}

int boolToInt(bool value) => value ? 1 : 0;

int? dateToMillis(DateTime? value) => value?.millisecondsSinceEpoch;

/// Builds a `WHERE ... IN (?, ?, ?)` fragment safely.
({String clause, List<Object?> args}) inClause(String column, List<Object?> values) {
  if (values.isEmpty) return (clause: '1 = 0', args: const <Object?>[]);
  final String placeholders = List<String>.filled(values.length, '?').join(', ');
  return (clause: '$column IN ($placeholders)', args: values);
}

/// Escapes a user-typed search term for a `LIKE` query.
String likeArgument(String raw) {
  final String escaped = raw.replaceAll(r'\', r'\\').replaceAll('%', r'\%').replaceAll('_', r'\_');
  return '%$escaped%';
}

Future<int> countOf(DatabaseExecutor db, String sql, [List<Object?> args = const <Object?>[]]) async {
  final List<Map<String, Object?>> rows = await db.rawQuery(sql, args);
  if (rows.isEmpty) return 0;
  final Object? value = rows.first.values.first;
  return value is int ? value : (value as num?)?.toInt() ?? 0;
}

Future<double> sumOf(DatabaseExecutor db, String sql, [List<Object?> args = const <Object?>[]]) async {
  final List<Map<String, Object?>> rows = await db.rawQuery(sql, args);
  if (rows.isEmpty) return 0;
  final Object? value = rows.first.values.first;
  return value is num ? value.toDouble() : 0;
}
