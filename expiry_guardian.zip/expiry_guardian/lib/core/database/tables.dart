/// Central registry of table names so no string literal is repeated in DAOs.
abstract final class Tables {
  static const String users = 'users';
  static const String areas = 'store_areas';
  static const String shelves = 'shelves';
  static const String categories = 'categories';
  static const String products = 'products';
  static const String productBarcodes = 'product_barcodes';
  static const String inventoryRecords = 'inventory_records';
  static const String recordEvents = 'record_events';
  static const String destructions = 'destructions';
  static const String policies = 'policies';
  static const String policyRules = 'policy_rules';
  static const String settings = 'app_settings';
  static const String syncOutbox = 'sync_outbox';
  static const String scheduledNotifications = 'scheduled_notifications';
  static const String notificationStages = 'notification_stages';
  static const String escalationRules = 'escalation_rules';
  static const String escalations = 'escalations';
  static const String auditLog = 'audit_log';
  static const String documentExports = 'document_exports';
}
