// GENERATED-BY-HAND but mechanical: one entry per user-visible string.
//
// Wording lives in these two maps and nowhere else, so a store manager can
// change any label by editing one line - no widget code is involved.
// `tool/add_strings.py` adds new keys to both tables at once and regenerates
// the constants below, so the two languages cannot drift apart.

/// Vietnamese (default).
const Map<String, String> stringsVi = <String, String>{
  'app.name': 'Expiry Guardian',
  'app.tagline': 'Quản lý hạn sử dụng theo chính sách công ty',
  'common.ok': 'OK',
  'common.cancel': 'Huỷ bỏ',
  'common.save': 'Lưu',
  'common.saveChanges': 'Lưu thay đổi',
  'common.delete': 'Xoá',
  'common.edit': 'Sửa',
  'common.add': 'Thêm',
  'common.close': 'Đóng',
  'common.back': 'Quay lại',
  'common.next': 'Tiếp tục',
  'common.done': 'Xong',
  'common.retry': 'Thử lại',
  'common.search': 'Tìm kiếm',
  'common.filter': 'Bộ lọc',
  'common.clear': 'Xoá lọc',
  'common.apply': 'Áp dụng',
  'common.confirm': 'Xác nhận',
  'common.yes': 'Có',
  'common.no': 'Không',
  'common.all': 'Tất cả',
  'common.none': 'Không có',
  'common.unknown': 'Chưa rõ',
  'common.loading': 'Đang tải…',
  'common.today': 'Hôm nay',
  'common.tomorrow': 'Ngày mai',
  'common.yesterday': 'Hôm qua',
  'common.notSet': 'Chưa đặt',
  'common.optional': 'Không bắt buộc',
  'common.required': 'Bắt buộc',
  'common.more': 'Thêm',
  'common.seeAll': 'Xem tất cả',
  'common.refresh': 'Làm mới',
  'common.share': 'Chia sẻ',
  'common.export': 'Xuất file',
  'common.quantity': 'Số lượng',
  'common.notes': 'Ghi chú',
  'common.photo': 'Ảnh',
  'common.reason': 'Lý do',
  'common.name': 'Tên',
  'common.code': 'Mã',
  'common.status': 'Trạng thái',
  'common.actions': 'Thao tác',
  'common.empty': 'Chưa có dữ liệu',
  'common.and': 'và',
  'common.of': 'trên',
  'common.items': 'mục',
  'common.units': 'đơn vị',
  'error.generic': 'Đã xảy ra lỗi. Vui lòng thử lại.',
  'error.database': 'Không đọc/ghi được dữ liệu trên máy.',
  'error.notFound': 'Không tìm thấy dữ liệu.',
  'error.duplicate': 'Dữ liệu đã tồn tại.',
  'error.validation': 'Thông tin chưa hợp lệ.',
  'error.permission': 'Bạn không có quyền thực hiện thao tác này.',
  'error.unauthenticated': 'Sai tài khoản hoặc mật khẩu.',
  'error.camera': 'Không mở được camera.',
  'error.recognition': 'Không nhận diện được ảnh.',
  'error.remoteNotConfigured': 'Chưa cấu hình máy chủ đồng bộ.',
  'error.usernameRequired': 'Vui lòng nhập tên đăng nhập.',
  'error.displayNameRequired': 'Vui lòng nhập tên hiển thị.',
  'error.passwordTooShort': 'Mật khẩu quá ngắn (tối thiểu 4 ký tự).',
  'error.usernameTaken': 'Tên đăng nhập đã được dùng.',
  'error.accountDisabled': 'Tài khoản đã bị khoá.',
  'error.nameRequired': 'Vui lòng nhập tên.',
  'error.barcodeRequired': 'Vui lòng nhập mã vạch.',
  'error.barcodeTaken': 'Mã vạch này đã thuộc về sản phẩm khác.',
  'error.quantityPositive': 'Số lượng phải lớn hơn 0.',
  'error.recordNotFound': 'Không tìm thấy lô hàng.',
  'error.recordNotActive': 'Lô hàng này đã đóng.',
  'error.invalidQuantity': 'Số lượng không hợp lệ.',
  'error.captureMissing': 'Không tìm thấy ảnh vừa chụp.',
  'error.scanFailed': 'Quét thất bại. Vui lòng chụp lại.',
  'auth.setupTitle': 'Tạo tài khoản quản trị',
  'auth.setupSubtitle': 'Đây là tài khoản đầu tiên của cửa hàng. Bạn có toàn quyền.',
  'auth.signInTitle': 'Đăng nhập',
  'auth.username': 'Tên đăng nhập',
  'auth.displayName': 'Tên hiển thị',
  'auth.password': 'Mật khẩu',
  'auth.confirmPassword': 'Nhập lại mật khẩu',
  'auth.passwordsDoNotMatch': 'Hai mật khẩu không khớp.',
  'auth.signIn': 'Đăng nhập',
  'auth.signOut': 'Đăng xuất',
  'auth.createAccount': 'Tạo tài khoản',
  'auth.signedInAs': 'Đang đăng nhập:',
  'auth.role': 'Vai trò',
  'auth.role.employee': 'Nhân viên',
  'auth.role.manager': 'Quản lý',
  'auth.role.admin': 'Quản trị',
  'auth.role.employee.desc': 'Quét hàng, xem tồn kho, huỷ hàng.',
  'auth.role.manager.desc': 'Toàn quyền nhân viên, thêm sửa chính sách, danh mục và báo cáo.',
  'auth.role.admin.desc': 'Toàn quyền, kể cả quản lý người dùng và cài đặt hệ thống.',
  'auth.changePassword': 'Đổi mật khẩu',
  'auth.currentPassword': 'Mật khẩu hiện tại',
  'auth.newPassword': 'Mật khẩu mới',
  'auth.passwordChanged': 'Đã đổi mật khẩu.',
  'nav.today': 'Hôm nay',
  'nav.scan': 'Quét',
  'nav.inventory': 'Tồn kho',
  'nav.reports': 'Báo cáo',
  'nav.more': 'Khác',
  'nav.dashboard': 'Tổng quan',
  'nav.insights': 'Dự báo',
  'nav.settings': 'Cài đặt',
  'dashboard.title': 'Tổng quan',
  'dashboard.totalProducts': 'Lô hàng đang theo dõi',
  'dashboard.approaching': 'Sắp đến hạn huỷ',
  'dashboard.destroyedToday': 'Đã huỷ hôm nay',
  'dashboard.expired': 'Đã quá hạn sử dụng',
  'dashboard.financialLoss': 'Thiệt hại hôm nay',
  'dashboard.stockValue': 'Giá trị tồn kho',
  'dashboard.trend': 'Xu hướng huỷ hàng',
  'dashboard.trend7': '7 ngày',
  'dashboard.trend30': '30 ngày',
  'dashboard.trend90': '90 ngày',
  'dashboard.partialLossWarning': 'Chỉ tính được {priced}/{total} lô có giá vốn. Nhập giá vốn để có số liệu đầy đủ.',
  'dashboard.noCostData': 'Chưa nhập giá vốn nên chưa tính được thiệt hại.',
  'dashboard.overdue': 'Quá hạn huỷ',
  'dashboard.dueToday': 'Đến hạn hôm nay',
  'today.title': 'Danh sách huỷ hôm nay',
  'today.empty': 'Không có sản phẩm nào cần huỷ hôm nay.',
  'today.emptyHint': 'Danh sách được tạo tự động mỗi sáng từ chính sách của công ty.',
  'today.generatedAt': 'Cập nhật lúc {time}',
  'today.itemsToDestroy': '{count} sản phẩm cần huỷ',
  'today.urgentCount': '{count} mục cần xử lý ngay',
  'today.estimatedLoss': 'Thiệt hại ước tính',
  'today.markDestroyed': 'Đã huỷ',
  'today.destroyAll': 'Huỷ toàn bộ kệ này',
  'today.route': 'Lộ trình kiểm tra',
  'today.noShelf': 'Chưa gán kệ',
  'today.noArea': 'Chưa gán khu vực',
  'priority.safe': 'An toàn',
  'priority.approaching': 'Sắp đến hạn',
  'priority.destroySoon': 'Huỷ trong 24 giờ',
  'priority.destroyNow': 'Huỷ ngay',
  'priority.expired': 'Đã quá hạn',
  'priority.legend': 'Chú thích màu',
  'scan.title': 'Quét hàng nhập',
  'scan.step.barcode': '1. Quét mã vạch',
  'scan.step.dates': '2. Chụp hạn sử dụng',
  'scan.step.review': '3. Kiểm tra và lưu',
  'scan.aimBarcode': 'Đưa mã vạch vào khung',
  'scan.aimLabel': 'Đưa phần in hạn sử dụng vào khung',
  'scan.capture': 'Chụp',
  'scan.retake': 'Chụp lại',
  'scan.torch': 'Đèn',
  'scan.processing': 'Đang xử lý ảnh…',
  'scan.quality.good': 'Ảnh rõ nét',
  'scan.quality.blurry': 'Ảnh bị mờ – giữ máy chắc tay rồi chụp lại',
  'scan.quality.dark': 'Thiếu sáng – bật đèn hoặc tới chỗ sáng hơn',
  'scan.quality.bright': 'Quá chói – tránh ánh sáng chiếu thẳng',
  'scan.enhanced': 'Đã tự động xử lý ảnh: {steps}',
  'scan.noBarcode': 'Chưa đọc được mã vạch.',
  'scan.enterBarcode': 'Nhập mã vạch bằng tay',
  'scan.unknownProduct': 'Mã vạch chưa có trong danh mục',
  'scan.unknownProductHint': 'Nhập thông tin một lần, lần sau hệ thống sẽ tự nhận ra.',
  'scan.createProduct': 'Thêm sản phẩm mới',
  'scan.foundProduct': 'Đã nhận ra sản phẩm',
  'scan.readFromBarcode': 'Đọc từ mã vạch GS1',
  'scan.readFromPhoto': 'Đọc từ ảnh (OCR)',
  'scan.enteredManually': 'Nhập tay',
  'scan.fromCatalog': 'Lấy từ danh mục',
  'scan.noDateFound': 'Chưa đọc được ngày trên nhãn. Vui lòng nhập tay.',
  'scan.checkDates': 'Kiểm tra lại ngày trước khi lưu',
  'scan.warning.ambiguous': 'Ngày/tháng có thể bị đảo – hãy kiểm tra kỹ.',
  'scan.warning.expiryPassed': 'Ngày hết hạn đã qua.',
  'scan.warning.expiryBeforeMfg': 'Hạn sử dụng sớm hơn ngày sản xuất.',
  'scan.warning.monthOnly': 'Nhãn chỉ in tháng/năm – hệ thống lấy ngày cuối tháng.',
  'scan.warning.multipleExpiry': 'Tìm thấy nhiều ngày hết hạn – hãy chọn đúng.',
  'scan.saveRecord': 'Lưu lô hàng',
  'scan.savedRecord': 'Đã lưu lô {code}',
  'scan.scanNext': 'Quét lô tiếp theo',
  'scan.permissionTitle': 'Cần quyền camera',
  'scan.permissionBody': 'Ứng dụng cần camera để quét mã vạch và đọc hạn sử dụng.',
  'scan.openSettings': 'Mở cài đặt',
  'record.barcode': 'Mã vạch',
  'record.product': 'Sản phẩm',
  'record.brand': 'Thương hiệu',
  'record.category': 'Ngành hàng',
  'record.batch': 'Số lô',
  'record.manufacturedAt': 'Ngày sản xuất',
  'record.expiryAt': 'Hạn sử dụng',
  'record.expiryTime': 'Giờ hết hạn',
  'record.destroyAt': 'Hạn huỷ',
  'record.shelf': 'Kệ',
  'record.area': 'Khu vực',
  'record.quantity': 'Số lượng',
  'record.remaining': 'Còn lại',
  'record.unit': 'Đơn vị',
  'record.unitCost': 'Giá vốn / đơn vị',
  'record.receivedAt': 'Ngày nhập',
  'record.code': 'Mã lô',
  'record.history': 'Lịch sử',
  'record.shelfLife': 'Tuổi thọ sản phẩm',
  'record.leadTime': 'Huỷ trước hạn',
  'record.appliedRule': 'Quy tắc áp dụng',
  'record.policyVersion': 'Phiên bản chính sách',
  'record.fallbackRule': 'Không khớp quy tắc nào – dùng giá trị mặc định',
  'record.hourly': 'Hàng theo giờ',
  'record.daily': 'Hàng theo ngày',
  'record.timeLeft': 'Còn {duration}',
  'record.overdueBy': 'Quá hạn {duration}',
  'record.status.active': 'Đang theo dõi',
  'record.status.destroyed': 'Đã huỷ',
  'record.status.soldOut': 'Đã bán hết',
  'record.status.removed': 'Đã loại bỏ',
  'event.created': 'Tạo lô hàng',
  'event.updated': 'Cập nhật',
  'event.quantityAdjusted': 'Điều chỉnh số lượng',
  'event.moved': 'Chuyển kệ',
  'event.destroyed': 'Huỷ hàng',
  'event.soldOut': 'Bán hết',
  'event.removed': 'Loại bỏ',
  'event.reopened': 'Mở lại',
  'event.policyRecalculated': 'Tính lại theo chính sách mới',
  'event.photoAttached': 'Đính kèm ảnh',
  'event.noteAdded': 'Thêm ghi chú',
  'destroy.title': 'Xác nhận huỷ hàng',
  'destroy.quantityToDestroy': 'Số lượng huỷ',
  'destroy.all': 'Huỷ toàn bộ',
  'destroy.partial': 'Huỷ một phần',
  'destroy.reason.policy': 'Theo chính sách hạn dùng',
  'destroy.reason.damaged': 'Hư hỏng',
  'destroy.reason.recalled': 'Thu hồi',
  'destroy.reason.contaminated': 'Nhiễm bẩn',
  'destroy.reason.other': 'Khác',
  'destroy.takePhoto': 'Chụp ảnh làm bằng chứng',
  'destroy.confirm': 'Xác nhận đã huỷ',
  'destroy.done': 'Đã ghi nhận huỷ {quantity} {unit}',
  'destroy.overdueNotice': 'Lô này đã quá hạn huỷ {duration}.',
  'destroy.lossRecorded': 'Thiệt hại ghi nhận: {amount}',
  'destroy.noCost': 'Chưa có giá vốn nên thiệt hại ghi nhận bằng 0.',
  'inventory.title': 'Tồn kho',
  'inventory.searchHint': 'Tìm theo tên, mã vạch, số lô, mã kệ…',
  'inventory.empty': 'Chưa có lô hàng nào.',
  'inventory.emptyHint': 'Bấm Quét để nhập lô hàng đầu tiên.',
  'inventory.resultCount': '{count} kết quả',
  'inventory.filter.status': 'Trạng thái',
  'inventory.filter.priority': 'Mức ưu tiên',
  'inventory.filter.area': 'Khu vực',
  'inventory.filter.shelf': 'Kệ',
  'inventory.filter.category': 'Ngành hàng',
  'inventory.filter.expiry': 'Hạn sử dụng',
  'inventory.filter.batch': 'Số lô',
  'inventory.sort': 'Sắp xếp',
  'inventory.sort.priority': 'Ưu tiên',
  'inventory.sort.destroyDate': 'Hạn huỷ',
  'inventory.sort.expiryDate': 'Hạn sử dụng',
  'inventory.sort.receivedDate': 'Ngày nhập',
  'inventory.sort.productName': 'Tên sản phẩm',
  'inventory.sort.location': 'Vị trí',
  'inventory.adjustQuantity': 'Điều chỉnh số lượng',
  'inventory.moveShelf': 'Chuyển kệ',
  'inventory.markSoldOut': 'Đánh dấu đã bán hết',
  'inventory.remove': 'Loại khỏi tồn kho',
  'catalog.title': 'Danh mục sản phẩm',
  'catalog.newProduct': 'Sản phẩm mới',
  'catalog.editProduct': 'Sửa sản phẩm',
  'catalog.empty': 'Danh mục còn trống.',
  'catalog.emptyHint': 'Sản phẩm được thêm khi bạn quét mã vạch lần đầu.',
  'catalog.extraBarcodes': 'Mã vạch phụ (thùng, lốc)',
  'catalog.defaultShelf': 'Kệ mặc định',
  'catalog.photo': 'Ảnh sản phẩm',
  'catalog.photoHint': 'Không bắt buộc. Hiện trong danh sách tồn kho để nhận ra hàng bằng mắt.',
  'catalog.noBarcode': 'Chưa có mã vạch',
  'catalog.expiryPrecision': 'Kiểu hạn sử dụng',
  'catalog.defaultShelfLife': 'Tuổi thọ mặc định',
  'catalog.defaultShelfLifeHint': 'Dùng để cảnh báo khi OCR đọc ra ngày vô lý.',
  'catalog.unitCostHint': 'Để trống nếu chưa biết. Không có giá vốn thì không tính được thiệt hại.',
  'catalog.categories': 'Ngành hàng',
  'catalog.newCategory': 'Ngành hàng mới',
  'catalog.productInUse': 'Sản phẩm đang có lô hàng nên chỉ được ẩn đi, không xoá.',
  'locations.title': 'Khu vực và kệ',
  'locations.areas': 'Khu vực',
  'locations.shelves': 'Kệ',
  'locations.newArea': 'Khu vực mới',
  'locations.newShelf': 'Kệ mới',
  'locations.empty': 'Chưa khai báo khu vực nào.',
  'locations.emptyHint': 'Khai báo khu vực và kệ để danh sách huỷ được sắp theo đường đi trong cửa hàng.',
  'locations.sortOrderHint': 'Thứ tự đi trong cửa hàng (số nhỏ đi trước).',
  'locations.deleteAreaWarning': 'Xoá khu vực sẽ xoá luôn các kệ bên trong.',
  'policy.title': 'Chính sách huỷ hàng',
  'policy.subtitle': 'Toàn bộ quy tắc dưới đây do quản lý tự chỉnh, không cố định trong ứng dụng.',
  'policy.activePolicy': 'Chính sách đang áp dụng',
  'policy.version': 'Phiên bản {version}',
  'policy.rules': 'Các quy tắc',
  'policy.newRule': 'Thêm quy tắc',
  'policy.editRule': 'Sửa quy tắc',
  'policy.ruleName': 'Tên quy tắc',
  'policy.shelfLifeFrom': 'Tuổi thọ từ',
  'policy.shelfLifeTo': 'Đến',
  'policy.inclusive': 'Bao gồm mốc này',
  'policy.exclusive': 'Không bao gồm mốc này',
  'policy.noLowerBound': 'Không giới hạn dưới',
  'policy.noUpperBound': 'Không giới hạn trên',
  'policy.leadTime': 'Huỷ trước hạn',
  'policy.matchesHourly': 'Áp dụng cho mọi hàng tính theo giờ',
  'policy.ruleActive': 'Đang áp dụng',
  'policy.basis': 'Cách tính tuổi thọ',
  'policy.basis.manufacturing': 'Từ ngày sản xuất đến hạn sử dụng',
  'policy.basis.intake': 'Từ ngày nhập hàng đến hạn sử dụng',
  'policy.fallbackBasis': 'Khi nhãn không có ngày sản xuất thì tính từ ngày nhập',
  'policy.endOfDay': 'Nhãn chỉ ghi ngày thì hàng dùng được hết ngày đó',
  'policy.fallbackLead': 'Thời gian huỷ trước hạn khi không quy tắc nào khớp',
  'policy.normalizeTime': 'Giờ huỷ cố định trong ngày',
  'policy.normalizeTimeHint': 'Bật để mọi việc huỷ trong ngày rơi vào cùng một giờ.',
  'policy.thresholds': 'Ngưỡng màu cảnh báo',
  'policy.orangeWindow': 'Chuyển màu cam khi còn',
  'policy.yellowWindow': 'Chuyển màu vàng khi còn',
  'policy.recalculate': 'Áp dụng cho hàng đang có',
  'policy.recalculated': 'Đã tính lại {count} lô hàng.',
  'policy.preview': 'Thử tính',
  'policy.previewHint': 'Nhập ngày sản xuất và hạn sử dụng để xem hệ thống chọn quy tắc nào.',
  'policy.previewResult': 'Áp dụng quy tắc “{rule}”, huỷ vào {destroyAt}.',
  'policy.issue.noActiveRules': 'Chính sách chưa có quy tắc nào đang bật.',
  'policy.issue.negativeLeadTime': 'Thời gian huỷ trước hạn không được âm.',
  'policy.issue.invertedRange': 'Mốc dưới lớn hơn mốc trên.',
  'policy.issue.coverageGap': 'Có khoảng tuổi thọ không quy tắc nào phủ (khoảng {days} ngày).',
  'policy.issue.overlappingRules': 'Hai quy tắc cùng phủ một khoảng tuổi thọ.',
  'policy.issue.noCatchAll': 'Không có quy tắc nào cho hàng tuổi thọ rất dài.',
  'policy.issue.leadTimeExceedsShelfLife': 'Thời gian huỷ trước hạn dài hơn cả tuổi thọ của nhóm này.',
  'policy.issue.duplicateSortOrder': 'Hai quy tắc có cùng thứ tự ưu tiên.',
  'policy.issuesFound': '{count} cảnh báo cần xem lại',
  'policy.noIssues': 'Chính sách hợp lệ.',
  'notif.title': 'Thông báo',
  'notif.dailyDigest': 'Tóm tắt buổi sáng',
  'notif.dailyDigestTime': 'Giờ gửi tóm tắt',
  'notif.perItem': 'Cảnh báo từng lô hàng',
  'notif.perItemLead': 'Nhắc trước hạn huỷ',
  'notif.overdue': 'Nhắc lại khi đã quá hạn',
  'notif.quietHours': 'Giờ yên lặng',
  'notif.quietHoursHint': 'Thông báo trong khoảng này sẽ dời tới sau giờ yên lặng.',
  'notif.permissionNeeded': 'Cần cấp quyền thông báo để nhận nhắc nhở.',
  'notif.exactAlarmNeeded': 'Android cần thêm quyền “báo thức chính xác” để nhắc đúng phút.',
  'notif.grant': 'Cấp quyền',
  'notif.scheduled': 'Đã đặt {count} nhắc nhở.',
  'notif.digestTitle': 'Danh sách huỷ hôm nay',
  'notif.digestBody': 'Bạn có {count} sản phẩm cần huỷ hôm nay.',
  'notif.digestBodyWithUrgent': 'Bạn có {count} sản phẩm cần huỷ hôm nay, {urgent} mục cần xử lý ngay.',
  'notif.itemDueTitle': 'Sắp tới hạn huỷ',
  'notif.itemDueBody': '{product} tại {location} phải huỷ trong {duration}.',
  'notif.itemDueBodyNoLocation': '{product} phải huỷ trong {duration}.',
  'notif.itemOverdueTitle': 'Quá hạn huỷ',
  'notif.itemOverdueBody': '{product} tại {location} đã quá hạn huỷ.',
  'reports.title': 'Báo cáo',
  'reports.daily': 'Ngày',
  'reports.weekly': 'Tuần',
  'reports.monthly': 'Tháng',
  'reports.destroyedQuantity': 'Số lượng đã huỷ',
  'reports.destroyedRecords': 'Số lô đã huỷ',
  'reports.expiredQuantity': 'Huỷ khi đã quá hạn sử dụng',
  'reports.overdueRecords': 'Huỷ trễ so với chính sách',
  'reports.onTimeRate': 'Tỷ lệ huỷ đúng hạn',
  'reports.financialLoss': 'Thiệt hại',
  'reports.mostWastedCategories': 'Ngành hàng lãng phí nhất',
  'reports.byShelf': 'Theo kệ',
  'reports.byProduct': 'Theo sản phẩm',
  'reports.byReason': 'Theo lý do',
  'reports.trend': 'Diễn biến',
  'reports.exportCsv': 'Xuất CSV',
  'reports.exported': 'Đã xuất báo cáo.',
  'reports.empty': 'Chưa có dữ liệu huỷ hàng trong kỳ này.',
  'reports.partialLoss': 'Thiệt hại chỉ tính trên {priced}/{total} lô có giá vốn.',
  'reports.previousPeriod': 'Kỳ trước',
  'reports.change': 'Thay đổi',
  'insights.title': 'Dự báo và phân tích',
  'insights.subtitle': 'Tính từ dữ liệu thật của cửa hàng, không phải số liệu mẫu.',
  'insights.shelfRisk': 'Kệ hay có hàng quá hạn',
  'insights.categoryRisk': 'Ngành hàng rủi ro cao',
  'insights.forgotten': 'Sản phẩm hay bị quên',
  'insights.route': 'Lộ trình kiểm tra gợi ý',
  'insights.forecast': 'Dự báo lãng phí',
  'insights.insufficient': 'Chưa đủ dữ liệu',
  'insights.insufficientHint': 'Cần ít nhất {required} lượt huỷ được ghi nhận; hiện có {actual}.',
  'insights.basedOn': 'Dựa trên {days} ngày gần nhất',
  'insights.wasteRate': 'Tỷ lệ huỷ {rate}',
  'insights.confidenceNote': 'Xếp hạng theo cận dưới khoảng tin cậy 95% nên vài lô lẻ không làm sai lệch.',
  'insights.sampleSize': '{count} lô nhập',
  'insights.overdueShare': '{rate} bị huỷ trễ',
  'insights.routeStops': '{stops} điểm dừng · {items} lô · khoảng {minutes} phút',
  'insights.routeEmpty': 'Hôm nay không cần đi kiểm tra kệ nào.',
  'insights.forecastScheduled': 'Chắc chắn phải huỷ trong {days} ngày tới',
  'insights.forecastProjected': 'Ước tính theo tốc độ huỷ trung bình',
  'insights.forecastNote': 'Phần “chắc chắn” lấy trực tiếp từ hạn huỷ đã tính; phần “ước tính” chỉ là phép ngoại suy.',
  'settings.title': 'Cài đặt',
  'settings.general': 'Chung',
  'settings.language': 'Ngôn ngữ',
  'settings.theme': 'Giao diện',
  'settings.theme.system': 'Theo hệ thống',
  'settings.theme.light': 'Sáng',
  'settings.theme.dark': 'Tối',
  'settings.storeName': 'Tên cửa hàng',
  'settings.currency': 'Tiền tệ',
  'settings.scanning': 'Quét và nhận diện',
  'settings.enhanceImages': 'Tự động cải thiện ảnh',
  'settings.keepPhotos': 'Lưu ảnh nhãn',
  'settings.dayFirst': 'Đọc ngày theo kiểu ngày/tháng',
  'settings.dayFirstHint': 'Tắt nếu hàng nhập chủ yếu in kiểu tháng/ngày (Mỹ).',
  'settings.blurThreshold': 'Ngưỡng cảnh báo ảnh mờ',
  'settings.darkThreshold': 'Ngưỡng cảnh báo thiếu sáng',
  'settings.maxFutureYears': 'Số năm tối đa của hạn sử dụng',
  'settings.destroyRules': 'Quy trình huỷ',
  'settings.requirePhoto': 'Bắt buộc chụp ảnh khi huỷ',
  'settings.requireReason': 'Bắt buộc chọn lý do khi huỷ',
  'settings.insights': 'Phân tích',
  'settings.lookbackDays': 'Số ngày lấy dữ liệu phân tích',
  'settings.forecastDays': 'Số ngày dự báo',
  'settings.minimumSamples': 'Số mẫu tối thiểu để hiển thị dự báo',
  'settings.users': 'Người dùng',
  'settings.newUser': 'Thêm người dùng',
  'settings.deactivate': 'Khoá tài khoản',
  'settings.activate': 'Mở khoá tài khoản',
  'settings.data': 'Dữ liệu',
  'settings.sync': 'Đồng bộ',
  'settings.about': 'Giới thiệu',
  'settings.version': 'Phiên bản {version} ({build})',
  'settings.resetData': 'Xoá toàn bộ dữ liệu vận hành',
  'settings.resetDataWarning': 'Thao tác này xoá mọi lô hàng, lịch sử và bản ghi huỷ. Danh mục, kệ và chính sách được giữ lại. Không thể hoàn tác.',
  'settings.resetDone': 'Đã xoá dữ liệu vận hành.',
  'sync.title': 'Đồng bộ',
  'sync.offlineOnly': 'Chế độ ngoại tuyến hoàn toàn',
  'sync.offlineOnlyBody': 'Bản cài đặt này chưa nối máy chủ. Mọi dữ liệu nằm trên máy và vẫn được xếp hàng chờ để đẩy lên khi bạn kết nối máy chủ sau này.',
  'sync.pending': '{count} thay đổi đang chờ đồng bộ',
  'sync.lastSuccess': 'Lần đồng bộ gần nhất: {time}',
  'sync.never': 'Chưa đồng bộ lần nào',
  'sync.syncNow': 'Đồng bộ ngay',
  'sync.online': 'Có mạng',
  'sync.offline': 'Không có mạng',
  'sync.phase.idle': 'Sẵn sàng',
  'sync.phase.checking': 'Đang kiểm tra…',
  'sync.phase.pushing': 'Đang gửi lên…',
  'sync.phase.pulling': 'Đang tải về…',
  'sync.phase.backingOff': 'Sẽ thử lại sau',
  'sync.phase.error': 'Lỗi đồng bộ',
  'time.days': '{count} ngày',
  'time.hours': '{count} giờ',
  'time.minutes': '{count} phút',
  'time.months': '{count} tháng',
  'time.years': '{count} năm',
  'time.now': 'ngay bây giờ',
  'notif.workflow': 'Quy trình nhắc nhở',
  'notif.workflow.subtitle': 'Bốn mốc nhắc quanh hạn huỷ. Mọi mốc và khoảng thời gian đều sửa được.',
  'notif.stage.kind.earlyWarning': 'Cảnh báo sớm',
  'notif.stage.kind.finalReminder': 'Nhắc lần cuối',
  'notif.stage.kind.mandatory': 'Bắt buộc huỷ',
  'notif.stage.kind.repeatUntilConfirmed': 'Nhắc lại tới khi xác nhận',
  'notif.stage.offsetBefore': 'Trước hạn huỷ {duration}',
  'notif.stage.offsetAt': 'Đúng lúc tới hạn huỷ',
  'notif.stage.offsetAfter': 'Sau hạn huỷ {duration}',
  'notif.stage.offset': 'Thời điểm nhắc',
  'notif.stage.direction': 'Trước hay sau hạn huỷ',
  'notif.stage.before': 'Trước',
  'notif.stage.after': 'Sau',
  'notif.stage.repeatEvery': 'Lặp lại mỗi',
  'notif.stage.maxRepeats': 'Số lần lặp tối đa',
  'notif.stage.repeatNote': 'Chỉ lặp tới khi nhân viên xác nhận đã huỷ. Xác nhận xong là dừng ngay.',
  'notif.stage.new': 'Thêm mốc nhắc',
  'notif.stage.edit': 'Sửa mốc nhắc',
  'notif.stage.name': 'Tên mốc',
  'notif.stage.restoreDefaults': 'Khôi phục mốc mặc định',
  'notif.stage.restored': 'Đã khôi phục mốc nhắc mặc định.',
  'notif.stage.count': '{count} mốc đang bật',
  'notif.stage.plannedPerLot': 'Mỗi lô sinh tối đa {count} lượt nhắc',
  'notif.stage.earlyTitle': 'Sắp tới hạn huỷ',
  'notif.stage.earlyBody': '{product} tại {location} phải huỷ sau {duration} nữa.',
  'notif.stage.finalTitle': 'Nhắc lần cuối trước hạn huỷ',
  'notif.stage.finalBody': '{product} tại {location} phải huỷ trong {duration}.',
  'notif.stage.mandatoryTitle': 'Bắt buộc huỷ ngay',
  'notif.stage.mandatoryBody': '{product} tại {location} đã tới hạn huỷ. Hãy huỷ và xác nhận.',
  'notif.stage.repeatTitle': 'Chưa xác nhận huỷ',
  'notif.stage.repeatBody': '{product} tại {location} vẫn chưa được xác nhận huỷ (lần nhắc {attempt}).',
  'notif.escalationTitle': 'Cảnh báo quản lý',
  'notif.escalationBody': '{product} tại {location} quá hạn huỷ {duration} mà chưa ai xác nhận.',
  'destroy.confirmation': 'Xác nhận huỷ hàng',
  'destroy.confirmedBy': 'Người xác nhận',
  'destroy.confirmedAt': 'Thời điểm xác nhận',
  'destroy.device': 'Thiết bị',
  'destroy.remindersCancelled': 'Đã huỷ {count} lượt nhắc còn lại.',
  'destroy.mustConfirm': 'Mỗi lô hàng huỷ đều phải có người xác nhận.',
  'destroy.reasonRequired': 'Vui lòng chọn lý do huỷ.',
  'destroy.photoRequired': 'Vui lòng chụp ảnh làm bằng chứng.',
  'escalation.title': 'Báo cáo quản lý',
  'escalation.subtitle': 'Lô hàng quá hạn mà chưa ai xác nhận huỷ sẽ tự động báo lên quản lý.',
  'escalation.dashboard': 'Bảng quản lý',
  'escalation.rules': 'Quy tắc báo lên',
  'escalation.newRule': 'Thêm quy tắc báo lên',
  'escalation.editRule': 'Sửa quy tắc báo lên',
  'escalation.ruleName': 'Tên quy tắc',
  'escalation.delayAfterDestroy': 'Báo lên sau hạn huỷ',
  'escalation.notifyRole': 'Báo cho vai trò',
  'escalation.severity': 'Mức nghiêm trọng',
  'escalation.severity.warning': 'Cảnh báo',
  'escalation.severity.critical': 'Nghiêm trọng',
  'escalation.repeatEvery': 'Nhắc lại quản lý mỗi',
  'escalation.maxRepeats': 'Số lần nhắc tối đa',
  'escalation.enabled': 'Bật tự động báo lên quản lý',
  'escalation.open': 'Đang chờ xử lý',
  'escalation.resolvedTab': 'Đã xử lý',
  'escalation.none': 'Không có cảnh báo nào.',
  'escalation.noneHint': 'Mọi lô hàng tới hạn đều đã được xác nhận huỷ đúng giờ.',
  'escalation.acknowledge': 'Đã tiếp nhận',
  'escalation.acknowledged': 'Đã tiếp nhận cảnh báo.',
  'escalation.acknowledgedBy': 'Người tiếp nhận',
  'escalation.level': 'Mức {level}',
  'escalation.raisedAt': 'Báo lên lúc',
  'escalation.overdueBy': 'Quá hạn {duration}',
  'escalation.managerOverride': 'Quản lý xử lý thay',
  'escalation.overrideHint': 'Quản lý đóng cảnh báo mà không huỷ hàng. Bắt buộc ghi lý do.',
  'escalation.overrideReason': 'Lý do xử lý thay',
  'escalation.overrideDone': 'Đã ghi nhận quyết định của quản lý.',
  'escalation.criticalCount': '{count} cảnh báo nghiêm trọng',
  'escalation.warningCount': '{count} cảnh báo',
  'escalation.restoreDefaults': 'Khôi phục quy tắc mặc định',
  'escalation.resolution.destroyed': 'Đã huỷ hàng',
  'escalation.resolution.acknowledged': 'Quản lý đã tiếp nhận',
  'escalation.resolution.override': 'Quản lý xử lý thay',
  'escalation.resolution.cancelled': 'Lô hàng đã đóng',
  'escalation.scanNow': 'Kiểm tra ngay',
  'escalation.raisedCount': 'Đã tạo {count} cảnh báo mới.',
  'audit.title': 'Nhật ký kiểm toán',
  'audit.subtitle': 'Mọi thao tác đều được ghi lại và không thể sửa hay xoá.',
  'audit.verify': 'Kiểm tra tính toàn vẹn',
  'audit.intact': 'Nhật ký nguyên vẹn: đã kiểm tra {count} bản ghi.',
  'audit.broken': 'Phát hiện sai lệch tại bản ghi #{sequence}.',
  'audit.immutableNote': 'Mỗi bản ghi mang mã băm của bản ghi trước, nên chỉ cần sửa một dòng là phát hiện được ngay.',
  'audit.previousValue': 'Giá trị cũ',
  'audit.newValue': 'Giá trị mới',
  'audit.actor': 'Người thực hiện',
  'audit.device': 'Thiết bị',
  'audit.action': 'Thao tác',
  'audit.entity': 'Đối tượng',
  'audit.entries': '{count} bản ghi',
  'audit.empty': 'Chưa có thao tác nào được ghi.',
  'audit.filterAction': 'Lọc theo thao tác',
  'audit.noChange': 'Không có thay đổi giá trị',
  'audit.action.productCreated': 'Tạo sản phẩm',
  'audit.action.productUpdated': 'Sửa sản phẩm',
  'audit.action.productDeleted': 'Xoá sản phẩm',
  'audit.action.recordCreated': 'Tạo lô hàng',
  'audit.action.recordScanned': 'Quét mã',
  'audit.action.recordEdited': 'Sửa lô hàng',
  'audit.action.recordMoved': 'Chuyển kệ',
  'audit.action.quantityAdjusted': 'Điều chỉnh số lượng',
  'audit.action.recordClosed': 'Đóng lô hàng',
  'audit.action.destroyReminderScheduled': 'Đặt lịch nhắc huỷ',
  'audit.action.destroyReminderFired': 'Đã nhắc huỷ',
  'audit.action.destroyConfirmed': 'Xác nhận đã huỷ',
  'audit.action.escalationRaised': 'Báo lên quản lý',
  'audit.action.escalationNotified': 'Đã báo quản lý',
  'audit.action.escalationAcknowledged': 'Quản lý tiếp nhận',
  'audit.action.escalationResolved': 'Đóng cảnh báo',
  'audit.action.managerOverride': 'Quản lý xử lý thay',
  'audit.action.policyEdited': 'Sửa chính sách',
  'audit.action.policyRuleEdited': 'Sửa quy tắc',
  'audit.action.policyRecalculated': 'Tính lại theo chính sách',
  'audit.action.notificationStageEdited': 'Sửa mốc nhắc',
  'audit.action.escalationRuleEdited': 'Sửa quy tắc báo lên',
  'audit.action.locationEdited': 'Sửa khu vực/kệ',
  'audit.action.settingChanged': 'Đổi cài đặt',
  'audit.action.userCreated': 'Tạo người dùng',
  'audit.action.userUpdated': 'Sửa người dùng',
  'audit.action.userSignedIn': 'Đăng nhập',
  'audit.action.userSignedOut': 'Đăng xuất',
  'audit.action.passwordChanged': 'Đổi mật khẩu',
  'audit.action.reportExported': 'Xuất báo cáo',
  'audit.action.dataReset': 'Xoá dữ liệu vận hành',
  'export.title': 'Xuất báo cáo',
  'export.template': 'Mẫu báo cáo',
  'export.template.dailyDestroy': 'Báo cáo huỷ hàng ngày',
  'export.template.weekly': 'Báo cáo tuần',
  'export.template.monthly': 'Báo cáo tháng',
  'export.template.audit': 'Báo cáo kiểm toán',
  'export.template.inventory': 'Báo cáo tồn kho',
  'export.template.expired': 'Báo cáo hàng quá hạn',
  'export.destination': 'Định dạng',
  'export.destination.localPdf': 'File PDF',
  'export.destination.localHtml': 'File HTML',
  'export.destination.localCsv': 'File CSV (Excel)',
  'export.destination.googleDocs': 'Google Docs',
  'export.includePhotos': 'Kèm ảnh',
  'export.includeSignatures': 'Kèm ô ký tên',
  'export.includeStatistics': 'Kèm phần thống kê',
  'export.generate': 'Tạo báo cáo',
  'export.generating': 'Đang tạo báo cáo…',
  'export.done': 'Đã tạo xong báo cáo.',
  'export.failed': 'Không tạo được báo cáo.',
  'export.history': 'Báo cáo đã tạo',
  'export.share': 'Chia sẻ',
  'export.open': 'Mở',
  'export.noData': 'Không có dữ liệu trong kỳ này.',
  'export.period': 'Kỳ báo cáo',
  'export.company': 'Công ty',
  'export.store': 'Cửa hàng',
  'export.generatedAt': 'Thời điểm lập',
  'export.generatedBy': 'Người lập',
  'export.section.summary': 'Thống kê',
  'export.section.details': 'Chi tiết',
  'export.section.photos': 'Hình ảnh',
  'export.section.signatures': 'Ký xác nhận',
  'export.signature.preparedBy': 'Người lập',
  'export.signature.checkedBy': 'Người kiểm tra',
  'export.signature.approvedBy': 'Người duyệt',
  'export.googleNotConfigured': 'Chưa cấu hình Google Docs. Bản này xuất ra file PDF/HTML/CSV dùng ngay được; xem docs/SYNC_CONTRACT.md để nối Google Docs sau.',
  'export.googleClientId': 'Google OAuth client ID',
  'export.googleFolderId': 'Thư mục Google Drive',
  'settings.workflow': 'Quy trình vận hành',
  'settings.device': 'Thiết bị này',
  'settings.deviceName': 'Tên thiết bị',
  'settings.deviceNameHint': 'Ví dụ: Máy quầy 1. Tên này xuất hiện trong nhật ký kiểm toán.',
  'settings.company': 'Tên công ty',
  'settings.storeCode': 'Mã cửa hàng',
  'settings.audit': 'Nhật ký kiểm toán',
  'settings.export': 'Xuất báo cáo',
  'nav.manager': 'Quản lý',
  'notif.stage.active': 'Đang bật mốc nhắc này',
  'export.pdfNotAvailableHere': 'Định dạng này không tạo được file PDF. Hãy chọn định dạng PDF.',
  'export.fontsMissing': 'Thiếu phông chữ báo cáo nên không tạo được PDF. Hãy dùng HTML hoặc CSV.',
  'export.savedTo': 'Đã lưu vào {path}',
  'error.exportFailed': 'Không tạo được báo cáo. Kiểm tra dung lượng máy rồi thử lại.',
  'error.exportNotFound': 'Không tìm thấy báo cáo này.',
  'manager.title': 'Quản lý',
  'manager.subtitle': 'Cảnh báo quá hạn, nhật ký kiểm toán và xuất báo cáo.',
  'manager.noAccess': 'Chỉ quản lý và quản trị mới xem được mục này.',
  'scan.liveHint': 'Đưa mã vạch vào khung - máy tự đọc, không cần bấm',
  'scan.productPhoto': 'Ảnh mặt sản phẩm',
  'scan.productPhotoHint': 'Không bắt buộc. Chụp mặt trước để người sau nhận ra đúng hàng.',
  'scan.retakePhoto': 'Chụp lại',
  'scan.removePhoto': 'Bỏ ảnh',
  'scan.barcodeNotRead': 'Không đọc được mã vạch, nhưng ảnh đã được lưu. Hãy nhìn ảnh và nhập số bên dưới.',
  'scan.barcodePhoto': 'Ảnh mã vạch',
  'scan.barcodePhotoKept': 'Ảnh này sẽ được lưu cùng sản phẩm.',
  'scan.typeBarcode': 'Nhập mã vạch',
  'scan.aimProductFront': 'Chụp mặt trước sản phẩm',
  'locations.shelfSaved': 'Đã lưu kệ',
  'locations.areaSaved': 'Đã lưu khu vực',
  'locations.nameRequired': 'Hãy nhập tên trước khi lưu.',
  'notif.maxScheduled': 'Số lời nhắc tối đa giữ trong máy',
  'notif.maxScheduledHint': 'Android chỉ cho giữ khoảng 500 báo thức. Số càng lớn thì dựng lại lịch càng lâu.',
  'scan.recalledProduct': 'Đã nhớ sản phẩm này từ lần trước - chỉ cần nhập ngày.',
  'scan.recalledWithShelf': 'Đã nhớ sản phẩm và kệ {shelf} - chỉ cần nhập ngày.',
  'scan.autoAdvance': 'Tự chuyển sang bước quét ngày',
  'scan.autoAdvanceHint': 'Khi quét mã đã biết, mở luôn camera đọc ngày thay vì phải bấm thêm.',
  'scan.liveTextHint': 'Đưa dòng ngày vào khung - máy tự đọc, không cần bấm',
  'notif.blockedTitle': 'Điện thoại đang chặn thông báo của app',
  'notif.blockedBody': 'Lịch nhắc vẫn được đặt nhưng sẽ không hiện lên. Bấm để cấp quyền thông báo.',
  'notif.allow': 'Cấp quyền',
  'calc.title': 'Máy tính hủy hàng',
  'calc.subtitle': 'Tính thời điểm bắt buộc hủy từ NSX và HSD, theo đúng chính sách của cửa hàng.',
  'calc.modePrinted': '1. HSD in sẵn trên bao bì',
  'calc.modeBoth': '2. Nhập cả NSX & HSD',
  'calc.modeSpan': '3. Nhập 1 mốc + thời hạn',
  'calc.useTime': 'Nhập thêm giờ',
  'calc.useTimeHint': 'Chỉ cần cho hàng tính theo giờ. Tắt thì tính theo ngày.',
  'calc.sop': 'Hàng SOP (bánh bao, xúc xích…)',
  'calc.sopHint': 'Luôn hủy trước mốc in trên bao bì đúng khoảng thời gian của quy tắc hàng theo giờ, bất kể hạn dài bao lâu.',
  'calc.nsx': 'Ngày sản xuất (NSX)',
  'calc.hsd': 'Hạn sử dụng in trên bao bì (HSD)',
  'calc.anchorExpiry': 'Có HSD → tìm NSX',
  'calc.anchorMfg': 'Có NSX → tìm HSD',
  'calc.spanLabel': 'Thời hạn (từ NSX đến HSD)',
  'calc.unitHour': 'Giờ',
  'calc.unitDay': 'Ngày',
  'calc.unitMonth': 'Tháng',
  'calc.unitYear': 'Năm',
  'calc.resultDestroy': 'THỜI ĐIỂM BẮT BUỘC PHẢI HỦY',
  'calc.resultRule': 'Quy tắc áp dụng',
  'calc.shelfLife': 'Vòng đời: {days} ngày',
  'calc.needShelfLife': 'Chưa đủ dữ liệu để tính giờ hủy: hãy nhập NSX, hoặc chuyển sang chế độ 2 và nhập thời hạn ghi trên bao bì.',
  'calc.usedFallback': 'Không có quy tắc nào khớp vòng đời này - đang dùng thời gian dự phòng của chính sách.',
  'calc.clear': 'Xóa',
  'calc.applyToIntake': 'Dùng 2 ngày này để nhập hàng',
  'calc.appliedToIntake': 'Đã điền NSX và HSD vào phiếu nhập hàng.',
  'calc.policyNote': 'Số liệu lấy từ Chính sách hủy hàng đang áp dụng. Sửa chính sách thì máy tính đổi theo.',
  'calc.pickTitle': 'Tính hạn sử dụng',
  'calc.pickSubtitle': 'Nhập HSD in trên bao bì, hoặc nhập NSX cùng thời hạn để máy tính ra HSD.',
  'calc.pickConfirm': 'Dùng hạn này',
  'calc.pickResultExpiry': 'HẠN SỬ DỤNG',
  'calc.pickPreviewDestroy': 'Dự kiến phải hủy: {when}',
};

/// English.
const Map<String, String> stringsEn = <String, String>{
  'app.name': 'Expiry Guardian',
  'app.tagline': 'Expiry control that follows the company policy',
  'common.ok': 'OK',
  'common.cancel': 'Cancel',
  'common.save': 'Save',
  'common.saveChanges': 'Save changes',
  'common.delete': 'Delete',
  'common.edit': 'Edit',
  'common.add': 'Add',
  'common.close': 'Close',
  'common.back': 'Back',
  'common.next': 'Next',
  'common.done': 'Done',
  'common.retry': 'Retry',
  'common.search': 'Search',
  'common.filter': 'Filters',
  'common.clear': 'Clear',
  'common.apply': 'Apply',
  'common.confirm': 'Confirm',
  'common.yes': 'Yes',
  'common.no': 'No',
  'common.all': 'All',
  'common.none': 'None',
  'common.unknown': 'Unknown',
  'common.loading': 'Loading…',
  'common.today': 'Today',
  'common.tomorrow': 'Tomorrow',
  'common.yesterday': 'Yesterday',
  'common.notSet': 'Not set',
  'common.optional': 'Optional',
  'common.required': 'Required',
  'common.more': 'More',
  'common.seeAll': 'See all',
  'common.refresh': 'Refresh',
  'common.share': 'Share',
  'common.export': 'Export',
  'common.quantity': 'Quantity',
  'common.notes': 'Notes',
  'common.photo': 'Photo',
  'common.reason': 'Reason',
  'common.name': 'Name',
  'common.code': 'Code',
  'common.status': 'Status',
  'common.actions': 'Actions',
  'common.empty': 'Nothing here yet',
  'common.and': 'and',
  'common.of': 'of',
  'common.items': 'items',
  'common.units': 'units',
  'error.generic': 'Something went wrong. Please try again.',
  'error.database': 'Could not read or write local data.',
  'error.notFound': 'Not found.',
  'error.duplicate': 'That already exists.',
  'error.validation': 'Please check the form.',
  'error.permission': 'You do not have permission for this.',
  'error.unauthenticated': 'Wrong username or password.',
  'error.camera': 'The camera is not available.',
  'error.recognition': 'Could not read the image.',
  'error.remoteNotConfigured': 'No sync server is configured.',
  'error.usernameRequired': 'Enter a username.',
  'error.displayNameRequired': 'Enter a display name.',
  'error.passwordTooShort': 'Password is too short (4 characters minimum).',
  'error.usernameTaken': 'That username is taken.',
  'error.accountDisabled': 'This account is disabled.',
  'error.nameRequired': 'Enter a name.',
  'error.barcodeRequired': 'Enter a barcode.',
  'error.barcodeTaken': 'That barcode already belongs to another product.',
  'error.quantityPositive': 'Quantity must be greater than zero.',
  'error.recordNotFound': 'That inventory record no longer exists.',
  'error.recordNotActive': 'That record is already closed.',
  'error.invalidQuantity': 'Invalid quantity.',
  'error.captureMissing': 'The captured photo is missing.',
  'error.scanFailed': 'The scan failed. Please capture again.',
  'auth.setupTitle': 'Create the administrator account',
  'auth.setupSubtitle': 'This is the store\'s first account and has full access.',
  'auth.signInTitle': 'Sign in',
  'auth.username': 'Username',
  'auth.displayName': 'Display name',
  'auth.password': 'Password',
  'auth.confirmPassword': 'Confirm password',
  'auth.passwordsDoNotMatch': 'The passwords do not match.',
  'auth.signIn': 'Sign in',
  'auth.signOut': 'Sign out',
  'auth.createAccount': 'Create account',
  'auth.signedInAs': 'Signed in as',
  'auth.role': 'Role',
  'auth.role.employee': 'Employee',
  'auth.role.manager': 'Manager',
  'auth.role.admin': 'Administrator',
  'auth.role.employee.desc': 'Scan, view stock, destroy.',
  'auth.role.manager.desc': 'Everything an employee can do, plus policy, catalog and reports.',
  'auth.role.admin.desc': 'Full access, including users and system settings.',
  'auth.changePassword': 'Change password',
  'auth.currentPassword': 'Current password',
  'auth.newPassword': 'New password',
  'auth.passwordChanged': 'Password changed.',
  'nav.today': 'Today',
  'nav.scan': 'Scan',
  'nav.inventory': 'Stock',
  'nav.reports': 'Reports',
  'nav.more': 'More',
  'nav.dashboard': 'Dashboard',
  'nav.insights': 'Insights',
  'nav.settings': 'Settings',
  'dashboard.title': 'Dashboard',
  'dashboard.totalProducts': 'Lots being tracked',
  'dashboard.approaching': 'Approaching destruction',
  'dashboard.destroyedToday': 'Destroyed today',
  'dashboard.expired': 'Past expiry',
  'dashboard.financialLoss': 'Loss today',
  'dashboard.stockValue': 'Stock value',
  'dashboard.trend': 'Destruction trend',
  'dashboard.trend7': '7 days',
  'dashboard.trend30': '30 days',
  'dashboard.trend90': '90 days',
  'dashboard.partialLossWarning': 'Only {priced} of {total} lots have a cost price. Enter cost prices for a complete figure.',
  'dashboard.noCostData': 'No cost prices entered yet, so no loss can be calculated.',
  'dashboard.overdue': 'Overdue',
  'dashboard.dueToday': 'Due today',
  'today.title': 'Today\'s destroy list',
  'today.empty': 'Nothing needs destroying today.',
  'today.emptyHint': 'The list is generated every morning from the company policy.',
  'today.generatedAt': 'Updated at {time}',
  'today.itemsToDestroy': '{count} products to destroy',
  'today.urgentCount': '{count} need action now',
  'today.estimatedLoss': 'Estimated loss',
  'today.markDestroyed': 'Mark destroyed',
  'today.destroyAll': 'Destroy this whole shelf',
  'today.route': 'Inspection route',
  'today.noShelf': 'No shelf assigned',
  'today.noArea': 'No area assigned',
  'priority.safe': 'Safe',
  'priority.approaching': 'Approaching',
  'priority.destroySoon': 'Destroy within 24h',
  'priority.destroyNow': 'Destroy now',
  'priority.expired': 'Expired',
  'priority.legend': 'Colour legend',
  'scan.title': 'Scan goods in',
  'scan.step.barcode': '1. Scan the barcode',
  'scan.step.dates': '2. Photograph the dates',
  'scan.step.review': '3. Check and save',
  'scan.aimBarcode': 'Line the barcode up in the frame',
  'scan.aimLabel': 'Frame the printed expiry date',
  'scan.capture': 'Capture',
  'scan.retake': 'Retake',
  'scan.torch': 'Torch',
  'scan.processing': 'Processing the image…',
  'scan.quality.good': 'Sharp image',
  'scan.quality.blurry': 'Blurry - hold still and retake',
  'scan.quality.dark': 'Too dark - use the torch or move to better light',
  'scan.quality.bright': 'Too bright - avoid direct glare',
  'scan.enhanced': 'Image automatically improved: {steps}',
  'scan.noBarcode': 'No barcode detected yet.',
  'scan.enterBarcode': 'Type the barcode',
  'scan.unknownProduct': 'This barcode is not in the catalog yet',
  'scan.unknownProductHint': 'Enter it once and the app will recognise it from now on.',
  'scan.createProduct': 'Add this product',
  'scan.foundProduct': 'Product recognised',
  'scan.readFromBarcode': 'Read from the GS1 barcode',
  'scan.readFromPhoto': 'Read from the photo (OCR)',
  'scan.enteredManually': 'Entered by hand',
  'scan.fromCatalog': 'From the catalog',
  'scan.noDateFound': 'No date was read from the label. Please type it in.',
  'scan.checkDates': 'Check the dates before saving',
  'scan.warning.ambiguous': 'Day and month may be swapped - please check.',
  'scan.warning.expiryPassed': 'That expiry date is already in the past.',
  'scan.warning.expiryBeforeMfg': 'The expiry date is earlier than the manufacturing date.',
  'scan.warning.monthOnly': 'The label prints only month and year - the last day of the month is used.',
  'scan.warning.multipleExpiry': 'Several expiry dates were found - pick the right one.',
  'scan.saveRecord': 'Save this lot',
  'scan.savedRecord': 'Saved lot {code}',
  'scan.scanNext': 'Scan the next lot',
  'scan.permissionTitle': 'Camera permission needed',
  'scan.permissionBody': 'The app needs the camera to scan barcodes and read expiry dates.',
  'scan.openSettings': 'Open settings',
  'record.barcode': 'Barcode',
  'record.product': 'Product',
  'record.brand': 'Brand',
  'record.category': 'Category',
  'record.batch': 'Batch / Lot',
  'record.manufacturedAt': 'Manufacturing date',
  'record.expiryAt': 'Expiry date',
  'record.expiryTime': 'Expiry time',
  'record.destroyAt': 'Destroy by',
  'record.shelf': 'Shelf',
  'record.area': 'Area',
  'record.quantity': 'Quantity',
  'record.remaining': 'Remaining',
  'record.unit': 'Unit',
  'record.unitCost': 'Cost per unit',
  'record.receivedAt': 'Received',
  'record.code': 'Lot code',
  'record.history': 'History',
  'record.shelfLife': 'Shelf life',
  'record.leadTime': 'Destroyed ahead of expiry by',
  'record.appliedRule': 'Rule applied',
  'record.policyVersion': 'Policy version',
  'record.fallbackRule': 'No rule matched - the default lead time was used',
  'record.hourly': 'Hourly product',
  'record.daily': 'Date-only product',
  'record.timeLeft': '{duration} left',
  'record.overdueBy': 'Overdue by {duration}',
  'record.status.active': 'On shelf',
  'record.status.destroyed': 'Destroyed',
  'record.status.soldOut': 'Sold out',
  'record.status.removed': 'Removed',
  'event.created': 'Lot created',
  'event.updated': 'Updated',
  'event.quantityAdjusted': 'Quantity adjusted',
  'event.moved': 'Moved',
  'event.destroyed': 'Destroyed',
  'event.soldOut': 'Sold out',
  'event.removed': 'Removed',
  'event.reopened': 'Reopened',
  'event.policyRecalculated': 'Recalculated under a new policy',
  'event.photoAttached': 'Photo attached',
  'event.noteAdded': 'Note added',
  'destroy.title': 'Confirm destruction',
  'destroy.quantityToDestroy': 'Quantity to destroy',
  'destroy.all': 'Destroy everything',
  'destroy.partial': 'Destroy part of the lot',
  'destroy.reason.policy': 'Expiry policy',
  'destroy.reason.damaged': 'Damaged',
  'destroy.reason.recalled': 'Recalled',
  'destroy.reason.contaminated': 'Contaminated',
  'destroy.reason.other': 'Other',
  'destroy.takePhoto': 'Take a photo as evidence',
  'destroy.confirm': 'Confirm destroyed',
  'destroy.done': 'Recorded: {quantity} {unit} destroyed',
  'destroy.overdueNotice': 'This lot is {duration} past its destroy deadline.',
  'destroy.lossRecorded': 'Loss recorded: {amount}',
  'destroy.noCost': 'No cost price, so the recorded loss is zero.',
  'inventory.title': 'Stock',
  'inventory.searchHint': 'Search by name, barcode, lot, shelf…',
  'inventory.empty': 'No stock has been booked in yet.',
  'inventory.emptyHint': 'Tap Scan to book in your first lot.',
  'inventory.resultCount': '{count} results',
  'inventory.filter.status': 'Status',
  'inventory.filter.priority': 'Priority',
  'inventory.filter.area': 'Area',
  'inventory.filter.shelf': 'Shelf',
  'inventory.filter.category': 'Category',
  'inventory.filter.expiry': 'Expiry',
  'inventory.filter.batch': 'Batch',
  'inventory.sort': 'Sort',
  'inventory.sort.priority': 'Priority',
  'inventory.sort.destroyDate': 'Destroy date',
  'inventory.sort.expiryDate': 'Expiry date',
  'inventory.sort.receivedDate': 'Received',
  'inventory.sort.productName': 'Product name',
  'inventory.sort.location': 'Location',
  'inventory.adjustQuantity': 'Adjust quantity',
  'inventory.moveShelf': 'Move to another shelf',
  'inventory.markSoldOut': 'Mark as sold out',
  'inventory.remove': 'Remove from stock',
  'catalog.title': 'Product catalog',
  'catalog.newProduct': 'New product',
  'catalog.editProduct': 'Edit product',
  'catalog.empty': 'The catalog is empty.',
  'catalog.emptyHint': 'Products are added the first time you scan their barcode.',
  'catalog.extraBarcodes': 'Extra barcodes (case, inner pack)',
  'catalog.defaultShelf': 'Default shelf',
  'catalog.photo': 'Product photo',
  'catalog.photoHint': 'Optional. Shown in the stock list so the item can be recognised by sight.',
  'catalog.noBarcode': 'No barcode',
  'catalog.expiryPrecision': 'Expiry type',
  'catalog.defaultShelfLife': 'Default shelf life',
  'catalog.defaultShelfLifeHint': 'Used to flag an implausible OCR result.',
  'catalog.unitCostHint': 'Leave blank if unknown. Without a cost price no loss can be calculated.',
  'catalog.categories': 'Categories',
  'catalog.newCategory': 'New category',
  'catalog.productInUse': 'This product still has stock, so it was hidden instead of deleted.',
  'locations.title': 'Areas and shelves',
  'locations.areas': 'Areas',
  'locations.shelves': 'Shelves',
  'locations.newArea': 'New area',
  'locations.newShelf': 'New shelf',
  'locations.empty': 'No areas defined yet.',
  'locations.emptyHint': 'Define areas and shelves so the destroy list follows your walking route.',
  'locations.sortOrderHint': 'Walking order in the store (lower numbers first).',
  'locations.deleteAreaWarning': 'Deleting an area also deletes its shelves.',
  'policy.title': 'Destruction policy',
  'policy.subtitle': 'Every rule below is editable - nothing is hard-coded in the app.',
  'policy.activePolicy': 'Active policy',
  'policy.version': 'Version {version}',
  'policy.rules': 'Rules',
  'policy.newRule': 'Add a rule',
  'policy.editRule': 'Edit rule',
  'policy.ruleName': 'Rule name',
  'policy.shelfLifeFrom': 'Shelf life from',
  'policy.shelfLifeTo': 'to',
  'policy.inclusive': 'Include this boundary',
  'policy.exclusive': 'Exclude this boundary',
  'policy.noLowerBound': 'No lower bound',
  'policy.noUpperBound': 'No upper bound',
  'policy.leadTime': 'Destroy this long before expiry',
  'policy.matchesHourly': 'Also applies to every hourly product',
  'policy.ruleActive': 'Active',
  'policy.basis': 'How shelf life is measured',
  'policy.basis.manufacturing': 'Manufacturing date to expiry',
  'policy.basis.intake': 'Goods receipt to expiry',
  'policy.fallbackBasis': 'Fall back to the goods-receipt date when no manufacturing date is printed',
  'policy.endOfDay': 'A date-only label means the goods are good through that whole day',
  'policy.fallbackLead': 'Lead time when no rule matches',
  'policy.normalizeTime': 'Fixed destroy time of day',
  'policy.normalizeTimeHint': 'Turn on so all destructions in a day fall at the same time.',
  'policy.thresholds': 'Warning colour thresholds',
  'policy.orangeWindow': 'Turn orange when this much time is left',
  'policy.yellowWindow': 'Turn yellow when this much time is left',
  'policy.recalculate': 'Apply to stock already on the shelves',
  'policy.recalculated': 'Recalculated {count} lots.',
  'policy.preview': 'Try it out',
  'policy.previewHint': 'Enter a manufacturing and expiry date to see which rule applies.',
  'policy.previewResult': 'Rule "{rule}" applies: destroy at {destroyAt}.',
  'policy.issue.noActiveRules': 'The policy has no active rules.',
  'policy.issue.negativeLeadTime': 'Lead time cannot be negative.',
  'policy.issue.invertedRange': 'The lower bound is greater than the upper bound.',
  'policy.issue.coverageGap': 'A shelf-life band is not covered by any rule (around {days} days).',
  'policy.issue.overlappingRules': 'Two rules cover the same shelf-life band.',
  'policy.issue.noCatchAll': 'No rule covers very long shelf lives.',
  'policy.issue.leadTimeExceedsShelfLife': 'The lead time is longer than this band\'s shelf life.',
  'policy.issue.duplicateSortOrder': 'Two rules share the same priority order.',
  'policy.issuesFound': '{count} issues to review',
  'policy.noIssues': 'The policy is valid.',
  'notif.title': 'Notifications',
  'notif.dailyDigest': 'Morning summary',
  'notif.dailyDigestTime': 'Summary time',
  'notif.perItem': 'Per-lot alerts',
  'notif.perItemLead': 'Remind before the destroy deadline',
  'notif.overdue': 'Remind again once overdue',
  'notif.quietHours': 'Quiet hours',
  'notif.quietHoursHint': 'Alerts inside this window are moved to just after it.',
  'notif.permissionNeeded': 'Notification permission is needed for reminders.',
  'notif.exactAlarmNeeded': 'Android needs the exact-alarm permission to remind you to the minute.',
  'notif.grant': 'Grant permission',
  'notif.scheduled': '{count} reminders scheduled.',
  'notif.digestTitle': 'Today\'s destroy list',
  'notif.digestBody': 'You have {count} products to destroy today.',
  'notif.digestBodyWithUrgent': 'You have {count} products to destroy today, {urgent} need action now.',
  'notif.itemDueTitle': 'Destroy deadline approaching',
  'notif.itemDueBody': '{product} on {location} must be destroyed in {duration}.',
  'notif.itemDueBodyNoLocation': '{product} must be destroyed in {duration}.',
  'notif.itemOverdueTitle': 'Destroy deadline passed',
  'notif.itemOverdueBody': '{product} on {location} is past its destroy deadline.',
  'reports.title': 'Reports',
  'reports.daily': 'Daily',
  'reports.weekly': 'Weekly',
  'reports.monthly': 'Monthly',
  'reports.destroyedQuantity': 'Quantity destroyed',
  'reports.destroyedRecords': 'Lots destroyed',
  'reports.expiredQuantity': 'Destroyed after expiry',
  'reports.overdueRecords': 'Destroyed late',
  'reports.onTimeRate': 'On-time rate',
  'reports.financialLoss': 'Financial loss',
  'reports.mostWastedCategories': 'Most wasted categories',
  'reports.byShelf': 'By shelf',
  'reports.byProduct': 'By product',
  'reports.byReason': 'By reason',
  'reports.trend': 'Trend',
  'reports.exportCsv': 'Export CSV',
  'reports.exported': 'Report exported.',
  'reports.empty': 'No destructions recorded in this period.',
  'reports.partialLoss': 'Loss covers only {priced} of {total} lots that have a cost price.',
  'reports.previousPeriod': 'Previous period',
  'reports.change': 'Change',
  'insights.title': 'Insights',
  'insights.subtitle': 'Computed from your store\'s own records - never sample data.',
  'insights.shelfRisk': 'Shelves that waste the most',
  'insights.categoryRisk': 'High-risk categories',
  'insights.forgotten': 'Products that get forgotten',
  'insights.route': 'Suggested inspection route',
  'insights.forecast': 'Waste forecast',
  'insights.insufficient': 'Not enough data yet',
  'insights.insufficientHint': 'At least {required} recorded destructions are needed; there are {actual}.',
  'insights.basedOn': 'Based on the last {days} days',
  'insights.wasteRate': '{rate} destroyed',
  'insights.confidenceNote': 'Ranked on the lower bound of a 95% confidence interval, so a couple of unlucky lots cannot distort it.',
  'insights.sampleSize': '{count} lots booked in',
  'insights.overdueShare': '{rate} destroyed late',
  'insights.routeStops': '{stops} stops · {items} lots · about {minutes} min',
  'insights.routeEmpty': 'No shelves need visiting today.',
  'insights.forecastScheduled': 'Certain to need destroying within {days} days',
  'insights.forecastProjected': 'Estimate from the average destruction run rate',
  'insights.forecastNote': 'The "certain" figure comes straight from computed destroy dates; the "estimate" is only an extrapolation.',
  'settings.title': 'Settings',
  'settings.general': 'General',
  'settings.language': 'Language',
  'settings.theme': 'Appearance',
  'settings.theme.system': 'Follow the system',
  'settings.theme.light': 'Light',
  'settings.theme.dark': 'Dark',
  'settings.storeName': 'Store name',
  'settings.currency': 'Currency',
  'settings.scanning': 'Scanning and recognition',
  'settings.enhanceImages': 'Automatically improve photos',
  'settings.keepPhotos': 'Keep label photos',
  'settings.dayFirst': 'Read dates as day/month',
  'settings.dayFirstHint': 'Turn off if your goods mostly print month/day (US style).',
  'settings.blurThreshold': 'Blur warning threshold',
  'settings.darkThreshold': 'Low-light warning threshold',
  'settings.maxFutureYears': 'Maximum years an expiry may be in the future',
  'settings.destroyRules': 'Destruction workflow',
  'settings.requirePhoto': 'Require a photo when destroying',
  'settings.requireReason': 'Require a reason when destroying',
  'settings.insights': 'Analysis',
  'settings.lookbackDays': 'Days of history to analyse',
  'settings.forecastDays': 'Days to forecast',
  'settings.minimumSamples': 'Minimum samples before a prediction is shown',
  'settings.users': 'Users',
  'settings.newUser': 'Add user',
  'settings.deactivate': 'Disable account',
  'settings.activate': 'Enable account',
  'settings.data': 'Data',
  'settings.sync': 'Sync',
  'settings.about': 'About',
  'settings.version': 'Version {version} ({build})',
  'settings.resetData': 'Erase all operational data',
  'settings.resetDataWarning': 'This erases every lot, its history and all destruction records. Catalog, shelves and policy are kept. This cannot be undone.',
  'settings.resetDone': 'Operational data erased.',
  'sync.title': 'Sync',
  'sync.offlineOnly': 'Fully offline mode',
  'sync.offlineOnlyBody': 'This installation has no server. All data stays on the device and every change is queued, ready to upload if a server is connected later.',
  'sync.pending': '{count} changes waiting to sync',
  'sync.lastSuccess': 'Last successful sync: {time}',
  'sync.never': 'Never synced',
  'sync.syncNow': 'Sync now',
  'sync.online': 'Online',
  'sync.offline': 'Offline',
  'sync.phase.idle': 'Idle',
  'sync.phase.checking': 'Checking…',
  'sync.phase.pushing': 'Uploading…',
  'sync.phase.pulling': 'Downloading…',
  'sync.phase.backingOff': 'Will retry later',
  'sync.phase.error': 'Sync error',
  'time.days': '{count} d',
  'time.hours': '{count} h',
  'time.minutes': '{count} min',
  'time.months': '{count} months',
  'time.years': '{count} years',
  'time.now': 'right now',
  'notif.workflow': 'Reminder workflow',
  'notif.workflow.subtitle': 'Four moments around the destroy deadline. Every moment and interval is editable.',
  'notif.stage.kind.earlyWarning': 'Early warning',
  'notif.stage.kind.finalReminder': 'Final reminder',
  'notif.stage.kind.mandatory': 'Mandatory destroy',
  'notif.stage.kind.repeatUntilConfirmed': 'Repeat until confirmed',
  'notif.stage.offsetBefore': '{duration} before the deadline',
  'notif.stage.offsetAt': 'Exactly at the deadline',
  'notif.stage.offsetAfter': '{duration} after the deadline',
  'notif.stage.offset': 'When it fires',
  'notif.stage.direction': 'Before or after the deadline',
  'notif.stage.before': 'Before',
  'notif.stage.after': 'After',
  'notif.stage.repeatEvery': 'Repeat every',
  'notif.stage.maxRepeats': 'Maximum repeats',
  'notif.stage.repeatNote': 'Repeats only until an employee confirms the destruction, then stops immediately.',
  'notif.stage.new': 'Add a stage',
  'notif.stage.edit': 'Edit stage',
  'notif.stage.name': 'Stage name',
  'notif.stage.restoreDefaults': 'Restore the default stages',
  'notif.stage.restored': 'The default stages were restored.',
  'notif.stage.count': '{count} active stages',
  'notif.stage.plannedPerLot': 'Up to {count} alerts per lot',
  'notif.stage.earlyTitle': 'Destroy deadline approaching',
  'notif.stage.earlyBody': '{product} on {location} must be destroyed in {duration}.',
  'notif.stage.finalTitle': 'Final reminder before the deadline',
  'notif.stage.finalBody': '{product} on {location} must be destroyed within {duration}.',
  'notif.stage.mandatoryTitle': 'Destroy now',
  'notif.stage.mandatoryBody': '{product} on {location} has reached its destroy deadline. Destroy it and confirm.',
  'notif.stage.repeatTitle': 'Destruction not confirmed',
  'notif.stage.repeatBody': '{product} on {location} is still not confirmed as destroyed (reminder {attempt}).',
  'notif.escalationTitle': 'Manager alert',
  'notif.escalationBody': '{product} on {location} is {duration} past its deadline with no confirmation.',
  'destroy.confirmation': 'Destruction confirmation',
  'destroy.confirmedBy': 'Confirmed by',
  'destroy.confirmedAt': 'Confirmed at',
  'destroy.device': 'Device',
  'destroy.remindersCancelled': '{count} pending reminders were cancelled.',
  'destroy.mustConfirm': 'Every destroyed lot must be confirmed by someone.',
  'destroy.reasonRequired': 'Please choose a reason.',
  'destroy.photoRequired': 'Please attach a photo as evidence.',
  'escalation.title': 'Manager escalation',
  'escalation.subtitle': 'Lots past their deadline with no confirmation are raised to a manager automatically.',
  'escalation.dashboard': 'Manager dashboard',
  'escalation.rules': 'Escalation rules',
  'escalation.newRule': 'Add an escalation rule',
  'escalation.editRule': 'Edit escalation rule',
  'escalation.ruleName': 'Rule name',
  'escalation.delayAfterDestroy': 'Escalate this long after the deadline',
  'escalation.notifyRole': 'Notify role',
  'escalation.severity': 'Severity',
  'escalation.severity.warning': 'Warning',
  'escalation.severity.critical': 'Critical',
  'escalation.repeatEvery': 'Remind the manager every',
  'escalation.maxRepeats': 'Maximum reminders',
  'escalation.enabled': 'Escalate to a manager automatically',
  'escalation.open': 'Open',
  'escalation.resolvedTab': 'Resolved',
  'escalation.none': 'No alerts.',
  'escalation.noneHint': 'Every due lot was confirmed on time.',
  'escalation.acknowledge': 'Acknowledge',
  'escalation.acknowledged': 'Alert acknowledged.',
  'escalation.acknowledgedBy': 'Acknowledged by',
  'escalation.level': 'Level {level}',
  'escalation.raisedAt': 'Raised at',
  'escalation.overdueBy': '{duration} overdue',
  'escalation.managerOverride': 'Manager override',
  'escalation.overrideHint': 'Close the alert without destroying the stock. A reason is required.',
  'escalation.overrideReason': 'Reason for the override',
  'escalation.overrideDone': 'The manager\'s decision was recorded.',
  'escalation.criticalCount': '{count} critical alerts',
  'escalation.warningCount': '{count} warnings',
  'escalation.restoreDefaults': 'Restore the default rules',
  'escalation.resolution.destroyed': 'Stock destroyed',
  'escalation.resolution.acknowledged': 'Acknowledged by a manager',
  'escalation.resolution.override': 'Manager override',
  'escalation.resolution.cancelled': 'Lot closed',
  'escalation.scanNow': 'Check now',
  'escalation.raisedCount': '{count} new alerts were raised.',
  'audit.title': 'Audit trail',
  'audit.subtitle': 'Every operation is recorded and can never be edited or deleted.',
  'audit.verify': 'Verify integrity',
  'audit.intact': 'The trail is intact: {count} entries verified.',
  'audit.broken': 'A mismatch was found at entry #{sequence}.',
  'audit.immutableNote': 'Each entry carries the hash of the one before it, so changing a single line is detectable.',
  'audit.previousValue': 'Previous value',
  'audit.newValue': 'New value',
  'audit.actor': 'Employee',
  'audit.device': 'Device',
  'audit.action': 'Action',
  'audit.entity': 'Object',
  'audit.entries': '{count} entries',
  'audit.empty': 'Nothing has been recorded yet.',
  'audit.filterAction': 'Filter by action',
  'audit.noChange': 'No value change',
  'audit.action.productCreated': 'Product created',
  'audit.action.productUpdated': 'Product updated',
  'audit.action.productDeleted': 'Product deleted',
  'audit.action.recordCreated': 'Lot created',
  'audit.action.recordScanned': 'Scanned',
  'audit.action.recordEdited': 'Lot edited',
  'audit.action.recordMoved': 'Moved',
  'audit.action.quantityAdjusted': 'Quantity adjusted',
  'audit.action.recordClosed': 'Lot closed',
  'audit.action.destroyReminderScheduled': 'Destroy reminders scheduled',
  'audit.action.destroyReminderFired': 'Destroy reminder fired',
  'audit.action.destroyConfirmed': 'Destruction confirmed',
  'audit.action.escalationRaised': 'Escalated',
  'audit.action.escalationNotified': 'Manager notified',
  'audit.action.escalationAcknowledged': 'Escalation acknowledged',
  'audit.action.escalationResolved': 'Escalation resolved',
  'audit.action.managerOverride': 'Manager override',
  'audit.action.policyEdited': 'Policy edited',
  'audit.action.policyRuleEdited': 'Policy rule edited',
  'audit.action.policyRecalculated': 'Policy recalculated',
  'audit.action.notificationStageEdited': 'Reminder stage edited',
  'audit.action.escalationRuleEdited': 'Escalation rule edited',
  'audit.action.locationEdited': 'Location edited',
  'audit.action.settingChanged': 'Setting changed',
  'audit.action.userCreated': 'User created',
  'audit.action.userUpdated': 'User updated',
  'audit.action.userSignedIn': 'Signed in',
  'audit.action.userSignedOut': 'Signed out',
  'audit.action.passwordChanged': 'Password changed',
  'audit.action.reportExported': 'Report exported',
  'audit.action.dataReset': 'Operational data erased',
  'export.title': 'Export a report',
  'export.template': 'Template',
  'export.template.dailyDestroy': 'Daily destroy report',
  'export.template.weekly': 'Weekly report',
  'export.template.monthly': 'Monthly report',
  'export.template.audit': 'Audit report',
  'export.template.inventory': 'Inventory report',
  'export.template.expired': 'Expired product report',
  'export.destination': 'Format',
  'export.destination.localPdf': 'PDF file',
  'export.destination.localHtml': 'HTML file',
  'export.destination.localCsv': 'CSV file (Excel)',
  'export.destination.googleDocs': 'Google Docs',
  'export.includePhotos': 'Include photos',
  'export.includeSignatures': 'Include signature blocks',
  'export.includeStatistics': 'Include statistics',
  'export.generate': 'Generate',
  'export.generating': 'Generating…',
  'export.done': 'The report is ready.',
  'export.failed': 'The report could not be generated.',
  'export.history': 'Previous exports',
  'export.share': 'Share',
  'export.open': 'Open',
  'export.noData': 'There is no data for this period.',
  'export.period': 'Period',
  'export.company': 'Company',
  'export.store': 'Store',
  'export.generatedAt': 'Generated at',
  'export.generatedBy': 'Generated by',
  'export.section.summary': 'Statistics',
  'export.section.details': 'Details',
  'export.section.photos': 'Photos',
  'export.section.signatures': 'Signatures',
  'export.signature.preparedBy': 'Prepared by',
  'export.signature.checkedBy': 'Checked by',
  'export.signature.approvedBy': 'Approved by',
  'export.googleNotConfigured': 'Google Docs is not configured. This build exports PDF/HTML/CSV files you can use right away; see docs/SYNC_CONTRACT.md to connect Google Docs later.',
  'export.googleClientId': 'Google OAuth client ID',
  'export.googleFolderId': 'Google Drive folder',
  'settings.workflow': 'Operation workflow',
  'settings.device': 'This device',
  'settings.deviceName': 'Device name',
  'settings.deviceNameHint': 'For example: Counter 1. This name appears in the audit trail.',
  'settings.company': 'Company name',
  'settings.storeCode': 'Store code',
  'settings.audit': 'Audit trail',
  'settings.export': 'Report export',
  'nav.manager': 'Manager',
  'notif.stage.active': 'This stage is on',
  'export.pdfNotAvailableHere': 'This format cannot produce a PDF. Choose the PDF format instead.',
  'export.fontsMissing': 'The report fonts are missing, so PDF export is off. Use HTML or CSV.',
  'export.savedTo': 'Saved to {path}',
  'error.exportFailed': 'The report could not be written. Check the free space and try again.',
  'error.exportNotFound': 'That report could not be found.',
  'manager.title': 'Manager',
  'manager.subtitle': 'Overdue alerts, the audit trail and report exports.',
  'manager.noAccess': 'Only managers and admins can open this section.',
  'scan.liveHint': 'Hold the barcode in the frame - it reads by itself, no button',
  'scan.productPhoto': 'Photo of the product front',
  'scan.productPhotoHint': 'Optional. A shot of the front helps the next person identify the item.',
  'scan.retakePhoto': 'Retake',
  'scan.removePhoto': 'Remove photo',
  'scan.barcodeNotRead': 'The barcode could not be read, but the photo was kept. Read the number off it and type it below.',
  'scan.barcodePhoto': 'Barcode photo',
  'scan.barcodePhotoKept': 'This photo will be saved with the product.',
  'scan.typeBarcode': 'Type the barcode',
  'scan.aimProductFront': 'Photograph the front of the product',
  'locations.shelfSaved': 'Shelf saved',
  'locations.areaSaved': 'Area saved',
  'locations.nameRequired': 'Enter a name before saving.',
  'notif.maxScheduled': 'Maximum reminders held on the phone',
  'notif.maxScheduledHint': 'Android allows about 500 alarms. A bigger number makes rebuilding the schedule slower.',
  'scan.recalledProduct': 'This product was remembered from last time - only the dates are left.',
  'scan.recalledWithShelf': 'Remembered this product and shelf {shelf} - only the dates are left.',
  'scan.autoAdvance': 'Jump straight to the date step',
  'scan.autoAdvanceHint': 'For a barcode already known, open the date camera instead of waiting for a tap.',
  'scan.liveTextHint': 'Hold the date line in the frame - it reads by itself, no button',
  'notif.blockedTitle': 'This phone is blocking the app\'s notifications',
  'notif.blockedBody': 'Reminders are still scheduled but will not appear. Tap to allow notifications.',
  'notif.allow': 'Allow',
  'calc.title': 'Destruction calculator',
  'calc.subtitle': 'Work out the destroy deadline from the production and expiry dates, using the store\'s own policy.',
  'calc.modePrinted': '1. Expiry printed on the pack',
  'calc.modeBoth': '2. Both NSX and expiry',
  'calc.modeSpan': '3. One date + shelf life',
  'calc.useTime': 'Include a time of day',
  'calc.useTimeHint': 'Only needed for goods counted in hours. Off means whole days.',
  'calc.sop': 'SOP goods (buns, sausages…)',
  'calc.sopHint': 'Always destroyed the hourly rule\'s lead time before the printed moment, however long the shelf life.',
  'calc.nsx': 'Production date (NSX)',
  'calc.hsd': 'Expiry printed on the pack (HSD)',
  'calc.anchorExpiry': 'Know the expiry → find NSX',
  'calc.anchorMfg': 'Know NSX → find the expiry',
  'calc.spanLabel': 'Shelf life (NSX to expiry)',
  'calc.unitHour': 'Hours',
  'calc.unitDay': 'Days',
  'calc.unitMonth': 'Months',
  'calc.unitYear': 'Years',
  'calc.resultDestroy': 'DESTROY BY',
  'calc.resultRule': 'Rule applied',
  'calc.shelfLife': 'Shelf life: {days} days',
  'calc.needShelfLife': 'Not enough to work out a destroy time: enter the production date, or switch to mode 2 and give the stated shelf life.',
  'calc.usedFallback': 'No rule matches this shelf life - the policy\'s fallback lead time was used.',
  'calc.clear': 'Clear',
  'calc.applyToIntake': 'Use these dates for goods-in',
  'calc.appliedToIntake': 'The production and expiry dates were filled into goods-in.',
  'calc.policyNote': 'Every figure comes from the active destruction policy. Change the policy and this changes with it.',
  'calc.pickTitle': 'Work out the expiry',
  'calc.pickSubtitle': 'Enter the expiry printed on the pack, or enter the production date and the shelf life and let the calculator work it out.',
  'calc.pickConfirm': 'Use this expiry',
  'calc.pickResultExpiry': 'EXPIRY DATE',
  'calc.pickPreviewDestroy': 'Destroy by: {when}',
};

/// Compile-time-checked keys. Using [K.todayTitle] instead of the raw string
/// means a typo is a build error rather than a blank label on a phone.
abstract final class K {
  static const String appName = 'app.name';
  static const String appTagline = 'app.tagline';
  static const String commonOk = 'common.ok';
  static const String commonCancel = 'common.cancel';
  static const String commonSave = 'common.save';
  static const String commonSaveChanges = 'common.saveChanges';
  static const String commonDelete = 'common.delete';
  static const String commonEdit = 'common.edit';
  static const String commonAdd = 'common.add';
  static const String commonClose = 'common.close';
  static const String commonBack = 'common.back';
  static const String commonNext = 'common.next';
  static const String commonDone = 'common.done';
  static const String commonRetry = 'common.retry';
  static const String commonSearch = 'common.search';
  static const String commonFilter = 'common.filter';
  static const String commonClear = 'common.clear';
  static const String commonApply = 'common.apply';
  static const String commonConfirm = 'common.confirm';
  static const String commonYes = 'common.yes';
  static const String commonNo = 'common.no';
  static const String commonAll = 'common.all';
  static const String commonNone = 'common.none';
  static const String commonUnknown = 'common.unknown';
  static const String commonLoading = 'common.loading';
  static const String commonToday = 'common.today';
  static const String commonTomorrow = 'common.tomorrow';
  static const String commonYesterday = 'common.yesterday';
  static const String commonNotSet = 'common.notSet';
  static const String commonOptional = 'common.optional';
  static const String commonRequired = 'common.required';
  static const String commonMore = 'common.more';
  static const String commonSeeAll = 'common.seeAll';
  static const String commonRefresh = 'common.refresh';
  static const String commonShare = 'common.share';
  static const String commonExport = 'common.export';
  static const String commonQuantity = 'common.quantity';
  static const String commonNotes = 'common.notes';
  static const String commonPhoto = 'common.photo';
  static const String commonReason = 'common.reason';
  static const String commonName = 'common.name';
  static const String commonCode = 'common.code';
  static const String commonStatus = 'common.status';
  static const String commonActions = 'common.actions';
  static const String commonEmpty = 'common.empty';
  static const String commonAnd = 'common.and';
  static const String commonOf = 'common.of';
  static const String commonItems = 'common.items';
  static const String commonUnits = 'common.units';
  static const String errorGeneric = 'error.generic';
  static const String errorDatabase = 'error.database';
  static const String errorNotFound = 'error.notFound';
  static const String errorDuplicate = 'error.duplicate';
  static const String errorValidation = 'error.validation';
  static const String errorPermission = 'error.permission';
  static const String errorUnauthenticated = 'error.unauthenticated';
  static const String errorCamera = 'error.camera';
  static const String errorRecognition = 'error.recognition';
  static const String errorRemoteNotConfigured = 'error.remoteNotConfigured';
  static const String errorUsernameRequired = 'error.usernameRequired';
  static const String errorDisplayNameRequired = 'error.displayNameRequired';
  static const String errorPasswordTooShort = 'error.passwordTooShort';
  static const String errorUsernameTaken = 'error.usernameTaken';
  static const String errorAccountDisabled = 'error.accountDisabled';
  static const String errorNameRequired = 'error.nameRequired';
  static const String errorBarcodeRequired = 'error.barcodeRequired';
  static const String errorBarcodeTaken = 'error.barcodeTaken';
  static const String errorQuantityPositive = 'error.quantityPositive';
  static const String errorRecordNotFound = 'error.recordNotFound';
  static const String errorRecordNotActive = 'error.recordNotActive';
  static const String errorInvalidQuantity = 'error.invalidQuantity';
  static const String errorCaptureMissing = 'error.captureMissing';
  static const String errorScanFailed = 'error.scanFailed';
  static const String authSetupTitle = 'auth.setupTitle';
  static const String authSetupSubtitle = 'auth.setupSubtitle';
  static const String authSignInTitle = 'auth.signInTitle';
  static const String authUsername = 'auth.username';
  static const String authDisplayName = 'auth.displayName';
  static const String authPassword = 'auth.password';
  static const String authConfirmPassword = 'auth.confirmPassword';
  static const String authPasswordsDoNotMatch = 'auth.passwordsDoNotMatch';
  static const String authSignIn = 'auth.signIn';
  static const String authSignOut = 'auth.signOut';
  static const String authCreateAccount = 'auth.createAccount';
  static const String authSignedInAs = 'auth.signedInAs';
  static const String authRole = 'auth.role';
  static const String authRoleEmployee = 'auth.role.employee';
  static const String authRoleManager = 'auth.role.manager';
  static const String authRoleAdmin = 'auth.role.admin';
  static const String authRoleEmployeeDesc = 'auth.role.employee.desc';
  static const String authRoleManagerDesc = 'auth.role.manager.desc';
  static const String authRoleAdminDesc = 'auth.role.admin.desc';
  static const String authChangePassword = 'auth.changePassword';
  static const String authCurrentPassword = 'auth.currentPassword';
  static const String authNewPassword = 'auth.newPassword';
  static const String authPasswordChanged = 'auth.passwordChanged';
  static const String navToday = 'nav.today';
  static const String navScan = 'nav.scan';
  static const String navInventory = 'nav.inventory';
  static const String navReports = 'nav.reports';
  static const String navMore = 'nav.more';
  static const String navDashboard = 'nav.dashboard';
  static const String navInsights = 'nav.insights';
  static const String navSettings = 'nav.settings';
  static const String dashboardTitle = 'dashboard.title';
  static const String dashboardTotalProducts = 'dashboard.totalProducts';
  static const String dashboardApproaching = 'dashboard.approaching';
  static const String dashboardDestroyedToday = 'dashboard.destroyedToday';
  static const String dashboardExpired = 'dashboard.expired';
  static const String dashboardFinancialLoss = 'dashboard.financialLoss';
  static const String dashboardStockValue = 'dashboard.stockValue';
  static const String dashboardTrend = 'dashboard.trend';
  static const String dashboardTrend7 = 'dashboard.trend7';
  static const String dashboardTrend30 = 'dashboard.trend30';
  static const String dashboardTrend90 = 'dashboard.trend90';
  static const String dashboardPartialLossWarning = 'dashboard.partialLossWarning';
  static const String dashboardNoCostData = 'dashboard.noCostData';
  static const String dashboardOverdue = 'dashboard.overdue';
  static const String dashboardDueToday = 'dashboard.dueToday';
  static const String todayTitle = 'today.title';
  static const String todayEmpty = 'today.empty';
  static const String todayEmptyHint = 'today.emptyHint';
  static const String todayGeneratedAt = 'today.generatedAt';
  static const String todayItemsToDestroy = 'today.itemsToDestroy';
  static const String todayUrgentCount = 'today.urgentCount';
  static const String todayEstimatedLoss = 'today.estimatedLoss';
  static const String todayMarkDestroyed = 'today.markDestroyed';
  static const String todayDestroyAll = 'today.destroyAll';
  static const String todayRoute = 'today.route';
  static const String todayNoShelf = 'today.noShelf';
  static const String todayNoArea = 'today.noArea';
  static const String prioritySafe = 'priority.safe';
  static const String priorityApproaching = 'priority.approaching';
  static const String priorityDestroySoon = 'priority.destroySoon';
  static const String priorityDestroyNow = 'priority.destroyNow';
  static const String priorityExpired = 'priority.expired';
  static const String priorityLegend = 'priority.legend';
  static const String scanTitle = 'scan.title';
  static const String scanStepBarcode = 'scan.step.barcode';
  static const String scanStepDates = 'scan.step.dates';
  static const String scanStepReview = 'scan.step.review';
  static const String scanAimBarcode = 'scan.aimBarcode';
  static const String scanAimLabel = 'scan.aimLabel';
  static const String scanCapture = 'scan.capture';
  static const String scanRetake = 'scan.retake';
  static const String scanTorch = 'scan.torch';
  static const String scanProcessing = 'scan.processing';
  static const String scanQualityGood = 'scan.quality.good';
  static const String scanQualityBlurry = 'scan.quality.blurry';
  static const String scanQualityDark = 'scan.quality.dark';
  static const String scanQualityBright = 'scan.quality.bright';
  static const String scanEnhanced = 'scan.enhanced';
  static const String scanNoBarcode = 'scan.noBarcode';
  static const String scanEnterBarcode = 'scan.enterBarcode';
  static const String scanUnknownProduct = 'scan.unknownProduct';
  static const String scanUnknownProductHint = 'scan.unknownProductHint';
  static const String scanCreateProduct = 'scan.createProduct';
  static const String scanFoundProduct = 'scan.foundProduct';
  static const String scanReadFromBarcode = 'scan.readFromBarcode';
  static const String scanReadFromPhoto = 'scan.readFromPhoto';
  static const String scanEnteredManually = 'scan.enteredManually';
  static const String scanFromCatalog = 'scan.fromCatalog';
  static const String scanNoDateFound = 'scan.noDateFound';
  static const String scanCheckDates = 'scan.checkDates';
  static const String scanWarningAmbiguous = 'scan.warning.ambiguous';
  static const String scanWarningExpiryPassed = 'scan.warning.expiryPassed';
  static const String scanWarningExpiryBeforeMfg = 'scan.warning.expiryBeforeMfg';
  static const String scanWarningMonthOnly = 'scan.warning.monthOnly';
  static const String scanWarningMultipleExpiry = 'scan.warning.multipleExpiry';
  static const String scanSaveRecord = 'scan.saveRecord';
  static const String scanSavedRecord = 'scan.savedRecord';
  static const String scanScanNext = 'scan.scanNext';
  static const String scanPermissionTitle = 'scan.permissionTitle';
  static const String scanPermissionBody = 'scan.permissionBody';
  static const String scanOpenSettings = 'scan.openSettings';
  static const String recordBarcode = 'record.barcode';
  static const String recordProduct = 'record.product';
  static const String recordBrand = 'record.brand';
  static const String recordCategory = 'record.category';
  static const String recordBatch = 'record.batch';
  static const String recordManufacturedAt = 'record.manufacturedAt';
  static const String recordExpiryAt = 'record.expiryAt';
  static const String recordExpiryTime = 'record.expiryTime';
  static const String recordDestroyAt = 'record.destroyAt';
  static const String recordShelf = 'record.shelf';
  static const String recordArea = 'record.area';
  static const String recordQuantity = 'record.quantity';
  static const String recordRemaining = 'record.remaining';
  static const String recordUnit = 'record.unit';
  static const String recordUnitCost = 'record.unitCost';
  static const String recordReceivedAt = 'record.receivedAt';
  static const String recordCode = 'record.code';
  static const String recordHistory = 'record.history';
  static const String recordShelfLife = 'record.shelfLife';
  static const String recordLeadTime = 'record.leadTime';
  static const String recordAppliedRule = 'record.appliedRule';
  static const String recordPolicyVersion = 'record.policyVersion';
  static const String recordFallbackRule = 'record.fallbackRule';
  static const String recordHourly = 'record.hourly';
  static const String recordDaily = 'record.daily';
  static const String recordTimeLeft = 'record.timeLeft';
  static const String recordOverdueBy = 'record.overdueBy';
  static const String recordStatusActive = 'record.status.active';
  static const String recordStatusDestroyed = 'record.status.destroyed';
  static const String recordStatusSoldOut = 'record.status.soldOut';
  static const String recordStatusRemoved = 'record.status.removed';
  static const String eventCreated = 'event.created';
  static const String eventUpdated = 'event.updated';
  static const String eventQuantityAdjusted = 'event.quantityAdjusted';
  static const String eventMoved = 'event.moved';
  static const String eventDestroyed = 'event.destroyed';
  static const String eventSoldOut = 'event.soldOut';
  static const String eventRemoved = 'event.removed';
  static const String eventReopened = 'event.reopened';
  static const String eventPolicyRecalculated = 'event.policyRecalculated';
  static const String eventPhotoAttached = 'event.photoAttached';
  static const String eventNoteAdded = 'event.noteAdded';
  static const String destroyTitle = 'destroy.title';
  static const String destroyQuantityToDestroy = 'destroy.quantityToDestroy';
  static const String destroyAll = 'destroy.all';
  static const String destroyPartial = 'destroy.partial';
  static const String destroyReasonPolicy = 'destroy.reason.policy';
  static const String destroyReasonDamaged = 'destroy.reason.damaged';
  static const String destroyReasonRecalled = 'destroy.reason.recalled';
  static const String destroyReasonContaminated = 'destroy.reason.contaminated';
  static const String destroyReasonOther = 'destroy.reason.other';
  static const String destroyTakePhoto = 'destroy.takePhoto';
  static const String destroyConfirm = 'destroy.confirm';
  static const String destroyDone = 'destroy.done';
  static const String destroyOverdueNotice = 'destroy.overdueNotice';
  static const String destroyLossRecorded = 'destroy.lossRecorded';
  static const String destroyNoCost = 'destroy.noCost';
  static const String inventoryTitle = 'inventory.title';
  static const String inventorySearchHint = 'inventory.searchHint';
  static const String inventoryEmpty = 'inventory.empty';
  static const String inventoryEmptyHint = 'inventory.emptyHint';
  static const String inventoryResultCount = 'inventory.resultCount';
  static const String inventoryFilterStatus = 'inventory.filter.status';
  static const String inventoryFilterPriority = 'inventory.filter.priority';
  static const String inventoryFilterArea = 'inventory.filter.area';
  static const String inventoryFilterShelf = 'inventory.filter.shelf';
  static const String inventoryFilterCategory = 'inventory.filter.category';
  static const String inventoryFilterExpiry = 'inventory.filter.expiry';
  static const String inventoryFilterBatch = 'inventory.filter.batch';
  static const String inventorySort = 'inventory.sort';
  static const String inventorySortPriority = 'inventory.sort.priority';
  static const String inventorySortDestroyDate = 'inventory.sort.destroyDate';
  static const String inventorySortExpiryDate = 'inventory.sort.expiryDate';
  static const String inventorySortReceivedDate = 'inventory.sort.receivedDate';
  static const String inventorySortProductName = 'inventory.sort.productName';
  static const String inventorySortLocation = 'inventory.sort.location';
  static const String inventoryAdjustQuantity = 'inventory.adjustQuantity';
  static const String inventoryMoveShelf = 'inventory.moveShelf';
  static const String inventoryMarkSoldOut = 'inventory.markSoldOut';
  static const String inventoryRemove = 'inventory.remove';
  static const String catalogTitle = 'catalog.title';
  static const String catalogNewProduct = 'catalog.newProduct';
  static const String catalogEditProduct = 'catalog.editProduct';
  static const String catalogEmpty = 'catalog.empty';
  static const String catalogEmptyHint = 'catalog.emptyHint';
  static const String catalogExtraBarcodes = 'catalog.extraBarcodes';
  static const String catalogDefaultShelf = 'catalog.defaultShelf';
  static const String catalogExpiryPrecision = 'catalog.expiryPrecision';
  static const String catalogDefaultShelfLife = 'catalog.defaultShelfLife';
  static const String catalogDefaultShelfLifeHint = 'catalog.defaultShelfLifeHint';
  static const String catalogUnitCostHint = 'catalog.unitCostHint';
  static const String catalogCategories = 'catalog.categories';
  static const String catalogNewCategory = 'catalog.newCategory';
  static const String catalogProductInUse = 'catalog.productInUse';
  static const String locationsTitle = 'locations.title';
  static const String locationsAreas = 'locations.areas';
  static const String locationsShelves = 'locations.shelves';
  static const String locationsNewArea = 'locations.newArea';
  static const String locationsNewShelf = 'locations.newShelf';
  static const String locationsEmpty = 'locations.empty';
  static const String locationsEmptyHint = 'locations.emptyHint';
  static const String locationsSortOrderHint = 'locations.sortOrderHint';
  static const String locationsDeleteAreaWarning = 'locations.deleteAreaWarning';
  static const String policyTitle = 'policy.title';
  static const String policySubtitle = 'policy.subtitle';
  static const String policyActivePolicy = 'policy.activePolicy';
  static const String policyVersion = 'policy.version';
  static const String policyRules = 'policy.rules';
  static const String policyNewRule = 'policy.newRule';
  static const String policyEditRule = 'policy.editRule';
  static const String policyRuleName = 'policy.ruleName';
  static const String policyShelfLifeFrom = 'policy.shelfLifeFrom';
  static const String policyShelfLifeTo = 'policy.shelfLifeTo';
  static const String policyInclusive = 'policy.inclusive';
  static const String policyExclusive = 'policy.exclusive';
  static const String policyNoLowerBound = 'policy.noLowerBound';
  static const String policyNoUpperBound = 'policy.noUpperBound';
  static const String policyLeadTime = 'policy.leadTime';
  static const String policyMatchesHourly = 'policy.matchesHourly';
  static const String policyRuleActive = 'policy.ruleActive';
  static const String policyBasis = 'policy.basis';
  static const String policyBasisManufacturing = 'policy.basis.manufacturing';
  static const String policyBasisIntake = 'policy.basis.intake';
  static const String policyFallbackBasis = 'policy.fallbackBasis';
  static const String policyEndOfDay = 'policy.endOfDay';
  static const String policyFallbackLead = 'policy.fallbackLead';
  static const String policyNormalizeTime = 'policy.normalizeTime';
  static const String policyNormalizeTimeHint = 'policy.normalizeTimeHint';
  static const String policyThresholds = 'policy.thresholds';
  static const String policyOrangeWindow = 'policy.orangeWindow';
  static const String policyYellowWindow = 'policy.yellowWindow';
  static const String policyRecalculate = 'policy.recalculate';
  static const String policyRecalculated = 'policy.recalculated';
  static const String policyPreview = 'policy.preview';
  static const String policyPreviewHint = 'policy.previewHint';
  static const String policyPreviewResult = 'policy.previewResult';
  static const String policyIssueNoActiveRules = 'policy.issue.noActiveRules';
  static const String policyIssueNegativeLeadTime = 'policy.issue.negativeLeadTime';
  static const String policyIssueInvertedRange = 'policy.issue.invertedRange';
  static const String policyIssueCoverageGap = 'policy.issue.coverageGap';
  static const String policyIssueOverlappingRules = 'policy.issue.overlappingRules';
  static const String policyIssueNoCatchAll = 'policy.issue.noCatchAll';
  static const String policyIssueLeadTimeExceedsShelfLife = 'policy.issue.leadTimeExceedsShelfLife';
  static const String policyIssueDuplicateSortOrder = 'policy.issue.duplicateSortOrder';
  static const String policyIssuesFound = 'policy.issuesFound';
  static const String policyNoIssues = 'policy.noIssues';
  static const String notifTitle = 'notif.title';
  static const String notifDailyDigest = 'notif.dailyDigest';
  static const String notifDailyDigestTime = 'notif.dailyDigestTime';
  static const String notifPerItem = 'notif.perItem';
  static const String notifPerItemLead = 'notif.perItemLead';
  static const String notifOverdue = 'notif.overdue';
  static const String notifQuietHours = 'notif.quietHours';
  static const String notifQuietHoursHint = 'notif.quietHoursHint';
  static const String notifPermissionNeeded = 'notif.permissionNeeded';
  static const String notifExactAlarmNeeded = 'notif.exactAlarmNeeded';
  static const String notifGrant = 'notif.grant';
  static const String notifScheduled = 'notif.scheduled';
  static const String notifDigestTitle = 'notif.digestTitle';
  static const String notifDigestBody = 'notif.digestBody';
  static const String notifDigestBodyWithUrgent = 'notif.digestBodyWithUrgent';
  static const String notifItemDueTitle = 'notif.itemDueTitle';
  static const String notifItemDueBody = 'notif.itemDueBody';
  static const String notifItemDueBodyNoLocation = 'notif.itemDueBodyNoLocation';
  static const String notifItemOverdueTitle = 'notif.itemOverdueTitle';
  static const String notifItemOverdueBody = 'notif.itemOverdueBody';
  static const String reportsTitle = 'reports.title';
  static const String reportsDaily = 'reports.daily';
  static const String reportsWeekly = 'reports.weekly';
  static const String reportsMonthly = 'reports.monthly';
  static const String reportsDestroyedQuantity = 'reports.destroyedQuantity';
  static const String reportsDestroyedRecords = 'reports.destroyedRecords';
  static const String reportsExpiredQuantity = 'reports.expiredQuantity';
  static const String reportsOverdueRecords = 'reports.overdueRecords';
  static const String reportsOnTimeRate = 'reports.onTimeRate';
  static const String reportsFinancialLoss = 'reports.financialLoss';
  static const String reportsMostWastedCategories = 'reports.mostWastedCategories';
  static const String reportsByShelf = 'reports.byShelf';
  static const String reportsByProduct = 'reports.byProduct';
  static const String reportsByReason = 'reports.byReason';
  static const String reportsTrend = 'reports.trend';
  static const String reportsExportCsv = 'reports.exportCsv';
  static const String reportsExported = 'reports.exported';
  static const String reportsEmpty = 'reports.empty';
  static const String reportsPartialLoss = 'reports.partialLoss';
  static const String reportsPreviousPeriod = 'reports.previousPeriod';
  static const String reportsChange = 'reports.change';
  static const String insightsTitle = 'insights.title';
  static const String insightsSubtitle = 'insights.subtitle';
  static const String insightsShelfRisk = 'insights.shelfRisk';
  static const String insightsCategoryRisk = 'insights.categoryRisk';
  static const String insightsForgotten = 'insights.forgotten';
  static const String insightsRoute = 'insights.route';
  static const String insightsForecast = 'insights.forecast';
  static const String insightsInsufficient = 'insights.insufficient';
  static const String insightsInsufficientHint = 'insights.insufficientHint';
  static const String insightsBasedOn = 'insights.basedOn';
  static const String insightsWasteRate = 'insights.wasteRate';
  static const String insightsConfidenceNote = 'insights.confidenceNote';
  static const String insightsSampleSize = 'insights.sampleSize';
  static const String insightsOverdueShare = 'insights.overdueShare';
  static const String insightsRouteStops = 'insights.routeStops';
  static const String insightsRouteEmpty = 'insights.routeEmpty';
  static const String insightsForecastScheduled = 'insights.forecastScheduled';
  static const String insightsForecastProjected = 'insights.forecastProjected';
  static const String insightsForecastNote = 'insights.forecastNote';
  static const String settingsTitle = 'settings.title';
  static const String settingsGeneral = 'settings.general';
  static const String settingsLanguage = 'settings.language';
  static const String settingsTheme = 'settings.theme';
  static const String settingsThemeSystem = 'settings.theme.system';
  static const String settingsThemeLight = 'settings.theme.light';
  static const String settingsThemeDark = 'settings.theme.dark';
  static const String settingsStoreName = 'settings.storeName';
  static const String settingsCurrency = 'settings.currency';
  static const String settingsScanning = 'settings.scanning';
  static const String settingsEnhanceImages = 'settings.enhanceImages';
  static const String settingsKeepPhotos = 'settings.keepPhotos';
  static const String settingsDayFirst = 'settings.dayFirst';
  static const String settingsDayFirstHint = 'settings.dayFirstHint';
  static const String settingsBlurThreshold = 'settings.blurThreshold';
  static const String settingsDarkThreshold = 'settings.darkThreshold';
  static const String settingsMaxFutureYears = 'settings.maxFutureYears';
  static const String settingsDestroyRules = 'settings.destroyRules';
  static const String settingsRequirePhoto = 'settings.requirePhoto';
  static const String settingsRequireReason = 'settings.requireReason';
  static const String settingsInsights = 'settings.insights';
  static const String settingsLookbackDays = 'settings.lookbackDays';
  static const String settingsForecastDays = 'settings.forecastDays';
  static const String settingsMinimumSamples = 'settings.minimumSamples';
  static const String settingsUsers = 'settings.users';
  static const String settingsNewUser = 'settings.newUser';
  static const String settingsDeactivate = 'settings.deactivate';
  static const String settingsActivate = 'settings.activate';
  static const String settingsData = 'settings.data';
  static const String settingsSync = 'settings.sync';
  static const String settingsAbout = 'settings.about';
  static const String settingsVersion = 'settings.version';
  static const String settingsResetData = 'settings.resetData';
  static const String settingsResetDataWarning = 'settings.resetDataWarning';
  static const String settingsResetDone = 'settings.resetDone';
  static const String syncTitle = 'sync.title';
  static const String syncOfflineOnly = 'sync.offlineOnly';
  static const String syncOfflineOnlyBody = 'sync.offlineOnlyBody';
  static const String syncPending = 'sync.pending';
  static const String syncLastSuccess = 'sync.lastSuccess';
  static const String syncNever = 'sync.never';
  static const String syncSyncNow = 'sync.syncNow';
  static const String syncOnline = 'sync.online';
  static const String syncOffline = 'sync.offline';
  static const String syncPhaseIdle = 'sync.phase.idle';
  static const String syncPhaseChecking = 'sync.phase.checking';
  static const String syncPhasePushing = 'sync.phase.pushing';
  static const String syncPhasePulling = 'sync.phase.pulling';
  static const String syncPhaseBackingOff = 'sync.phase.backingOff';
  static const String syncPhaseError = 'sync.phase.error';
  static const String timeDays = 'time.days';
  static const String timeHours = 'time.hours';
  static const String timeMinutes = 'time.minutes';
  static const String timeMonths = 'time.months';
  static const String timeYears = 'time.years';
  static const String timeNow = 'time.now';
  static const String notifWorkflow = 'notif.workflow';
  static const String notifWorkflowSubtitle = 'notif.workflow.subtitle';
  static const String notifStageKindEarlyWarning = 'notif.stage.kind.earlyWarning';
  static const String notifStageKindFinalReminder = 'notif.stage.kind.finalReminder';
  static const String notifStageKindMandatory = 'notif.stage.kind.mandatory';
  static const String notifStageKindRepeatUntilConfirmed = 'notif.stage.kind.repeatUntilConfirmed';
  static const String notifStageOffsetBefore = 'notif.stage.offsetBefore';
  static const String notifStageOffsetAt = 'notif.stage.offsetAt';
  static const String notifStageOffsetAfter = 'notif.stage.offsetAfter';
  static const String notifStageOffset = 'notif.stage.offset';
  static const String notifStageDirection = 'notif.stage.direction';
  static const String notifStageBefore = 'notif.stage.before';
  static const String notifStageAfter = 'notif.stage.after';
  static const String notifStageRepeatEvery = 'notif.stage.repeatEvery';
  static const String notifStageMaxRepeats = 'notif.stage.maxRepeats';
  static const String notifStageRepeatNote = 'notif.stage.repeatNote';
  static const String notifStageNew = 'notif.stage.new';
  static const String notifStageEdit = 'notif.stage.edit';
  static const String notifStageName = 'notif.stage.name';
  static const String notifStageRestoreDefaults = 'notif.stage.restoreDefaults';
  static const String notifStageRestored = 'notif.stage.restored';
  static const String notifStageCount = 'notif.stage.count';
  static const String notifStagePlannedPerLot = 'notif.stage.plannedPerLot';
  static const String notifStageEarlyTitle = 'notif.stage.earlyTitle';
  static const String notifStageEarlyBody = 'notif.stage.earlyBody';
  static const String notifStageFinalTitle = 'notif.stage.finalTitle';
  static const String notifStageFinalBody = 'notif.stage.finalBody';
  static const String notifStageMandatoryTitle = 'notif.stage.mandatoryTitle';
  static const String notifStageMandatoryBody = 'notif.stage.mandatoryBody';
  static const String notifStageRepeatTitle = 'notif.stage.repeatTitle';
  static const String notifStageRepeatBody = 'notif.stage.repeatBody';
  static const String notifEscalationTitle = 'notif.escalationTitle';
  static const String notifEscalationBody = 'notif.escalationBody';
  static const String destroyConfirmation = 'destroy.confirmation';
  static const String destroyConfirmedBy = 'destroy.confirmedBy';
  static const String destroyConfirmedAt = 'destroy.confirmedAt';
  static const String destroyDevice = 'destroy.device';
  static const String destroyRemindersCancelled = 'destroy.remindersCancelled';
  static const String destroyMustConfirm = 'destroy.mustConfirm';
  static const String destroyReasonRequired = 'destroy.reasonRequired';
  static const String destroyPhotoRequired = 'destroy.photoRequired';
  static const String escalationTitle = 'escalation.title';
  static const String escalationSubtitle = 'escalation.subtitle';
  static const String escalationDashboard = 'escalation.dashboard';
  static const String escalationRules = 'escalation.rules';
  static const String escalationNewRule = 'escalation.newRule';
  static const String escalationEditRule = 'escalation.editRule';
  static const String escalationRuleName = 'escalation.ruleName';
  static const String escalationDelayAfterDestroy = 'escalation.delayAfterDestroy';
  static const String escalationNotifyRole = 'escalation.notifyRole';
  static const String escalationSeverity = 'escalation.severity';
  static const String escalationSeverityWarning = 'escalation.severity.warning';
  static const String escalationSeverityCritical = 'escalation.severity.critical';
  static const String escalationRepeatEvery = 'escalation.repeatEvery';
  static const String escalationMaxRepeats = 'escalation.maxRepeats';
  static const String escalationEnabled = 'escalation.enabled';
  static const String escalationOpen = 'escalation.open';
  static const String escalationResolvedTab = 'escalation.resolvedTab';
  static const String escalationNone = 'escalation.none';
  static const String escalationNoneHint = 'escalation.noneHint';
  static const String escalationAcknowledge = 'escalation.acknowledge';
  static const String escalationAcknowledged = 'escalation.acknowledged';
  static const String escalationAcknowledgedBy = 'escalation.acknowledgedBy';
  static const String escalationLevel = 'escalation.level';
  static const String escalationRaisedAt = 'escalation.raisedAt';
  static const String escalationOverdueBy = 'escalation.overdueBy';
  static const String escalationManagerOverride = 'escalation.managerOverride';
  static const String escalationOverrideHint = 'escalation.overrideHint';
  static const String escalationOverrideReason = 'escalation.overrideReason';
  static const String escalationOverrideDone = 'escalation.overrideDone';
  static const String escalationCriticalCount = 'escalation.criticalCount';
  static const String escalationWarningCount = 'escalation.warningCount';
  static const String escalationRestoreDefaults = 'escalation.restoreDefaults';
  static const String escalationResolutionDestroyed = 'escalation.resolution.destroyed';
  static const String escalationResolutionAcknowledged = 'escalation.resolution.acknowledged';
  static const String escalationResolutionOverride = 'escalation.resolution.override';
  static const String escalationResolutionCancelled = 'escalation.resolution.cancelled';
  static const String escalationScanNow = 'escalation.scanNow';
  static const String escalationRaisedCount = 'escalation.raisedCount';
  static const String auditTitle = 'audit.title';
  static const String auditSubtitle = 'audit.subtitle';
  static const String auditVerify = 'audit.verify';
  static const String auditIntact = 'audit.intact';
  static const String auditBroken = 'audit.broken';
  static const String auditImmutableNote = 'audit.immutableNote';
  static const String auditPreviousValue = 'audit.previousValue';
  static const String auditNewValue = 'audit.newValue';
  static const String auditActor = 'audit.actor';
  static const String auditDevice = 'audit.device';
  static const String auditAction = 'audit.action';
  static const String auditEntity = 'audit.entity';
  static const String auditEntries = 'audit.entries';
  static const String auditEmpty = 'audit.empty';
  static const String auditFilterAction = 'audit.filterAction';
  static const String auditNoChange = 'audit.noChange';
  static const String auditActionProductCreated = 'audit.action.productCreated';
  static const String auditActionProductUpdated = 'audit.action.productUpdated';
  static const String auditActionProductDeleted = 'audit.action.productDeleted';
  static const String auditActionRecordCreated = 'audit.action.recordCreated';
  static const String auditActionRecordScanned = 'audit.action.recordScanned';
  static const String auditActionRecordEdited = 'audit.action.recordEdited';
  static const String auditActionRecordMoved = 'audit.action.recordMoved';
  static const String auditActionQuantityAdjusted = 'audit.action.quantityAdjusted';
  static const String auditActionRecordClosed = 'audit.action.recordClosed';
  static const String auditActionDestroyReminderScheduled = 'audit.action.destroyReminderScheduled';
  static const String auditActionDestroyReminderFired = 'audit.action.destroyReminderFired';
  static const String auditActionDestroyConfirmed = 'audit.action.destroyConfirmed';
  static const String auditActionEscalationRaised = 'audit.action.escalationRaised';
  static const String auditActionEscalationNotified = 'audit.action.escalationNotified';
  static const String auditActionEscalationAcknowledged = 'audit.action.escalationAcknowledged';
  static const String auditActionEscalationResolved = 'audit.action.escalationResolved';
  static const String auditActionManagerOverride = 'audit.action.managerOverride';
  static const String auditActionPolicyEdited = 'audit.action.policyEdited';
  static const String auditActionPolicyRuleEdited = 'audit.action.policyRuleEdited';
  static const String auditActionPolicyRecalculated = 'audit.action.policyRecalculated';
  static const String auditActionNotificationStageEdited = 'audit.action.notificationStageEdited';
  static const String auditActionEscalationRuleEdited = 'audit.action.escalationRuleEdited';
  static const String auditActionLocationEdited = 'audit.action.locationEdited';
  static const String auditActionSettingChanged = 'audit.action.settingChanged';
  static const String auditActionUserCreated = 'audit.action.userCreated';
  static const String auditActionUserUpdated = 'audit.action.userUpdated';
  static const String auditActionUserSignedIn = 'audit.action.userSignedIn';
  static const String auditActionUserSignedOut = 'audit.action.userSignedOut';
  static const String auditActionPasswordChanged = 'audit.action.passwordChanged';
  static const String auditActionReportExported = 'audit.action.reportExported';
  static const String auditActionDataReset = 'audit.action.dataReset';
  static const String exportTitle = 'export.title';
  static const String exportTemplate = 'export.template';
  static const String exportTemplateDailyDestroy = 'export.template.dailyDestroy';
  static const String exportTemplateWeekly = 'export.template.weekly';
  static const String exportTemplateMonthly = 'export.template.monthly';
  static const String exportTemplateAudit = 'export.template.audit';
  static const String exportTemplateInventory = 'export.template.inventory';
  static const String exportTemplateExpired = 'export.template.expired';
  static const String exportDestination = 'export.destination';
  static const String exportDestinationLocalPdf = 'export.destination.localPdf';
  static const String exportDestinationLocalHtml = 'export.destination.localHtml';
  static const String exportDestinationLocalCsv = 'export.destination.localCsv';
  static const String exportDestinationGoogleDocs = 'export.destination.googleDocs';
  static const String exportIncludePhotos = 'export.includePhotos';
  static const String exportIncludeSignatures = 'export.includeSignatures';
  static const String exportIncludeStatistics = 'export.includeStatistics';
  static const String exportGenerate = 'export.generate';
  static const String exportGenerating = 'export.generating';
  static const String exportDone = 'export.done';
  static const String exportFailed = 'export.failed';
  static const String exportHistory = 'export.history';
  static const String exportShare = 'export.share';
  static const String exportOpen = 'export.open';
  static const String exportNoData = 'export.noData';
  static const String exportPeriod = 'export.period';
  static const String exportCompany = 'export.company';
  static const String exportStore = 'export.store';
  static const String exportGeneratedAt = 'export.generatedAt';
  static const String exportGeneratedBy = 'export.generatedBy';
  static const String exportSectionSummary = 'export.section.summary';
  static const String exportSectionDetails = 'export.section.details';
  static const String exportSectionPhotos = 'export.section.photos';
  static const String exportSectionSignatures = 'export.section.signatures';
  static const String exportSignaturePreparedBy = 'export.signature.preparedBy';
  static const String exportSignatureCheckedBy = 'export.signature.checkedBy';
  static const String exportSignatureApprovedBy = 'export.signature.approvedBy';
  static const String exportGoogleNotConfigured = 'export.googleNotConfigured';
  static const String exportGoogleClientId = 'export.googleClientId';
  static const String exportGoogleFolderId = 'export.googleFolderId';
  static const String settingsWorkflow = 'settings.workflow';
  static const String settingsDevice = 'settings.device';
  static const String settingsDeviceName = 'settings.deviceName';
  static const String settingsDeviceNameHint = 'settings.deviceNameHint';
  static const String settingsCompany = 'settings.company';
  static const String settingsStoreCode = 'settings.storeCode';
  static const String settingsAudit = 'settings.audit';
  static const String settingsExport = 'settings.export';
  static const String navManager = 'nav.manager';
  static const String notifStageActive = 'notif.stage.active';
  static const String exportPdfNotAvailableHere = 'export.pdfNotAvailableHere';
  static const String exportFontsMissing = 'export.fontsMissing';
  static const String exportSavedTo = 'export.savedTo';
  static const String errorExportFailed = 'error.exportFailed';
  static const String errorExportNotFound = 'error.exportNotFound';
  static const String managerTitle = 'manager.title';
  static const String managerSubtitle = 'manager.subtitle';
  static const String managerNoAccess = 'manager.noAccess';
  static const String scanLiveHint = 'scan.liveHint';
  static const String scanProductPhoto = 'scan.productPhoto';
  static const String scanProductPhotoHint = 'scan.productPhotoHint';
  static const String scanRetakePhoto = 'scan.retakePhoto';
  static const String scanRemovePhoto = 'scan.removePhoto';
  static const String scanBarcodeNotRead = 'scan.barcodeNotRead';
  static const String scanBarcodePhoto = 'scan.barcodePhoto';
  static const String scanBarcodePhotoKept = 'scan.barcodePhotoKept';
  static const String scanTypeBarcode = 'scan.typeBarcode';
  static const String catalogPhoto = 'catalog.photo';
  static const String catalogPhotoHint = 'catalog.photoHint';
  static const String catalogNoBarcode = 'catalog.noBarcode';
  static const String scanAimProductFront = 'scan.aimProductFront';
  static const String locationsShelfSaved = 'locations.shelfSaved';
  static const String locationsAreaSaved = 'locations.areaSaved';
  static const String locationsNameRequired = 'locations.nameRequired';
  static const String notifMaxScheduled = 'notif.maxScheduled';
  static const String notifMaxScheduledHint = 'notif.maxScheduledHint';
  static const String scanRecalledProduct = 'scan.recalledProduct';
  static const String scanRecalledWithShelf = 'scan.recalledWithShelf';
  static const String scanAutoAdvance = 'scan.autoAdvance';
  static const String scanAutoAdvanceHint = 'scan.autoAdvanceHint';
  static const String scanLiveTextHint = 'scan.liveTextHint';
  static const String notifBlockedTitle = 'notif.blockedTitle';
  static const String notifBlockedBody = 'notif.blockedBody';
  static const String notifAllow = 'notif.allow';
  static const String calcTitle = 'calc.title';
  static const String calcSubtitle = 'calc.subtitle';
  static const String calcModePrinted = 'calc.modePrinted';
  static const String calcModeBoth = 'calc.modeBoth';
  static const String calcModeSpan = 'calc.modeSpan';
  static const String calcUseTime = 'calc.useTime';
  static const String calcUseTimeHint = 'calc.useTimeHint';
  static const String calcSop = 'calc.sop';
  static const String calcSopHint = 'calc.sopHint';
  static const String calcNsx = 'calc.nsx';
  static const String calcHsd = 'calc.hsd';
  static const String calcAnchorExpiry = 'calc.anchorExpiry';
  static const String calcAnchorMfg = 'calc.anchorMfg';
  static const String calcSpanLabel = 'calc.spanLabel';
  static const String calcUnitHour = 'calc.unitHour';
  static const String calcUnitDay = 'calc.unitDay';
  static const String calcUnitMonth = 'calc.unitMonth';
  static const String calcUnitYear = 'calc.unitYear';
  static const String calcResultDestroy = 'calc.resultDestroy';
  static const String calcResultRule = 'calc.resultRule';
  static const String calcShelfLife = 'calc.shelfLife';
  static const String calcNeedShelfLife = 'calc.needShelfLife';
  static const String calcUsedFallback = 'calc.usedFallback';
  static const String calcClear = 'calc.clear';
  static const String calcApplyToIntake = 'calc.applyToIntake';
  static const String calcAppliedToIntake = 'calc.appliedToIntake';
  static const String calcPolicyNote = 'calc.policyNote';
  static const String calcPickTitle = 'calc.pickTitle';
  static const String calcPickSubtitle = 'calc.pickSubtitle';
  static const String calcPickConfirm = 'calc.pickConfirm';
  static const String calcPickResultExpiry = 'calc.pickResultExpiry';
  static const String calcPickPreviewDestroy = 'calc.pickPreviewDestroy';
}
