import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';

/// Bilingual lookup with `{placeholder}` interpolation.
///
/// Deliberately map-based rather than code-generated: the two tables in
/// [stringsVi] / [stringsEn] are the whole translation surface, so a store can
/// adjust any wording without a toolchain.
class AppLocalizations {
  AppLocalizations(this.locale)
      : _table = locale.languageCode == 'en' ? stringsEn : stringsVi,
        _fallback = stringsEn;

  final Locale locale;
  final Map<String, String> _table;
  final Map<String, String> _fallback;

  /// Loads the date symbols for every supported locale.
  ///
  /// `DateFormat.yMd('vi')` throws until this has run, and the reminder
  /// planner, the report builder and the export repository all format dates
  /// before any localization delegate has loaded - so this is called once at
  /// start-up rather than being left to whichever widget happens to build
  /// first.
  static Future<void> ensureDateFormattingReady() async {
    for (final Locale locale in supportedLocales) {
      await initializeDateFormatting(locale.languageCode);
    }
  }

  static const List<Locale> supportedLocales = <Locale>[
    Locale('vi'),
    Locale('en'),
  ];

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static AppLocalizations of(BuildContext context) {
    final AppLocalizations? found =
        Localizations.of<AppLocalizations>(context, AppLocalizations);
    return found ?? AppLocalizations(const Locale('vi'));
  }

  bool get isVietnamese => locale.languageCode == 'vi';

  /// Looks a key up and substitutes `{name}` placeholders.
  ///
  /// A missing key returns the key itself, which makes an untranslated string
  /// obvious in review instead of silently blank.
  /// True when [key] exists in either table - lets a caller decide whether a
  /// string is a key or already human-readable text.
  bool has(String key) => _table.containsKey(key) || _fallback.containsKey(key);

  String t(String key, [Map<String, Object?> params = const <String, Object?>{}]) {
    final String template = _table[key] ?? _fallback[key] ?? key;
    if (params.isEmpty) return template;
    return template.replaceAllMapped(RegExp(r'\{(\w+)\}'), (Match match) {
      final Object? value = params[match.group(1)];
      return value?.toString() ?? match.group(0)!;
    });
  }

  // ---------------------------------------------------------- formatting

  String get _localeName => locale.languageCode;

  String date(DateTime value) => DateFormat.yMd(_localeName).format(value);

  String dateTime(DateTime value) => DateFormat.yMd(_localeName).add_Hm().format(value);

  String time(DateTime value) => DateFormat.Hm(_localeName).format(value);

  String dayMonth(DateTime value) => DateFormat.MMMd(_localeName).format(value);

  String weekday(DateTime value) => DateFormat.EEEE(_localeName).format(value);

  String number(num value, {int decimals = 0}) =>
      NumberFormat.decimalPatternDigits(locale: _localeName, decimalDigits: decimals)
          .format(value);

  String percent(double fraction) =>
      NumberFormat.decimalPercentPattern(locale: _localeName, decimalDigits: 1)
          .format(fraction);

  /// Money is formatted with the store's configured symbol rather than the
  /// locale default, because a Vietnamese store may still price in USD.
  String money(double value, {required String symbol, int decimals = 0}) {
    final String formatted =
        NumberFormat.decimalPatternDigits(locale: _localeName, decimalDigits: decimals)
            .format(value);
    return isVietnamese ? '$formatted $symbol' : '$symbol$formatted';
  }

  /// Compact, human duration: "3 ngày 4 giờ" / "3 d 4 h".
  String duration(Duration value, {int parts = 2}) {
    Duration remaining = value.isNegative ? -value : value;
    if (remaining.inMinutes < 1) return t(K.timeNow);

    final List<String> pieces = <String>[];
    final int days = remaining.inDays;
    if (days > 0) {
      pieces.add(t(K.timeDays, <String, Object?>{'count': days}));
      remaining -= Duration(days: days);
    }
    if (pieces.length < parts) {
      final int hours = remaining.inHours;
      if (hours > 0) {
        pieces.add(t(K.timeHours, <String, Object?>{'count': hours}));
        remaining -= Duration(hours: hours);
      }
    }
    if (pieces.length < parts) {
      final int minutes = remaining.inMinutes;
      if (minutes > 0) {
        pieces.add(t(K.timeMinutes, <String, Object?>{'count': minutes}));
      }
    }
    return pieces.isEmpty ? t(K.timeNow) : pieces.join(' ');
  }

  /// Longer spans read better in months and years.
  String shelfLife(Duration value) {
    final int days = value.inDays;
    if (days >= 365) {
      final int years = days ~/ 365;
      final int months = (days % 365) ~/ 30;
      final String head = t(K.timeYears, <String, Object?>{'count': years});
      return months == 0 ? head : '$head ${t(K.timeMonths, <String, Object?>{'count': months})}';
    }
    if (days >= 30) {
      final int months = days ~/ 30;
      final int rest = days % 30;
      final String head = t(K.timeMonths, <String, Object?>{'count': months});
      return rest == 0 ? head : '$head ${t(K.timeDays, <String, Object?>{'count': rest})}';
    }
    if (days >= 1) return t(K.timeDays, <String, Object?>{'count': days});
    return duration(value);
  }
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      AppLocalizations.supportedLocales
          .any((Locale l) => l.languageCode == locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

extension LocalizationsX on BuildContext {
  AppLocalizations get l10n => AppLocalizations.of(this);
}
