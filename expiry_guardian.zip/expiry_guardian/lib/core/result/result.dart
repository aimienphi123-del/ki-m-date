import 'package:expiry_guardian/core/error/failure.dart';

/// A minimal, dependency-free `Either`-style result type.
///
/// Repositories return [Result] instead of throwing so that call sites are
/// forced to handle the failure path. Data sources may still throw; the
/// repository implementation is the single place where exceptions are mapped
/// onto [Failure]s.
sealed class Result<T> {
  const Result();

  const factory Result.ok(T value) = Ok<T>;
  const factory Result.err(Failure failure) = Err<T>;

  bool get isOk => this is Ok<T>;
  bool get isErr => this is Err<T>;

  /// The value when successful, otherwise `null`.
  T? get valueOrNull => switch (this) {
        Ok<T>(:final value) => value,
        Err<T>() => null,
      };

  /// The failure when unsuccessful, otherwise `null`.
  Failure? get failureOrNull => switch (this) {
        Ok<T>() => null,
        Err<T>(:final failure) => failure,
      };

  R fold<R>(R Function(Failure failure) onErr, R Function(T value) onOk) {
    return switch (this) {
      Ok<T>(:final value) => onOk(value),
      Err<T>(:final failure) => onErr(failure),
    };
  }

  Result<R> map<R>(R Function(T value) transform) {
    return switch (this) {
      Ok<T>(:final value) => Result<R>.ok(transform(value)),
      Err<T>(:final failure) => Result<R>.err(failure),
    };
  }

  Future<Result<R>> mapAsync<R>(Future<R> Function(T value) transform) async {
    return switch (this) {
      Ok<T>(:final value) => Result<R>.ok(await transform(value)),
      Err<T>(:final failure) => Result<R>.err(failure),
    };
  }

  /// Returns the value or throws the failure. Only use where a failure is a
  /// programming error (for example inside tests).
  T unwrap() {
    return switch (this) {
      Ok<T>(:final value) => value,
      Err<T>(:final failure) => throw StateError('Unwrapped an error result: $failure'),
    };
  }
}

final class Ok<T> extends Result<T> {
  const Ok(this.value);
  final T value;

  @override
  String toString() => 'Ok($value)';
}

final class Err<T> extends Result<T> {
  const Err(this.failure);
  final Failure failure;

  @override
  String toString() => 'Err($failure)';
}
