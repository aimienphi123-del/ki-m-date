import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/theme/priority_palette.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:flutter/material.dart';

/// Maps a [Failure] onto a localized message. The raw English text inside a
/// failure is for logs; the shop floor sees its own language.
String describeFailure(BuildContext context, Failure failure) {
  final AppLocalizations l10n = context.l10n;
  final String byMessage = switch (failure.message) {
    'username_required' => l10n.t(K.errorUsernameRequired),
    'display_name_required' => l10n.t(K.errorDisplayNameRequired),
    'password_too_short' => l10n.t(K.errorPasswordTooShort),
    'username_taken' => l10n.t(K.errorUsernameTaken),
    'account_disabled' => l10n.t(K.errorAccountDisabled),
    'invalid_credentials' => l10n.t(K.errorUnauthenticated),
    'name_required' => l10n.t(K.errorNameRequired),
    'barcode_required' => l10n.t(K.errorBarcodeRequired),
    'barcode_taken' => l10n.t(K.errorBarcodeTaken),
    'quantity_must_be_positive' => l10n.t(K.errorQuantityPositive),
    'record_not_found' => l10n.t(K.errorRecordNotFound),
    'record_not_active' => l10n.t(K.errorRecordNotActive),
    'invalid_quantity' => l10n.t(K.errorInvalidQuantity),
    'capture_missing' => l10n.t(K.errorCaptureMissing),
    'scan_failed' => l10n.t(K.errorScanFailed),
    'export_failed' => l10n.t(K.errorExportFailed),
    'export_not_found' => l10n.t(K.errorExportNotFound),
    _ => '',
  };
  if (byMessage.isNotEmpty) return byMessage;

  // Some failures carry a localization key directly - the export gateways do,
  // because the reason a destination is unusable is written for a person.
  if (failure.message.contains('.') && l10n.has(failure.message)) {
    return l10n.t(failure.message);
  }

  return switch (failure.code) {
    FailureCode.database => l10n.t(K.errorDatabase),
    FailureCode.notFound => l10n.t(K.errorNotFound),
    FailureCode.duplicate => l10n.t(K.errorDuplicate),
    FailureCode.validation => l10n.t(K.errorValidation),
    FailureCode.permissionDenied => l10n.t(K.errorPermission),
    FailureCode.unauthenticated => l10n.t(K.errorUnauthenticated),
    FailureCode.cameraUnavailable => l10n.t(K.errorCamera),
    FailureCode.recognitionFailed => l10n.t(K.errorRecognition),
    FailureCode.remoteNotConfigured => l10n.t(K.errorRemoteNotConfigured),
    _ => l10n.t(K.errorGeneric),
  };
}

/// Colour + icon + word. Never colour alone.
class PriorityBadge extends StatelessWidget {
  const PriorityBadge({required this.level, this.compact = false, super.key});

  final PriorityLevel level;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final PriorityColors colors = PriorityPalette.of(context, level);
    final String label = context.l10n.t(switch (level) {
      PriorityLevel.safe => K.prioritySafe,
      PriorityLevel.approaching => K.priorityApproaching,
      PriorityLevel.destroySoon => K.priorityDestroySoon,
      PriorityLevel.destroyNow => K.priorityDestroyNow,
      PriorityLevel.expired => K.priorityExpired,
    },);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 10, vertical: compact ? 4 : 6),
      decoration: BoxDecoration(
        color: colors.background,
        border: Border.all(color: colors.border),
        borderRadius: BorderRadius.circular(Dimens.radiusSmall),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(PriorityPalette.iconOf(level), size: compact ? 14 : 18, color: colors.foreground),
          if (!compact) ...<Widget>[
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: colors.foreground,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  const SectionHeader({required this.title, this.subtitle, this.trailing, super.key});

  final String title;
  final String? subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, Dimens.gapL, 0, Dimens.gapS),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                ),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      subtitle!,
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                  ),
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class AppCard extends StatelessWidget {
  const AppCard({
    required this.child,
    this.onTap,
    this.padding = Dimens.cardPadding,
    this.borderColor,
    super.key,
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Material(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(Dimens.radius),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(Dimens.radius),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(Dimens.radius),
            border: Border.all(
              color: borderColor ?? theme.colorScheme.outlineVariant.withValues(alpha: 0.6),
            ),
          ),
          padding: padding,
          child: child,
        ),
      ),
    );
  }
}

class StatTile extends StatelessWidget {
  const StatTile({
    required this.label,
    required this.value,
    this.caption,
    this.icon,
    this.accent,
    this.onTap,
    super.key,
  });

  final String label;
  final String value;
  final String? caption;
  final IconData? icon;
  final Color? accent;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final Color color = accent ?? theme.colorScheme.primary;
    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Row(
            children: <Widget>[
              if (icon != null) ...<Widget>[
                Icon(icon, size: 18, color: color),
                const SizedBox(width: 6),
              ],
              Expanded(
                child: Text(
                  label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.labelMedium
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimens.gapS),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800, color: color),
          ),
          if (caption != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                caption!,
                maxLines: 2,
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    required this.title,
    this.message,
    this.icon = Icons.inbox_outlined,
    this.action,
    super.key,
  });

  final String title;
  final String? message;
  final IconData icon;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(Dimens.gapXl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 56, color: theme.colorScheme.outline),
            const SizedBox(height: Dimens.gapM),
            Text(
              title,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
            ),
            if (message != null) ...<Widget>[
              const SizedBox(height: Dimens.gapS),
              Text(
                message!,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
            if (action != null) ...<Widget>[
              const SizedBox(height: Dimens.gapL),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

class ErrorView extends StatelessWidget {
  const ErrorView({required this.message, this.onRetry, super.key});

  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return EmptyState(
      icon: Icons.error_outline,
      title: context.l10n.t(K.errorGeneric),
      message: message,
      action: onRetry == null
          ? null
          : FilledButton.tonalIcon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: Text(context.l10n.t(K.commonRetry)),
            ),
    );
  }
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});

  @override
  Widget build(BuildContext context) =>
      const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator()));
}

/// A labelled read-only row used on detail screens.
class DetailRow extends StatelessWidget {
  const DetailRow({
    required this.label,
    required this.value,
    this.icon,
    this.valueColor,
    this.caption,
    super.key,
  });

  final String label;
  final String value;
  final IconData? icon;
  final Color? valueColor;
  final String? caption;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (icon != null) ...<Widget>[
            Icon(icon, size: 18, color: theme.colorScheme.onSurfaceVariant),
            const SizedBox(width: Dimens.gapS),
          ],
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
          Expanded(
            flex: 5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  value,
                  textAlign: TextAlign.right,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: valueColor,
                  ),
                ),
                if (caption != null)
                  Text(
                    caption!,
                    textAlign: TextAlign.right,
                    style: theme.textTheme.bodySmall
                        ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// A short banner used for warnings that must not be missed but must not block.
class NoticeBanner extends StatelessWidget {
  const NoticeBanner({
    required this.message,
    this.icon = Icons.info_outline,
    this.tone = NoticeTone.info,
    this.action,
    super.key,
  });

  final String message;
  final IconData icon;
  final NoticeTone tone;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final (Color background, Color foreground) = switch (tone) {
      NoticeTone.info => (
          theme.colorScheme.secondaryContainer,
          theme.colorScheme.onSecondaryContainer
        ),
      NoticeTone.warning => (
          PriorityPalette.of(context, PriorityLevel.approaching).background,
          PriorityPalette.of(context, PriorityLevel.approaching).foreground
        ),
      NoticeTone.danger => (
          PriorityPalette.of(context, PriorityLevel.destroyNow).background,
          PriorityPalette.of(context, PriorityLevel.destroyNow).foreground
        ),
    };

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(Dimens.radiusSmall),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(icon, size: 20, color: foreground),
          const SizedBox(width: Dimens.gapS),
          Expanded(
            child: Text(
              message,
              style: theme.textTheme.bodyMedium?.copyWith(color: foreground),
            ),
          ),
          if (action != null) ...<Widget>[const SizedBox(width: Dimens.gapS), action!],
        ],
      ),
    );
  }
}

enum NoticeTone { info, warning, danger }

/// One-line feedback, in the store's language.
///
/// Every screen needs this and every screen was writing the same six lines, so
/// it lives here once. Errors get the theme's error colour and stay up longer,
/// because the shop floor is a noisy place to read a message.
void showAppSnack(BuildContext context, String message, {bool isError = false}) {
  final ThemeData theme = Theme.of(context);
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(color: isError ? theme.colorScheme.onError : null),
        ),
        backgroundColor: isError ? theme.colorScheme.error : null,
        duration: Duration(seconds: isError ? 5 : 3),
      ),
    );
}

/// A yes/no dialog. Returns false when dismissed, never null, so callers do not
/// have to think about the third case.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  String? message,
  String? confirmLabel,
  bool destructive = false,
}) async {
  final AppLocalizations l10n = context.l10n;
  final bool? answer = await showDialog<bool>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: Text(title),
      content: message == null ? null : Text(message),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text(l10n.t(K.commonCancel)),
        ),
        FilledButton(
          style: destructive
              ? FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.error,
                  foregroundColor: Theme.of(context).colorScheme.onError,
                )
              : null,
          onPressed: () => Navigator.of(context).pop(true),
          child: Text(confirmLabel ?? l10n.t(K.commonConfirm)),
        ),
      ],
    ),
  );
  return answer ?? false;
}
