import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:flutter/material.dart';

enum DurationUnit { minutes, hours, days, months, years }

extension DurationUnitX on DurationUnit {
  Duration toDuration(int amount) => switch (this) {
        DurationUnit.minutes => Duration(minutes: amount),
        DurationUnit.hours => Duration(hours: amount),
        DurationUnit.days => Duration(days: amount),
        DurationUnit.months => Duration(days: amount * 30),
        DurationUnit.years => Duration(days: amount * 365),
      };

  String labelKey() => switch (this) {
        DurationUnit.minutes => K.timeMinutes,
        DurationUnit.hours => K.timeHours,
        DurationUnit.days => K.timeDays,
        DurationUnit.months => K.timeMonths,
        DurationUnit.years => K.timeYears,
      };
}

/// Picks the coarsest unit that represents [value] exactly, so a lead time of
/// 2 hours does not come back as "120 minutes".
({DurationUnit unit, int amount}) decomposeDuration(Duration value) {
  final int minutes = value.inMinutes;
  if (minutes == 0) return (unit: DurationUnit.minutes, amount: 0);
  if (minutes % (365 * 24 * 60) == 0) {
    return (unit: DurationUnit.years, amount: minutes ~/ (365 * 24 * 60));
  }
  if (minutes % (30 * 24 * 60) == 0) {
    return (unit: DurationUnit.months, amount: minutes ~/ (30 * 24 * 60));
  }
  if (minutes % (24 * 60) == 0) {
    return (unit: DurationUnit.days, amount: minutes ~/ (24 * 60));
  }
  if (minutes % 60 == 0) return (unit: DurationUnit.hours, amount: minutes ~/ 60);
  return (unit: DurationUnit.minutes, amount: minutes);
}

/// Amount + unit editor. Used everywhere a policy time span is configured.
class DurationField extends StatefulWidget {
  const DurationField({
    required this.label,
    required this.value,
    required this.onChanged,
    this.allowNull = false,
    this.helperText,
    super.key,
  });

  final String label;
  final Duration? value;
  final ValueChanged<Duration?> onChanged;
  final bool allowNull;
  final String? helperText;

  @override
  State<DurationField> createState() => _DurationFieldState();
}

class _DurationFieldState extends State<DurationField> {
  late final TextEditingController _controller;
  late DurationUnit _unit;

  @override
  void initState() {
    super.initState();
    final ({int amount, DurationUnit unit}) parts =
        decomposeDuration(widget.value ?? Duration.zero);
    _unit = parts.unit;
    _controller =
        TextEditingController(text: widget.value == null ? '' : parts.amount.toString());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _emit() {
    final String text = _controller.text.trim();
    if (text.isEmpty) {
      widget.onChanged(widget.allowNull ? null : Duration.zero);
      return;
    }
    final int? amount = int.tryParse(text);
    if (amount == null) return;
    widget.onChanged(_unit.toDuration(amount));
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          flex: 4,
          child: TextField(
            controller: _controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: widget.label,
              helperText: widget.helperText,
              helperMaxLines: 2,
              hintText: widget.allowNull ? l10n.t(K.commonNone) : null,
            ),
            onChanged: (_) => _emit(),
          ),
        ),
        const SizedBox(width: Dimens.gapS),
        Expanded(
          flex: 3,
          child: DropdownButtonFormField<DurationUnit>(
            initialValue: _unit,
            isExpanded: true,
            decoration: const InputDecoration(),
            items: DurationUnit.values
                .map((DurationUnit unit) => DropdownMenuItem<DurationUnit>(
                      value: unit,
                      child: Text(
                        l10n.t(unit.labelKey(), <String, Object?>{'count': ''}).trim(),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),)
                .toList(growable: false),
            onChanged: (DurationUnit? unit) {
              if (unit == null) return;
              setState(() => _unit = unit);
              _emit();
            },
          ),
        ),
      ],
    );
  }
}
