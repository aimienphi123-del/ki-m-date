/// The report templates the store can produce.
enum ReportTemplate {
  dailyDestroy,
  weekly,
  monthly,
  audit,
  inventory,
  expired;

  static ReportTemplate fromName(String? value) => ReportTemplate.values.firstWhere(
        (ReportTemplate t) => t.name == value,
        orElse: () => ReportTemplate.dailyDestroy,
      );

  String get labelKey => switch (this) {
        ReportTemplate.dailyDestroy => 'export.template.dailyDestroy',
        ReportTemplate.weekly => 'export.template.weekly',
        ReportTemplate.monthly => 'export.template.monthly',
        ReportTemplate.audit => 'export.template.audit',
        ReportTemplate.inventory => 'export.template.inventory',
        ReportTemplate.expired => 'export.template.expired',
      };
}

/// Where a generated report goes.
enum ExportDestination {
  localPdf,
  localHtml,
  localCsv,
  googleDocs;

  static ExportDestination fromName(String? value) =>
      ExportDestination.values.firstWhere(
        (ExportDestination d) => d.name == value,
        orElse: () => ExportDestination.localPdf,
      );

  String get labelKey => switch (this) {
        ExportDestination.localPdf => 'export.destination.localPdf',
        ExportDestination.localHtml => 'export.destination.localHtml',
        ExportDestination.localCsv => 'export.destination.localCsv',
        ExportDestination.googleDocs => 'export.destination.googleDocs',
      };

  String get fileExtension => switch (this) {
        ExportDestination.localPdf => 'pdf',
        ExportDestination.localHtml => 'html',
        ExportDestination.localCsv => 'csv',
        ExportDestination.googleDocs => 'gdoc',
      };

  bool get isLocalFile => this != ExportDestination.googleDocs;
}

/// The masthead every document carries.
class DocumentHeader {
  const DocumentHeader({
    required this.title,
    required this.generatedAt,
    this.company = '',
    this.store = '',
    this.storeCode = '',
    this.generatedBy = '',
    this.deviceLabel = '',
    this.periodLabel = '',
  });

  final String title;
  final String company;
  final String store;
  final String storeCode;
  final DateTime generatedAt;
  final String generatedBy;
  final String deviceLabel;
  final String periodLabel;
}

sealed class DocumentSection {
  const DocumentSection();
}

/// Free prose, used for notes and caveats.
class TextSection extends DocumentSection {
  const TextSection({required this.heading, required this.paragraphs});

  final String heading;
  final List<String> paragraphs;
}

class StatItem {
  const StatItem({required this.label, required this.value, this.caption});

  final String label;
  final String value;
  final String? caption;
}

/// A block of headline figures.
class StatSection extends DocumentSection {
  const StatSection({required this.heading, required this.items});

  final String heading;
  final List<StatItem> items;
}

/// A table. [numericColumns] are right-aligned by every renderer.
class TableSection extends DocumentSection {
  const TableSection({
    required this.heading,
    required this.columns,
    required this.rows,
    this.numericColumns = const <int>{},
    this.emptyMessage,
    this.totals,
  });

  final String heading;
  final List<String> columns;
  final List<List<String>> rows;
  final Set<int> numericColumns;
  final String? emptyMessage;

  /// Optional totals row, rendered in bold.
  final List<String>? totals;

  bool get isEmpty => rows.isEmpty;
}

class DocumentImage {
  const DocumentImage({required this.path, this.caption = ''});

  final String path;
  final String caption;
}

/// Evidence photos, only included when the manager asks for them.
class ImageSection extends DocumentSection {
  const ImageSection({required this.heading, required this.images});

  final String heading;
  final List<DocumentImage> images;
}

/// A place for a wet signature on the printed page.
class SignatureBlock {
  const SignatureBlock({required this.role, this.name = ''});

  final String role;
  final String name;
}

/// A finished, renderer-agnostic report.
///
/// The builder produces this from real rows; the PDF, HTML and CSV renderers -
/// and any future Google Docs writer - all consume the same structure, so the
/// six templates only have to be defined once.
class ReportDocument {
  const ReportDocument({
    required this.template,
    required this.header,
    required this.sections,
    this.signatures = const <SignatureBlock>[],
    this.footerNote = '',
  });

  final ReportTemplate template;
  final DocumentHeader header;
  final List<DocumentSection> sections;
  final List<SignatureBlock> signatures;
  final String footerNote;

  bool get hasContent => sections.any(
        (DocumentSection s) => s is! TableSection || !s.isEmpty,
      );

  /// Every table in the document, in order - what the CSV renderer walks.
  List<TableSection> get tables =>
      sections.whereType<TableSection>().toList(growable: false);
}

/// The record of one export, kept so a manager can find the file again.
class DocumentExport {
  const DocumentExport({
    required this.id,
    required this.template,
    required this.destination,
    required this.title,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.documentId,
    this.url,
    this.filePath,
    this.periodFrom,
    this.periodTo,
    this.createdBy,
    this.deviceId,
    this.error,
  });

  final String id;
  final ReportTemplate template;
  final ExportDestination destination;
  final String title;

  /// pending | ready | failed
  final String status;

  /// Google Docs document id, when that destination is used.
  final String? documentId;

  /// Shareable link, when the destination provides one.
  final String? url;

  /// Local file, for the three offline destinations.
  final String? filePath;

  final DateTime? periodFrom;
  final DateTime? periodTo;
  final String? createdBy;
  final String? deviceId;
  final String? error;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isReady => status == 'ready';
}
