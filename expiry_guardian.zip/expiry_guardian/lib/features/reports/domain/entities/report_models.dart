import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';

enum ReportGranularity { daily, weekly, monthly }

class ReportPeriod {
  const ReportPeriod({required this.from, required this.to, required this.granularity});

  /// Inclusive.
  final DateTime from;

  /// Exclusive.
  final DateTime to;
  final ReportGranularity granularity;

  factory ReportPeriod.day(DateTime day) {
    final DateTime start = DateTime(day.year, day.month, day.day);
    return ReportPeriod(
      from: start,
      to: start.add(const Duration(days: 1)),
      granularity: ReportGranularity.daily,
    );
  }

  factory ReportPeriod.week(DateTime anyDayInWeek) {
    final DateTime day = DateTime(anyDayInWeek.year, anyDayInWeek.month, anyDayInWeek.day);
    final DateTime monday = day.subtract(Duration(days: day.weekday - DateTime.monday));
    return ReportPeriod(
      from: monday,
      to: monday.add(const Duration(days: 7)),
      granularity: ReportGranularity.weekly,
    );
  }

  factory ReportPeriod.month(DateTime anyDayInMonth) {
    final DateTime start = DateTime(anyDayInMonth.year, anyDayInMonth.month);
    return ReportPeriod(
      from: start,
      to: DateTime(anyDayInMonth.year, anyDayInMonth.month + 1),
      granularity: ReportGranularity.monthly,
    );
  }

  factory ReportPeriod.lastDays(DateTime now, int days) {
    final DateTime end = DateTime(now.year, now.month, now.day).add(const Duration(days: 1));
    return ReportPeriod(
      from: end.subtract(Duration(days: days)),
      to: end,
      granularity: ReportGranularity.daily,
    );
  }

  int get dayCount => to.difference(from).inDays;

  ReportPeriod get previous {
    final Duration span = to.difference(from);
    return ReportPeriod(from: from.subtract(span), to: from, granularity: granularity);
  }
}

/// One point on a trend chart.
class TrendPoint {
  const TrendPoint({
    required this.bucketStart,
    required this.records,
    required this.units,
    required this.loss,
    required this.overdueRecords,
  });

  final DateTime bucketStart;
  final int records;
  final double units;
  final double loss;
  final int overdueRecords;
}

/// A named slice of the destruction totals (category, shelf, product, reason).
class WasteSlice {
  const WasteSlice({
    required this.key,
    required this.label,
    required this.records,
    required this.units,
    required this.loss,
  });

  final String key;
  final String label;
  final int records;
  final double units;
  final double loss;
}

class DestructionReport {
  const DestructionReport({
    required this.period,
    required this.totalRecords,
    required this.totalUnits,
    required this.totalLoss,
    required this.overdueRecords,
    required this.expiredOnDestroyRecords,
    required this.pricedRecords,
    required this.byCategory,
    required this.byShelf,
    required this.byProduct,
    required this.byReason,
    required this.trend,
  });

  final ReportPeriod period;
  final int totalRecords;
  final double totalUnits;
  final double totalLoss;

  /// Destroyed after the policy deadline.
  final int overdueRecords;

  /// Destroyed after the goods had already expired - the hard policy breach.
  final int expiredOnDestroyRecords;

  /// How many destruction rows carried a unit cost.
  final int pricedRecords;

  final List<WasteSlice> byCategory;
  final List<WasteSlice> byShelf;
  final List<WasteSlice> byProduct;
  final List<WasteSlice> byReason;
  final List<TrendPoint> trend;

  bool get lossIsPartial => pricedRecords < totalRecords;

  double get onTimeRate =>
      totalRecords == 0 ? 1 : (totalRecords - overdueRecords) / totalRecords;
}

/// Counts of records created / closed in a period, for the intake side.
class IntakeReport {
  const IntakeReport({
    required this.period,
    required this.recordsCreated,
    required this.unitsReceived,
    required this.byStatus,
  });

  final ReportPeriod period;
  final int recordsCreated;
  final double unitsReceived;
  final Map<InventoryStatus, int> byStatus;
}
