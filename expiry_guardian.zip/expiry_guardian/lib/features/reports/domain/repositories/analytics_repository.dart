import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';

/// Aggregate figures for one shelf, product or category, used both by the
/// reports screen and by the prediction engine.
class WasteStats {
  const WasteStats({
    required this.key,
    required this.label,
    required this.intakeRecords,
    required this.intakeUnits,
    required this.destroyedRecords,
    required this.destroyedUnits,
    required this.overdueRecords,
    required this.expiredRecords,
    required this.loss,
  });

  final String key;
  final String label;

  /// Records booked in during the window - the denominator.
  final int intakeRecords;
  final double intakeUnits;

  final int destroyedRecords;
  final double destroyedUnits;

  /// Destroyed after the policy deadline.
  final int overdueRecords;

  /// Destroyed after the goods had expired.
  final int expiredRecords;

  final double loss;

  double get wasteRate => intakeRecords == 0 ? 0 : destroyedRecords / intakeRecords;
  double get overdueRate => destroyedRecords == 0 ? 0 : overdueRecords / destroyedRecords;
}

abstract interface class AnalyticsRepository {
  Future<Result<DestructionReport>> destructionReport(ReportPeriod period);

  Future<Result<IntakeReport>> intakeReport(ReportPeriod period);

  Future<Result<List<WasteStats>>> wasteByShelf(ReportPeriod period);

  Future<Result<List<WasteStats>>> wasteByCategory(ReportPeriod period);

  Future<Result<List<WasteStats>>> wasteByProduct(ReportPeriod period, {int limit = 50});

  /// Value of the stock currently on the shelves, grouped by category, used to
  /// project future waste.
  Future<Result<List<WasteSlice>>> openStockByCategory();

  /// Total number of destruction rows recorded, ever. Drives the
  /// "not enough data yet" state of the prediction screen.
  Future<Result<int>> destructionSampleSize();
}
