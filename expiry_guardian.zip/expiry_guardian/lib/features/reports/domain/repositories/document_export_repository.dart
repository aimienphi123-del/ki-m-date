import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/services/report_document_builder.dart';

/// What the export screen asks for.
class ExportRequest {
  const ExportRequest({
    required this.template,
    required this.destination,
    required this.period,
    this.options = const ReportOptions(),
  });

  final ReportTemplate template;
  final ExportDestination destination;
  final ReportPeriod period;
  final ReportOptions options;
}

/// Generates report documents and remembers where they went.
abstract interface class DocumentExportRepository {
  /// Gathers the rows, builds the document and writes it to the destination.
  Future<Result<DocumentExport>> generate(ExportRequest request);

  /// Rebuilds an earlier export with fresh data, over the same document.
  Future<Result<DocumentExport>> regenerate(String exportId);

  /// Builds the document without writing anything - used by the preview.
  Future<Result<ReportDocument>> preview(ExportRequest request);

  Future<Result<List<DocumentExport>>> history({int limit = 50});

  /// A link a person can open or forward, when the destination provides one.
  Future<Result<String?>> shareLink(String exportId);

  /// True when the destination is usable right now.
  bool isDestinationConfigured(ExportDestination destination);

  /// Why a destination is not usable, as a localization key.
  String? unavailableReasonKey(ExportDestination destination);

  Stream<void> watch();
}
