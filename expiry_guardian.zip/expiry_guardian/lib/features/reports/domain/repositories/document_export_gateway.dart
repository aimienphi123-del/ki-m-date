import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';

/// What one export produced.
class ExportOutcome {
  const ExportOutcome({
    required this.destination,
    this.filePath,
    this.documentId,
    this.url,
  });

  final ExportDestination destination;

  /// Local file, for the offline destinations.
  final String? filePath;

  /// Remote document id, for a document service.
  final String? documentId;

  /// Shareable link, when the destination provides one.
  final String? url;
}

/// Thrown when a destination is asked for something it cannot do.
class ExportUnavailableException implements Exception {
  const ExportUnavailableException(this.messageKey, {this.detail});

  /// A localization key, so the reason reaches the shop floor in its own
  /// language rather than as an English exception string.
  final String messageKey;
  final String? detail;

  @override
  String toString() => 'ExportUnavailableException($messageKey)';
}

/// Writes a [ReportDocument] somewhere a person can read it.
///
/// Three offline implementations ship (PDF, HTML, CSV). A Google Docs
/// implementation is the same interface: create a document, update an existing
/// one, hand back a share link, and export a PDF. See `docs/EXPORT.md`.
abstract interface class DocumentExportGateway {
  ExportDestination get destination;

  /// False when the destination needs configuration the store has not done.
  bool get isConfigured;

  /// Human-readable reason, as a localization key, when [isConfigured] is
  /// false. Null when it is configured.
  String? get unavailableReasonKey;

  /// Writes a new document.
  Future<ExportOutcome> create(ReportDocument document);

  /// Replaces the contents of a document that was created earlier.
  /// Destinations that cannot update in place create a new file instead and
  /// say so through the returned outcome.
  Future<ExportOutcome> update(String documentId, ReportDocument document);

  /// A link anybody with it can open, when the destination supports sharing.
  Future<String?> shareLink(String documentId);

  /// A PDF of the same document, when the destination can produce one.
  Future<String?> exportPdf(String documentId, ReportDocument document);
}
