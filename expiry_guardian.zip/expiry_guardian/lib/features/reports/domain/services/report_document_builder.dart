import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';

/// Options a manager toggles before generating.
class ReportOptions {
  const ReportOptions({
    this.includeStatistics = true,
    this.includePhotos = false,
    this.includeSignatures = true,
    this.maxRows = 500,
  });

  final bool includeStatistics;
  final bool includePhotos;
  final bool includeSignatures;
  final int maxRows;
}

/// Everything a report needs, gathered by the repository before building.
class ReportInputs {
  const ReportInputs({
    required this.period,
    required this.header,
    this.destructions = const <DestructionLine>[],
    this.report,
    this.inventory = const <InventoryItemView>[],
    this.auditEntries = const <AuditEntry>[],
    this.auditIntegrity,
    this.currencySymbol = '',
  });

  final ReportPeriod period;
  final DocumentHeader header;
  final List<DestructionLine> destructions;
  final DestructionReport? report;
  final List<InventoryItemView> inventory;
  final List<AuditEntry> auditEntries;
  final AuditIntegrityReport? auditIntegrity;
  final String currencySymbol;
}

/// One destruction joined with the product and place it happened.
class DestructionLine {
  const DestructionLine({
    required this.destruction,
    required this.productName,
    this.locationLabel = '',
    this.recordCode = '',
    this.batchCode,
    this.unit = '',
    this.employeeName,
  });

  final Destruction destruction;
  final String productName;
  final String locationLabel;
  final String recordCode;
  final String? batchCode;
  final String unit;
  final String? employeeName;
}

/// Turns gathered rows into one of the six documents.
///
/// Pure and renderer-agnostic: the same [ReportDocument] becomes a PDF, an
/// HTML page, a CSV or - when a Google Docs gateway is configured - a Google
/// document, with no template logic duplicated per format.
class ReportDocumentBuilder {
  const ReportDocumentBuilder(this._strings);

  final AppLocalizations _strings;

  String _t(String key, [Map<String, Object?> params = const <String, Object?>{}]) =>
      _strings.t(key, params);

  ReportDocument build({
    required ReportTemplate template,
    required ReportInputs inputs,
    ReportOptions options = const ReportOptions(),
  }) {
    return switch (template) {
      ReportTemplate.dailyDestroy ||
      ReportTemplate.weekly ||
      ReportTemplate.monthly =>
        _destructionDocument(template, inputs, options),
      ReportTemplate.audit => _auditDocument(inputs, options),
      ReportTemplate.inventory => _inventoryDocument(inputs, options),
      ReportTemplate.expired => _expiredDocument(inputs, options),
    };
  }

  // ------------------------------------------------- destruction reports

  ReportDocument _destructionDocument(
    ReportTemplate template,
    ReportInputs inputs,
    ReportOptions options,
  ) {
    final DestructionReport? report = inputs.report;
    final List<DocumentSection> sections = <DocumentSection>[];

    if (options.includeStatistics && report != null) {
      sections.add(StatSection(
        heading: _t(K.exportSectionSummary),
        items: <StatItem>[
          StatItem(
            label: _t(K.reportsDestroyedRecords),
            value: _strings.number(report.totalRecords),
          ),
          StatItem(
            label: _t(K.reportsDestroyedQuantity),
            value: _strings.number(report.totalUnits),
          ),
          StatItem(
            label: _t(K.reportsFinancialLoss),
            value: _strings.money(report.totalLoss, symbol: inputs.currencySymbol),
            caption: report.lossIsPartial
                ? _t(K.reportsPartialLoss, <String, Object?>{
                    'priced': report.pricedRecords,
                    'total': report.totalRecords,
                  })
                : null,
          ),
          StatItem(
            label: _t(K.reportsOnTimeRate),
            value: _strings.percent(report.onTimeRate),
            caption: '${_t(K.reportsOverdueRecords)}: ${report.overdueRecords}',
          ),
          StatItem(
            label: _t(K.reportsExpiredQuantity),
            value: _strings.number(report.expiredOnDestroyRecords),
          ),
        ],
      ),);
    }

    sections.add(TableSection(
      heading: _t(K.exportSectionDetails),
      columns: <String>[
        _t(K.recordCode),
        _t(K.recordProduct),
        _t(K.recordBatch),
        _t(K.recordShelf),
        _t(K.commonQuantity),
        _t(K.commonReason),
        _t(K.destroyConfirmedBy),
        _t(K.destroyConfirmedAt),
        _t(K.reportsFinancialLoss),
      ],
      numericColumns: const <int>{4, 8},
      emptyMessage: _t(K.exportNoData),
      rows: inputs.destructions
          .take(options.maxRows)
          .map((DestructionLine line) => <String>[
                line.recordCode,
                line.productName,
                line.batchCode ?? '',
                line.locationLabel,
                '${_strings.number(line.destruction.quantity)} ${line.unit}',
                _t('destroy.reason.${line.destruction.reason.name}'),
                line.employeeName ?? '',
                _strings.dateTime(line.destruction.confirmedAt),
                _strings.money(line.destruction.lossAmount, symbol: inputs.currencySymbol),
              ],)
          .toList(growable: false),
      totals: inputs.destructions.isEmpty
          ? null
          : <String>[
              '',
              '',
              '',
              '',
              _strings.number(
                inputs.destructions.fold<double>(
                  0,
                  (double sum, DestructionLine l) => sum + l.destruction.quantity,
                ),
              ),
              '',
              '',
              '',
              _strings.money(
                inputs.destructions.fold<double>(
                  0,
                  (double sum, DestructionLine l) => sum + l.destruction.lossAmount,
                ),
                symbol: inputs.currencySymbol,
              ),
            ],
    ),);

    if (options.includeStatistics && report != null && report.byCategory.isNotEmpty) {
      sections.add(_sliceTable(
        _t(K.reportsMostWastedCategories),
        report.byCategory,
        inputs.currencySymbol,
      ),);
    }
    if (options.includeStatistics && report != null && report.byShelf.isNotEmpty) {
      sections.add(_sliceTable(_t(K.reportsByShelf), report.byShelf, inputs.currencySymbol));
    }

    if (options.includePhotos) {
      final List<DocumentImage> images = inputs.destructions
          .where((DestructionLine l) => (l.destruction.photoPath ?? '').isNotEmpty)
          .map((DestructionLine l) => DocumentImage(
                path: l.destruction.photoPath!,
                caption: '${l.recordCode} · ${l.productName}',
              ),)
          .toList(growable: false);
      if (images.isNotEmpty) {
        sections.add(ImageSection(heading: _t(K.exportSectionPhotos), images: images));
      }
    }

    return ReportDocument(
      template: template,
      header: inputs.header,
      sections: sections,
      signatures: options.includeSignatures ? _signatures() : const <SignatureBlock>[],
      footerNote: report?.lossIsPartial ?? false
          ? _t(K.reportsPartialLoss, <String, Object?>{
              'priced': report!.pricedRecords,
              'total': report.totalRecords,
            })
          : '',
    );
  }

  TableSection _sliceTable(String heading, List<WasteSlice> slices, String currency) {
    return TableSection(
      heading: heading,
      columns: <String>[
        _t(K.commonName),
        _t(K.reportsDestroyedRecords),
        _t(K.reportsDestroyedQuantity),
        _t(K.reportsFinancialLoss),
      ],
      numericColumns: const <int>{1, 2, 3},
      emptyMessage: _t(K.exportNoData),
      rows: slices
          .map((WasteSlice slice) => <String>[
                slice.label.isEmpty ? _t(K.commonUnknown) : slice.label,
                _strings.number(slice.records),
                _strings.number(slice.units),
                _strings.money(slice.loss, symbol: currency),
              ],)
          .toList(growable: false),
    );
  }

  // -------------------------------------------------------- audit report

  ReportDocument _auditDocument(ReportInputs inputs, ReportOptions options) {
    final List<DocumentSection> sections = <DocumentSection>[];
    final AuditIntegrityReport? integrity = inputs.auditIntegrity;

    if (integrity != null) {
      sections.add(TextSection(
        heading: _t(K.auditVerify),
        paragraphs: <String>[
          integrity.isIntact
              ? _t(K.auditIntact, <String, Object?>{'count': integrity.entriesChecked})
              : _t(K.auditBroken,
                  <String, Object?>{'sequence': integrity.firstBrokenSequence ?? 0},),
          _t(K.auditImmutableNote),
        ],
      ),);
    }

    sections.add(TableSection(
      heading: _t(K.exportSectionDetails),
      columns: <String>[
        '#',
        _t(K.commonDone),
        _t(K.auditAction),
        _t(K.auditEntity),
        _t(K.auditActor),
        _t(K.auditDevice),
        _t(K.commonNotes),
      ],
      numericColumns: const <int>{0},
      emptyMessage: _t(K.auditEmpty),
      rows: inputs.auditEntries
          .take(options.maxRows)
          .map((AuditEntry entry) => <String>[
                '${entry.sequence}',
                _strings.dateTime(entry.occurredAt),
                _t('audit.action.${entry.action.name}'),
                entry.entityLabel ?? entry.entity,
                entry.actorName ?? '',
                entry.deviceId == null
                    ? ''
                    : entry.deviceId!.substring(0, entry.deviceId!.length.clamp(0, 8)),
                entry.note ?? '',
              ],)
          .toList(growable: false),
    ),);

    return ReportDocument(
      template: ReportTemplate.audit,
      header: inputs.header,
      sections: sections,
      signatures: options.includeSignatures ? _signatures() : const <SignatureBlock>[],
      footerNote: _t(K.auditImmutableNote),
    );
  }

  // ---------------------------------------------------- inventory report

  ReportDocument _inventoryDocument(ReportInputs inputs, ReportOptions options) {
    final List<DocumentSection> sections = <DocumentSection>[];

    if (options.includeStatistics) {
      final double units = inputs.inventory.fold<double>(
        0,
        (double sum, InventoryItemView i) => sum + i.record.quantityRemaining,
      );
      final double value = inputs.inventory
          .fold<double>(0, (double sum, InventoryItemView i) => sum + i.lossValue);
      sections.add(StatSection(
        heading: _t(K.exportSectionSummary),
        items: <StatItem>[
          StatItem(
            label: _t(K.dashboardTotalProducts),
            value: _strings.number(inputs.inventory.length),
          ),
          StatItem(label: _t(K.commonUnits), value: _strings.number(units)),
          StatItem(
            label: _t(K.dashboardStockValue),
            value: _strings.money(value, symbol: inputs.currencySymbol),
          ),
        ],
      ),);
    }

    sections.add(TableSection(
      heading: _t(K.exportSectionDetails),
      columns: <String>[
        _t(K.recordCode),
        _t(K.recordProduct),
        _t(K.recordBatch),
        _t(K.recordShelf),
        _t(K.recordRemaining),
        _t(K.recordExpiryAt),
        _t(K.recordDestroyAt),
        _t(K.commonStatus),
      ],
      numericColumns: const <int>{4},
      emptyMessage: _t(K.exportNoData),
      rows: inputs.inventory
          .take(options.maxRows)
          .map((InventoryItemView item) => <String>[
                item.record.code,
                item.product.displayName,
                item.record.batchCode ?? '',
                item.locationLabel,
                '${_strings.number(item.record.quantityRemaining)} ${item.record.unit}',
                _strings.date(item.record.expiryAt),
                _strings.dateTime(item.record.destroyAt),
                _t(_priorityKey(item)),
              ],)
          .toList(growable: false),
    ),);

    return ReportDocument(
      template: ReportTemplate.inventory,
      header: inputs.header,
      sections: sections,
      signatures: options.includeSignatures ? _signatures() : const <SignatureBlock>[],
    );
  }

  // ------------------------------------------------------ expired report

  ReportDocument _expiredDocument(ReportInputs inputs, ReportOptions options) {
    final List<InventoryItemView> expired = inputs.inventory
        .where((InventoryItemView i) => i.priority.isExpired || i.priority.isOverdue)
        .toList(growable: false);

    final List<DocumentSection> sections = <DocumentSection>[
      if (options.includeStatistics)
        StatSection(
          heading: _t(K.exportSectionSummary),
          items: <StatItem>[
            StatItem(
              label: _t(K.dashboardExpired),
              value: _strings.number(
                expired.where((InventoryItemView i) => i.priority.isExpired).length,
              ),
            ),
            StatItem(
              label: _t(K.dashboardOverdue),
              value: _strings.number(
                expired
                    .where((InventoryItemView i) =>
                        i.priority.isOverdue && !i.priority.isExpired,)
                    .length,
              ),
            ),
            StatItem(
              label: _t(K.reportsFinancialLoss),
              value: _strings.money(
                expired.fold<double>(
                  0,
                  (double sum, InventoryItemView i) => sum + i.lossValue,
                ),
                symbol: inputs.currencySymbol,
              ),
            ),
          ],
        ),
      TableSection(
        heading: _t(K.exportSectionDetails),
        columns: <String>[
          _t(K.recordCode),
          _t(K.recordProduct),
          _t(K.recordShelf),
          _t(K.recordRemaining),
          _t(K.recordExpiryAt),
          _t(K.recordDestroyAt),
          _t(K.dashboardOverdue),
        ],
        numericColumns: const <int>{3},
        emptyMessage: _t(K.exportNoData),
        rows: expired
            .take(options.maxRows)
            .map((InventoryItemView item) => <String>[
                  item.record.code,
                  item.product.displayName,
                  item.locationLabel,
                  '${_strings.number(item.record.quantityRemaining)} ${item.record.unit}',
                  _strings.date(item.record.expiryAt),
                  _strings.dateTime(item.record.destroyAt),
                  _strings.duration(item.priority.timeUntilDestroy),
                ],)
            .toList(growable: false),
      ),
    ];

    return ReportDocument(
      template: ReportTemplate.expired,
      header: inputs.header,
      sections: sections,
      signatures: options.includeSignatures ? _signatures() : const <SignatureBlock>[],
    );
  }

  String _priorityKey(InventoryItemView item) => switch (item.priority.level.name) {
        'safe' => K.prioritySafe,
        'approaching' => K.priorityApproaching,
        'destroySoon' => K.priorityDestroySoon,
        'destroyNow' => K.priorityDestroyNow,
        _ => K.priorityExpired,
      };

  List<SignatureBlock> _signatures() => <SignatureBlock>[
        SignatureBlock(role: _t(K.exportSignaturePreparedBy)),
        SignatureBlock(role: _t(K.exportSignatureCheckedBy)),
        SignatureBlock(role: _t(K.exportSignatureApprovedBy)),
      ];
}
