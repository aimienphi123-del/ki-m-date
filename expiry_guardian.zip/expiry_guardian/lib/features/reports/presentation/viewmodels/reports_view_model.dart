import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Which period the reports screen is showing.
class ReportSelection {
  const ReportSelection({required this.granularity, required this.anchor});

  final ReportGranularity granularity;

  /// Any date inside the period.
  final DateTime anchor;

  ReportPeriod get period => switch (granularity) {
        ReportGranularity.daily => ReportPeriod.day(anchor),
        ReportGranularity.weekly => ReportPeriod.week(anchor),
        ReportGranularity.monthly => ReportPeriod.month(anchor),
      };

  ReportSelection shift(int steps) {
    final DateTime next = switch (granularity) {
      ReportGranularity.daily => anchor.add(Duration(days: steps)),
      ReportGranularity.weekly => anchor.add(Duration(days: 7 * steps)),
      ReportGranularity.monthly => DateTime(anchor.year, anchor.month + steps, 1),
    };
    return ReportSelection(granularity: granularity, anchor: next);
  }

  ReportSelection withGranularity(ReportGranularity value) =>
      ReportSelection(granularity: value, anchor: anchor);
}

class ReportSelectionController extends Notifier<ReportSelection> {
  @override
  ReportSelection build() => ReportSelection(
        granularity: ReportGranularity.weekly,
        anchor: ref.watch(clockProvider).today(),
      );

  void setGranularity(ReportGranularity value) => state = state.withGranularity(value);

  void previous() => state = state.shift(-1);

  void next() {
    final DateTime today = ref.read(clockProvider).today();
    final ReportSelection candidate = state.shift(1);
    if (candidate.period.from.isAfter(today)) return;
    state = candidate;
  }
}

final NotifierProvider<ReportSelectionController, ReportSelection> reportSelectionProvider =
    NotifierProvider<ReportSelectionController, ReportSelection>(
        ReportSelectionController.new,);

final FutureProvider<DestructionReport> destructionReportProvider =
    FutureProvider<DestructionReport>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  final ReportSelection selection = ref.watch(reportSelectionProvider);
  final Result<DestructionReport> result =
      await ref.watch(analyticsRepositoryProvider).destructionReport(selection.period);
  return result.fold((Failure f) => throw f, (DestructionReport v) => v);
});

final FutureProvider<DestructionReport> previousPeriodReportProvider =
    FutureProvider<DestructionReport>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  final ReportSelection selection = ref.watch(reportSelectionProvider);
  final Result<DestructionReport> result = await ref
      .watch(analyticsRepositoryProvider)
      .destructionReport(selection.period.previous);
  return result.fold((Failure f) => throw f, (DestructionReport v) => v);
});

final FutureProvider<IntakeReport> intakeReportProvider =
    FutureProvider<IntakeReport>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  final ReportSelection selection = ref.watch(reportSelectionProvider);
  final Result<IntakeReport> result =
      await ref.watch(analyticsRepositoryProvider).intakeReport(selection.period);
  return result.fold((Failure f) => throw f, (IntakeReport v) => v);
});
