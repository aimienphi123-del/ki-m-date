import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/utils/csv.dart';
import 'package:expiry_guardian/features/dashboard/presentation/widgets/mini_bar_chart.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/presentation/viewmodels/reports_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Daily / weekly / monthly destruction reporting, straight from the rows the
/// store recorded.
class ReportsPage extends ConsumerWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ReportSelection selection = ref.watch(reportSelectionProvider);
    final ReportSelectionController controller = ref.read(reportSelectionProvider.notifier);
    final AsyncValue<DestructionReport> report = ref.watch(destructionReportProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.reportsTitle)),
        actions: <Widget>[
          IconButton(
            tooltip: l10n.t(K.reportsExportCsv),
            onPressed: report.valueOrNull == null
                ? null
                : () => _export(context, ref, report.value!),
            icon: const Icon(Icons.ios_share),
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              Dimens.gapS,
              Dimens.gutter,
              Dimens.gapS,
            ),
            child: Column(
              children: <Widget>[
                SegmentedButton<ReportGranularity>(
                  showSelectedIcon: false,
                  segments: <ButtonSegment<ReportGranularity>>[
                    ButtonSegment<ReportGranularity>(
                      value: ReportGranularity.daily,
                      label: Text(l10n.t(K.reportsDaily)),
                    ),
                    ButtonSegment<ReportGranularity>(
                      value: ReportGranularity.weekly,
                      label: Text(l10n.t(K.reportsWeekly)),
                    ),
                    ButtonSegment<ReportGranularity>(
                      value: ReportGranularity.monthly,
                      label: Text(l10n.t(K.reportsMonthly)),
                    ),
                  ],
                  selected: <ReportGranularity>{selection.granularity},
                  onSelectionChanged: (Set<ReportGranularity> value) =>
                      controller.setGranularity(value.first),
                ),
                const SizedBox(height: Dimens.gapS),
                Row(
                  children: <Widget>[
                    IconButton.filledTonal(
                      onPressed: controller.previous,
                      icon: const Icon(Icons.chevron_left),
                    ),
                    Expanded(
                      child: Text(
                        _periodLabel(l10n, selection.period),
                        textAlign: TextAlign.center,
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                    ),
                    IconButton.filledTonal(
                      onPressed: controller.next,
                      icon: const Icon(Icons.chevron_right),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: report.when(
              loading: () => const LoadingView(),
              error: (Object e, StackTrace s) => ErrorView(
                message: e.toString(),
                onRetry: () => ref.invalidate(destructionReportProvider),
              ),
              data: (DestructionReport value) => _ReportBody(report: value),
            ),
          ),
        ],
      ),
    );
  }

  String _periodLabel(AppLocalizations l10n, ReportPeriod period) {
    final DateTime last = period.to.subtract(const Duration(days: 1));
    if (period.granularity == ReportGranularity.daily) return l10n.date(period.from);
    return '${l10n.date(period.from)} - ${l10n.date(last)}';
  }

  Future<void> _export(BuildContext context, WidgetRef ref, DestructionReport report) async {
    final AppLocalizations l10n = context.l10n;
    final Directory directory = await getTemporaryDirectory();
    final String stamp = report.period.from.toIso8601String().split('T').first;
    final File file = await Csv.writeCsvFile(
      path: '${directory.path}/expiry_guardian_$stamp.csv',
      header: <String>[
        l10n.t(K.commonName),
        l10n.t(K.reportsDestroyedRecords),
        l10n.t(K.reportsDestroyedQuantity),
        l10n.t(K.reportsFinancialLoss),
      ],
      rows: <List<Object?>>[
        for (final WasteSlice slice in report.byCategory)
          <Object?>[slice.label, slice.records, slice.units, slice.loss],
        <Object?>[],
        for (final WasteSlice slice in report.byProduct)
          <Object?>[slice.label, slice.records, slice.units, slice.loss],
      ],
    );
    if (!context.mounted) return;
    await Share.shareXFiles(<XFile>[XFile(file.path)], text: l10n.t(K.reportsTitle));
  }
}

class _ReportBody extends ConsumerWidget {
  const _ReportBody({required this.report});

  final DestructionReport report;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final String currency = ref.watch(currencySymbolProvider);
    final AsyncValue<DestructionReport> previous = ref.watch(previousPeriodReportProvider);

    if (report.totalRecords == 0) {
      return EmptyState(
        icon: Icons.insert_chart_outlined,
        title: l10n.t(K.reportsEmpty),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        0,
        Dimens.gutter,
        Dimens.gapXl * 3,
      ),
      children: <Widget>[
        GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          mainAxisSpacing: Dimens.gapM,
          crossAxisSpacing: Dimens.gapM,
          childAspectRatio: 1.45,
          children: <Widget>[
            StatTile(
              icon: Icons.delete_forever_outlined,
              label: l10n.t(K.reportsDestroyedRecords),
              value: l10n.number(report.totalRecords),
              caption: _delta(l10n, report.totalRecords, previous.valueOrNull?.totalRecords),
            ),
            StatTile(
              icon: Icons.scale_outlined,
              label: l10n.t(K.reportsDestroyedQuantity),
              value: l10n.number(report.totalUnits, decimals: 0),
            ),
            StatTile(
              icon: Icons.payments_outlined,
              label: l10n.t(K.reportsFinancialLoss),
              value: l10n.money(report.totalLoss, symbol: currency),
              caption: report.lossIsPartial
                  ? l10n.t(K.reportsPartialLoss, <String, Object?>{
                      'priced': report.pricedRecords,
                      'total': report.totalRecords,
                    })
                  : null,
            ),
            StatTile(
              icon: Icons.verified_outlined,
              label: l10n.t(K.reportsOnTimeRate),
              value: l10n.percent(report.onTimeRate),
              caption: '${l10n.t(K.reportsOverdueRecords)}: ${report.overdueRecords}',
              accent: report.onTimeRate < 0.9
                  ? Theme.of(context).colorScheme.error
                  : Theme.of(context).colorScheme.primary,
            ),
          ],
        ),
        if (report.expiredOnDestroyRecords > 0) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.report_gmailerrorred_outlined,
            message: '${l10n.t(K.reportsExpiredQuantity)}: ${report.expiredOnDestroyRecords}',
          ),
        ],
        SectionHeader(title: l10n.t(K.reportsTrend)),
        AppCard(
          child: MiniBarChart(
            emptyLabel: l10n.t(K.reportsEmpty),
            data: report.trend
                .map((TrendPoint point) => BarDatum(
                      label: l10n.dayMonth(point.bucketStart),
                      value: point.records.toDouble(),
                      highlight: point.overdueRecords > 0,
                    ),)
                .toList(growable: false),
          ),
        ),
        _SliceSection(
          title: l10n.t(K.reportsMostWastedCategories),
          slices: report.byCategory,
          currency: currency,
        ),
        _SliceSection(
          title: l10n.t(K.reportsByShelf),
          slices: report.byShelf,
          currency: currency,
        ),
        _SliceSection(
          title: l10n.t(K.reportsByProduct),
          slices: report.byProduct,
          currency: currency,
        ),
        _SliceSection(
          title: l10n.t(K.reportsByReason),
          slices: report.byReason,
          currency: currency,
          translateReason: true,
        ),
      ],
    );
  }

  String? _delta(AppLocalizations l10n, int current, int? previous) {
    if (previous == null) return null;
    final int diff = current - previous;
    final String sign = diff > 0 ? '+' : '';
    return '${l10n.t(K.reportsPreviousPeriod)}: $previous ($sign$diff)';
  }
}

class _SliceSection extends StatelessWidget {
  const _SliceSection({
    required this.title,
    required this.slices,
    required this.currency,
    this.translateReason = false,
  });

  final String title;
  final List<WasteSlice> slices;
  final String currency;
  final bool translateReason;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    if (slices.isEmpty) return const SizedBox.shrink();

    final double maxLoss = slices
        .map((WasteSlice s) => s.loss)
        .fold<double>(0, (double a, double b) => a > b ? a : b);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        SectionHeader(title: title),
        AppCard(
          child: Column(
            children: slices.take(8).map((WasteSlice slice) {
              final String label = translateReason
                  ? l10n.t('destroy.reason.${slice.key}')
                  : (slice.label.isEmpty ? l10n.t(K.commonUnknown) : slice.label);
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(label, overflow: TextOverflow.ellipsis),
                        ),
                        Text(
                          '${slice.records} · ${l10n.money(slice.loss, symbol: currency)}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: maxLoss <= 0 ? 0 : (slice.loss / maxLoss).clamp(0.0, 1.0),
                        minHeight: 6,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(growable: false),
          ),
        ),
      ],
    );
  }
}
