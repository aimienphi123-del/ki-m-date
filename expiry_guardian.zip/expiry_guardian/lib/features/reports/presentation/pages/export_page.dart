import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/reports/domain/services/report_document_builder.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';

final FutureProvider<List<DocumentExport>> exportHistoryProvider =
    FutureProvider<List<DocumentExport>>((Ref ref) async {
  ref.watch(exportChangesProvider);
  final Result<List<DocumentExport>> result =
      await ref.watch(documentExportRepositoryProvider).history();
  return result.valueOrNull ?? const <DocumentExport>[];
});

/// Feature 5: the six report templates, written to a real file the employee
/// can share from the phone.
///
/// This build exports PDF, HTML and CSV with no account and no network. The
/// Google Docs destination is listed but reports itself unconfigured rather
/// than pretending to upload - connecting it later swaps one gateway and
/// changes nothing on this screen.
class ExportPage extends ConsumerStatefulWidget {
  const ExportPage({super.key});

  static Future<void> open(BuildContext context) => Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const ExportPage()),
      );

  @override
  ConsumerState<ExportPage> createState() => _ExportPageState();
}

class _ExportPageState extends ConsumerState<ExportPage> {
  ReportTemplate _template = ReportTemplate.dailyDestroy;
  ExportDestination? _destination;
  DateTimeRange? _range;
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    final DocumentExportRepository repository = ref.watch(documentExportRepositoryProvider);

    final ExportDestination destination = _destination ??
        ExportDestination.fromName(
          settings.readString(
            SettingKeys.exportDefaultDestination,
            SettingDefaults.exportDefaultDestination,
          ),
        );
    final bool available = repository.isDestinationConfigured(destination);
    final String? reason = repository.unavailableReasonKey(destination);
    final ReportPeriod period = _period();

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.exportTitle))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gapXl * 2,
        ),
        children: <Widget>[
          SectionHeader(title: l10n.t(K.exportTemplate)),
          AppCard(
            child: RadioGroup<ReportTemplate>(
              groupValue: _template,
              onChanged: (ReportTemplate? value) =>
                  setState(() => _template = value ?? _template),
              child: Column(
                children: <Widget>[
                  for (final ReportTemplate template in ReportTemplate.values)
                    RadioListTile<ReportTemplate>(
                      contentPadding: EdgeInsets.zero,
                      value: template,
                      title: Text(l10n.t(template.labelKey)),
                    ),
                ],
              ),
            ),
          ),
          SectionHeader(title: l10n.t(K.exportPeriod)),
          AppCard(
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.date_range_outlined),
              title: Text(_periodLabel(l10n, period)),
              trailing: const Icon(Icons.edit_calendar_outlined),
              onTap: _pickRange,
            ),
          ),
          SectionHeader(title: l10n.t(K.exportDestination)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Wrap(
                  spacing: Dimens.gapS,
                  runSpacing: Dimens.gapS,
                  children: <Widget>[
                    for (final ExportDestination option in ExportDestination.values)
                      ChoiceChip(
                        label: Text(l10n.t(option.labelKey)),
                        selected: option == destination,
                        avatar: repository.isDestinationConfigured(option)
                            ? null
                            : const Icon(Icons.lock_outline, size: 16),
                        onSelected: (_) => setState(() => _destination = option),
                      ),
                  ],
                ),
                if (!available && reason != null) ...<Widget>[
                  const SizedBox(height: Dimens.gapM),
                  NoticeBanner(
                    tone: NoticeTone.warning,
                    icon: Icons.info_outline,
                    message: l10n.t(reason),
                  ),
                ],
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsExport)),
          AppCard(
            child: Column(
              children: <Widget>[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.exportIncludeStatistics)),
                  value: settings.readBool(
                    SettingKeys.exportIncludeStatistics,
                    SettingDefaults.exportIncludeStatistics,
                  ),
                  onChanged: (bool value) =>
                      writeSettingFrom(ref, SettingKeys.exportIncludeStatistics, value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.exportIncludePhotos)),
                  value: settings.readBool(
                    SettingKeys.exportIncludePhotos,
                    SettingDefaults.exportIncludePhotos,
                  ),
                  onChanged: (bool value) =>
                      writeSettingFrom(ref, SettingKeys.exportIncludePhotos, value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.exportIncludeSignatures)),
                  value: settings.readBool(
                    SettingKeys.exportIncludeSignatures,
                    SettingDefaults.exportIncludeSignatures,
                  ),
                  onChanged: (bool value) =>
                      writeSettingFrom(ref, SettingKeys.exportIncludeSignatures, value),
                ),
              ],
            ),
          ),
          const SizedBox(height: Dimens.gapL),
          FilledButton.icon(
            onPressed: _busy || !available ? null : () => _generate(destination, period),
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.description_outlined),
            label: Text(l10n.t(_busy ? K.exportGenerating : K.exportGenerate)),
          ),
          SectionHeader(title: l10n.t(K.exportHistory)),
          const _ExportHistory(),
        ],
      ),
    );
  }

  ReportPeriod _period() {
    final DateTimeRange? range = _range;
    if (range != null) {
      return ReportPeriod(
        from: DateTime(range.start.year, range.start.month, range.start.day),
        to: DateTime(range.end.year, range.end.month, range.end.day)
            .add(const Duration(days: 1)),
        granularity: _granularity(),
      );
    }
    final DateTime now = ref.read(clockProvider).now();
    return switch (_template) {
      ReportTemplate.weekly => ReportPeriod.week(now),
      ReportTemplate.monthly => ReportPeriod.month(now),
      _ => ReportPeriod.day(now),
    };
  }

  ReportGranularity _granularity() => switch (_template) {
        ReportTemplate.weekly => ReportGranularity.weekly,
        ReportTemplate.monthly => ReportGranularity.monthly,
        _ => ReportGranularity.daily,
      };

  String _periodLabel(AppLocalizations l10n, ReportPeriod period) {
    final DateTime last = period.to.subtract(const Duration(days: 1));
    if (period.dayCount <= 1) return l10n.date(period.from);
    return '${l10n.date(period.from)} – ${l10n.date(last)}';
  }

  Future<void> _pickRange() async {
    final DateTime now = ref.read(clockProvider).now();
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 3),
      lastDate: DateTime(now.year + 1),
      initialDateRange: _range,
    );
    if (picked != null) setState(() => _range = picked);
  }

  Future<void> _generate(ExportDestination destination, ReportPeriod period) async {
    final AppLocalizations l10n = context.l10n;
    setState(() => _busy = true);

    final SettingsStore settings = ref.read(settingsStoreProvider);
    final Result<DocumentExport> result =
        await ref.read(documentExportRepositoryProvider).generate(
              ExportRequest(
                template: _template,
                destination: destination,
                period: period,
                options: ReportOptions(
                  includeStatistics: settings.readBool(
                    SettingKeys.exportIncludeStatistics,
                    SettingDefaults.exportIncludeStatistics,
                  ),
                  includePhotos: settings.readBool(
                    SettingKeys.exportIncludePhotos,
                    SettingDefaults.exportIncludePhotos,
                  ),
                  includeSignatures: settings.readBool(
                    SettingKeys.exportIncludeSignatures,
                    SettingDefaults.exportIncludeSignatures,
                  ),
                ),
              ),
            );

    ref.invalidate(exportHistoryProvider);
    if (!mounted) return;
    setState(() => _busy = false);

    result.fold(
      (_) => showAppSnack(
        context,
        describeFailure(context, result.failureOrNull!),
        isError: true,
      ),
      (DocumentExport export) {
        showAppSnack(context, l10n.t(K.exportDone));
        _share(export);
      },
    );
  }

  Future<void> _share(DocumentExport export) async {
    final String? path = export.filePath;
    if (path == null || !File(path).existsSync()) return;
    await Share.shareXFiles(<XFile>[XFile(path)], text: export.title);
  }
}

class _ExportHistory extends ConsumerWidget {
  const _ExportHistory();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<DocumentExport>> history = ref.watch(exportHistoryProvider);

    return history.when(
      loading: () => const LoadingView(),
      error: (Object error, StackTrace stack) => ErrorView(message: error.toString()),
      data: (List<DocumentExport> exports) {
        if (exports.isEmpty) {
          return EmptyState(icon: Icons.folder_open_outlined, title: l10n.t(K.exportHistory));
        }
        return Column(
          children: <Widget>[
            for (final DocumentExport export in exports)
              Padding(
                padding: const EdgeInsets.only(bottom: Dimens.gapS),
                child: AppCard(
                  child: Row(
                    children: <Widget>[
                      Icon(_icon(export.destination)),
                      const SizedBox(width: Dimens.gapM),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              export.title,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            Text(
                              l10n.dateTime(export.createdAt),
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                            if (!export.isReady && (export.error ?? '').isNotEmpty)
                              Text(
                                l10n.t(K.exportFailed),
                                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Theme.of(context).colorScheme.error,
                                    ),
                              ),
                          ],
                        ),
                      ),
                      if (export.isReady && export.filePath != null)
                        IconButton(
                          tooltip: l10n.t(K.exportShare),
                          icon: const Icon(Icons.ios_share),
                          onPressed: () => Share.shareXFiles(
                            <XFile>[XFile(export.filePath!)],
                            text: export.title,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  static IconData _icon(ExportDestination destination) => switch (destination) {
        ExportDestination.localPdf => Icons.picture_as_pdf_outlined,
        ExportDestination.localHtml => Icons.html_outlined,
        ExportDestination.localCsv => Icons.table_chart_outlined,
        ExportDestination.googleDocs => Icons.cloud_outlined,
      };
}
