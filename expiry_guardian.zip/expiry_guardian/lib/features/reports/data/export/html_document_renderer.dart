import 'dart:convert';

import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';

/// Renders a [ReportDocument] as one self-contained HTML page.
///
/// Pure string building with no Flutter dependency, so the whole layout is
/// unit-tested. The page has a print stylesheet, which is how a phone turns it
/// into a PDF from the browser's share sheet if the store prefers that route.
class HtmlDocumentRenderer {
  const HtmlDocumentRenderer();

  String render(ReportDocument document) {
    final StringBuffer out = StringBuffer();
    out.writeln('<!DOCTYPE html>');
    out.writeln('<html lang="vi"><head>');
    out.writeln('<meta charset="utf-8">');
    out.writeln('<meta name="viewport" content="width=device-width, initial-scale=1">');
    out.writeln('<title>${_escape(document.header.title)}</title>');
    out.writeln('<style>${_css()}</style>');
    out.writeln('</head><body>');

    _writeHeader(out, document.header);
    for (final DocumentSection section in document.sections) {
      _writeSection(out, section);
    }
    if (document.signatures.isNotEmpty) _writeSignatures(out, document.signatures);
    if (document.footerNote.isNotEmpty) {
      out.writeln('<p class="footnote">${_escape(document.footerNote)}</p>');
    }

    out.writeln('</body></html>');
    return out.toString();
  }

  void _writeHeader(StringBuffer out, DocumentHeader header) {
    out.writeln('<header class="masthead">');
    if (header.company.isNotEmpty) {
      out.writeln('<div class="company">${_escape(header.company)}</div>');
    }
    out.writeln('<h1>${_escape(header.title)}</h1>');
    out.writeln('<dl class="meta">');
    void meta(String label, String value) {
      if (value.isEmpty) return;
      out.writeln('<dt>${_escape(label)}</dt><dd>${_escape(value)}</dd>');
    }

    meta('Cửa hàng / Store', <String>[
      header.store,
      if (header.storeCode.isNotEmpty) '(${header.storeCode})',
    ].where((String s) => s.isNotEmpty).join(' '),);
    meta('Kỳ / Period', header.periodLabel);
    meta('Lập lúc / Generated', _formatIso(header.generatedAt));
    meta('Người lập / By', header.generatedBy);
    meta('Thiết bị / Device', header.deviceLabel);
    out.writeln('</dl></header>');
  }

  void _writeSection(StringBuffer out, DocumentSection section) {
    switch (section) {
      case TextSection(:final String heading, :final List<String> paragraphs):
        out.writeln('<section><h2>${_escape(heading)}</h2>');
        for (final String paragraph in paragraphs) {
          out.writeln('<p>${_escape(paragraph)}</p>');
        }
        out.writeln('</section>');

      case StatSection(:final String heading, :final List<StatItem> items):
        out.writeln('<section><h2>${_escape(heading)}</h2><div class="stats">');
        for (final StatItem item in items) {
          out.writeln('<div class="stat">');
          out.writeln('<div class="label">${_escape(item.label)}</div>');
          out.writeln('<div class="value">${_escape(item.value)}</div>');
          if (item.caption != null && item.caption!.isNotEmpty) {
            out.writeln('<div class="caption">${_escape(item.caption!)}</div>');
          }
          out.writeln('</div>');
        }
        out.writeln('</div></section>');

      case TableSection():
        out.writeln('<section><h2>${_escape(section.heading)}</h2>');
        if (section.isEmpty) {
          out.writeln('<p class="empty">${_escape(section.emptyMessage ?? '')}</p>');
        } else {
          out.writeln('<table><thead><tr>');
          for (int i = 0; i < section.columns.length; i++) {
            final String align = section.numericColumns.contains(i) ? ' class="num"' : '';
            out.writeln('<th$align>${_escape(section.columns[i])}</th>');
          }
          out.writeln('</tr></thead><tbody>');
          for (final List<String> row in section.rows) {
            out.writeln('<tr>');
            for (int i = 0; i < row.length; i++) {
              final String align = section.numericColumns.contains(i) ? ' class="num"' : '';
              out.writeln('<td$align>${_escape(row[i])}</td>');
            }
            out.writeln('</tr>');
          }
          out.writeln('</tbody>');
          final List<String>? totals = section.totals;
          if (totals != null) {
            out.writeln('<tfoot><tr>');
            for (int i = 0; i < totals.length; i++) {
              final String align = section.numericColumns.contains(i) ? ' class="num"' : '';
              out.writeln('<td$align>${_escape(totals[i])}</td>');
            }
            out.writeln('</tr></tfoot>');
          }
          out.writeln('</table>');
        }
        out.writeln('</section>');

      case ImageSection(:final String heading, :final List<DocumentImage> images):
        out.writeln('<section class="photos"><h2>${_escape(heading)}</h2><div class="grid">');
        for (final DocumentImage image in images) {
          out.writeln('<figure>');
          out.writeln('<img src="${_escape(Uri.file(image.path).toString())}" alt="">');
          if (image.caption.isNotEmpty) {
            out.writeln('<figcaption>${_escape(image.caption)}</figcaption>');
          }
          out.writeln('</figure>');
        }
        out.writeln('</div></section>');
    }
  }

  void _writeSignatures(StringBuffer out, List<SignatureBlock> signatures) {
    out.writeln('<section class="signatures"><div class="row">');
    for (final SignatureBlock block in signatures) {
      out.writeln('<div class="sign">');
      out.writeln('<div class="role">${_escape(block.role)}</div>');
      out.writeln('<div class="line"></div>');
      out.writeln('<div class="name">${_escape(block.name)}</div>');
      out.writeln('</div>');
    }
    out.writeln('</div></section>');
  }

  static String _formatIso(DateTime value) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(value.day)}/${two(value.month)}/${value.year} '
        '${two(value.hour)}:${two(value.minute)}';
  }

  static String _escape(String value) => const HtmlEscape().convert(value);

  String _css() => '''
:root { color-scheme: light; }
* { box-sizing: border-box; }
body {
  margin: 0; padding: 24px;
  font-family: -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color: #16232a; background: #fff; line-height: 1.5;
}
.masthead { border-bottom: 2px solid #00695c; padding-bottom: 12px; margin-bottom: 20px; }
.company { font-size: 13px; letter-spacing: .08em; text-transform: uppercase; color: #00695c; }
h1 { font-size: 22px; margin: 4px 0 12px; }
h2 { font-size: 15px; margin: 24px 0 8px; color: #00695c; }
dl.meta { display: grid; grid-template-columns: max-content 1fr; gap: 2px 12px; margin: 0; font-size: 13px; }
dl.meta dt { color: #5b6b73; }
dl.meta dd { margin: 0; }
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
.stat { border: 1px solid #d8e2e2; border-radius: 10px; padding: 10px 12px; }
.stat .label { font-size: 12px; color: #5b6b73; }
.stat .value { font-size: 20px; font-weight: 700; color: #00584c; }
.stat .caption { font-size: 11px; color: #5b6b73; margin-top: 2px; }
table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
th, td { border: 1px solid #d8e2e2; padding: 6px 8px; text-align: left; vertical-align: top; }
th { background: #eef5f4; font-weight: 700; }
td.num, th.num { text-align: right; white-space: nowrap; }
tfoot td { font-weight: 700; background: #f6faf9; }
.empty { color: #5b6b73; font-style: italic; }
.photos .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px; }
.photos img { width: 100%; border-radius: 8px; border: 1px solid #d8e2e2; }
.photos figcaption { font-size: 11px; color: #5b6b73; }
.signatures .row { display: flex; gap: 32px; margin-top: 36px; }
.signatures .sign { flex: 1; text-align: center; }
.signatures .role { font-size: 12px; color: #5b6b73; }
.signatures .line { border-bottom: 1px solid #16232a; height: 56px; margin: 4px 8px; }
.signatures .name { font-size: 12px; min-height: 16px; }
.footnote { margin-top: 20px; font-size: 11.5px; color: #5b6b73; }
@media print {
  body { padding: 0; }
  section { break-inside: avoid; }
  table { break-inside: auto; }
  tr { break-inside: avoid; }
}
''';
}
