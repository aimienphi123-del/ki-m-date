import 'dart:io';
import 'dart:typed_data';

import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/reports/data/export/csv_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/html_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/pdf_document_renderer.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_gateway.dart';

/// Where generated reports are written, injected so tests use a temp folder.
typedef ExportDirectoryResolver = Future<Directory> Function();

/// Writes reports as files on the handset.
///
/// This is the destination the store actually uses today: the file lands in the
/// app's documents folder and is then shared through the system sheet - Zalo,
/// Drive, email, or a USB cable. Nothing here needs a network, an account or a
/// server, which is the point.
///
/// [documentId] for this gateway is the file path, so [update] rewrites the same
/// file and [shareLink] returns a `file://` URI.
class LocalFileExportGateway implements DocumentExportGateway {
  LocalFileExportGateway({
    required this.destination,
    required ExportDirectoryResolver directory,
    required Clock clock,
    PdfDocumentRenderer? pdfRenderer,
    HtmlDocumentRenderer html = const HtmlDocumentRenderer(),
    CsvDocumentRenderer csv = const CsvDocumentRenderer(),
    Future<Uint8List?> Function(String path)? imageLoader,
  })  : assert(
          destination != ExportDestination.googleDocs,
          'LocalFileExportGateway writes files; Google Docs needs its own gateway.',
        ),
        assert(
          destination != ExportDestination.localPdf || pdfRenderer != null,
          'A PDF gateway needs a renderer with real font bytes.',
        ),
        _directory = directory,
        _clock = clock,
        _pdf = pdfRenderer,
        _html = html,
        _csv = csv,
        _imageLoader = imageLoader;

  @override
  final ExportDestination destination;

  final ExportDirectoryResolver _directory;
  final Clock _clock;
  final PdfDocumentRenderer? _pdf;
  final HtmlDocumentRenderer _html;
  final CsvDocumentRenderer _csv;
  final Future<Uint8List?> Function(String path)? _imageLoader;

  @override
  bool get isConfigured => true;

  @override
  String? get unavailableReasonKey => null;

  @override
  Future<ExportOutcome> create(ReportDocument document) async {
    final Directory dir = await _directory();
    await dir.create(recursive: true);
    final String path = _uniquePath(dir, document);
    return _write(path, document);
  }

  @override
  Future<ExportOutcome> update(String documentId, ReportDocument document) =>
      _write(documentId, document);

  @override
  Future<String?> shareLink(String documentId) async {
    final File file = File(documentId);
    if (!file.existsSync()) return null;
    return Uri.file(file.absolute.path).toString();
  }

  @override
  Future<String?> exportPdf(String documentId, ReportDocument document) async {
    final PdfDocumentRenderer? renderer = _pdf;
    if (renderer == null) {
      // An HTML or CSV gateway has no font bytes, so it cannot make a PDF.
      // The caller should pick the PDF destination instead of being handed a
      // file with the wrong contents under a .pdf name.
      throw const ExportUnavailableException('export.pdfNotAvailableHere');
    }
    final String path = documentId.toLowerCase().endsWith('.pdf')
        ? documentId
        : '${_withoutExtension(documentId)}.pdf';
    await renderer.renderToFile(document, path, imageLoader: _imageLoader);
    return path;
  }

  Future<ExportOutcome> _write(String path, ReportDocument document) async {
    final File file = File(path);
    await file.parent.create(recursive: true);
    switch (destination) {
      case ExportDestination.localPdf:
        await _pdf!.renderToFile(document, path, imageLoader: _imageLoader);
      case ExportDestination.localHtml:
        await file.writeAsString(_html.render(document), flush: true);
      case ExportDestination.localCsv:
        // The BOM keeps Vietnamese readable when Excel opens the file.
        await file.writeAsString('﻿${_csv.render(document)}', flush: true);
      case ExportDestination.googleDocs:
        throw const ExportUnavailableException('export.googleNotConfigured');
    }
    return ExportOutcome(
      destination: destination,
      filePath: path,
      documentId: path,
      url: Uri.file(file.absolute.path).toString(),
    );
  }

  String _uniquePath(Directory dir, ReportDocument document) {
    final DateTime now = _clock.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final String stamp = '${now.year}${two(now.month)}${two(now.day)}'
        '-${two(now.hour)}${two(now.minute)}${two(now.second)}';
    final String base = '${_slug(document.template.name)}-$stamp';
    String candidate = '${dir.path}/$base.${destination.fileExtension}';
    int suffix = 2;
    while (File(candidate).existsSync()) {
      candidate = '${dir.path}/$base-$suffix.${destination.fileExtension}';
      suffix++;
    }
    return candidate;
  }

  static String _withoutExtension(String path) {
    final int dot = path.lastIndexOf('.');
    final int slash = path.lastIndexOf('/');
    if (dot <= slash) return path;
    return path.substring(0, dot);
  }

  static String _slug(String value) {
    final String lower = value.toLowerCase();
    final StringBuffer out = StringBuffer();
    for (final int unit in lower.codeUnits) {
      final bool isDigit = unit >= 0x30 && unit <= 0x39;
      final bool isLetter = unit >= 0x61 && unit <= 0x7A;
      out.writeCharCode(isDigit || isLetter ? unit : 0x2D);
    }
    return out.toString().replaceAll(RegExp('-+'), '-').replaceAll(RegExp(r'^-|-$'), '');
  }
}
