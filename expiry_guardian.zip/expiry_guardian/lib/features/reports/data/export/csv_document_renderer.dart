import 'package:expiry_guardian/core/utils/csv.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';

/// Renders a [ReportDocument] as one CSV file.
///
/// A CSV is a flat grid, so the document's structure is flattened in reading
/// order: the masthead first as label/value pairs, then each section with its
/// heading, then its rows. Excel and Google Sheets both open the result; the
/// byte-order mark is added by [Csv.writeCsvFile] when the bytes hit disk.
class CsvDocumentRenderer {
  const CsvDocumentRenderer();

  String render(ReportDocument document) {
    final List<List<String>> grid = <List<String>>[];

    void blank() => grid.add(const <String>[]);
    void pair(String label, String value) {
      if (value.isEmpty) return;
      grid.add(<String>[label, value]);
    }

    final DocumentHeader header = document.header;
    if (header.company.isNotEmpty) grid.add(<String>[header.company]);
    grid.add(<String>[header.title]);
    pair('Cua hang / Store', <String>[
      header.store,
      if (header.storeCode.isNotEmpty) '(${header.storeCode})',
    ].where((String s) => s.isNotEmpty).join(' '),);
    pair('Ky / Period', header.periodLabel);
    pair('Lap luc / Generated', _formatStamp(header.generatedAt));
    pair('Nguoi lap / By', header.generatedBy);
    pair('Thiet bi / Device', header.deviceLabel);

    for (final DocumentSection section in document.sections) {
      blank();
      switch (section) {
        case TextSection(:final String heading, :final List<String> paragraphs):
          grid.add(<String>[heading]);
          for (final String paragraph in paragraphs) {
            grid.add(<String>[paragraph]);
          }

        case StatSection(:final String heading, :final List<StatItem> items):
          grid.add(<String>[heading]);
          for (final StatItem item in items) {
            grid.add(<String>[
              item.label,
              item.value,
              if (item.caption != null && item.caption!.isNotEmpty) item.caption!,
            ]);
          }

        case TableSection():
          grid.add(<String>[section.heading]);
          if (section.isEmpty) {
            grid.add(<String>[section.emptyMessage ?? '']);
          } else {
            grid.add(section.columns);
            grid.addAll(section.rows);
            final List<String>? totals = section.totals;
            if (totals != null) grid.add(totals);
          }

        case ImageSection(:final String heading, :final List<DocumentImage> images):
          // A spreadsheet cannot hold the photo, so it holds the path to it.
          grid.add(<String>[heading]);
          grid.add(const <String>['File', 'Ghi chu / Caption']);
          for (final DocumentImage image in images) {
            grid.add(<String>[image.path, image.caption]);
          }
      }
    }

    if (document.signatures.isNotEmpty) {
      blank();
      grid.add(<String>['Ky xac nhan / Signatures']);
      for (final SignatureBlock block in document.signatures) {
        grid.add(<String>[block.role, block.name]);
      }
    }

    if (document.footerNote.isNotEmpty) {
      blank();
      grid.add(<String>[document.footerNote]);
    }

    final StringBuffer out = StringBuffer();
    for (final List<String> row in grid) {
      out.writeln(row.map(Csv.escapeField).join(','));
    }
    return out.toString();
  }

  static String _formatStamp(DateTime value) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(value.day)}/${two(value.month)}/${value.year} '
        '${two(value.hour)}:${two(value.minute)}';
  }
}
