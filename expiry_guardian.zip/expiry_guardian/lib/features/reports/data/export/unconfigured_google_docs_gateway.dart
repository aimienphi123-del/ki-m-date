import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_gateway.dart';

/// A destination that cannot run right now, and says so honestly.
///
/// Every call throws [ExportUnavailableException] carrying a localization key
/// instead of pretending to work: no silent no-ops, no fabricated document ids,
/// no "success" toast for a document that was never created. The export screen
/// reads [isConfigured] and greys the option out before anyone can pick it.
class UnavailableExportGateway implements DocumentExportGateway {
  const UnavailableExportGateway({
    required this.destination,
    required this.reasonKey,
  });

  @override
  final ExportDestination destination;

  final String reasonKey;

  @override
  bool get isConfigured => false;

  @override
  String? get unavailableReasonKey => reasonKey;

  @override
  Future<ExportOutcome> create(ReportDocument document) async =>
      throw ExportUnavailableException(reasonKey);

  @override
  Future<ExportOutcome> update(String documentId, ReportDocument document) async =>
      throw ExportUnavailableException(reasonKey);

  @override
  Future<String?> shareLink(String documentId) async => throw ExportUnavailableException(reasonKey);

  @override
  Future<String?> exportPdf(String documentId, ReportDocument document) async =>
      throw ExportUnavailableException(reasonKey);
}

/// The Google Docs destination before anybody has connected an account.
///
/// When a store connects Google Docs, this class is swapped for a real
/// implementation of the same interface and every caller - the export screen,
/// the repository, the tests - stays exactly as it is. The contract such an
/// implementation must honour is written out in `docs/EXPORT.md`.
class UnconfiguredGoogleDocsGateway extends UnavailableExportGateway {
  const UnconfiguredGoogleDocsGateway({super.reasonKey = 'export.googleNotConfigured'})
      : super(destination: ExportDestination.googleDocs);
}
