import 'dart:io';
import 'dart:typed_data';

import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

/// The two font faces a report needs, as raw TTF bytes.
///
/// Passed in rather than loaded here so the renderer has no Flutter
/// dependency and can be unit-tested from the Dart VM. In the app the bytes
/// come from `rootBundle`; in tests they come from `assets/fonts` on disk.
class ReportFonts {
  ReportFonts({required Uint8List regular, required Uint8List bold})
      : regular = pw.Font.ttf(regular.buffer.asByteData()),
        bold = pw.Font.ttf(bold.buffer.asByteData());

  final pw.Font regular;
  final pw.Font bold;
}

/// Renders a [ReportDocument] as a real, paginated PDF.
///
/// Uses the bundled Roboto faces rather than the pdf package's built-in Helvetica,
/// because Helvetica has no Vietnamese diacritics and would silently drop them -
/// "Sữa tươi" would print as "Sa ti". Tables flow across pages with the header row
/// repeated, and every page carries a footer with the page number.
class PdfDocumentRenderer {
  const PdfDocumentRenderer(this.fonts);

  final ReportFonts fonts;

  static const PdfColor _accent = PdfColor.fromInt(0xFF00695C);
  static const PdfColor _accentDark = PdfColor.fromInt(0xFF00584C);
  static const PdfColor _ink = PdfColor.fromInt(0xFF16232A);
  static const PdfColor _muted = PdfColor.fromInt(0xFF5B6B73);
  static const PdfColor _line = PdfColor.fromInt(0xFFD8E2E2);
  static const PdfColor _tint = PdfColor.fromInt(0xFFEEF5F4);

  /// Builds the document bytes. [imageLoader] is used only when the document
  /// carries an [ImageSection]; a photo that cannot be read is skipped rather
  /// than failing the whole export.
  Future<Uint8List> render(
    ReportDocument document, {
    Future<Uint8List?> Function(String path)? imageLoader,
  }) async {
    final pw.Document pdf = pw.Document(
      title: document.header.title,
      author: document.header.company.isEmpty ? null : document.header.company,
      creator: 'Expiry Guardian',
    );

    final pw.ThemeData theme = pw.ThemeData.withFont(
      base: fonts.regular,
      bold: fonts.bold,
    ).copyWith(
      defaultTextStyle: pw.TextStyle(font: fonts.regular, fontSize: 9.5, color: _ink),
    );

    final Map<String, pw.MemoryImage> images = await _loadImages(document, imageLoader);

    pdf.addPage(
      pw.MultiPage(
        theme: theme,
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(32, 30, 32, 36),
        header: (pw.Context context) =>
            context.pageNumber == 1 ? _masthead(document.header) : _runningHead(document.header),
        footer: _footer,
        build: (pw.Context context) => <pw.Widget>[
          for (final DocumentSection section in document.sections) ..._section(section, images),
          if (document.signatures.isNotEmpty) _signatures(document.signatures),
          if (document.footerNote.isNotEmpty)
            pw.Padding(
              padding: const pw.EdgeInsets.only(top: 16),
              child: pw.Text(
                document.footerNote,
                style: pw.TextStyle(fontSize: 7.5, color: _muted, font: fonts.regular),
              ),
            ),
        ],
      ),
    );

    return pdf.save();
  }

  /// Renders and writes the file in one step.
  Future<File> renderToFile(
    ReportDocument document,
    String path, {
    Future<Uint8List?> Function(String path)? imageLoader,
  }) async {
    final Uint8List bytes = await render(document, imageLoader: imageLoader);
    final File file = File(path);
    await file.parent.create(recursive: true);
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  Future<Map<String, pw.MemoryImage>> _loadImages(
    ReportDocument document,
    Future<Uint8List?> Function(String path)? loader,
  ) async {
    final Map<String, pw.MemoryImage> result = <String, pw.MemoryImage>{};
    final Iterable<ImageSection> sections = document.sections.whereType<ImageSection>();
    if (sections.isEmpty) return result;
    final Future<Uint8List?> Function(String path) read = loader ?? _readFile;
    for (final ImageSection section in sections) {
      for (final DocumentImage image in section.images) {
        if (result.containsKey(image.path)) continue;
        try {
          final Uint8List? bytes = await read(image.path);
          if (bytes != null && bytes.isNotEmpty) {
            result[image.path] = pw.MemoryImage(bytes);
          }
        } on Object {
          // A missing or corrupt photo must not cost the store its report.
        }
      }
    }
    return result;
  }

  static Future<Uint8List?> _readFile(String path) async {
    final File file = File(path);
    if (!file.existsSync()) return null;
    return file.readAsBytes();
  }

  pw.Widget _masthead(DocumentHeader header) {
    final List<List<String>> meta = <List<String>>[
      if (header.store.isNotEmpty || header.storeCode.isNotEmpty)
        <String>[
          'Cửa hàng / Store',
          <String>[
            header.store,
            if (header.storeCode.isNotEmpty) '(${header.storeCode})',
          ].where((String s) => s.isNotEmpty).join(' '),
        ],
      if (header.periodLabel.isNotEmpty) <String>['Kỳ / Period', header.periodLabel],
      <String>['Lập lúc / Generated', _formatStamp(header.generatedAt)],
      if (header.generatedBy.isNotEmpty) <String>['Người lập / By', header.generatedBy],
      if (header.deviceLabel.isNotEmpty) <String>['Thiết bị / Device', header.deviceLabel],
    ];

    return pw.Container(
      margin: const pw.EdgeInsets.only(bottom: 14),
      padding: const pw.EdgeInsets.only(bottom: 8),
      decoration: const pw.BoxDecoration(
        border: pw.Border(bottom: pw.BorderSide(color: _accent, width: 1.6)),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: <pw.Widget>[
          if (header.company.isNotEmpty)
            pw.Text(
              header.company.toUpperCase(),
              style: pw.TextStyle(font: fonts.bold, fontSize: 8, color: _accent, letterSpacing: 1),
            ),
          pw.SizedBox(height: 2),
          pw.Text(header.title, style: pw.TextStyle(font: fonts.bold, fontSize: 15, color: _ink)),
          pw.SizedBox(height: 6),
          pw.Wrap(
            spacing: 18,
            runSpacing: 2,
            children: <pw.Widget>[
              for (final List<String> row in meta)
                pw.RichText(
                  text: pw.TextSpan(children: <pw.InlineSpan>[
                    pw.TextSpan(
                      text: '${row[0]}: ',
                      style: pw.TextStyle(font: fonts.regular, fontSize: 8, color: _muted),
                    ),
                    pw.TextSpan(
                      text: row[1],
                      style: pw.TextStyle(font: fonts.bold, fontSize: 8, color: _ink),
                    ),
                  ],),
                ),
            ],
          ),
        ],
      ),
    );
  }

  pw.Widget _runningHead(DocumentHeader header) => pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 10),
        padding: const pw.EdgeInsets.only(bottom: 4),
        decoration: const pw.BoxDecoration(
          border: pw.Border(bottom: pw.BorderSide(color: _line, width: 0.6)),
        ),
        child: pw.Text(
          <String>[header.title, header.store, header.periodLabel]
              .where((String s) => s.isNotEmpty)
              .join('  •  '),
          style: pw.TextStyle(font: fonts.regular, fontSize: 7.5, color: _muted),
        ),
      );

  pw.Widget _footer(pw.Context context) => pw.Container(
        alignment: pw.Alignment.centerRight,
        margin: const pw.EdgeInsets.only(top: 8),
        child: pw.Text(
          'Trang ${context.pageNumber}/${context.pagesCount}',
          style: pw.TextStyle(font: fonts.regular, fontSize: 7.5, color: _muted),
        ),
      );

  List<pw.Widget> _section(DocumentSection section, Map<String, pw.MemoryImage> images) {
    switch (section) {
      case TextSection(:final String heading, :final List<String> paragraphs):
        return <pw.Widget>[
          _heading(heading),
          for (final String paragraph in paragraphs)
            pw.Padding(
              padding: const pw.EdgeInsets.only(bottom: 3),
              child: pw.Text(paragraph, style: pw.TextStyle(font: fonts.regular, fontSize: 9)),
            ),
          pw.SizedBox(height: 6),
        ];

      case StatSection(:final String heading, :final List<StatItem> items):
        return <pw.Widget>[
          _heading(heading),
          pw.Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <pw.Widget>[for (final StatItem item in items) _statCard(item)],
          ),
          pw.SizedBox(height: 10),
        ];

      case TableSection():
        return <pw.Widget>[
          _heading(section.heading),
          if (section.isEmpty)
            pw.Text(
              section.emptyMessage ?? '',
              style: pw.TextStyle(font: fonts.regular, fontSize: 9, color: _muted),
            )
          else
            _table(section),
          pw.SizedBox(height: 10),
        ];

      case ImageSection(:final String heading, images: final List<DocumentImage> photos):
        final List<DocumentImage> available =
            photos.where((DocumentImage i) => images.containsKey(i.path)).toList();
        if (available.isEmpty) return const <pw.Widget>[];
        return <pw.Widget>[
          _heading(heading),
          pw.Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <pw.Widget>[
              for (final DocumentImage image in available)
                pw.Container(
                  width: 150,
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: <pw.Widget>[
                      pw.ClipRRect(
                        horizontalRadius: 4,
                        verticalRadius: 4,
                        child: pw.Image(images[image.path]!, height: 110, fit: pw.BoxFit.cover),
                      ),
                      if (image.caption.isNotEmpty)
                        pw.Padding(
                          padding: const pw.EdgeInsets.only(top: 2),
                          child: pw.Text(
                            image.caption,
                            style: pw.TextStyle(font: fonts.regular, fontSize: 7, color: _muted),
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          ),
          pw.SizedBox(height: 10),
        ];
    }
  }

  pw.Widget _heading(String text) => pw.Padding(
        padding: const pw.EdgeInsets.only(top: 4, bottom: 5),
        child: pw.Text(text, style: pw.TextStyle(font: fonts.bold, fontSize: 11, color: _accent)),
      );

  pw.Widget _statCard(StatItem item) => pw.Container(
        width: 120,
        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: _line, width: 0.6),
          borderRadius: pw.BorderRadius.circular(5),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: <pw.Widget>[
            pw.Text(item.label, style: pw.TextStyle(font: fonts.regular, fontSize: 7.5, color: _muted)),
            pw.SizedBox(height: 1),
            pw.Text(item.value,
                style: pw.TextStyle(font: fonts.bold, fontSize: 13, color: _accentDark),),
            if (item.caption != null && item.caption!.isNotEmpty)
              pw.Text(item.caption!,
                  style: pw.TextStyle(font: fonts.regular, fontSize: 6.5, color: _muted),),
          ],
        ),
      );

  pw.Widget _table(TableSection section) {
    pw.Widget cell(String text, {required bool numeric, required bool header, bool total = false}) =>
        pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
          child: pw.Text(
            text,
            textAlign: numeric ? pw.TextAlign.right : pw.TextAlign.left,
            style: pw.TextStyle(
              font: header || total ? fonts.bold : fonts.regular,
              fontSize: 8,
              color: _ink,
            ),
          ),
        );

    final int columnCount = section.columns.length;
    return pw.Table(
      border: pw.TableBorder.all(color: _line, width: 0.5),
      defaultVerticalAlignment: pw.TableCellVerticalAlignment.top,
      columnWidths: <int, pw.TableColumnWidth>{
        for (int i = 0; i < columnCount; i++)
          i: section.numericColumns.contains(i)
              ? const pw.IntrinsicColumnWidth(flex: 1)
              : const pw.FlexColumnWidth(2.4),
      },
      children: <pw.TableRow>[
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: _tint),
          repeat: true,
          children: <pw.Widget>[
            for (int i = 0; i < columnCount; i++)
              cell(section.columns[i],
                  numeric: section.numericColumns.contains(i), header: true,),
          ],
        ),
        for (final List<String> row in section.rows)
          pw.TableRow(
            children: <pw.Widget>[
              for (int i = 0; i < columnCount; i++)
                cell(i < row.length ? row[i] : '',
                    numeric: section.numericColumns.contains(i), header: false,),
            ],
          ),
        if (section.totals != null)
          pw.TableRow(
            decoration: const pw.BoxDecoration(color: _tint),
            children: <pw.Widget>[
              for (int i = 0; i < columnCount; i++)
                cell(i < section.totals!.length ? section.totals![i] : '',
                    numeric: section.numericColumns.contains(i), header: false, total: true,),
            ],
          ),
      ],
    );
  }

  pw.Widget _signatures(List<SignatureBlock> blocks) => pw.Padding(
        padding: const pw.EdgeInsets.only(top: 26),
        child: pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: <pw.Widget>[
            for (final SignatureBlock block in blocks)
              pw.Expanded(
                child: pw.Column(
                  children: <pw.Widget>[
                    pw.Text(block.role,
                        style: pw.TextStyle(font: fonts.regular, fontSize: 8, color: _muted),),
                    pw.SizedBox(height: 42),
                    pw.Container(
                      margin: const pw.EdgeInsets.symmetric(horizontal: 10),
                      decoration: const pw.BoxDecoration(
                        border: pw.Border(top: pw.BorderSide(color: _ink, width: 0.6)),
                      ),
                      padding: const pw.EdgeInsets.only(top: 3),
                      child: pw.Text(block.name,
                          textAlign: pw.TextAlign.center,
                          style: pw.TextStyle(font: fonts.regular, fontSize: 8),),
                    ),
                  ],
                ),
              ),
          ],
        ),
      );

  static String _formatStamp(DateTime value) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(value.day)}/${two(value.month)}/${value.year} '
        '${two(value.hour)}:${two(value.minute)}';
  }
}
