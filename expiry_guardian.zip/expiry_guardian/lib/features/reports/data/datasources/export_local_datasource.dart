import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/features/inventory/data/models/inventory_mapper.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/services/report_document_builder.dart';
import 'package:sqflite/sqflite.dart';

/// Reads the rows the six report templates need, and keeps the history of
/// what was exported.
abstract interface class ExportLocalDataSource {
  /// Destructions in the window, joined with the product, place and person, so
  /// a report line reads like a shop-floor line rather than a row of ids.
  Future<List<DestructionLine>> destructionLines(DateTime from, DateTime to);

  Future<void> insertExport(DocumentExport export);

  Future<void> updateExport(DocumentExport export);

  Future<List<DocumentExport>> listExports({int limit});

  Future<DocumentExport?> findExport(String id);
}

class SqfliteExportDataSource implements ExportLocalDataSource {
  const SqfliteExportDataSource(this._database);

  final AppDatabase _database;

  @override
  Future<List<DestructionLine>> destructionLines(DateTime from, DateTime to) async {
    final List<Map<String, Object?>> rows = await _database.db.rawQuery(
      '''
      SELECT d.*,
             p.name AS product_name, p.unit AS product_unit,
             r.code AS record_code, r.batch_code AS batch_code, r.unit AS record_unit,
             a.name AS area_name, s.name AS shelf_name,
             u.display_name AS actor_name
      FROM ${Tables.destructions} d
      LEFT JOIN ${Tables.products} p ON p.id = d.product_id
      LEFT JOIN ${Tables.inventoryRecords} r ON r.id = d.record_id
      LEFT JOIN ${Tables.areas} a ON a.id = d.area_id
      LEFT JOIN ${Tables.shelves} s ON s.id = d.shelf_id
      LEFT JOIN ${Tables.users} u ON u.id = d.actor_id
      WHERE d.destroyed_at >= ? AND d.destroyed_at < ?
      ORDER BY d.destroyed_at DESC
      ''',
      <Object?>[from.millisecondsSinceEpoch, to.millisecondsSinceEpoch],
    );

    return rows.map((Map<String, Object?> row) {
      final Destruction destruction = InventoryMapper.destructionFromRow(row);
      final String area = (row['area_name'] as String?) ?? '';
      final String shelf = (row['shelf_name'] as String?) ?? '';
      return DestructionLine(
        destruction: destruction,
        productName: (row['product_name'] as String?) ?? '',
        locationLabel: <String>[area, shelf].where((String s) => s.isNotEmpty).join(' / '),
        recordCode: (row['record_code'] as String?) ?? '',
        batchCode: row['batch_code'] as String?,
        unit: (row['record_unit'] as String?) ?? (row['product_unit'] as String?) ?? '',
        employeeName: row['actor_name'] as String?,
      );
    }).toList(growable: false);
  }

  @override
  Future<void> insertExport(DocumentExport export) async {
    await _database.write(<String>{Tables.documentExports}, (Transaction txn) async {
      await txn.insert(
        Tables.documentExports,
        _toRow(export),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  @override
  Future<void> updateExport(DocumentExport export) async {
    await _database.write(<String>{Tables.documentExports}, (Transaction txn) async {
      await txn.update(
        Tables.documentExports,
        _toRow(export),
        where: 'id = ?',
        whereArgs: <Object?>[export.id],
      );
    });
  }

  @override
  Future<List<DocumentExport>> listExports({int limit = 50}) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.documentExports,
      orderBy: 'created_at DESC',
      limit: limit,
    );
    return rows.map(_fromRow).toList(growable: false);
  }

  @override
  Future<DocumentExport?> findExport(String id) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.documentExports,
      where: 'id = ?',
      whereArgs: <Object?>[id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return _fromRow(rows.first);
  }

  static Map<String, Object?> _toRow(DocumentExport export) => <String, Object?>{
        'id': export.id,
        'template': export.template.name,
        'destination': export.destination.name,
        'title': export.title,
        'document_id': export.documentId,
        'url': export.url,
        'file_path': export.filePath,
        'period_from': export.periodFrom?.millisecondsSinceEpoch,
        'period_to': export.periodTo?.millisecondsSinceEpoch,
        'created_by': export.createdBy,
        'device_id': export.deviceId,
        'status': export.status,
        'error': export.error,
        'created_at': export.createdAt.millisecondsSinceEpoch,
        'updated_at': export.updatedAt.millisecondsSinceEpoch,
      };

  static DocumentExport _fromRow(Map<String, Object?> row) => DocumentExport(
        id: row['id']! as String,
        template: ReportTemplate.fromName(row['template'] as String?),
        destination: ExportDestination.fromName(row['destination'] as String?),
        title: (row['title'] as String?) ?? '',
        status: (row['status'] as String?) ?? 'ready',
        documentId: row['document_id'] as String?,
        url: row['url'] as String?,
        filePath: row['file_path'] as String?,
        periodFrom: _date(row['period_from']),
        periodTo: _date(row['period_to']),
        createdBy: row['created_by'] as String?,
        deviceId: row['device_id'] as String?,
        error: row['error'] as String?,
        createdAt: _date(row['created_at'])!,
        updatedAt: _date(row['updated_at'])!,
      );

  static DateTime? _date(Object? value) =>
      value == null ? null : DateTime.fromMillisecondsSinceEpoch(value as int);
}
