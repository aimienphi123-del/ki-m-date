import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';

/// All figures come from `SUM`/`COUNT` over the rows the store actually
/// created. Nothing is estimated, interpolated or back-filled.
class AnalyticsRepositoryImpl implements AnalyticsRepository {
  const AnalyticsRepositoryImpl({required AppDatabase database, required AppLogger logger})
      : _database = database,
        _logger = logger;

  final AppDatabase _database;
  final AppLogger _logger;

  static const String _tag = 'AnalyticsRepository';
  static const String _unassigned = '__unassigned__';

  @override
  Future<Result<DestructionReport>> destructionReport(ReportPeriod period) async {
    return _guard(() async {
      final int from = period.from.millisecondsSinceEpoch;
      final int to = period.to.millisecondsSinceEpoch;
      final List<Object?> range = <Object?>[from, to];

      final List<Map<String, Object?>> totals = await _database.db.rawQuery(
        '''
        SELECT
          COUNT(*) AS records,
          COALESCE(SUM(d.quantity), 0) AS units,
          COALESCE(SUM(d.loss_amount), 0) AS loss,
          COALESCE(SUM(CASE WHEN d.was_overdue = 1 THEN 1 ELSE 0 END), 0) AS overdue,
          COALESCE(SUM(CASE WHEN d.destroyed_at > r.expiry_instant THEN 1 ELSE 0 END), 0) AS expired,
          COALESCE(SUM(CASE WHEN d.unit_cost IS NOT NULL THEN 1 ELSE 0 END), 0) AS priced
        FROM ${Tables.destructions} d
        JOIN ${Tables.inventoryRecords} r ON r.id = d.record_id
        WHERE d.destroyed_at >= ? AND d.destroyed_at < ?
        ''',
        range,
      );
      final Map<String, Object?> row = totals.first;

      return DestructionReport(
        period: period,
        totalRecords: row.integer('records'),
        totalUnits: row.number('units'),
        totalLoss: row.number('loss'),
        overdueRecords: row.integer('overdue'),
        expiredOnDestroyRecords: row.integer('expired'),
        pricedRecords: row.integer('priced'),
        byCategory: await _slices(
          groupExpression: "COALESCE(p.category_id, '$_unassigned')",
          labelExpression: 'c.name',
          extraJoins: 'LEFT JOIN ${Tables.categories} c ON c.id = p.category_id',
          range: range,
        ),
        byShelf: await _slices(
          groupExpression: "COALESCE(d.shelf_id, '$_unassigned')",
          labelExpression: "COALESCE(a.name || ' - ', '') || s.name",
          extraJoins: 'LEFT JOIN ${Tables.shelves} s ON s.id = d.shelf_id '
              'LEFT JOIN ${Tables.areas} a ON a.id = s.area_id',
          range: range,
        ),
        byProduct: await _slices(
          groupExpression: 'd.product_id',
          labelExpression: "COALESCE(p.brand || ' ', '') || p.name",
          extraJoins: '',
          range: range,
          limit: 25,
        ),
        byReason: await _slices(
          groupExpression: 'd.reason',
          labelExpression: 'd.reason',
          extraJoins: '',
          range: range,
        ),
        trend: await _trend(period),
      );
    });
  }

  Future<List<WasteSlice>> _slices({
    required String groupExpression,
    required String labelExpression,
    required String extraJoins,
    required List<Object?> range,
    int limit = 100,
  }) async {
    final List<Map<String, Object?>> rows = await _database.db.rawQuery(
      '''
      SELECT
        $groupExpression AS slice_key,
        $labelExpression AS slice_label,
        COUNT(*) AS records,
        COALESCE(SUM(d.quantity), 0) AS units,
        COALESCE(SUM(d.loss_amount), 0) AS loss
      FROM ${Tables.destructions} d
      JOIN ${Tables.products} p ON p.id = d.product_id
      $extraJoins
      WHERE d.destroyed_at >= ? AND d.destroyed_at < ?
      GROUP BY slice_key
      ORDER BY loss DESC, records DESC
      LIMIT ?
      ''',
      <Object?>[...range, limit],
    );
    return rows
        .map((Map<String, Object?> r) => WasteSlice(
              key: r.strOrNull('slice_key') ?? _unassigned,
              label: r.strOrNull('slice_label') ?? '',
              records: r.integer('records'),
              units: r.number('units'),
              loss: r.number('loss'),
            ),)
        .toList(growable: false);
  }

  Future<List<TrendPoint>> _trend(ReportPeriod period) async {
    final Duration bucket = switch (period.granularity) {
      ReportGranularity.daily => const Duration(days: 1),
      ReportGranularity.weekly => const Duration(days: 7),
      ReportGranularity.monthly => const Duration(days: 30),
    };
    // Daily buckets, aggregated client-side into the requested granularity.
    final List<Map<String, Object?>> rows = await _database.db.rawQuery(
      '''
      SELECT
        CAST((d.destroyed_at - ?) / 86400000 AS INTEGER) AS day_index,
        COUNT(*) AS records,
        COALESCE(SUM(d.quantity), 0) AS units,
        COALESCE(SUM(d.loss_amount), 0) AS loss,
        COALESCE(SUM(CASE WHEN d.was_overdue = 1 THEN 1 ELSE 0 END), 0) AS overdue
      FROM ${Tables.destructions} d
      WHERE d.destroyed_at >= ? AND d.destroyed_at < ?
      GROUP BY day_index
      ORDER BY day_index
      ''',
      <Object?>[
        period.from.millisecondsSinceEpoch,
        period.from.millisecondsSinceEpoch,
        period.to.millisecondsSinceEpoch,
      ],
    );

    final int bucketDays = bucket.inDays.clamp(1, 365);
    final Map<int, TrendPoint> merged = <int, TrendPoint>{};
    for (final Map<String, Object?> row in rows) {
      final int dayIndex = row.integer('day_index');
      final int bucketIndex = dayIndex ~/ bucketDays;
      final TrendPoint? existing = merged[bucketIndex];
      merged[bucketIndex] = TrendPoint(
        bucketStart: period.from.add(Duration(days: bucketIndex * bucketDays)),
        records: (existing?.records ?? 0) + row.integer('records'),
        units: (existing?.units ?? 0) + row.number('units'),
        loss: (existing?.loss ?? 0) + row.number('loss'),
        overdueRecords: (existing?.overdueRecords ?? 0) + row.integer('overdue'),
      );
    }

    // Emit an entry for every bucket so a chart shows the zero days too.
    final int bucketCount = (period.dayCount / bucketDays).ceil().clamp(1, 400);
    return List<TrendPoint>.generate(bucketCount, (int i) {
      return merged[i] ??
          TrendPoint(
            bucketStart: period.from.add(Duration(days: i * bucketDays)),
            records: 0,
            units: 0,
            loss: 0,
            overdueRecords: 0,
          );
    });
  }

  @override
  Future<Result<IntakeReport>> intakeReport(ReportPeriod period) async {
    return _guard(() async {
      final List<Object?> range = <Object?>[
        period.from.millisecondsSinceEpoch,
        period.to.millisecondsSinceEpoch,
      ];
      final List<Map<String, Object?>> rows = await _database.db.rawQuery(
        '''
        SELECT status, COUNT(*) AS records, COALESCE(SUM(quantity), 0) AS units
        FROM ${Tables.inventoryRecords}
        WHERE created_at >= ? AND created_at < ?
        GROUP BY status
        ''',
        range,
      );
      int records = 0;
      double units = 0;
      final Map<InventoryStatus, int> byStatus = <InventoryStatus, int>{};
      for (final Map<String, Object?> row in rows) {
        final int count = row.integer('records');
        records += count;
        units += row.number('units');
        byStatus[InventoryStatus.fromName(row.strOrNull('status'))] = count;
      }
      return IntakeReport(
        period: period,
        recordsCreated: records,
        unitsReceived: units,
        byStatus: byStatus,
      );
    });
  }

  @override
  Future<Result<List<WasteStats>>> wasteByShelf(ReportPeriod period) => _wasteStats(
        period: period,
        keyExpression: "COALESCE(r.shelf_id, '$_unassigned')",
        labelExpression: "COALESCE(a.name || ' - ', '') || COALESCE(s.name, '')",
        joins: 'LEFT JOIN ${Tables.shelves} s ON s.id = r.shelf_id '
            'LEFT JOIN ${Tables.areas} a ON a.id = s.area_id',
      );

  @override
  Future<Result<List<WasteStats>>> wasteByCategory(ReportPeriod period) => _wasteStats(
        period: period,
        keyExpression: "COALESCE(p.category_id, '$_unassigned')",
        labelExpression: 'c.name',
        joins: 'LEFT JOIN ${Tables.categories} c ON c.id = p.category_id',
      );

  @override
  Future<Result<List<WasteStats>>> wasteByProduct(ReportPeriod period, {int limit = 50}) =>
      _wasteStats(
        period: period,
        keyExpression: 'r.product_id',
        labelExpression: "COALESCE(p.brand || ' ', '') || p.name",
        joins: '',
        limit: limit,
      );

  /// Joins intake (the denominator) with destruction (the numerator) so a
  /// shelf that simply handles more stock is not flagged as risky.
  Future<Result<List<WasteStats>>> _wasteStats({
    required ReportPeriod period,
    required String keyExpression,
    required String labelExpression,
    required String joins,
    int limit = 100,
  }) async {
    return _guard(() async {
      final List<Object?> range = <Object?>[
        period.from.millisecondsSinceEpoch,
        period.to.millisecondsSinceEpoch,
      ];
      final List<Map<String, Object?>> rows = await _database.db.rawQuery(
        '''
        SELECT
          $keyExpression AS stat_key,
          $labelExpression AS stat_label,
          COUNT(DISTINCT r.id) AS intake_records,
          COALESCE(SUM(DISTINCT r.quantity), 0) AS intake_units,
          COUNT(d.id) AS destroyed_records,
          COALESCE(SUM(d.quantity), 0) AS destroyed_units,
          COALESCE(SUM(CASE WHEN d.was_overdue = 1 THEN 1 ELSE 0 END), 0) AS overdue_records,
          COALESCE(SUM(CASE WHEN d.destroyed_at > r.expiry_instant THEN 1 ELSE 0 END), 0)
            AS expired_records,
          COALESCE(SUM(d.loss_amount), 0) AS loss
        FROM ${Tables.inventoryRecords} r
        JOIN ${Tables.products} p ON p.id = r.product_id
        $joins
        LEFT JOIN ${Tables.destructions} d ON d.record_id = r.id
        WHERE r.created_at >= ? AND r.created_at < ?
        GROUP BY stat_key
        ORDER BY destroyed_records DESC, intake_records DESC
        LIMIT ?
        ''',
        <Object?>[...range, limit],
      );
      return rows
          .map((Map<String, Object?> r) => WasteStats(
                key: r.strOrNull('stat_key') ?? _unassigned,
                label: r.strOrNull('stat_label') ?? '',
                intakeRecords: r.integer('intake_records'),
                intakeUnits: r.number('intake_units'),
                destroyedRecords: r.integer('destroyed_records'),
                destroyedUnits: r.number('destroyed_units'),
                overdueRecords: r.integer('overdue_records'),
                expiredRecords: r.integer('expired_records'),
                loss: r.number('loss'),
              ),)
          .toList(growable: false);
    });
  }

  @override
  Future<Result<List<WasteSlice>>> openStockByCategory() async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.rawQuery(
        '''
        SELECT
          COALESCE(p.category_id, '$_unassigned') AS slice_key,
          COALESCE(c.name, '') AS slice_label,
          COUNT(*) AS records,
          COALESCE(SUM(r.quantity_remaining), 0) AS units,
          COALESCE(SUM(r.quantity_remaining * COALESCE(r.unit_cost, p.unit_cost, 0)), 0) AS loss
        FROM ${Tables.inventoryRecords} r
        JOIN ${Tables.products} p ON p.id = r.product_id
        LEFT JOIN ${Tables.categories} c ON c.id = p.category_id
        WHERE r.status = ?
        GROUP BY slice_key
        ORDER BY loss DESC
        ''',
        <Object?>[InventoryStatus.active.name],
      );
      return rows
          .map((Map<String, Object?> r) => WasteSlice(
                key: r.strOrNull('slice_key') ?? _unassigned,
                label: r.strOrNull('slice_label') ?? '',
                records: r.integer('records'),
                units: r.number('units'),
                loss: r.number('loss'),
              ),)
          .toList(growable: false);
    });
  }

  @override
  Future<Result<int>> destructionSampleSize() =>
      _guard(() => countOf(_database.db, 'SELECT COUNT(*) FROM ${Tables.destructions}'));

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Analytics query failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('Analytics query failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
