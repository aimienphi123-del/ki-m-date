import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/audit/audit_repository_impl.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/reports/data/datasources/export_local_datasource.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_gateway.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/reports/domain/services/report_document_builder.dart';

/// Gathers real rows, builds one of the six documents, hands it to the chosen
/// destination and records what happened.
///
/// Everything it reports on comes from the database - there is no sample data
/// path. When a period holds nothing, the document says so in the store's
/// language instead of being padded with invented lines.
class DocumentExportRepositoryImpl implements DocumentExportRepository {
  DocumentExportRepositoryImpl({
    required ExportLocalDataSource dataSource,
    required AnalyticsRepository analytics,
    required InventoryRepository inventory,
    required AuditRepository audit,
    required AppDatabase database,
    required SettingsStore settings,
    required Clock clock,
    required IdGenerator ids,
    required DeviceIdentityProvider device,
    required AuditActorResolver actor,
    required AppLocalizations Function() strings,
    required Map<ExportDestination, DocumentExportGateway> gateways,
    required AppLogger logger,
  })  : _dataSource = dataSource,
        _analytics = analytics,
        _inventory = inventory,
        _audit = audit,
        _database = database,
        _settings = settings,
        _clock = clock,
        _ids = ids,
        _device = device,
        _actor = actor,
        _strings = strings,
        _gateways = gateways,
        _logger = logger;

  final ExportLocalDataSource _dataSource;
  final AnalyticsRepository _analytics;
  final InventoryRepository _inventory;
  final AuditRepository _audit;
  final AppDatabase _database;
  final SettingsStore _settings;
  final Clock _clock;
  final IdGenerator _ids;
  final DeviceIdentityProvider _device;
  final AuditActorResolver _actor;
  final AppLocalizations Function() _strings;
  final Map<ExportDestination, DocumentExportGateway> _gateways;
  final AppLogger _logger;

  static const String _tag = 'DocumentExport';

  /// How many audit rows an audit report carries. Beyond this the document
  /// says how many were left out rather than growing without bound.
  static const int _auditRowLimit = 2000;

  @override
  bool isDestinationConfigured(ExportDestination destination) =>
      _gateways[destination]?.isConfigured ?? false;

  @override
  String? unavailableReasonKey(ExportDestination destination) {
    final DocumentExportGateway? gateway = _gateways[destination];
    if (gateway == null) return K.exportFailed;
    return gateway.unavailableReasonKey;
  }

  @override
  Stream<void> watch() => _database.changes.where((String table) => table == Tables.documentExports);

  @override
  Future<Result<List<DocumentExport>>> history({int limit = 50}) async {
    try {
      return Ok<List<DocumentExport>>(await _dataSource.listExports(limit: limit));
    } on Object catch (error, stack) {
      _logger.e(_tag, 'history failed', error: error, stackTrace: stack);
      return Result<List<DocumentExport>>.err(Failure.io('export_failed', cause: error));
    }
  }

  @override
  Future<Result<ReportDocument>> preview(ExportRequest request) async {
    try {
      final ReportInputs inputs = await _gather(request);
      return Ok<ReportDocument>(
        ReportDocumentBuilder(_strings()).build(
          template: request.template,
          inputs: inputs,
          options: request.options,
        ),
      );
    } on Object catch (error, stack) {
      _logger.e(_tag, 'preview failed', error: error, stackTrace: stack);
      return Result<ReportDocument>.err(Failure.unknown('export_failed', cause: error));
    }
  }

  @override
  Future<Result<DocumentExport>> generate(ExportRequest request) =>
      _run(request, existing: null);

  @override
  Future<Result<DocumentExport>> regenerate(String exportId) async {
    final DocumentExport? existing = await _dataSource.findExport(exportId);
    if (existing == null) {
      return Result<DocumentExport>.err(const Failure.notFound('export_not_found'));
    }
    final ReportPeriod period = existing.periodFrom != null && existing.periodTo != null
        ? ReportPeriod(
            from: existing.periodFrom!,
            to: existing.periodTo!,
            granularity: _granularityFor(existing.template),
          )
        : _defaultPeriod(existing.template);
    return _run(
      ExportRequest(
        template: existing.template,
        destination: existing.destination,
        period: period,
        options: _optionsFromSettings(),
      ),
      existing: existing,
    );
  }

  @override
  Future<Result<String?>> shareLink(String exportId) async {
    try {
      final DocumentExport? export = await _dataSource.findExport(exportId);
      if (export == null) {
        return Result<String?>.err(const Failure.notFound('export_not_found'));
      }
      final DocumentExportGateway? gateway = _gateways[export.destination];
      final String? documentId = export.documentId ?? export.filePath;
      if (gateway == null || documentId == null) {
        return Ok<String?>(export.url);
      }
      return Ok<String?>(await gateway.shareLink(documentId) ?? export.url);
    } on ExportUnavailableException catch (error) {
      return Result<String?>.err(Failure.notConfigured(error.messageKey));
    } on Object catch (error, stack) {
      _logger.e(_tag, 'shareLink failed', error: error, stackTrace: stack);
      return Result<String?>.err(Failure.io('export_failed', cause: error));
    }
  }

  // --------------------------------------------------------------- internals

  Future<Result<DocumentExport>> _run(
    ExportRequest request, {
    required DocumentExport? existing,
  }) async {
    final DocumentExportGateway? gateway = _gateways[request.destination];
    if (gateway == null) {
      return Result<DocumentExport>.err(
        const Failure.notConfigured(K.exportFailed),
      );
    }
    if (!gateway.isConfigured) {
      return Result<DocumentExport>.err(
        Failure.notConfigured(gateway.unavailableReasonKey ?? K.exportFailed),
      );
    }

    final DateTime now = _clock.now();
    final AuditActor actor = _actor();
    final DeviceIdentity device = _device.current;

    ReportDocument document;
    try {
      final ReportInputs inputs = await _gather(request);
      document = ReportDocumentBuilder(_strings()).build(
        template: request.template,
        inputs: inputs,
        options: request.options,
      );
    } on Object catch (error, stack) {
      _logger.e(_tag, 'gather failed', error: error, stackTrace: stack);
      return Result<DocumentExport>.err(Failure.io('export_failed', cause: error));
    }

    final String id = existing?.id ?? _ids.newId();
    DocumentExport record = DocumentExport(
      id: id,
      template: request.template,
      destination: request.destination,
      title: document.header.title,
      status: 'pending',
      documentId: existing?.documentId,
      filePath: existing?.filePath,
      url: existing?.url,
      periodFrom: request.period.from,
      periodTo: request.period.to,
      createdBy: actor.id,
      deviceId: device.id,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    );

    if (existing == null) {
      await _dataSource.insertExport(record);
    } else {
      await _dataSource.updateExport(record);
    }

    try {
      final String? reuseId = existing?.documentId;
      final ExportOutcome outcome = reuseId == null
          ? await gateway.create(document)
          : await gateway.update(reuseId, document);

      record = DocumentExport(
        id: id,
        template: record.template,
        destination: record.destination,
        title: record.title,
        status: 'ready',
        documentId: outcome.documentId,
        filePath: outcome.filePath,
        url: outcome.url,
        periodFrom: record.periodFrom,
        periodTo: record.periodTo,
        createdBy: record.createdBy,
        deviceId: record.deviceId,
        createdAt: record.createdAt,
        updatedAt: _clock.now(),
      );
      await _dataSource.updateExport(record);

      await _audit.append(
        AuditDraft(
          action: AuditAction.reportExported,
          entity: Tables.documentExports,
          entityId: id,
          entityLabel: record.title,
          newValue: <String, Object?>{
            'template': record.template.name,
            'destination': record.destination.name,
            'periodFrom': record.periodFrom?.toIso8601String(),
            'periodTo': record.periodTo?.toIso8601String(),
            'filePath': record.filePath,
            'documentId': record.documentId,
            'regenerated': existing != null,
          },
          occurredAt: record.updatedAt,
        ),
      );

      return Ok<DocumentExport>(record);
    } on ExportUnavailableException catch (error) {
      await _markFailed(record, error.messageKey);
      return Result<DocumentExport>.err(Failure.notConfigured(error.messageKey));
    } on Object catch (error, stack) {
      _logger.e(_tag, 'export failed', error: error, stackTrace: stack);
      await _markFailed(record, error.toString());
      return Result<DocumentExport>.err(Failure.io('export_failed', cause: error));
    }
  }

  Future<void> _markFailed(DocumentExport record, String error) async {
    await _dataSource.updateExport(
      DocumentExport(
        id: record.id,
        template: record.template,
        destination: record.destination,
        title: record.title,
        status: 'failed',
        documentId: record.documentId,
        filePath: record.filePath,
        url: record.url,
        periodFrom: record.periodFrom,
        periodTo: record.periodTo,
        createdBy: record.createdBy,
        deviceId: record.deviceId,
        error: error,
        createdAt: record.createdAt,
        updatedAt: _clock.now(),
      ),
    );
  }

  /// Reads only what the chosen template actually prints, so an inventory
  /// report does not pay for an audit scan and vice versa.
  Future<ReportInputs> _gather(ExportRequest request) async {
    final AppLocalizations strings = _strings();
    final ReportPeriod period = request.period;

    List<DestructionLine> destructions = const <DestructionLine>[];
    DestructionReport? report;
    List<InventoryItemView> inventory = const <InventoryItemView>[];
    List<AuditEntry> auditEntries = const <AuditEntry>[];
    AuditIntegrityReport? integrity;

    switch (request.template) {
      case ReportTemplate.dailyDestroy:
      case ReportTemplate.weekly:
      case ReportTemplate.monthly:
        destructions = await _dataSource.destructionLines(period.from, period.to);
        report = (await _analytics.destructionReport(period)).valueOrNull;

      case ReportTemplate.audit:
        auditEntries = (await _audit.query(
              AuditQuery(from: period.from, to: period.to, limit: _auditRowLimit),
            ))
                .valueOrNull ??
            const <AuditEntry>[];
        integrity = (await _audit.verifyChain()).valueOrNull;

      case ReportTemplate.inventory:
        inventory = (await _inventory.search(
              const InventoryQuery(
                statuses: <InventoryStatus>{InventoryStatus.active},
                sort: InventorySort.destroyDate,
                limit: 5000,
              ),
            ))
                .valueOrNull ??
            const <InventoryItemView>[];

      case ReportTemplate.expired:
        inventory = (await _inventory.search(
              InventoryQuery(
                statuses: const <InventoryStatus>{InventoryStatus.active},
                expiryBefore: _clock.now(),
                sort: InventorySort.expiryDate,
                limit: 5000,
              ),
            ))
                .valueOrNull ??
            const <InventoryItemView>[];
    }

    return ReportInputs(
      period: period,
      header: DocumentHeader(
        title: strings.t(request.template.labelKey),
        company: _settings.readString(SettingKeys.companyName, ''),
        store: _settings.readString(SettingKeys.storeName, ''),
        storeCode: _settings.readString(SettingKeys.storeCode, ''),
        generatedAt: _clock.now(),
        generatedBy: _actor().name ?? '',
        deviceLabel: _device.current.displayName,
        periodLabel: _periodLabel(period, strings),
      ),
      destructions: destructions,
      report: report,
      inventory: inventory,
      auditEntries: auditEntries,
      auditIntegrity: integrity,
      currencySymbol:
          _settings.readString(SettingKeys.currencySymbol, SettingDefaults.currencySymbol),
    );
  }

  ReportOptions _optionsFromSettings() => ReportOptions(
        includeStatistics: _settings.readBool(
          SettingKeys.exportIncludeStatistics,
          SettingDefaults.exportIncludeStatistics,
        ),
        includePhotos: _settings.readBool(
          SettingKeys.exportIncludePhotos,
          SettingDefaults.exportIncludePhotos,
        ),
        includeSignatures: _settings.readBool(
          SettingKeys.exportIncludeSignatures,
          SettingDefaults.exportIncludeSignatures,
        ),
      );

  String _periodLabel(ReportPeriod period, AppLocalizations strings) {
    final DateTime lastDay = period.to.subtract(const Duration(milliseconds: 1));
    if (period.dayCount <= 1) return strings.date(period.from);
    return '${strings.date(period.from)} – ${strings.date(lastDay)}';
  }

  ReportGranularity _granularityFor(ReportTemplate template) => switch (template) {
        ReportTemplate.weekly => ReportGranularity.weekly,
        ReportTemplate.monthly => ReportGranularity.monthly,
        _ => ReportGranularity.daily,
      };

  ReportPeriod _defaultPeriod(ReportTemplate template) {
    final DateTime now = _clock.now();
    return switch (template) {
      ReportTemplate.weekly => ReportPeriod.week(now),
      ReportTemplate.monthly => ReportPeriod.month(now),
      _ => ReportPeriod.day(now),
    };
  }
}
