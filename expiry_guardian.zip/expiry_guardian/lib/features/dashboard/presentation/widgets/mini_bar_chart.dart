import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:flutter/material.dart';

class BarDatum {
  const BarDatum({required this.label, required this.value, this.highlight = false});

  final String label;
  final double value;
  final bool highlight;
}

/// A dependency-free bar chart, sized for a phone. Bars carry their value as
/// text as well as height, so the chart is readable without colour vision.
class MiniBarChart extends StatelessWidget {
  const MiniBarChart({
    required this.data,
    this.height = 160,
    this.valueFormatter,
    this.emptyLabel,
    super.key,
  });

  final List<BarDatum> data;
  final double height;
  final String Function(double value)? valueFormatter;
  final String? emptyLabel;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    if (data.isEmpty) {
      return SizedBox(
        height: height,
        child: Center(
          child: Text(
            emptyLabel ?? '',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
        ),
      );
    }

    final double maxValue = data
        .map((BarDatum d) => d.value)
        .fold<double>(0, (double a, double b) => a > b ? a : b);
    final double safeMax = maxValue <= 0 ? 1 : maxValue;

    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: data.map((BarDatum datum) {
          final double fraction = (datum.value / safeMax).clamp(0.0, 1.0);
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  if (datum.value > 0)
                    Text(
                      valueFormatter?.call(datum.value) ?? datum.value.toStringAsFixed(0),
                      style: theme.textTheme.labelSmall,
                      maxLines: 1,
                      overflow: TextOverflow.clip,
                    ),
                  const SizedBox(height: 2),
                  Container(
                    height: (height - 44) * fraction + (datum.value > 0 ? 3 : 1),
                    decoration: BoxDecoration(
                      color: datum.highlight
                          ? theme.colorScheme.error
                          : theme.colorScheme.primary
                              .withValues(alpha: datum.value > 0 ? 0.85 : 0.18),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: Dimens.gapXs),
                  Text(
                    datum.label,
                    style: theme.textTheme.labelSmall
                        ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    maxLines: 1,
                    overflow: TextOverflow.clip,
                  ),
                ],
              ),
            ),
          );
        }).toList(growable: false),
      ),
    );
  }
}
