import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Trend window shown on the dashboard.
final StateProvider<int> trendDaysProvider = StateProvider<int>((Ref ref) => 30);

final FutureProvider<InventorySummary> dashboardSummaryProvider =
    FutureProvider<InventorySummary>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  ref.watch(activePolicyProvider);
  final Clock clock = ref.watch(clockProvider);
  final DateTime start = clock.today();
  final Result<InventorySummary> result =
      await ref.watch(inventoryRepositoryProvider).summary(
            dayStart: start,
            dayEnd: start.add(const Duration(days: 1)),
          );
  return result.fold((Failure f) => throw f, (InventorySummary v) => v);
});

final FutureProvider<DestructionReport> dashboardTrendProvider =
    FutureProvider<DestructionReport>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  final Clock clock = ref.watch(clockProvider);
  final int days = ref.watch(trendDaysProvider);
  final Result<DestructionReport> result = await ref
      .watch(analyticsRepositoryProvider)
      .destructionReport(ReportPeriod.lastDays(clock.now(), days));
  return result.fold((Failure f) => throw f, (DestructionReport v) => v);
});
