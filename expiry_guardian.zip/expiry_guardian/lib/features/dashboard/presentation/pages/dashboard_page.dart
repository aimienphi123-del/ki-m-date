import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/theme/priority_palette.dart';
import 'package:expiry_guardian/features/dashboard/presentation/viewmodels/dashboard_view_model.dart';
import 'package:expiry_guardian/features/dashboard/presentation/widgets/mini_bar_chart.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Store-wide numbers, all computed with SQL over the rows the store created.
class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<InventorySummary> summary = ref.watch(dashboardSummaryProvider);
    final AsyncValue<DestructionReport> trend = ref.watch(dashboardTrendProvider);
    final String currency = ref.watch(currencySymbolProvider);
    final int trendDays = ref.watch(trendDaysProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.dashboardTitle))),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(dashboardSummaryProvider);
          ref.invalidate(dashboardTrendProvider);
        },
        child: summary.when(
          loading: () => const LoadingView(),
          error: (Object e, StackTrace s) => ErrorView(
            message: e.toString(),
            onRetry: () => ref.invalidate(dashboardSummaryProvider),
          ),
          data: (InventorySummary value) => ListView(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gapXl * 3,
            ),
            children: <Widget>[
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: Dimens.gapM,
                crossAxisSpacing: Dimens.gapM,
                childAspectRatio: 1.35,
                children: <Widget>[
                  StatTile(
                    icon: Icons.inventory_2_outlined,
                    label: l10n.t(K.dashboardTotalProducts),
                    value: l10n.number(value.activeRecords),
                    caption:
                        '${l10n.number(value.activeUnits)} ${l10n.t(K.commonUnits)}',
                  ),
                  StatTile(
                    icon: Icons.schedule,
                    label: l10n.t(K.dashboardApproaching),
                    value: l10n.number(value.approachingRecords),
                    accent: PriorityPalette.of(context, PriorityLevel.approaching).foreground,
                    caption: '${l10n.t(K.dashboardDueToday)}: ${value.dueTodayRecords}',
                  ),
                  StatTile(
                    icon: Icons.local_fire_department_outlined,
                    label: l10n.t(K.dashboardOverdue),
                    value: l10n.number(value.overdueRecords),
                    accent: PriorityPalette.of(context, PriorityLevel.destroyNow).foreground,
                  ),
                  StatTile(
                    icon: Icons.block,
                    label: l10n.t(K.dashboardExpired),
                    value: l10n.number(value.expiredRecords),
                    accent: PriorityPalette.of(context, PriorityLevel.expired).foreground,
                  ),
                  StatTile(
                    icon: Icons.delete_forever_outlined,
                    label: l10n.t(K.dashboardDestroyedToday),
                    value: l10n.number(value.destroyedTodayRecords),
                    caption:
                        '${l10n.number(value.destroyedTodayUnits)} ${l10n.t(K.commonUnits)}',
                  ),
                  StatTile(
                    icon: Icons.payments_outlined,
                    label: l10n.t(K.dashboardFinancialLoss),
                    value: l10n.money(value.destroyedTodayLoss, symbol: currency),
                  ),
                ],
              ),
              const SizedBox(height: Dimens.gapM),
              StatTile(
                icon: Icons.account_balance_wallet_outlined,
                label: l10n.t(K.dashboardStockValue),
                value: l10n.money(value.activeStockValue, symbol: currency),
                caption: value.activeRecords == 0
                    ? null
                    : (value.pricedProductsRatio < 1
                        ? l10n.t(K.dashboardPartialLossWarning, <String, Object?>{
                            'priced':
                                (value.pricedProductsRatio * value.activeRecords).round(),
                            'total': value.activeRecords,
                          })
                        : null),
              ),
              SectionHeader(
                title: l10n.t(K.dashboardTrend),
                trailing: SegmentedButton<int>(
                  showSelectedIcon: false,
                  segments: <ButtonSegment<int>>[
                    ButtonSegment<int>(value: 7, label: Text(l10n.t(K.dashboardTrend7))),
                    ButtonSegment<int>(value: 30, label: Text(l10n.t(K.dashboardTrend30))),
                    ButtonSegment<int>(value: 90, label: Text(l10n.t(K.dashboardTrend90))),
                  ],
                  selected: <int>{trendDays},
                  onSelectionChanged: (Set<int> selection) =>
                      ref.read(trendDaysProvider.notifier).state = selection.first,
                ),
              ),
              AppCard(
                child: trend.when(
                  loading: () => const LoadingView(),
                  error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
                  data: (DestructionReport report) {
                    if (report.totalRecords == 0) {
                      return SizedBox(
                        height: 140,
                        child: Center(child: Text(l10n.t(K.reportsEmpty))),
                      );
                    }
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        MiniBarChart(
                          data: _downsample(report.trend, 10)
                              .map((TrendPoint point) => BarDatum(
                                    label: l10n.dayMonth(point.bucketStart),
                                    value: point.records.toDouble(),
                                    highlight: point.overdueRecords > 0,
                                  ),)
                              .toList(growable: false),
                        ),
                        const SizedBox(height: Dimens.gapM),
                        DetailRow(
                          label: l10n.t(K.reportsDestroyedRecords),
                          value: l10n.number(report.totalRecords),
                        ),
                        DetailRow(
                          label: l10n.t(K.reportsOverdueRecords),
                          value: l10n.number(report.overdueRecords),
                        ),
                        DetailRow(
                          label: l10n.t(K.reportsFinancialLoss),
                          value: l10n.money(report.totalLoss, symbol: currency),
                          caption: report.lossIsPartial
                              ? l10n.t(K.reportsPartialLoss, <String, Object?>{
                                  'priced': report.pricedRecords,
                                  'total': report.totalRecords,
                                })
                              : null,
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Merges neighbouring daily buckets so a 90-day chart still fits a phone.
  List<TrendPoint> _downsample(List<TrendPoint> points, int maxBars) {
    if (points.length <= maxBars) return points;
    final int step = (points.length / maxBars).ceil();
    final List<TrendPoint> out = <TrendPoint>[];
    for (int i = 0; i < points.length; i += step) {
      int records = 0;
      double units = 0;
      double loss = 0;
      int overdue = 0;
      for (final TrendPoint point in points.skip(i).take(step)) {
        records += point.records;
        units += point.units;
        loss += point.loss;
        overdue += point.overdueRecords;
      }
      out.add(TrendPoint(
        bucketStart: points[i].bucketStart,
        records: records,
        units: units,
        loss: loss,
        overdueRecords: overdue,
      ),);
    }
    return out;
  }
}
