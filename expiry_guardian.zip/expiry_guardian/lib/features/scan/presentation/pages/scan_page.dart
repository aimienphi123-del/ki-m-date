import 'dart:io';

import 'package:collection/collection.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/presentation/pages/product_form_page.dart';
import 'package:expiry_guardian/features/catalog/presentation/pages/product_picker_page.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_list_view_model.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/locations/domain/repositories/location_repository.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/disposal_calculator_page.dart';
import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scan_outcome.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/camera_capture_page.dart';
import 'package:expiry_guardian/features/scan/presentation/viewmodels/scan_flow_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Goods-in. Three steps, each a single tap:
/// scan the barcode, photograph the dates, save.
class ScanPage extends ConsumerWidget {
  const ScanPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.scanTitle)),
        actions: <Widget>[
          if (state.step != ScanStep.start)
            TextButton(
              onPressed: () => ref.read(scanFlowProvider.notifier).reset(),
              child: Text(l10n.t(K.commonClear)),
            ),
        ],
      ),
      body: switch (state.step) {
        ScanStep.start => const _StartStep(),
        ScanStep.needsProduct => const _UnknownProductStep(),
        ScanStep.review => const _ReviewStep(),
        ScanStep.saved => const _SavedStep(),
      },
    );
  }
}

Future<void> _captureBarcode(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  // Live mode: the viewfinder reads the code itself, so a shaky hand and a
  // small printed barcode stop being a dead end.
  final CaptureResult? shot = await CameraCapturePage.open(
    context,
    title: l10n.t(K.scanStepBarcode),
    hint: l10n.t(K.scanAimBarcode),
    liveBarcode: true,
  );
  if (shot == null) return;
  if (shot.path.isEmpty && shot.codes.isEmpty) return;
  await ref
      .read(scanFlowProvider.notifier)
      .processBarcodeCapture(shot.path, alreadyRead: shot.codes);

  // A barcode the store has seen before arrives with its name, unit, price and
  // shelf already filled in, so the only thing still missing is the dates.
  // Walking the employee to that step is the whole point of remembering the
  // product; making them find the button again is not.
  if (!context.mounted) return;
  final ScanFlowState after = ref.read(scanFlowProvider);
  final bool autoAdvance = ref
      .read(settingsStoreProvider)
      .readBool(SettingKeys.scanAutoAdvance, SettingDefaults.scanAutoAdvance);
  if (autoAdvance &&
      after.step == ScanStep.review &&
      after.needsManualDate &&
      !after.busy) {
    await _captureLabel(context, ref);
  }
}

Future<void> _captureLabel(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  // Live mode here too: a printed date is small, low contrast and often on a
  // curved surface - the single attempt a photograph gets is exactly what the
  // recogniser handles worst.
  final CaptureResult? shot = await CameraCapturePage.open(
    context,
    title: l10n.t(K.scanStepDates),
    hint: l10n.t(K.scanAimLabel),
    liveText: true,
  );
  if (shot == null) return;
  if (shot.path.isEmpty && shot.lines.isEmpty) return;
  await ref
      .read(scanFlowProvider.notifier)
      .processLabelCapture(shot.path, alreadyReadLines: shot.lines);
}

/// Opens the calculator to settle the expiry, seeded with whatever the scan
/// already read so a correct OCR reading only has to be confirmed.
Future<void> _openCalculator(BuildContext context, WidgetRef ref) async {
  final ScanFlowState state = ref.read(scanFlowProvider);
  final CalculatorPick? pick = await DisposalCalculatorPage.pick(
    context,
    expiry: state.expiry,
    manufacturing: state.manufactured,
  );
  if (pick == null) return;
  final ScanFlowController controller = ref.read(scanFlowProvider.notifier);
  controller.setExpiry(
    pick.expiry,
    precision: pick.hasTimeOfDay ? ExpiryPrecision.hour : ExpiryPrecision.day,
  );
  final DateTime? made = pick.manufacturing;
  if (made != null) controller.setManufactured(made);
}

class _StartStep extends ConsumerWidget {
  const _StartStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return ListView(
      padding: const EdgeInsets.all(Dimens.gutter),
      children: <Widget>[
        const SizedBox(height: Dimens.gapM),
        Text(
          l10n.t(K.scanStepBarcode),
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: Dimens.gapL),
        if (state.busy)
          const LoadingView()
        else ...<Widget>[
          // Two paths, named for what the employee already knows, because the
          // work is completely different: a product the store has had before
          // needs nothing but a tap, while a new one needs a name, a photo and
          // a shelf. One combined screen made both feel like the harder case.
          _PathCard(
            icon: Icons.inventory_2_outlined,
            title: l10n.t(K.scanExistingProduct),
            subtitle: l10n.t(K.scanExistingProductHint),
            primary: true,
            onTap: () => _pickExistingProduct(context, ref),
            secondaryIcon: Icons.qr_code_scanner,
            secondaryLabel: l10n.t(K.scanCapture),
            onSecondary: () => _captureBarcode(context, ref),
          ),
          const SizedBox(height: Dimens.gapM),
          _PathCard(
            icon: Icons.add_box_outlined,
            title: l10n.t(K.scanNewProduct),
            subtitle: l10n.t(K.scanNewProductHint),
            onTap: () => _startNewProduct(context, ref),
          ),
        ],
        if (state.failure != null) ...<Widget>[
          const SizedBox(height: Dimens.gapL),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.error_outline,
            message: describeFailure(context, state.failure!),
          ),
        ],
        if (state.outcome.codes.isEmpty && state.outcome.quality != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          _QualityNotice(quality: state.outcome.quality!),
        ],
        // The scan kept its picture even though no decoder could read it. That
        // picture is the whole point: the number is perfectly legible to a
        // person, so it is shown here and typed in underneath rather than the
        // capture being thrown away and asked for again.
        if (!state.hasBarcode && state.barcodePhotoPath != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          _BarcodePhotoCard(
            path: state.barcodePhotoPath!,
            message: l10n.t(K.scanBarcodeNotRead),
            onRetake: () => _captureBarcode(context, ref),
          ),
          const SizedBox(height: Dimens.gapM),
          _ManualBarcodeField(
            onSubmitted: (String value) =>
                ref.read(scanFlowProvider.notifier).setBarcodeManually(value),
          ),
        ],
        const SizedBox(height: Dimens.gapM),
        TextButton.icon(
          onPressed: () => _promptForBarcode(context, ref),
          icon: const Icon(Icons.keyboard),
          label: Text(l10n.t(K.scanEnterBarcode)),
        ),
      ],
    );
  }
}

/// One of the two ways into goods-in.
class _PathCard extends StatelessWidget {
  const _PathCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.primary = false,
    this.secondaryIcon,
    this.secondaryLabel,
    this.onSecondary,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool primary;
  final IconData? secondaryIcon;
  final String? secondaryLabel;
  final VoidCallback? onSecondary;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return AppCard(
      onTap: onTap,
      borderColor: primary ? theme.colorScheme.primary : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(icon, size: 32, color: theme.colorScheme.primary),
              const SizedBox(width: Dimens.gapM),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
          if (onSecondary != null) ...<Widget>[
            const SizedBox(height: Dimens.gapM),
            OutlinedButton.icon(
              onPressed: onSecondary,
              icon: Icon(secondaryIcon),
              label: Text(secondaryLabel ?? ''),
            ),
          ],
        ],
      ),
    );
  }
}

/// Photographs the product's face and keeps it on the catalog entry, so every
/// later scan and every stock row shows it.
Future<void> _setProductPhoto(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  final Product? product = ref.read(scanFlowProvider).product;
  if (product == null) return;

  final CaptureResult? shot = await CameraCapturePage.open(
    context,
    title: l10n.t(K.catalogPhoto),
    hint: l10n.t(K.catalogPhotoHint),
  );
  if (shot == null || shot.path.isEmpty) return;

  final Result<Product> saved = await ref
      .read(catalogRepositoryProvider)
      .updateProduct(product.copyWith(photoPath: shot.path));
  if (!context.mounted) return;
  saved.fold(
    (Failure failure) =>
        showAppSnack(context, describeFailure(context, failure), isError: true),
    (Product updated) => ref.read(scanFlowProvider.notifier).attachProduct(updated),
  );
}

/// "I know this product" - show the list and let them tap it.
Future<void> _pickExistingProduct(BuildContext context, WidgetRef ref) async {
  final Product? picked = await ProductPickerPage.open(context);
  if (picked == null) return;
  ref.read(scanFlowProvider.notifier).attachProduct(picked);
}

/// "This is new" - photograph the barcode first, then describe it once.
Future<void> _startNewProduct(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  final CaptureResult? shot = await CameraCapturePage.open(
    context,
    title: l10n.t(K.scanStepBarcode),
    hint: l10n.t(K.scanAimBarcode),
    liveBarcode: true,
  );
  if (!context.mounted) return;

  String? barcode;
  String? photo;
  if (shot != null) {
    photo = shot.path.isEmpty ? null : shot.path;
    barcode = shot.codes.isEmpty ? null : shot.codes.first.rawValue;
  }

  final Product? created = await ProductFormPage.open(
    context,
    initialBarcode: barcode,
    initialBarcodePhotoPath: photo,
  );
  if (created == null) return;
  ref.read(scanFlowProvider.notifier).attachProduct(created);
}

Future<void> _promptForBarcode(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  final TextEditingController controller = TextEditingController();
  final String? value = await showDialog<String>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: Text(l10n.t(K.scanEnterBarcode)),
      content: TextField(
        controller: controller,
        autofocus: true,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(labelText: l10n.t(K.recordBarcode)),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.t(K.commonCancel)),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(controller.text.trim()),
          child: Text(l10n.t(K.commonNext)),
        ),
      ],
    ),
  );
  controller.dispose();
  if (value == null || value.isEmpty) return;
  ref.read(scanFlowProvider.notifier).setBarcodeManually(value);
}

/// Creates a shelf without leaving goods-in.
///
/// The store's locations are two levels deep - an area holds shelves, and
/// stock sits on a shelf - which is easy to half-finish: create "Nước" as an
/// area, and the goods-in screen correctly reports no shelves while the
/// locations screen looks complete. Sending someone to another screen to
/// notice that is worse than letting them fix it here.
Future<void> _createShelfInline(
  BuildContext context,
  WidgetRef ref,
  List<StoreArea> areas,
  ValueChanged<String?> onChanged,
) async {
  final AppLocalizations l10n = context.l10n;
  final TextEditingController shelfName = TextEditingController();
  final TextEditingController areaName = TextEditingController();
  String? areaId = areas.isEmpty ? null : areas.first.id;
  final GlobalKey<FormState> form = GlobalKey<FormState>();

  final bool? confirmed = await showDialog<bool>(
    context: context,
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setDialogState) {
          return AlertDialog(
            title: Text(l10n.t(K.scanNewShelfTitle)),
            content: SizedBox(
              width: 360,
              child: SingleChildScrollView(
                child: Form(
                  key: form,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      if (areas.isEmpty)
                        TextFormField(
                          controller: areaName,
                          autofocus: true,
                          textCapitalization: TextCapitalization.sentences,
                          decoration: InputDecoration(
                            labelText: l10n.t(K.scanAreaNameLabel),
                          ),
                          validator: (String? v) => (v ?? '').trim().isEmpty
                              ? l10n.t(K.locationsNameRequired)
                              : null,
                        )
                      else
                        DropdownButtonFormField<String>(
                          initialValue: areaId,
                          isExpanded: true,
                          decoration: InputDecoration(
                            labelText: l10n.t(K.scanAreaOfLabel),
                          ),
                          items: <DropdownMenuItem<String>>[
                            for (final StoreArea area in areas)
                              DropdownMenuItem<String>(
                                value: area.id,
                                child: Text(
                                  area.name,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                          ],
                          onChanged: (String? value) =>
                              setDialogState(() => areaId = value),
                        ),
                      const SizedBox(height: Dimens.gapM),
                      TextFormField(
                        controller: shelfName,
                        autofocus: areas.isNotEmpty,
                        textCapitalization: TextCapitalization.sentences,
                        textInputAction: TextInputAction.done,
                        decoration: InputDecoration(
                          labelText: l10n.t(K.scanShelfNameLabel),
                        ),
                        validator: (String? v) => (v ?? '').trim().isEmpty
                            ? l10n.t(K.locationsNameRequired)
                            : null,
                        onFieldSubmitted: (_) {
                          if (form.currentState?.validate() ?? false) {
                            Navigator.of(context).pop(true);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: Text(l10n.t(K.commonCancel)),
              ),
              FilledButton(
                onPressed: () {
                  if (form.currentState?.validate() ?? false) {
                    Navigator.of(context).pop(true);
                  }
                },
                child: Text(l10n.t(K.commonSave)),
              ),
            ],
          );
        },
      );
    },
  );

  final String shelf = shelfName.text.trim();
  final String area = areaName.text.trim();
  shelfName.dispose();
  areaName.dispose();
  if (confirmed != true || shelf.isEmpty || !context.mounted) return;

  final LocationRepository locations = ref.read(locationRepositoryProvider);

  String? targetArea = areaId;
  if (targetArea == null) {
    final Result<StoreArea> created = await locations.createArea(name: area);
    if (created.isErr) {
      if (!context.mounted) return;
      showAppSnack(
        context,
        describeFailure(context, created.failureOrNull!),
        isError: true,
      );
      return;
    }
    targetArea = created.unwrap().id;
  }

  final Result<Shelf> created =
      await locations.createShelf(areaId: targetArea, name: shelf);
  // The two lists this screen reads are rebuilt explicitly rather than waiting
  // on the change notification, so the new shelf is selectable immediately.
  ref.invalidate(storeAreasProvider);
  ref.invalidate(shelfLocationsProvider);
  if (!context.mounted) return;
  created.fold(
    (Failure failure) =>
        showAppSnack(context, describeFailure(context, failure), isError: true),
    (Shelf value) {
      onChanged(value.id);
      showAppSnack(
        context,
        l10n.t(K.scanShelfCreated, <String, Object?>{'name': value.name}),
      );
    },
  );
}

/// The shelf this lot goes on, shown as a row of taps rather than a dropdown.
///
/// A closed dropdown shows only the *selected* item, so with nothing chosen it
/// read "Không có" - which employees reasonably took to mean the store had no
/// shelves, when the list was one tap away the whole time. Laying the shelves
/// out means what exists is never in doubt, and the genuinely empty case says
/// so and points at the screen that fixes it.
class _ShelfPicker extends ConsumerWidget {
  const _ShelfPicker({
    required this.shelves,
    required this.selected,
    required this.onChanged,
  });

  final List<ShelfLocation> shelves;
  final String? selected;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final List<StoreArea> areas =
        ref.watch(storeAreasProvider).valueOrNull ?? const <StoreArea>[];

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.shelves, color: theme.colorScheme.primary),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  l10n.t(K.scanPickShelf),
                  style: theme.textTheme.titleSmall,
                ),
              ),
              if (shelves.isNotEmpty)
                Text(
                  l10n.t(K.scanShelfCount, <String, Object?>{'count': shelves.length}),
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
            ],
          ),
          const SizedBox(height: Dimens.gapS),
          if (shelves.isEmpty) ...<Widget>[
            NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.info_outline,
              // Saying "no shelves" when the store has an area but no shelf in
              // it sends people back to a screen where everything looks done.
              // The two cases need different sentences.
              message: l10n.t(
                areas.isEmpty ? K.scanNoShelves : K.scanNoShelvesYet,
              ),
            ),
            const SizedBox(height: Dimens.gapS),
            // ...and a dead end in the middle of goods-in is worth one button
            // rather than a trip to another screen and back.
            FilledButton.icon(
              onPressed: () => _createShelfInline(context, ref, areas, onChanged),
              icon: const Icon(Icons.add),
              label: Text(l10n.t(K.scanCreateShelfNow)),
            ),
          ] else
            Wrap(
              spacing: Dimens.gapS,
              runSpacing: Dimens.gapS,
              children: <Widget>[
                ChoiceChip(
                  label: Text(l10n.t(K.commonNone)),
                  selected: selected == null,
                  onSelected: (_) => onChanged(null),
                ),
                for (final ShelfLocation location in shelves)
                  ChoiceChip(
                    label: Text(location.label),
                    selected: selected == location.shelf.id,
                    onSelected: (_) => onChanged(location.shelf.id),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

/// The still taken while aiming at the barcode, shown so the number can be
/// read off it by eye.
class _BarcodePhotoCard extends StatelessWidget {
  const _BarcodePhotoCard({
    required this.path,
    required this.message,
    this.onRetake,
  });

  final String path;
  final String message;
  final VoidCallback? onRetake;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.qr_code_2, color: theme.colorScheme.primary),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  l10n.t(K.scanBarcodePhoto),
                  style: theme.textTheme.titleSmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimens.gapXs),
          Text(
            message,
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: Dimens.gapM),
          ClipRRect(
            borderRadius: BorderRadius.circular(Dimens.radiusSmall),
            child: Image.file(
              File(path),
              height: 180,
              width: double.infinity,
              fit: BoxFit.contain,
              errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                  const SizedBox.shrink(),
            ),
          ),
          if (onRetake != null) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            OutlinedButton.icon(
              onPressed: onRetake,
              icon: const Icon(Icons.replay),
              label: Text(l10n.t(K.scanRetake)),
            ),
          ],
        ],
      ),
    );
  }
}

/// A small preview of the barcode still, for the steps that only need to show
/// that it was kept.
class _BarcodeThumb extends StatelessWidget {
  const _BarcodeThumb({required this.path});

  final String path;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        ClipRRect(
          borderRadius: BorderRadius.circular(Dimens.radiusSmall),
          child: Image.file(
            File(path),
            width: 96,
            height: 72,
            fit: BoxFit.cover,
            errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                const SizedBox.shrink(),
          ),
        ),
        const SizedBox(width: Dimens.gapM),
        Expanded(
          child: Text(
            l10n.t(K.scanBarcodePhotoKept),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ),
      ],
    );
  }
}

/// Typing the number in, right under the photograph it was read from.
class _ManualBarcodeField extends StatefulWidget {
  const _ManualBarcodeField({required this.onSubmitted});

  final ValueChanged<String> onSubmitted;

  @override
  State<_ManualBarcodeField> createState() => _ManualBarcodeFieldState();
}

class _ManualBarcodeFieldState extends State<_ManualBarcodeField> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final String value = _controller.text.trim();
    if (value.isEmpty) return;
    widget.onSubmitted(value);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextField(
            controller: _controller,
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(labelText: l10n.t(K.scanTypeBarcode)),
            onSubmitted: (_) => _submit(),
          ),
          const SizedBox(height: Dimens.gapM),
          FilledButton.icon(
            onPressed: _submit,
            icon: const Icon(Icons.check),
            label: Text(l10n.t(K.commonNext)),
          ),
        ],
      ),
    );
  }
}

class _UnknownProductStep extends ConsumerWidget {
  const _UnknownProductStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return ListView(
      padding: const EdgeInsets.all(Dimens.gutter),
      children: <Widget>[
        NoticeBanner(
          tone: NoticeTone.warning,
          icon: Icons.help_outline,
          message: l10n.t(K.scanUnknownProduct),
        ),
        const SizedBox(height: Dimens.gapM),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              DetailRow(
                label: l10n.t(K.recordBarcode),
                value: state.barcode ?? l10n.t(K.commonUnknown),
              ),
              if (state.barcodePhotoPath != null) ...<Widget>[
                const SizedBox(height: Dimens.gapS),
                _BarcodeThumb(path: state.barcodePhotoPath!),
              ],
              const SizedBox(height: Dimens.gapS),
              Text(
                l10n.t(K.scanUnknownProductHint),
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
        const SizedBox(height: Dimens.gapL),
        FilledButton.icon(
          onPressed: () async {
            final Product? created = await ProductFormPage.open(
              context,
              initialBarcode: state.barcode,
              initialBarcodePhotoPath: state.barcodePhotoPath,
            );
            if (created != null) {
              ref.read(scanFlowProvider.notifier).attachProduct(created);
            }
          },
          icon: const Icon(Icons.add),
          label: Text(l10n.t(K.scanCreateProduct)),
        ),
        const SizedBox(height: Dimens.gapM),
        OutlinedButton.icon(
          onPressed: () => _captureBarcode(context, ref),
          icon: const Icon(Icons.replay),
          label: Text(l10n.t(K.scanRetake)),
        ),
      ],
    );
  }
}

class _ReviewStep extends ConsumerWidget {
  const _ReviewStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final ScanFlowState state = ref.watch(scanFlowProvider);
    final ScanFlowController controller = ref.read(scanFlowProvider.notifier);
    final String currency = ref.watch(currencySymbolProvider);
    final List<ShelfLocation> shelves =
        ref.watch(shelfLocationsProvider).valueOrNull ?? const <ShelfLocation>[];

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gapXl * 2,
      ),
      children: <Widget>[
        // The product's own photo lives here, not only on the catalog form:
        // the form is reached when a product is *created*, so an item the
        // store has had for months could never be given a face. It can now,
        // from the screen the employee is already on.
        AppCard(
          child: Row(
            children: <Widget>[
              ProductAvatar(
                path: state.product!.photoPath,
                label: state.product!.displayName,
                size: 56,
              ),
              const SizedBox(width: Dimens.gapM),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      state.product!.displayName,
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    Text(
                      state.barcode ??
                          state.product!.barcode ??
                          l10n.t(K.catalogNoBarcode),
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                    const SizedBox(height: Dimens.gapXs),
                    TextButton.icon(
                      onPressed: () => _setProductPhoto(context, ref),
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(0, 32),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      icon: const Icon(Icons.photo_camera_outlined, size: 18),
                      label: Text(
                        l10n.t(state.product!.photoPath == null
                            ? K.scanAddPhoto
                            : K.scanChangePhoto,),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (state.outcome.quality != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          _QualityNotice(quality: state.outcome.quality!),
        ],
        if (state.outcome.enhancementSteps.isNotEmpty) ...<Widget>[
          const SizedBox(height: Dimens.gapS),
          NoticeBanner(
            icon: Icons.auto_fix_high,
            message: l10n.t(K.scanEnhanced, <String, Object?>{
              'steps': state.outcome.enhancementSteps.join(', '),
            }),
          ),
        ],
        for (final LabelWarning warning in state.warnings)
          Padding(
            padding: const EdgeInsets.only(top: Dimens.gapS),
            child: NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.warning_amber_rounded,
              message: l10n.t(switch (warning) {
                LabelWarning.ambiguousDayMonth => K.scanWarningAmbiguous,
                LabelWarning.expiryAlreadyPassed => K.scanWarningExpiryPassed,
                LabelWarning.expiryBeforeManufacturing => K.scanWarningExpiryBeforeMfg,
                LabelWarning.onlyMonthPrinted => K.scanWarningMonthOnly,
                LabelWarning.multipleExpiryCandidates => K.scanWarningMultipleExpiry,
                LabelWarning.noDatesFound => K.scanNoDateFound,
                LabelWarning.implausibleYear => K.scanCheckDates,
              },),
            ),
          ),
        SectionHeader(title: l10n.t(K.scanStepDates)),
        // The expiry is entered through the calculator rather than a bare
        // date picker. Most of the time that is still one tap on a date - the
        // calculator's first mode is exactly that - but the same screen also
        // takes "NSX + 6 tháng" and works the expiry out, which is what the
        // label actually says on a large share of goods. Picking the date
        // blind and doing that arithmetic in your head is where the mistakes
        // come from, and the screen shows the resulting destroy deadline
        // before anything is saved.
        _DateField(
          label: l10n.t(K.recordExpiryAt),
          value: state.expiry,
          precision: state.precision,
          source: state.outcome.expiry.source,
          icon: Icons.calculate_outlined,
          onTap: () => _openCalculator(context, ref),
          onChanged: (DateTime? value) => controller.setExpiry(value),
          onPrecisionChanged: (ExpiryPrecision precision) =>
              controller.setExpiry(state.expiry, precision: precision),
        ),
        const SizedBox(height: Dimens.gapS),
        _DateField(
          label: l10n.t(K.recordManufacturedAt),
          value: state.manufactured,
          precision: ExpiryPrecision.day,
          source: state.outcome.manufactured.source,
          optional: true,
          onChanged: controller.setManufactured,
        ),
        const SizedBox(height: Dimens.gapS),
        OutlinedButton.icon(
          onPressed: () => _captureLabel(context, ref),
          icon: const Icon(Icons.photo_camera_outlined),
          label: Text(
            state.expiry == null ? l10n.t(K.scanStepDates) : l10n.t(K.scanRetake),
          ),
        ),
        SectionHeader(title: l10n.t(K.scanStepReview)),
        TextFormField(
          initialValue: state.batchCode ?? '',
          decoration: InputDecoration(
            labelText: '${l10n.t(K.recordBatch)} (${l10n.t(K.commonOptional)})',
            helperText: _sourceLabel(l10n, state.outcome.batchCode.source),
          ),
          onChanged: controller.setBatch,
        ),
        const SizedBox(height: Dimens.gapM),
        Row(
          children: <Widget>[
            Expanded(
              child: TextFormField(
                initialValue: state.quantity.toString(),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: l10n.t(K.recordQuantity)),
                onChanged: (String value) => controller.setQuantity(
                  double.tryParse(value.replaceAll(',', '.')) ?? 0,
                ),
              ),
            ),
            const SizedBox(width: Dimens.gapM),
            Expanded(
              child: TextFormField(
                initialValue: state.unitCost?.toString() ?? '',
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: l10n.t(K.recordUnitCost),
                  suffixText: currency,
                ),
                onChanged: (String value) => controller
                    .setUnitCost(double.tryParse(value.replaceAll(',', '.'))),
              ),
            ),
          ],
        ),
        const SizedBox(height: Dimens.gapM),
        _ShelfPicker(
          shelves: shelves,
          selected: selectableShelfId(state.shelfId, shelves),
          onChanged: controller.setShelf,
        ),
        if (state.product != null && state.needsManualDate) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            icon: Icons.history,
            message: state.shelfId == null
                ? l10n.t(K.scanRecalledProduct)
                : l10n.t(K.scanRecalledWithShelf, <String, Object?>{
                    'shelf': shelves
                            .where((ShelfLocation l) => l.shelf.id == state.shelfId)
                            .map((ShelfLocation l) => l.label)
                            .firstOrNull ??
                        '',
                  }),
          ),
        ],
        const SizedBox(height: Dimens.gapM),
        _ProductPhotoCard(
          path: state.photoPath,
          onPick: () async {
            final CaptureResult? shot = await CameraCapturePage.open(
              context,
              title: l10n.t(K.scanProductPhoto),
              hint: l10n.t(K.scanAimProductFront),
            );
            if (shot == null || shot.path.isEmpty) return;
            controller.setProductPhoto(shot.path);
          },
          onRemove: () => controller.setProductPhoto(null),
        ),
        if (state.failure != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.error_outline,
            message: describeFailure(context, state.failure!),
          ),
        ],
        const SizedBox(height: Dimens.gapL),
        FilledButton.icon(
          onPressed: state.canSave
              ? () async {
                  final InventoryRecord? record = await controller.save();
                  if (record != null && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(l10n.t(
                          K.scanSavedRecord,
                          <String, Object?>{'code': record.code},
                        ),),
                      ),
                    );
                  }
                }
              : null,
          icon: state.busy
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2.5),
                )
              : const Icon(Icons.save),
          label: Text(l10n.t(K.scanSaveRecord)),
        ),
        if (state.needsManualDate)
          Padding(
            padding: const EdgeInsets.only(top: Dimens.gapS),
            child: Text(
              l10n.t(K.scanNoDateFound),
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
      ],
    );
  }
}

class _SavedStep extends ConsumerWidget {
  const _SavedStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return EmptyState(
      icon: Icons.check_circle_outline,
      title: l10n.t(K.scanSavedRecord, <String, Object?>{'code': state.savedCode ?? ''}),
      action: Column(
        children: <Widget>[
          FilledButton.icon(
            onPressed: () {
              ref.read(scanFlowProvider.notifier).reset();
              _captureBarcode(context, ref);
            },
            icon: const Icon(Icons.qr_code_scanner),
            label: Text(l10n.t(K.scanScanNext)),
          ),
          const SizedBox(height: Dimens.gapS),
          TextButton(
            onPressed: () => ref.read(scanFlowProvider.notifier).reset(),
            child: Text(l10n.t(K.commonDone)),
          ),
        ],
      ),
    );
  }
}

class _QualityNotice extends StatelessWidget {
  const _QualityNotice({required this.quality});

  final ImageQualityReport quality;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    if (quality.isUsable) {
      return NoticeBanner(
        icon: Icons.check_circle_outline,
        message: l10n.t(K.scanQualityGood),
      );
    }
    return NoticeBanner(
      tone: NoticeTone.warning,
      icon: Icons.blur_on,
      message: l10n.t(
        quality.isBlurry
            ? K.scanQualityBlurry
            : quality.isTooDark
                ? K.scanQualityDark
                : K.scanQualityBright,
      ),
    );
  }
}

String? _sourceLabel(AppLocalizations l10n, FieldSource source) => switch (source) {
      FieldSource.barcodeGs1 => l10n.t(K.scanReadFromBarcode),
      FieldSource.ocr => l10n.t(K.scanReadFromPhoto),
      FieldSource.catalogDefault => l10n.t(K.scanFromCatalog),
      FieldSource.manual => l10n.t(K.scanEnteredManually),
      FieldSource.none => null,
    };

class _DateField extends StatelessWidget {
  const _DateField({
    required this.label,
    required this.value,
    required this.precision,
    required this.source,
    required this.onChanged,
    this.onPrecisionChanged,
    this.optional = false,
    this.icon = Icons.event,
    this.onTap,
  });

  final String label;
  final DateTime? value;
  final ExpiryPrecision precision;
  final FieldSource source;
  final ValueChanged<DateTime?> onChanged;
  final ValueChanged<ExpiryPrecision>? onPrecisionChanged;
  final bool optional;

  final IconData icon;

  /// Replaces the plain date picker. The expiry field uses this to open the
  /// calculator instead.
  final VoidCallback? onTap;

  Future<void> _pick(BuildContext context) async {
    final DateTime now = DateTime.now();
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate: value ?? now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 15),
    );
    if (date == null) return;
    if (precision.isHourly && context.mounted) {
      final TimeOfDay? time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(value ?? now),
      );
      if (time != null) {
        onChanged(DateTime(date.year, date.month, date.day, time.hour, time.minute));
        return;
      }
    }
    onChanged(date);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final String? caption = _sourceLabel(l10n, source);

    return AppCard(
      onTap: onTap ?? () => _pick(context),
      child: Row(
        children: <Widget>[
          Icon(icon, color: theme.colorScheme.primary),
          const SizedBox(width: Dimens.gapM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  label,
                  style: theme.textTheme.labelMedium
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 2),
                Text(
                  value == null
                      ? (optional ? l10n.t(K.commonNotSet) : l10n.t(K.commonRequired))
                      : (precision.isHourly ? l10n.dateTime(value!) : l10n.date(value!)),
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: value == null && !optional ? theme.colorScheme.error : null,
                  ),
                ),
                if (caption != null)
                  Text(
                    caption,
                    style: theme.textTheme.bodySmall
                        ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
              ],
            ),
          ),
          if (onPrecisionChanged != null)
            IconButton(
              tooltip: precision.isHourly ? l10n.t(K.recordHourly) : l10n.t(K.recordDaily),
              onPressed: () => onPrecisionChanged!(
                precision.isHourly ? ExpiryPrecision.day : ExpiryPrecision.hour,
              ),
              icon: Icon(precision.isHourly ? Icons.schedule : Icons.calendar_today),
            ),
          if (value != null && optional)
            IconButton(
              onPressed: () => onChanged(null),
              icon: const Icon(Icons.clear),
            ),
        ],
      ),
    );
  }
}


/// The optional photograph of the product's face, on the goods-in review step.
///
/// Kept optional deliberately: the barcode and the printed date are what the
/// policy engine actually needs. The picture is for the human who later has to
/// find this exact lot on a shelf, which is why it is offered rather than
/// demanded - a required photo would make every intake slower for a benefit
/// that only sometimes matters.
class _ProductPhotoCard extends StatelessWidget {
  const _ProductPhotoCard({
    required this.path,
    required this.onPick,
    required this.onRemove,
  });

  final String? path;
  final Future<void> Function() onPick;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final String? current = path;
    final bool hasPhoto = current != null && current.isNotEmpty;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.photo_camera_outlined, color: theme.colorScheme.primary),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  '${l10n.t(K.scanProductPhoto)} (${l10n.t(K.commonOptional)})',
                  style: theme.textTheme.titleSmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimens.gapXs),
          Text(
            l10n.t(K.scanProductPhotoHint),
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          if (hasPhoto) ...<Widget>[
            const SizedBox(height: Dimens.gapM),
            ClipRRect(
              borderRadius: BorderRadius.circular(Dimens.radiusSmall),
              child: Image.file(
                File(current),
                height: 140,
                width: double.infinity,
                fit: BoxFit.cover,
                // A capture that was cleaned up between steps must not break
                // the whole review screen.
                errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                    const SizedBox.shrink(),
              ),
            ),
          ],
          const SizedBox(height: Dimens.gapS),
          Row(
            children: <Widget>[
              OutlinedButton.icon(
                onPressed: onPick,
                icon: Icon(hasPhoto ? Icons.refresh : Icons.photo_camera_outlined),
                label: Text(
                  hasPhoto ? l10n.t(K.scanRetakePhoto) : l10n.t(K.scanProductPhoto),
                ),
              ),
              if (hasPhoto) ...<Widget>[
                const SizedBox(width: Dimens.gapS),
                TextButton.icon(
                  onPressed: onRemove,
                  icon: const Icon(Icons.close),
                  label: Text(l10n.t(K.scanRemovePhoto)),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
