import 'dart:io';

import 'package:collection/collection.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/presentation/pages/product_form_page.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_list_view_model.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/disposal_calculator_page.dart';
import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scan_outcome.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/camera_capture_page.dart';
import 'package:expiry_guardian/features/scan/presentation/viewmodels/scan_flow_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Goods-in. Three steps, each a single tap:
/// scan the barcode, photograph the dates, save.
class ScanPage extends ConsumerWidget {
  const ScanPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.scanTitle)),
        actions: <Widget>[
          if (state.step != ScanStep.start)
            TextButton(
              onPressed: () => ref.read(scanFlowProvider.notifier).reset(),
              child: Text(l10n.t(K.commonClear)),
            ),
        ],
      ),
      body: switch (state.step) {
        ScanStep.start => const _StartStep(),
        ScanStep.needsProduct => const _UnknownProductStep(),
        ScanStep.review => const _ReviewStep(),
        ScanStep.saved => const _SavedStep(),
      },
    );
  }
}

Future<void> _captureBarcode(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  // Live mode: the viewfinder reads the code itself, so a shaky hand and a
  // small printed barcode stop being a dead end.
  final CaptureResult? shot = await CameraCapturePage.open(
    context,
    title: l10n.t(K.scanStepBarcode),
    hint: l10n.t(K.scanAimBarcode),
    liveBarcode: true,
  );
  if (shot == null) return;
  if (shot.path.isEmpty && shot.codes.isEmpty) return;
  await ref
      .read(scanFlowProvider.notifier)
      .processBarcodeCapture(shot.path, alreadyRead: shot.codes);

  // A barcode the store has seen before arrives with its name, unit, price and
  // shelf already filled in, so the only thing still missing is the dates.
  // Walking the employee to that step is the whole point of remembering the
  // product; making them find the button again is not.
  if (!context.mounted) return;
  final ScanFlowState after = ref.read(scanFlowProvider);
  final bool autoAdvance = ref
      .read(settingsStoreProvider)
      .readBool(SettingKeys.scanAutoAdvance, SettingDefaults.scanAutoAdvance);
  if (autoAdvance &&
      after.step == ScanStep.review &&
      after.needsManualDate &&
      !after.busy) {
    await _captureLabel(context, ref);
  }
}

Future<void> _captureLabel(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  // Live mode here too: a printed date is small, low contrast and often on a
  // curved surface - the single attempt a photograph gets is exactly what the
  // recogniser handles worst.
  final CaptureResult? shot = await CameraCapturePage.open(
    context,
    title: l10n.t(K.scanStepDates),
    hint: l10n.t(K.scanAimLabel),
    liveText: true,
  );
  if (shot == null) return;
  if (shot.path.isEmpty && shot.lines.isEmpty) return;
  await ref
      .read(scanFlowProvider.notifier)
      .processLabelCapture(shot.path, alreadyReadLines: shot.lines);
}

/// Opens the calculator to settle the expiry, seeded with whatever the scan
/// already read so a correct OCR reading only has to be confirmed.
Future<void> _openCalculator(BuildContext context, WidgetRef ref) async {
  final ScanFlowState state = ref.read(scanFlowProvider);
  final CalculatorPick? pick = await DisposalCalculatorPage.pick(
    context,
    expiry: state.expiry,
    manufacturing: state.manufactured,
  );
  if (pick == null) return;
  final ScanFlowController controller = ref.read(scanFlowProvider.notifier);
  controller.setExpiry(
    pick.expiry,
    precision: pick.hasTimeOfDay ? ExpiryPrecision.hour : ExpiryPrecision.day,
  );
  final DateTime? made = pick.manufacturing;
  if (made != null) controller.setManufactured(made);
}

class _StartStep extends ConsumerWidget {
  const _StartStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return ListView(
      padding: const EdgeInsets.all(Dimens.gutter),
      children: <Widget>[
        const SizedBox(height: Dimens.gapL),
        Icon(
          Icons.qr_code_scanner,
          size: 96,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(height: Dimens.gapL),
        Text(
          l10n.t(K.scanStepBarcode),
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: Dimens.gapS),
        Text(
          l10n.t(K.scanAimBarcode),
          textAlign: TextAlign.center,
          style: Theme.of(context)
              .textTheme
              .bodyMedium
              ?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
        const SizedBox(height: Dimens.gapXl),
        if (state.busy)
          const LoadingView()
        else
          FilledButton.icon(
            onPressed: () => _captureBarcode(context, ref),
            icon: const Icon(Icons.photo_camera),
            label: Text(l10n.t(K.scanCapture)),
          ),
        const SizedBox(height: Dimens.gapM),
        OutlinedButton.icon(
          onPressed: () => _promptForBarcode(context, ref),
          icon: const Icon(Icons.keyboard),
          label: Text(l10n.t(K.scanEnterBarcode)),
        ),
        if (state.failure != null) ...<Widget>[
          const SizedBox(height: Dimens.gapL),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.error_outline,
            message: describeFailure(context, state.failure!),
          ),
        ],
        if (state.outcome.codes.isEmpty && state.outcome.quality != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          _QualityNotice(quality: state.outcome.quality!),
        ],
        // The scan kept its picture even though no decoder could read it. That
        // picture is the whole point: the number is perfectly legible to a
        // person, so it is shown here and typed in underneath rather than the
        // capture being thrown away and asked for again.
        if (!state.hasBarcode && state.barcodePhotoPath != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          _BarcodePhotoCard(
            path: state.barcodePhotoPath!,
            message: l10n.t(K.scanBarcodeNotRead),
            onRetake: () => _captureBarcode(context, ref),
          ),
          const SizedBox(height: Dimens.gapM),
          _ManualBarcodeField(
            onSubmitted: (String value) =>
                ref.read(scanFlowProvider.notifier).setBarcodeManually(value),
          ),
        ],
      ],
    );
  }
}

Future<void> _promptForBarcode(BuildContext context, WidgetRef ref) async {
  final AppLocalizations l10n = context.l10n;
  final TextEditingController controller = TextEditingController();
  final String? value = await showDialog<String>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: Text(l10n.t(K.scanEnterBarcode)),
      content: TextField(
        controller: controller,
        autofocus: true,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(labelText: l10n.t(K.recordBarcode)),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.t(K.commonCancel)),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(controller.text.trim()),
          child: Text(l10n.t(K.commonNext)),
        ),
      ],
    ),
  );
  controller.dispose();
  if (value == null || value.isEmpty) return;
  ref.read(scanFlowProvider.notifier).setBarcodeManually(value);
}

/// The still taken while aiming at the barcode, shown so the number can be
/// read off it by eye.
class _BarcodePhotoCard extends StatelessWidget {
  const _BarcodePhotoCard({
    required this.path,
    required this.message,
    this.onRetake,
  });

  final String path;
  final String message;
  final VoidCallback? onRetake;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.qr_code_2, color: theme.colorScheme.primary),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  l10n.t(K.scanBarcodePhoto),
                  style: theme.textTheme.titleSmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimens.gapXs),
          Text(
            message,
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: Dimens.gapM),
          ClipRRect(
            borderRadius: BorderRadius.circular(Dimens.radiusSmall),
            child: Image.file(
              File(path),
              height: 180,
              width: double.infinity,
              fit: BoxFit.contain,
              errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                  const SizedBox.shrink(),
            ),
          ),
          if (onRetake != null) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            OutlinedButton.icon(
              onPressed: onRetake,
              icon: const Icon(Icons.replay),
              label: Text(l10n.t(K.scanRetake)),
            ),
          ],
        ],
      ),
    );
  }
}

/// A small preview of the barcode still, for the steps that only need to show
/// that it was kept.
class _BarcodeThumb extends StatelessWidget {
  const _BarcodeThumb({required this.path});

  final String path;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        ClipRRect(
          borderRadius: BorderRadius.circular(Dimens.radiusSmall),
          child: Image.file(
            File(path),
            width: 96,
            height: 72,
            fit: BoxFit.cover,
            errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                const SizedBox.shrink(),
          ),
        ),
        const SizedBox(width: Dimens.gapM),
        Expanded(
          child: Text(
            l10n.t(K.scanBarcodePhotoKept),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ),
      ],
    );
  }
}

/// Typing the number in, right under the photograph it was read from.
class _ManualBarcodeField extends StatefulWidget {
  const _ManualBarcodeField({required this.onSubmitted});

  final ValueChanged<String> onSubmitted;

  @override
  State<_ManualBarcodeField> createState() => _ManualBarcodeFieldState();
}

class _ManualBarcodeFieldState extends State<_ManualBarcodeField> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final String value = _controller.text.trim();
    if (value.isEmpty) return;
    widget.onSubmitted(value);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextField(
            controller: _controller,
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(labelText: l10n.t(K.scanTypeBarcode)),
            onSubmitted: (_) => _submit(),
          ),
          const SizedBox(height: Dimens.gapM),
          FilledButton.icon(
            onPressed: _submit,
            icon: const Icon(Icons.check),
            label: Text(l10n.t(K.commonNext)),
          ),
        ],
      ),
    );
  }
}

class _UnknownProductStep extends ConsumerWidget {
  const _UnknownProductStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return ListView(
      padding: const EdgeInsets.all(Dimens.gutter),
      children: <Widget>[
        NoticeBanner(
          tone: NoticeTone.warning,
          icon: Icons.help_outline,
          message: l10n.t(K.scanUnknownProduct),
        ),
        const SizedBox(height: Dimens.gapM),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              DetailRow(
                label: l10n.t(K.recordBarcode),
                value: state.barcode ?? l10n.t(K.commonUnknown),
              ),
              if (state.barcodePhotoPath != null) ...<Widget>[
                const SizedBox(height: Dimens.gapS),
                _BarcodeThumb(path: state.barcodePhotoPath!),
              ],
              const SizedBox(height: Dimens.gapS),
              Text(
                l10n.t(K.scanUnknownProductHint),
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
        const SizedBox(height: Dimens.gapL),
        FilledButton.icon(
          onPressed: () async {
            final Product? created = await ProductFormPage.open(
              context,
              initialBarcode: state.barcode,
              initialBarcodePhotoPath: state.barcodePhotoPath,
            );
            if (created != null) {
              ref.read(scanFlowProvider.notifier).attachProduct(created);
            }
          },
          icon: const Icon(Icons.add),
          label: Text(l10n.t(K.scanCreateProduct)),
        ),
        const SizedBox(height: Dimens.gapM),
        OutlinedButton.icon(
          onPressed: () => _captureBarcode(context, ref),
          icon: const Icon(Icons.replay),
          label: Text(l10n.t(K.scanRetake)),
        ),
      ],
    );
  }
}

class _ReviewStep extends ConsumerWidget {
  const _ReviewStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final ScanFlowState state = ref.watch(scanFlowProvider);
    final ScanFlowController controller = ref.read(scanFlowProvider.notifier);
    final String currency = ref.watch(currencySymbolProvider);
    final List<ShelfLocation> shelves =
        ref.watch(shelfLocationsProvider).valueOrNull ?? const <ShelfLocation>[];

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gapXl * 2,
      ),
      children: <Widget>[
        AppCard(
          child: Row(
            children: <Widget>[
              const Icon(Icons.check_circle, color: Colors.green),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      state.product!.displayName,
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    Text(
                      state.barcode ?? '',
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        if (state.outcome.quality != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          _QualityNotice(quality: state.outcome.quality!),
        ],
        if (state.outcome.enhancementSteps.isNotEmpty) ...<Widget>[
          const SizedBox(height: Dimens.gapS),
          NoticeBanner(
            icon: Icons.auto_fix_high,
            message: l10n.t(K.scanEnhanced, <String, Object?>{
              'steps': state.outcome.enhancementSteps.join(', '),
            }),
          ),
        ],
        for (final LabelWarning warning in state.warnings)
          Padding(
            padding: const EdgeInsets.only(top: Dimens.gapS),
            child: NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.warning_amber_rounded,
              message: l10n.t(switch (warning) {
                LabelWarning.ambiguousDayMonth => K.scanWarningAmbiguous,
                LabelWarning.expiryAlreadyPassed => K.scanWarningExpiryPassed,
                LabelWarning.expiryBeforeManufacturing => K.scanWarningExpiryBeforeMfg,
                LabelWarning.onlyMonthPrinted => K.scanWarningMonthOnly,
                LabelWarning.multipleExpiryCandidates => K.scanWarningMultipleExpiry,
                LabelWarning.noDatesFound => K.scanNoDateFound,
                LabelWarning.implausibleYear => K.scanCheckDates,
              },),
            ),
          ),
        SectionHeader(title: l10n.t(K.scanStepDates)),
        // The expiry is entered through the calculator rather than a bare
        // date picker. Most of the time that is still one tap on a date - the
        // calculator's first mode is exactly that - but the same screen also
        // takes "NSX + 6 tháng" and works the expiry out, which is what the
        // label actually says on a large share of goods. Picking the date
        // blind and doing that arithmetic in your head is where the mistakes
        // come from, and the screen shows the resulting destroy deadline
        // before anything is saved.
        _DateField(
          label: l10n.t(K.recordExpiryAt),
          value: state.expiry,
          precision: state.precision,
          source: state.outcome.expiry.source,
          icon: Icons.calculate_outlined,
          onTap: () => _openCalculator(context, ref),
          onChanged: (DateTime? value) => controller.setExpiry(value),
          onPrecisionChanged: (ExpiryPrecision precision) =>
              controller.setExpiry(state.expiry, precision: precision),
        ),
        const SizedBox(height: Dimens.gapS),
        _DateField(
          label: l10n.t(K.recordManufacturedAt),
          value: state.manufactured,
          precision: ExpiryPrecision.day,
          source: state.outcome.manufactured.source,
          optional: true,
          onChanged: controller.setManufactured,
        ),
        const SizedBox(height: Dimens.gapS),
        OutlinedButton.icon(
          onPressed: () => _captureLabel(context, ref),
          icon: const Icon(Icons.photo_camera_outlined),
          label: Text(
            state.expiry == null ? l10n.t(K.scanStepDates) : l10n.t(K.scanRetake),
          ),
        ),
        SectionHeader(title: l10n.t(K.scanStepReview)),
        TextFormField(
          initialValue: state.batchCode ?? '',
          decoration: InputDecoration(
            labelText: '${l10n.t(K.recordBatch)} (${l10n.t(K.commonOptional)})',
            helperText: _sourceLabel(l10n, state.outcome.batchCode.source),
          ),
          onChanged: controller.setBatch,
        ),
        const SizedBox(height: Dimens.gapM),
        Row(
          children: <Widget>[
            Expanded(
              child: TextFormField(
                initialValue: state.quantity.toString(),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: l10n.t(K.recordQuantity)),
                onChanged: (String value) => controller.setQuantity(
                  double.tryParse(value.replaceAll(',', '.')) ?? 0,
                ),
              ),
            ),
            const SizedBox(width: Dimens.gapM),
            Expanded(
              child: TextFormField(
                initialValue: state.unitCost?.toString() ?? '',
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: l10n.t(K.recordUnitCost),
                  suffixText: currency,
                ),
                onChanged: (String value) => controller
                    .setUnitCost(double.tryParse(value.replaceAll(',', '.'))),
              ),
            ),
          ],
        ),
        const SizedBox(height: Dimens.gapM),
        DropdownButtonFormField<String?>(
          initialValue: selectableShelfId(state.shelfId, shelves),
          isExpanded: true,
          decoration: InputDecoration(labelText: l10n.t(K.recordShelf)),
          items: <DropdownMenuItem<String?>>[
            DropdownMenuItem<String?>(child: Text(l10n.t(K.commonNone))),
            for (final ShelfLocation location in shelves)
              DropdownMenuItem<String?>(
                value: location.shelf.id,
                child: Text(location.label, overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: controller.setShelf,
        ),
        if (state.product != null && state.needsManualDate) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            icon: Icons.history,
            message: state.shelfId == null
                ? l10n.t(K.scanRecalledProduct)
                : l10n.t(K.scanRecalledWithShelf, <String, Object?>{
                    'shelf': shelves
                            .where((ShelfLocation l) => l.shelf.id == state.shelfId)
                            .map((ShelfLocation l) => l.label)
                            .firstOrNull ??
                        '',
                  }),
          ),
        ],
        const SizedBox(height: Dimens.gapM),
        _ProductPhotoCard(
          path: state.photoPath,
          onPick: () async {
            final CaptureResult? shot = await CameraCapturePage.open(
              context,
              title: l10n.t(K.scanProductPhoto),
              hint: l10n.t(K.scanAimProductFront),
            );
            if (shot == null || shot.path.isEmpty) return;
            controller.setProductPhoto(shot.path);
          },
          onRemove: () => controller.setProductPhoto(null),
        ),
        if (state.failure != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.error_outline,
            message: describeFailure(context, state.failure!),
          ),
        ],
        const SizedBox(height: Dimens.gapL),
        FilledButton.icon(
          onPressed: state.canSave
              ? () async {
                  final InventoryRecord? record = await controller.save();
                  if (record != null && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(l10n.t(
                          K.scanSavedRecord,
                          <String, Object?>{'code': record.code},
                        ),),
                      ),
                    );
                  }
                }
              : null,
          icon: state.busy
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2.5),
                )
              : const Icon(Icons.save),
          label: Text(l10n.t(K.scanSaveRecord)),
        ),
        if (state.needsManualDate)
          Padding(
            padding: const EdgeInsets.only(top: Dimens.gapS),
            child: Text(
              l10n.t(K.scanNoDateFound),
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
          ),
      ],
    );
  }
}

class _SavedStep extends ConsumerWidget {
  const _SavedStep();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowState state = ref.watch(scanFlowProvider);

    return EmptyState(
      icon: Icons.check_circle_outline,
      title: l10n.t(K.scanSavedRecord, <String, Object?>{'code': state.savedCode ?? ''}),
      action: Column(
        children: <Widget>[
          FilledButton.icon(
            onPressed: () {
              ref.read(scanFlowProvider.notifier).reset();
              _captureBarcode(context, ref);
            },
            icon: const Icon(Icons.qr_code_scanner),
            label: Text(l10n.t(K.scanScanNext)),
          ),
          const SizedBox(height: Dimens.gapS),
          TextButton(
            onPressed: () => ref.read(scanFlowProvider.notifier).reset(),
            child: Text(l10n.t(K.commonDone)),
          ),
        ],
      ),
    );
  }
}

class _QualityNotice extends StatelessWidget {
  const _QualityNotice({required this.quality});

  final ImageQualityReport quality;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    if (quality.isUsable) {
      return NoticeBanner(
        icon: Icons.check_circle_outline,
        message: l10n.t(K.scanQualityGood),
      );
    }
    return NoticeBanner(
      tone: NoticeTone.warning,
      icon: Icons.blur_on,
      message: l10n.t(
        quality.isBlurry
            ? K.scanQualityBlurry
            : quality.isTooDark
                ? K.scanQualityDark
                : K.scanQualityBright,
      ),
    );
  }
}

String? _sourceLabel(AppLocalizations l10n, FieldSource source) => switch (source) {
      FieldSource.barcodeGs1 => l10n.t(K.scanReadFromBarcode),
      FieldSource.ocr => l10n.t(K.scanReadFromPhoto),
      FieldSource.catalogDefault => l10n.t(K.scanFromCatalog),
      FieldSource.manual => l10n.t(K.scanEnteredManually),
      FieldSource.none => null,
    };

class _DateField extends StatelessWidget {
  const _DateField({
    required this.label,
    required this.value,
    required this.precision,
    required this.source,
    required this.onChanged,
    this.onPrecisionChanged,
    this.optional = false,
    this.icon = Icons.event,
    this.onTap,
  });

  final String label;
  final DateTime? value;
  final ExpiryPrecision precision;
  final FieldSource source;
  final ValueChanged<DateTime?> onChanged;
  final ValueChanged<ExpiryPrecision>? onPrecisionChanged;
  final bool optional;

  final IconData icon;

  /// Replaces the plain date picker. The expiry field uses this to open the
  /// calculator instead.
  final VoidCallback? onTap;

  Future<void> _pick(BuildContext context) async {
    final DateTime now = DateTime.now();
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate: value ?? now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 15),
    );
    if (date == null) return;
    if (precision.isHourly && context.mounted) {
      final TimeOfDay? time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(value ?? now),
      );
      if (time != null) {
        onChanged(DateTime(date.year, date.month, date.day, time.hour, time.minute));
        return;
      }
    }
    onChanged(date);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final String? caption = _sourceLabel(l10n, source);

    return AppCard(
      onTap: onTap ?? () => _pick(context),
      child: Row(
        children: <Widget>[
          Icon(icon, color: theme.colorScheme.primary),
          const SizedBox(width: Dimens.gapM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  label,
                  style: theme.textTheme.labelMedium
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 2),
                Text(
                  value == null
                      ? (optional ? l10n.t(K.commonNotSet) : l10n.t(K.commonRequired))
                      : (precision.isHourly ? l10n.dateTime(value!) : l10n.date(value!)),
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: value == null && !optional ? theme.colorScheme.error : null,
                  ),
                ),
                if (caption != null)
                  Text(
                    caption,
                    style: theme.textTheme.bodySmall
                        ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
              ],
            ),
          ),
          if (onPrecisionChanged != null)
            IconButton(
              tooltip: precision.isHourly ? l10n.t(K.recordHourly) : l10n.t(K.recordDaily),
              onPressed: () => onPrecisionChanged!(
                precision.isHourly ? ExpiryPrecision.day : ExpiryPrecision.hour,
              ),
              icon: Icon(precision.isHourly ? Icons.schedule : Icons.calendar_today),
            ),
          if (value != null && optional)
            IconButton(
              onPressed: () => onChanged(null),
              icon: const Icon(Icons.clear),
            ),
        ],
      ),
    );
  }
}


/// The optional photograph of the product's face, on the goods-in review step.
///
/// Kept optional deliberately: the barcode and the printed date are what the
/// policy engine actually needs. The picture is for the human who later has to
/// find this exact lot on a shelf, which is why it is offered rather than
/// demanded - a required photo would make every intake slower for a benefit
/// that only sometimes matters.
class _ProductPhotoCard extends StatelessWidget {
  const _ProductPhotoCard({
    required this.path,
    required this.onPick,
    required this.onRemove,
  });

  final String? path;
  final Future<void> Function() onPick;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final String? current = path;
    final bool hasPhoto = current != null && current.isNotEmpty;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.photo_camera_outlined, color: theme.colorScheme.primary),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  '${l10n.t(K.scanProductPhoto)} (${l10n.t(K.commonOptional)})',
                  style: theme.textTheme.titleSmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimens.gapXs),
          Text(
            l10n.t(K.scanProductPhotoHint),
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          if (hasPhoto) ...<Widget>[
            const SizedBox(height: Dimens.gapM),
            ClipRRect(
              borderRadius: BorderRadius.circular(Dimens.radiusSmall),
              child: Image.file(
                File(current),
                height: 140,
                width: double.infinity,
                fit: BoxFit.cover,
                // A capture that was cleaned up between steps must not break
                // the whole review screen.
                errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                    const SizedBox.shrink(),
              ),
            ),
          ],
          const SizedBox(height: Dimens.gapS),
          Row(
            children: <Widget>[
              OutlinedButton.icon(
                onPressed: onPick,
                icon: Icon(hasPhoto ? Icons.refresh : Icons.photo_camera_outlined),
                label: Text(
                  hasPhoto ? l10n.t(K.scanRetakePhoto) : l10n.t(K.scanProductPhoto),
                ),
              ),
              if (hasPhoto) ...<Widget>[
                const SizedBox(width: Dimens.gapS),
                TextButton.icon(
                  onPressed: onRemove,
                  icon: const Icon(Icons.close),
                  label: Text(l10n.t(K.scanRemovePhoto)),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
