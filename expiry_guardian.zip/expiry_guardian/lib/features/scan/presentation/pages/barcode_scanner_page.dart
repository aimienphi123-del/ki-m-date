import 'dart:async';
import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/camera_capture_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart' as ms;

/// The formats a shop actually meets: retail EAN/UPC, the Code 128 and ITF on
/// cartons, and the 2D codes on newer packs. Leaving out the exotic ones makes
/// every frame cheaper to decode.
const List<ms.BarcodeFormat> retailFormats = <ms.BarcodeFormat>[
  ms.BarcodeFormat.ean13,
  ms.BarcodeFormat.ean8,
  ms.BarcodeFormat.upcA,
  ms.BarcodeFormat.upcE,
  ms.BarcodeFormat.code128,
  ms.BarcodeFormat.code39,
  ms.BarcodeFormat.code93,
  ms.BarcodeFormat.itf14,
  ms.BarcodeFormat.codabar,
  ms.BarcodeFormat.qrCode,
  ms.BarcodeFormat.dataMatrix,
];

/// Maps a mobile_scanner result onto the app's own code type.
ScannedCode? scannedCodeFrom(ms.Barcode barcode) {
  final String raw = barcode.rawValue ?? '';
  if (raw.isEmpty) return null;
  final Rect? box = barcode.corners.isEmpty
      ? null
      : Rect.fromPoints(
          Offset(
            barcode.corners.map((Offset o) => o.dx).reduce((double a, double b) => a < b ? a : b),
            barcode.corners.map((Offset o) => o.dy).reduce((double a, double b) => a < b ? a : b),
          ),
          Offset(
            barcode.corners.map((Offset o) => o.dx).reduce((double a, double b) => a > b ? a : b),
            barcode.corners.map((Offset o) => o.dy).reduce((double a, double b) => a > b ? a : b),
          ),
        );
  return ScannedCode(
    rawValue: raw,
    displayValue: barcode.displayValue,
    format: switch (barcode.format) {
      ms.BarcodeFormat.ean13 => CodeFormat.ean13,
      ms.BarcodeFormat.ean8 => CodeFormat.ean8,
      ms.BarcodeFormat.upcA => CodeFormat.upcA,
      ms.BarcodeFormat.upcE => CodeFormat.upcE,
      ms.BarcodeFormat.code128 => CodeFormat.code128,
      ms.BarcodeFormat.code39 => CodeFormat.code39,
      ms.BarcodeFormat.code93 => CodeFormat.code93,
      ms.BarcodeFormat.itf14 => CodeFormat.itf,
      ms.BarcodeFormat.codabar => CodeFormat.codabar,
      ms.BarcodeFormat.dataMatrix => CodeFormat.dataMatrix,
      ms.BarcodeFormat.qrCode => CodeFormat.qrCode,
      ms.BarcodeFormat.pdf417 => CodeFormat.pdf417,
      ms.BarcodeFormat.aztec => CodeFormat.aztec,
      _ => CodeFormat.unknown,
    },
    boundingBox: box == null ? null : ScanBox(box.left, box.top, box.right, box.bottom),
  );
}

/// The barcode scanner.
///
/// Built on mobile_scanner rather than on the general camera screen. The camera
/// screen hands every frame from the native side to Dart and back to ML Kit -
/// several megabytes per frame over two platform channels - and leaves focus,
/// lens choice and stream resolution to guesswork. mobile_scanner runs CameraX
/// and ML Kit together natively, which is how retail scanners on Android are
/// actually built, and only crosses into Dart once a code has been read.
///
/// The frame the code was read from is kept as the barcode photograph. When
/// nothing will scan - a crumpled foil lid, a code half torn off - the photo
/// button takes an ordinary still, reads it once more turned and cleaned up,
/// and hands it back either way so the number can be typed off the picture.
class BarcodeScannerPage extends ConsumerStatefulWidget {
  const BarcodeScannerPage({required this.title, required this.hint, super.key});

  final String title;
  final String hint;

  static Future<CaptureResult?> open(
    BuildContext context, {
    required String title,
    required String hint,
  }) {
    return Navigator.of(context).push<CaptureResult>(
      MaterialPageRoute<CaptureResult>(
        builder: (_) => BarcodeScannerPage(title: title, hint: hint),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  ConsumerState<BarcodeScannerPage> createState() => _BarcodeScannerPageState();
}

class _BarcodeScannerPageState extends ConsumerState<BarcodeScannerPage> {
  final ms.MobileScannerController _controller = ms.MobileScannerController(
    formats: retailFormats,
    returnImage: true,
    // Android's default analysis stream is 640x480, on which a bar of a
    // three-centimetre EAN-13 is barely a pixel. 720p is where retail codes
    // read reliably without starving older phones of frames.
    cameraResolution: const Size(1280, 720),
    detectionTimeoutMs: 150,
    // Zooms in by itself when a code is found but too small to decode -
    // instead of a fixed zoom, which on some phones switches to a telephoto
    // lens that cannot focus at arm's length.
    autoZoom: true,
  );

  bool _finished = false;
  bool _readingStill = false;

  @override
  void dispose() {
    unawaited(_controller.dispose());
    super.dispose();
  }

  Future<void> _onDetect(ms.BarcodeCapture capture) async {
    if (_finished) return;
    final List<ScannedCode> codes = <ScannedCode>[
      for (final ms.Barcode b in capture.barcodes)
        if (scannedCodeFrom(b) case final ScannedCode code) code,
    ];
    if (codes.isEmpty) return;
    _finished = true;
    unawaited(HapticFeedback.mediumImpact());
    final String path = await _keep(capture.image);
    await _controller.stop();
    if (!mounted) return;
    Navigator.of(context).pop(CaptureResult(path: path, codes: codes));
  }

  /// Saves the frame the code was read from as the product's barcode photo.
  Future<String> _keep(Uint8List? jpeg) async {
    if (jpeg == null || jpeg.isEmpty) return '';
    try {
      final String path =
          '${await capturesDirectory()}/barcode_${DateTime.now().millisecondsSinceEpoch}.jpg';
      await File(path).writeAsBytes(jpeg, flush: true);
      return path;
    } on Object catch (error) {
      // The code is what matters; a photo that could not be kept is not a
      // reason to throw a good read away.
      ref.read(loggerProvider).w('BarcodeScanner', 'Could not keep the frame: $error');
      return '';
    }
  }

  /// The way out when nothing scans: an ordinary photograph, read once more.
  Future<void> _photoInstead() async {
    if (_finished) return;
    _finished = true;
    // Two screens cannot hold the camera at once.
    await _controller.stop();
    if (!mounted) return;
    final CaptureResult? shot = await CameraCapturePage.open(
      context,
      title: widget.title,
      hint: widget.hint,
    );
    if (!mounted) return;
    if (shot == null || shot.path.isEmpty) {
      // Backed out of the photo: go back to scanning.
      _finished = false;
      await _controller.start();
      return;
    }
    setState(() => _readingStill = true);
    final List<ScannedCode> codes =
        await ref.read(scanPipelineProvider).readBarcodes(shot.path);
    if (!mounted) return;
    Navigator.of(context).pop(CaptureResult(path: shot.path, codes: codes));
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title),
        actions: <Widget>[
          ValueListenableBuilder<ms.MobileScannerState>(
            valueListenable: _controller,
            builder: (BuildContext context, ms.MobileScannerState state, _) {
              if (state.torchState == ms.TorchState.unavailable) {
                return const SizedBox.shrink();
              }
              return IconButton(
                tooltip: l10n.t(K.scanTorch),
                onPressed: _controller.toggleTorch,
                icon: Icon(
                  state.torchState == ms.TorchState.on
                      ? Icons.flashlight_on
                      : Icons.flashlight_off,
                ),
              );
            },
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          ms.MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            tapToFocus: true,
            errorBuilder: (BuildContext context, ms.MobileScannerException error) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(Dimens.gapXl),
                  child: Text(
                    error.errorCode == ms.MobileScannerErrorCode.permissionDenied
                        ? l10n.t(K.scanPermissionBody)
                        : l10n.t(K.scanScannerError),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              );
            },
          ),
          const IgnorePointer(child: _ScanFrame()),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(Dimens.gutter),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.55),
                        borderRadius: BorderRadius.circular(Dimens.radiusSmall),
                      ),
                      child: Text(
                        _readingStill ? l10n.t(K.scanReadingStill) : l10n.t(K.scanLiveHint),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 15),
                      ),
                    ),
                    const SizedBox(height: Dimens.gapL),
                    FilledButton.icon(
                      onPressed: _readingStill ? null : _photoInstead,
                      icon: _readingStill
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.camera_alt),
                      label: Text(l10n.t(K.scanPhotoInstead)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ScanFrame extends StatelessWidget {
  const _ScanFrame();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: FractionallySizedBox(
        widthFactor: 0.86,
        heightFactor: 0.28,
        child: DecoratedBox(
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFF4CD964), width: 3),
            borderRadius: BorderRadius.circular(Dimens.radius),
          ),
        ),
      ),
    );
  }
}
