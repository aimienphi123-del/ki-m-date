import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/services/camera_tuning.dart';
import 'package:expiry_guardian/features/scan/domain/services/frame_rotation.dart';
import 'package:expiry_guardian/features/scan/domain/services/label_text_parser.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

/// Where captured stills live.
///
/// Deliberately **not** the temporary directory. A still taken here is not a
/// scratch file: it is attached to the stock record and, when the store
/// requires a photo on destruction, it is the evidence that the destruction
/// happened. Android empties the cache directory whenever it wants storage
/// back, which would quietly erase exactly those photographs - and the record
/// screens, which already guard with `existsSync()`, would simply stop showing
/// them. The documents directory is app-private and survives.
Future<String> capturesDirectory() async {
  final Directory documents = await getApplicationDocumentsDirectory();
  final Directory captures = Directory('${documents.path}/captures');
  if (!captures.existsSync()) await captures.create(recursive: true);
  return captures.path;
}

/// What one visit to the camera produced.
class CaptureResult {
  const CaptureResult({
    required this.path,
    this.codes = const <ScannedCode>[],
    this.lines = const <RecognisedLine>[],
  });

  /// The still that was saved, for the record and for OCR.
  final String path;

  /// Codes the live scanner decoded off the viewfinder before the still was
  /// taken. Empty when the employee used the shutter button instead.
  final List<ScannedCode> codes;

  /// Text lines the live recogniser read off the viewfinder, for the same
  /// reason: many attempts beat the single attempt a photograph gets.
  final List<RecognisedLine> lines;
}

/// A single-purpose camera screen: frame something, get a file back.
///
/// With [liveBarcode] it also behaves like a real scanner - it reads the
/// viewfinder continuously and returns the moment it decodes a code, without
/// anybody pressing anything. That distinction matters: a retail barcode
/// photographed once, by hand, at arm's length is frequently unreadable, while
/// the same barcode held in front of a running stream decodes within a second.
/// The shutter button stays, for a damaged or missing barcode.
class CameraCapturePage extends ConsumerStatefulWidget {
  const CameraCapturePage({
    required this.title,
    required this.hint,
    this.liveBarcode = false,
    this.liveText = false,
    this.showTorchByDefault = false,
    super.key,
  });

  final String title;
  final String hint;
  final bool liveBarcode;

  /// Read printed dates off the stream and return as soon as one resolves.
  final bool liveText;
  final bool showTorchByDefault;

  static Future<CaptureResult?> open(
    BuildContext context, {
    required String title,
    required String hint,
    bool liveBarcode = false,
    bool liveText = false,
  }) {
    return Navigator.of(context).push<CaptureResult>(
      MaterialPageRoute<CaptureResult>(
        builder: (_) => CameraCapturePage(
          title: title,
          hint: hint,
          liveBarcode: liveBarcode,
          liveText: liveText,
        ),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  ConsumerState<CameraCapturePage> createState() => _CameraCapturePageState();
}

class _CameraCapturePageState extends ConsumerState<CameraCapturePage>
    with WidgetsBindingObserver {
  CameraController? _controller;
  CameraDescription? _camera;
  Future<void>? _initialization;
  bool _torchOn = false;
  bool _capturing = false;
  bool _permissionDenied = false;
  String? _error;

  /// One frame in flight at a time. Without this the stream queues frames
  /// faster than the detector drains them and the preview stutters badly.
  bool _analysing = false;
  bool _streaming = false;
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _torchOn = widget.showTorchByDefault;
    _initialization = _setUp();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(_teardown());
    super.dispose();
  }

  Future<void> _teardown() async {
    final CameraController? controller = _controller;
    _controller = null;
    if (controller == null) return;
    try {
      if (_streaming && controller.value.isStreamingImages) {
        await controller.stopImageStream();
      }
    } on Object {
      // Tearing down is best effort; a controller that is already gone is
      // not a problem worth reporting to a shop assistant.
    }
    _streaming = false;
    await controller.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final CameraController? controller = _controller;
    if (state == AppLifecycleState.inactive) {
      if (controller == null || !controller.value.isInitialized) return;
      unawaited(_teardown());
    } else if (state == AppLifecycleState.resumed) {
      if (_controller != null || _finished) return;
      setState(() => _initialization = _setUp());
    }
  }

  Future<void> _setUp() async {
    final PermissionStatus status = await Permission.camera.request();
    if (!status.isGranted) {
      if (mounted) setState(() => _permissionDenied = true);
      return;
    }
    try {
      final List<CameraDescription> cameras = await availableCameras();
      if (cameras.isEmpty) {
        if (mounted) setState(() => _error = 'no_camera');
        return;
      }
      final CameraDescription back = cameras.firstWhere(
        (CameraDescription c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      _camera = back;

      // A printed EAN-13 is only a couple of millimetres of bar per digit. At
      // 720p, held at a natural distance, a bar lands on barely one pixel and
      // no decoder can recover it - so ask for the highest sensible
      // resolution and step down only if the hardware refuses.
      final CameraController controller = await _openAtBestResolution(back);
      await controller.setFocusMode(FocusMode.auto);
      if (widget.liveBarcode || widget.liveText) {
        await _zoomForReading(controller);
      }
      if (_torchOn) {
        await controller.setFlashMode(FlashMode.torch);
      }
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() => _controller = controller);

      if (widget.liveBarcode || widget.liveText) {
        await _startScanning(controller);
      }
    } on CameraException catch (e) {
      if (mounted) setState(() => _error = e.description ?? e.code);
    }
  }

  /// Only for the steps that read print. A product photograph wants the whole
  /// pack in frame, so it stays at one times.
  Future<void> _zoomForReading(CameraController controller) async {
    try {
      await controller.setZoomLevel(readingZoomLevel(
        min: await controller.getMinZoomLevel(),
        max: await controller.getMaxZoomLevel(),
      ),);
    } on CameraException {
      // Fixed-zoom hardware exists and is not a failure worth reporting.
    }
  }

  Future<CameraController> _openAtBestResolution(
    CameraDescription camera,
  ) async {
    // The stream format has to be one ML Kit accepts directly: NV21 on
    // Android, BGRA on iOS. Stills come back as JPEG either way.
    final ImageFormatGroup group = defaultTargetPlatform == TargetPlatform.iOS
        ? ImageFormatGroup.bgra8888
        : ImageFormatGroup.nv21;

    CameraException? last;
    for (final ResolutionPreset preset in <ResolutionPreset>[
      ResolutionPreset.veryHigh,
      ResolutionPreset.high,
      ResolutionPreset.medium,
    ]) {
      final CameraController candidate = CameraController(
        camera,
        preset,
        enableAudio: false,
        imageFormatGroup: group,
      );
      try {
        await candidate.initialize();
        return candidate;
      } on CameraException catch (e) {
        last = e;
        await candidate.dispose();
      }
    }
    throw last ?? CameraException('no_resolution', 'No usable preset');
  }

  Future<void> _startScanning(CameraController controller) async {
    try {
      await controller.startImageStream(_onFrame);
      _streaming = true;
    } on CameraException catch (e) {
      // Streaming can be unavailable on some devices. The shutter button is
      // still there, so say nothing and let the employee take a photo.
      ref.read(loggerProvider).w(
            'CameraCapture',
            'Live scanning unavailable, falling back to the shutter: ${e.code}',
          );
    }
  }

  Future<void> _onFrame(CameraImage image) async {
    if (_analysing || _finished || !mounted) return;
    _analysing = true;
    try {
      final CameraFrame? frame = _toFrame(image);
      if (frame == null) return;

      if (widget.liveBarcode) {
        final List<ScannedCode> codes =
            await ref.read(barcodeReaderProvider).readFrame(frame);
        if (codes.isNotEmpty && !_finished && mounted) {
          await _finishWith(codes: codes);
          return;
        }
      }

      if (widget.liveText && mounted && !_finished) {
        final List<RecognisedLine> lines =
            await ref.read(textReaderProvider).readFrame(frame);
        if (lines.isEmpty || _finished || !mounted) return;
        // Stop on the first frame that yields a usable date rather than on the
        // first frame that yields any text at all - a label is covered in text
        // that is not a date, and returning on that would be worse than
        // returning nothing.
        if (!_parser.parse(
          lines.map((RecognisedLine l) => l.text).toList(growable: false),
          now: DateTime.now(),
        ).hasExpiry) {
          return;
        }
        await _finishWith(lines: lines);
      }
    } finally {
      _analysing = false;
    }
  }

  LabelTextParser? _cachedParser;

  /// The store's own date conventions, so the live pass agrees with the
  /// pipeline about what counts as a date. Built once and kept: this runs on
  /// every frame, and the settings cannot change while the camera is open.
  LabelTextParser get _parser {
    final LabelTextParser? cached = _cachedParser;
    if (cached != null) return cached;
    final SettingsStore settings = ref.read(settingsStoreProvider);
    return _cachedParser = LabelTextParser(
      config: LabelParserConfig(
        dayFirst: settings.readBool(
          SettingKeys.scanDayFirstDates,
          SettingDefaults.scanDayFirstDates,
        ),
        maxFutureYears: settings.readInt(
          SettingKeys.scanMaxFutureYears,
          SettingDefaults.scanMaxFutureYears,
        ),
      ),
    );
  }

  CameraFrame? _toFrame(CameraImage image) {
    if (image.planes.isEmpty) return null;
    final CameraDescription? camera = _camera;
    if (camera == null) return null;

    final Uint8List bytes;
    final CameraFrameFormat format;
    switch (image.format.group) {
      case ImageFormatGroup.nv21:
        bytes = image.planes.first.bytes;
        format = CameraFrameFormat.nv21;
      case ImageFormatGroup.bgra8888:
        bytes = image.planes.first.bytes;
        format = CameraFrameFormat.bgra8888;
      case ImageFormatGroup.yuv420:
        // Concatenated planes, which is what ML Kit expects for YUV_420_888.
        final BytesBuilder builder = BytesBuilder(copy: false);
        for (final Plane plane in image.planes) {
          builder.add(plane.bytes);
        }
        bytes = builder.toBytes();
        format = CameraFrameFormat.yuv420;
      case ImageFormatGroup.jpeg:
      case ImageFormatGroup.unknown:
        return null;
    }

    return CameraFrame(
      bytes: bytes,
      width: image.width,
      height: image.height,
      rotationDegrees: _rotationFor(camera),
      bytesPerRow: image.planes.first.bytesPerRow,
      format: format,
    );
  }

  /// See [frameRotationDegrees] for why the sensor orientation alone is not
  /// enough.
  int _rotationFor(CameraDescription camera) {
    return frameRotationDegrees(
      sensorOrientation: camera.sensorOrientation,
      deviceTurn: switch (_controller?.value.deviceOrientation) {
        DeviceOrientation.landscapeLeft => DeviceTurn.landscapeLeft,
        DeviceOrientation.portraitDown => DeviceTurn.portraitDown,
        DeviceOrientation.landscapeRight => DeviceTurn.landscapeRight,
        _ => DeviceTurn.portraitUp,
      },
      isFrontFacing: camera.lensDirection == CameraLensDirection.front,
      isIOS: defaultTargetPlatform == TargetPlatform.iOS,
    );
  }

  /// Something was read: stop looking, tell the hand that it worked, keep a
  /// still for the record, and leave.
  Future<void> _finishWith({
    List<ScannedCode> codes = const <ScannedCode>[],
    List<RecognisedLine> lines = const <RecognisedLine>[],
  }) async {
    if (_finished) return;
    _finished = true;
    final CameraController? controller = _controller;
    if (controller == null) return;

    await HapticFeedback.mediumImpact();
    if (mounted) setState(() => _capturing = true);

    try {
      if (_streaming && controller.value.isStreamingImages) {
        await controller.stopImageStream();
        _streaming = false;
      }
      final String path = await _takeStill(controller);
      if (!mounted) return;
      Navigator.of(context)
          .pop(CaptureResult(path: path, codes: codes, lines: lines));
    } on Object catch (error) {
      // The code is the valuable part; a still that failed to save must not
      // throw away a successful scan.
      ref.read(loggerProvider).w(
            'CameraCapture',
            'Read the label but could not keep the still: $error',
          );
      if (!mounted) return;
      Navigator.of(context)
          .pop(CaptureResult(path: '', codes: codes, lines: lines));
    }
  }

  Future<String> _takeStill(CameraController controller) async {
    final XFile shot = await controller.takePicture();
    final String path =
        '${await capturesDirectory()}/capture_${DateTime.now().millisecondsSinceEpoch}.jpg';
    await File(shot.path).copy(path);
    return path;
  }

  Future<void> _toggleTorch() async {
    final CameraController? controller = _controller;
    if (controller == null) return;
    final bool next = !_torchOn;
    await controller.setFlashMode(next ? FlashMode.torch : FlashMode.off);
    if (mounted) setState(() => _torchOn = next);
  }

  /// Tap the preview to focus and meter there. Small printed dates are the
  /// case that needs this most - the centre-weighted default focuses on the
  /// package, not on the two lines of text.
  Future<void> _focusAt(TapDownDetails details, BoxConstraints box) async {
    final CameraController? controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final Offset point = Offset(
      (details.localPosition.dx / box.maxWidth).clamp(0.0, 1.0),
      (details.localPosition.dy / box.maxHeight).clamp(0.0, 1.0),
    );
    try {
      await controller.setFocusPoint(point);
      await controller.setExposurePoint(point);
      await controller.setFocusMode(FocusMode.auto);
    } on CameraException {
      // Plenty of cameras cannot be told where to focus. Ignore it.
    }
  }

  Future<void> _capture() async {
    final CameraController? controller = _controller;
    if (controller == null || _capturing || _finished) return;
    setState(() => _capturing = true);
    try {
      if (_streaming && controller.value.isStreamingImages) {
        await controller.stopImageStream();
        _streaming = false;
      }
      final String path = await _takeStill(controller);
      _finished = true;
      if (!mounted) return;
      Navigator.of(context).pop(CaptureResult(path: path));
    } on CameraException catch (e) {
      if (mounted) {
        setState(() {
          _capturing = false;
          _error = e.description ?? e.code;
        });
      }
      if ((widget.liveBarcode || widget.liveText) && controller.value.isInitialized) {
        await _startScanning(controller);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title),
        actions: <Widget>[
          if (_controller != null)
            IconButton(
              tooltip: l10n.t(K.scanTorch),
              onPressed: _toggleTorch,
              icon: Icon(_torchOn ? Icons.flashlight_on : Icons.flashlight_off),
            ),
        ],
      ),
      body: FutureBuilder<void>(
        future: _initialization,
        builder: (BuildContext context, AsyncSnapshot<void> snapshot) {
          if (_permissionDenied) {
            return EmptyState(
              icon: Icons.no_photography_outlined,
              title: l10n.t(K.scanPermissionTitle),
              message: l10n.t(K.scanPermissionBody),
              action: FilledButton.icon(
                onPressed: openAppSettings,
                icon: const Icon(Icons.settings),
                label: Text(l10n.t(K.scanOpenSettings)),
              ),
            );
          }
          if (_error != null) {
            return ErrorView(
              message: l10n.t(K.errorCamera),
              onRetry: () => setState(() {
                _error = null;
                _initialization = _setUp();
              }),
            );
          }
          final CameraController? controller = _controller;
          if (controller == null || !controller.value.isInitialized) {
            return const LoadingView();
          }
          return Stack(
            fit: StackFit.expand,
            children: <Widget>[
              Center(
                child: AspectRatio(
                  aspectRatio: 1 / controller.value.aspectRatio,
                  child: LayoutBuilder(
                    builder: (BuildContext context, BoxConstraints box) {
                      return GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: (TapDownDetails d) => _focusAt(d, box),
                        child: CameraPreview(controller),
                      );
                    },
                  ),
                ),
              ),
              _ViewfinderOverlay(scanning: _streaming && !_finished),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(Dimens.gutter),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.55),
                            borderRadius:
                                BorderRadius.circular(Dimens.radiusSmall),
                          ),
                          child: Text(
                            _streaming && !_finished
                                ? l10n.t(
                                    widget.liveText
                                        ? K.scanLiveTextHint
                                        : K.scanLiveHint,
                                  )
                                : widget.hint,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                        ),
                        const SizedBox(height: Dimens.gapL),
                        SizedBox(
                          height: 84,
                          width: 84,
                          child: FilledButton(
                            onPressed: _capturing ? null : _capture,
                            style: FilledButton.styleFrom(
                              shape: const CircleBorder(),
                              padding: EdgeInsets.zero,
                            ),
                            child: _capturing
                                ? const CircularProgressIndicator(
                                    strokeWidth: 3,
                                  )
                                : const Icon(Icons.camera_alt, size: 34),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ViewfinderOverlay extends StatelessWidget {
  const _ViewfinderOverlay({this.scanning = false});

  /// Draws the frame green while the scanner is actually looking, so it is
  /// obvious that no button needs pressing.
  final bool scanning;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Center(
        child: FractionallySizedBox(
          widthFactor: 0.86,
          heightFactor: 0.34,
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: scanning
                    ? const Color(0xFF4CD964)
                    : Colors.white.withValues(alpha: 0.85),
                width: scanning ? 3 : 2,
              ),
              borderRadius: BorderRadius.circular(Dimens.radius),
            ),
          ),
        ),
      ),
    );
  }
}
