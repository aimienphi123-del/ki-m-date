import 'dart:async';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scan_outcome.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';
import 'package:expiry_guardian/features/scan/domain/services/label_text_parser.dart';
import 'package:expiry_guardian/features/scan/domain/services/scan_pipeline.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

enum ScanStep { start, needsProduct, review, saved }

class ScanFlowState {
  const ScanFlowState({
    this.step = ScanStep.start,
    this.busy = false,
    this.outcome = const ScanOutcome.empty(),
    this.barcode,
    this.product,
    this.expiry,
    this.precision = ExpiryPrecision.day,
    this.manufactured,
    this.batchCode,
    this.quantity = 1,
    this.unit,
    this.unitCost,
    this.shelfId,
    this.note,
    this.photoPath,
    this.barcodePhotoPath,
    this.failure,
    this.savedCode,
    this.warnings = const <LabelWarning>[],
  });

  final ScanStep step;
  final bool busy;
  final ScanOutcome outcome;

  final String? barcode;
  final Product? product;

  final DateTime? expiry;
  final ExpiryPrecision precision;
  final DateTime? manufactured;
  final String? batchCode;

  final double quantity;
  final String? unit;
  final double? unitCost;
  final String? shelfId;
  final String? note;
  final String? photoPath;

  /// The still taken while aiming at the barcode, kept whether or not anything
  /// decoded. It is what lets the employee type the number in by hand without
  /// losing the picture that proves which pack it came from.
  final String? barcodePhotoPath;

  final Failure? failure;
  final String? savedCode;
  final List<LabelWarning> warnings;

  bool get hasBarcode => (barcode ?? '').isNotEmpty;
  bool get canSave => product != null && expiry != null && quantity > 0 && !busy;

  /// True when the label read produced nothing and the employee has to type
  /// the date in. The app says so rather than inventing a date.
  bool get needsManualDate => expiry == null;

  ScanFlowState copyWith({
    ScanStep? step,
    bool? busy,
    ScanOutcome? outcome,
    String? barcode,
    Product? product,
    bool clearProduct = false,
    DateTime? expiry,
    bool clearExpiry = false,
    ExpiryPrecision? precision,
    DateTime? manufactured,
    bool clearManufactured = false,
    String? batchCode,
    bool clearBatch = false,
    double? quantity,
    String? unit,
    double? unitCost,
    bool clearUnitCost = false,
    String? shelfId,
    bool clearShelf = false,
    String? note,
    String? photoPath,
    bool clearPhoto = false,
    String? barcodePhotoPath,
    bool clearBarcodePhoto = false,
    Failure? failure,
    bool clearFailure = false,
    String? savedCode,
    List<LabelWarning>? warnings,
  }) {
    return ScanFlowState(
      step: step ?? this.step,
      busy: busy ?? this.busy,
      outcome: outcome ?? this.outcome,
      barcode: barcode ?? this.barcode,
      product: clearProduct ? null : (product ?? this.product),
      expiry: clearExpiry ? null : (expiry ?? this.expiry),
      precision: precision ?? this.precision,
      manufactured: clearManufactured ? null : (manufactured ?? this.manufactured),
      batchCode: clearBatch ? null : (batchCode ?? this.batchCode),
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      unitCost: clearUnitCost ? null : (unitCost ?? this.unitCost),
      shelfId: clearShelf ? null : (shelfId ?? this.shelfId),
      note: note ?? this.note,
      photoPath: clearPhoto ? null : (photoPath ?? this.photoPath),
      barcodePhotoPath:
          clearBarcodePhoto ? null : (barcodePhotoPath ?? this.barcodePhotoPath),
      failure: clearFailure ? null : (failure ?? this.failure),
      savedCode: savedCode ?? this.savedCode,
      warnings: warnings ?? this.warnings,
    );
  }
}

/// Drives the goods-in flow: barcode -> product -> dates -> save.
class ScanFlowController extends Notifier<ScanFlowState> {
  @override
  ScanFlowState build() => const ScanFlowState();

  ScanPipeline get _pipeline => ref.read(scanPipelineProvider);
  SettingsStore get _settings => ref.read(settingsStoreProvider);

  ScanOptions get _options => ScanOptions(
        enhanceImages:
            _settings.readBool(SettingKeys.scanEnhanceImages, SettingDefaults.scanEnhanceImages),
        keepPhoto: _settings.readBool(SettingKeys.scanKeepPhotos, SettingDefaults.scanKeepPhotos),
        quality: ImageQualityConfig(
          blurThreshold:
              _settings.readDouble(SettingKeys.scanBlurThreshold, SettingDefaults.scanBlurThreshold),
          darkThreshold: _settings.readDouble(
            SettingKeys.scanLowLightThreshold,
            SettingDefaults.scanLowLightThreshold,
          ),
        ),
        parser: LabelParserConfig(
          dayFirst:
              _settings.readBool(SettingKeys.scanDayFirstDates, SettingDefaults.scanDayFirstDates),
          maxFutureYears:
              _settings.readInt(SettingKeys.scanMaxFutureYears, SettingDefaults.scanMaxFutureYears),
        ),
      );

  void reset() => state = const ScanFlowState();

  /// Step 1: the employee aimed at the barcode.
  ///
  /// [alreadyRead] is whatever the live viewfinder decoded before the still
  /// was taken; it is trusted over anything re-read from the photograph.
  Future<void> processBarcodeCapture(
    String imagePath, {
    List<ScannedCode> alreadyRead = const <ScannedCode>[],
  }) async {
    // Keep the still first, and keep it whatever the decoder makes of it. A
    // code the scanner cannot read is still perfectly legible to a person, so
    // the picture is the thing that lets the employee type the number in
    // without the scan having been wasted.
    state = state.copyWith(
      busy: true,
      clearFailure: true,
      barcodePhotoPath: imagePath.isEmpty ? null : imagePath,
    );
    final Result<ScanOutcome> result = await _pipeline.process(
      imagePath,
      options: _options,
      alreadyRead: alreadyRead,
    );
    result.fold(
      (Failure failure) => state = state.copyWith(busy: false, failure: failure),
      _applyOutcome,
    );
  }

  /// Step 2: the employee aimed at the printed dates.
  Future<void> processLabelCapture(
    String imagePath, {
    List<RecognisedLine> alreadyReadLines = const <RecognisedLine>[],
  }) async {
    state = state.copyWith(busy: true, clearFailure: true);
    final Result<ScanOutcome> result = await _pipeline.process(
      imagePath,
      options: _options,
      alreadyReadLines: alreadyReadLines,
    );
    result.fold(
      (Failure failure) => state = state.copyWith(busy: false, failure: failure),
      (ScanOutcome outcome) => _applyOutcome(outcome, keepProduct: true),
    );
  }

  void _applyOutcome(ScanOutcome outcome, {bool keepProduct = false}) {
    final Product? product = outcome.product ?? (keepProduct ? state.product : null);
    state = state.copyWith(
      busy: false,
      outcome: outcome,
      barcode: outcome.primaryBarcode ?? state.barcode,
      product: product,
      clearProduct: product == null,
      expiry: outcome.expiry.value ?? state.expiry,
      precision: outcome.precision,
      manufactured: outcome.manufactured.value ?? state.manufactured,
      batchCode: outcome.batchCode.value ?? state.batchCode,
      unit: product?.unit ?? state.unit,
      unitCost: product?.unitCost ?? state.unitCost,
      shelfId: state.shelfId ?? product?.defaultShelfId,
      photoPath: outcome.photoPath ?? state.photoPath,
      warnings: outcome.labelReading.warnings,
      step: product == null
          ? ((outcome.primaryBarcode ?? '').isEmpty ? ScanStep.start : ScanStep.needsProduct)
          : ScanStep.review,
    );
  }

  void setBarcodeManually(String barcode) {
    state = state.copyWith(barcode: barcode.trim(), clearFailure: true);
    unawaitedLookup(barcode.trim());
  }

  /// Drops the barcode still, for the rare case where the employee wants to
  /// retake it rather than keep the one on screen.
  void clearBarcodePhoto() => state = state.copyWith(clearBarcodePhoto: true);

  Future<void> unawaitedLookup(String barcode) async {
    if (barcode.isEmpty) return;
    state = state.copyWith(busy: true);
    final Result<Product?> result =
        await ref.read(catalogRepositoryProvider).findByBarcode(barcode);
    final Product? product = result.valueOrNull;
    state = state.copyWith(
      busy: false,
      product: product,
      clearProduct: product == null,
      unit: product?.unit ?? state.unit,
      unitCost: product?.unitCost ?? state.unitCost,
      shelfId: state.shelfId ?? product?.defaultShelfId,
      step: product == null ? ScanStep.needsProduct : ScanStep.review,
    );
  }

  void attachProduct(Product product) {
    state = state.copyWith(
      product: product,
      unit: product.unit,
      unitCost: product.unitCost ?? state.unitCost,
      shelfId: state.shelfId ?? product.defaultShelfId,
      precision: product.expiryPrecision,
      step: ScanStep.review,
    );
  }

  void setExpiry(DateTime? value, {ExpiryPrecision? precision}) => state = state.copyWith(
        expiry: value,
        clearExpiry: value == null,
        precision: precision ?? state.precision,
      );

  void setManufactured(DateTime? value) =>
      state = state.copyWith(manufactured: value, clearManufactured: value == null);

  void setBatch(String? value) => state = state.copyWith(
        batchCode: value,
        clearBatch: value == null || value.isEmpty,
      );

  void setQuantity(double value) => state = state.copyWith(quantity: value);

  void setUnitCost(double? value) =>
      state = state.copyWith(unitCost: value, clearUnitCost: value == null);

  void setShelf(String? shelfId) =>
      state = state.copyWith(shelfId: shelfId, clearShelf: shelfId == null);

  void setNote(String? note) => state = state.copyWith(note: note);

  /// The optional photograph of the front of the product.
  ///
  /// Optional on purpose: the barcode and the printed dates are what the
  /// policy engine needs, and making a shop assistant photograph every face
  /// would slow goods-in down for no gain. It earns its place when the next
  /// person has to find the lot on a shelf - a picture of the front is faster
  /// to match than a code.
  void setProductPhoto(String? path) => state = state.copyWith(
        photoPath: path,
        clearPhoto: path == null,
      );

  /// Step 3: write the lot and let the policy engine set its destroy instant.
  Future<InventoryRecord?> save() async {
    final ScanFlowState current = state;
    if (!current.canSave) return null;

    state = current.copyWith(busy: true, clearFailure: true);
    final Result<InventoryRecord> result =
        await ref.read(inventoryRepositoryProvider).intake(
              IntakeDraft(
                productId: current.product!.id,
                expiryAt: current.expiry!,
                expiryPrecision: current.precision,
                manufacturedAt: current.manufactured,
                batchCode: current.batchCode,
                quantity: current.quantity,
                unit: current.unit,
                unitCost: current.unitCost,
                shelfId: current.shelfId,
                photoPath: current.photoPath,
                note: current.note,
                source: current.outcome.hasBarcode ? IntakeSource.scan : IntakeSource.manual,
              ),
              actorId: ref.read(sessionUserIdProvider),
            );

    return result.fold(
      (Failure failure) {
        state = current.copyWith(busy: false, failure: failure);
        return null;
      },
      (InventoryRecord record) {
        state = ScanFlowState(step: ScanStep.saved, savedCode: record.code);
        _rememberShelfForNextTime(current);
        _refreshReminders();
        return record;
      },
    );
  }

  /// Teaches the catalog where this product lives, so the next scan of the
  /// same barcode arrives with its shelf already filled in.
  ///
  /// Only ever records a shelf the employee actually chose, and only when the
  /// product has none yet - a product that already has a home keeps it, and a
  /// one-off placement never silently overwrites the usual one. Nothing is
  /// guessed: no choice means nothing is written.
  void _rememberShelfForNextTime(ScanFlowState saved) {
    final Product? product = saved.product;
    final String? shelfId = saved.shelfId;
    if (product == null || shelfId == null || shelfId.isEmpty) return;
    if (product.defaultShelfId == shelfId) return;
    if ((product.defaultShelfId ?? '').isNotEmpty) return;

    unawaited(
      ref
          .read(catalogRepositoryProvider)
          .updateProduct(product.copyWith(defaultShelfId: shelfId))
          .then((Result<Product> result) {
        if (result.isErr) {
          ref.read(loggerProvider).w(
                'ScanFlow',
                'Could not remember the shelf for ${product.displayName}: '
                    '${result.failureOrNull?.message}',
              );
        }
      }),
    );
  }

  void _refreshReminders() {
    final NotificationPlanner planner = ref.read(dependenciesProvider).notificationPlanner;
    planner
        .reschedule(
          preferences: ref.read(notificationPreferencesProvider),
          strings: ref.read(stringsProvider),
        )
        .then((Result<NotificationPlan> result) {
      if (result.isErr) {
        ref.read(dependenciesProvider).logger.w(
              'ScanFlow',
              'Reminder refresh failed: ${result.failureOrNull?.message}',
            );
      }
    });
  }
}

final NotifierProvider<ScanFlowController, ScanFlowState> scanFlowProvider =
    NotifierProvider<ScanFlowController, ScanFlowState>(ScanFlowController.new);
