import 'dart:math' as math;

import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

/// What to do to a captured still before it is handed to OCR.
class EnhanceRequest {
  const EnhanceRequest({
    required this.bytes,
    this.cropTo,
    this.cropPadding = 0.12,
    this.maxWidth = 1600,
    this.autoContrast = true,
    this.lowLightBoost = true,
    this.sharpen = true,
    this.jpegQuality = 92,
    this.quality = const ImageQualityConfig(),
  });

  final Uint8List bytes;

  /// Region of interest, usually the barcode or text block reported by ML Kit.
  final ScanBox? cropTo;

  /// Extra margin around [cropTo], as a fraction of its size.
  final double cropPadding;

  final int maxWidth;
  final bool autoContrast;
  final bool lowLightBoost;
  final bool sharpen;
  final int jpegQuality;
  final ImageQualityConfig quality;
}

class EnhanceResult {
  const EnhanceResult({
    required this.bytes,
    required this.before,
    required this.after,
    required this.appliedSteps,
    required this.width,
    required this.height,
  });

  final Uint8List bytes;
  final ImageQualityReport before;
  final ImageQualityReport after;
  final List<String> appliedSteps;
  final int width;
  final int height;

  bool get improved => after.score > before.score;
}

/// Real image processing: automatic cropping, low-light correction, contrast
/// stretching and unsharp masking.
///
/// Everything runs on a background isolate through [compute] so the camera
/// preview never stutters.
class ImageEnhancer {
  const ImageEnhancer();

  Future<EnhanceResult?> enhance(EnhanceRequest request) =>
      compute(_enhanceIsolate, _EnhancePayload.from(request));

  /// Synchronous variant used by tests and by the isolate entry point.
  static EnhanceResult? enhanceSync(EnhanceRequest request) {
    final img.Image? decoded = _decode(request.bytes);
    if (decoded == null) return null;

    final List<String> steps = <String>[];
    img.Image image = img.bakeOrientation(decoded);

    final ScanBox? crop = request.cropTo;
    if (crop != null) {
      final ScanBox padded = crop.inflate(request.cropPadding).clampTo(image.width, image.height);
      final int w = padded.width.round();
      final int h = padded.height.round();
      if (w > 16 && h > 16) {
        image = img.copyCrop(
          image,
          x: padded.left.round(),
          y: padded.top.round(),
          width: w,
          height: h,
        );
        steps.add('crop');
      }
    }

    if (image.width > request.maxWidth) {
      image = img.copyResize(image, width: request.maxWidth);
      steps.add('resize');
    }

    final ImageQualityAnalyzer analyzer = ImageQualityAnalyzer(config: request.quality);
    final GrayFrame beforeFrame = toGrayFrame(image, targetWidth: request.quality.analysisWidth);
    final ImageQualityReport before = analyzer.analyze(beforeFrame);

    if (request.lowLightBoost && before.isTooDark) {
      final double gamma = _gammaFor(before.brightness, target: 128);
      image = img.adjustColor(image, gamma: gamma);
      steps.add('lowLight(gamma=${gamma.toStringAsFixed(2)})');
    } else if (before.isTooBright) {
      final double gamma = _gammaFor(before.brightness, target: 150);
      image = img.adjustColor(image, gamma: gamma);
      steps.add('highlightRecovery(gamma=${gamma.toStringAsFixed(2)})');
    }

    if (request.autoContrast) {
      final GrayFrame frame = toGrayFrame(image, targetWidth: request.quality.analysisWidth);
      final ({int high, int low}) bounds = ImageQualityAnalyzer.percentileBounds(frame.pixels);
      if (bounds.high - bounds.low < 235) {
        image = stretchContrast(image, bounds.low, bounds.high);
        steps.add('contrastStretch(${bounds.low}-${bounds.high})');
      }
    }

    if (request.sharpen) {
      final GrayFrame frame = toGrayFrame(image, targetWidth: request.quality.analysisWidth);
      final double sharpness = ImageQualityAnalyzer.laplacianVariance(frame);
      if (sharpness < request.quality.blurThreshold * 3) {
        // Unsharp masking recovers edge definition; it cannot rescue a badly
        // motion-blurred frame, which is why the camera screen also tells the
        // employee to hold still and retake.
        image = unsharpMask(image, amount: sharpness < request.quality.blurThreshold ? 1.4 : 0.8);
        steps.add('unsharpMask');
      }
    }

    final GrayFrame afterFrame = toGrayFrame(image, targetWidth: request.quality.analysisWidth);
    final ImageQualityReport after = analyzer.analyze(afterFrame);

    return EnhanceResult(
      bytes: img.encodeJpg(image, quality: request.jpegQuality),
      before: before,
      after: after,
      appliedSteps: steps,
      width: image.width,
      height: image.height,
    );
  }

  /// Downscales and converts to 8-bit luminance.
  static GrayFrame toGrayFrame(img.Image source, {int targetWidth = 480}) {
    final img.Image scaled = source.width > targetWidth
        ? img.copyResize(source, width: targetWidth)
        : source;
    final Uint8List pixels = Uint8List(scaled.width * scaled.height);
    int index = 0;
    for (int y = 0; y < scaled.height; y++) {
      for (int x = 0; x < scaled.width; x++) {
        final img.Pixel pixel = scaled.getPixel(x, y);
        final double luminance =
            0.299 * pixel.r.toDouble() + 0.587 * pixel.g.toDouble() + 0.114 * pixel.b.toDouble();
        pixels[index++] = luminance.clamp(0, 255).round();
      }
    }
    return GrayFrame(pixels: pixels, width: scaled.width, height: scaled.height);
  }

  /// Gamma that moves [mean] towards [target] on a 0..255 scale.
  static double _gammaFor(double mean, {required double target}) {
    final double normalisedMean = (mean / 255).clamp(0.01, 0.99);
    final double normalisedTarget = (target / 255).clamp(0.01, 0.99);
    final double gamma = math.log(normalisedTarget) / math.log(normalisedMean);
    return gamma.clamp(0.35, 2.5);
  }

  /// Linear per-channel stretch that maps [low]..[high] onto 0..255.
  static img.Image stretchContrast(img.Image source, int low, int high) {
    if (high <= low) return source;
    final double scale = 255 / (high - low);
    final img.Image out = img.Image.from(source);
    for (int y = 0; y < out.height; y++) {
      for (int x = 0; x < out.width; x++) {
        final img.Pixel pixel = out.getPixel(x, y);
        out.setPixelRgb(
          x,
          y,
          ((pixel.r.toDouble() - low) * scale).clamp(0, 255),
          ((pixel.g.toDouble() - low) * scale).clamp(0, 255),
          ((pixel.b.toDouble() - low) * scale).clamp(0, 255),
        );
      }
    }
    return out;
  }

  /// out = original + amount * (original - blurred)
  static img.Image unsharpMask(img.Image source, {double amount = 1.0, int radius = 2}) {
    final img.Image blurred = img.gaussianBlur(img.Image.from(source), radius: radius);
    final img.Image out = img.Image.from(source);
    for (int y = 0; y < out.height; y++) {
      for (int x = 0; x < out.width; x++) {
        final img.Pixel original = source.getPixel(x, y);
        final img.Pixel soft = blurred.getPixel(x, y);
        out.setPixelRgb(
          x,
          y,
          (original.r.toDouble() + amount * (original.r.toDouble() - soft.r.toDouble()))
              .clamp(0, 255),
          (original.g.toDouble() + amount * (original.g.toDouble() - soft.g.toDouble()))
              .clamp(0, 255),
          (original.b.toDouble() + amount * (original.b.toDouble() - soft.b.toDouble()))
              .clamp(0, 255),
        );
      }
    }
    return out;
  }

  /// Decodes defensively: a truncated or corrupt capture must never crash the
  /// scan flow, it must simply be retaken.
  static img.Image? _decode(Uint8List bytes) {
    if (bytes.length < 32) return null;
    try {
      return img.decodeImage(bytes);
    } catch (_) {
      return null;
    }
  }

  /// Quality check on raw bytes without producing a new image.
  static ImageQualityReport? inspect(
    Uint8List bytes, {
    ImageQualityConfig config = const ImageQualityConfig(),
  }) {
    final img.Image? decoded = _decode(bytes);
    if (decoded == null) return null;
    return ImageQualityAnalyzer(config: config)
        .analyze(toGrayFrame(decoded, targetWidth: config.analysisWidth));
  }
}

/// Isolate-transferable copy of [EnhanceRequest].
class _EnhancePayload {
  const _EnhancePayload({
    required this.bytes,
    required this.cropLeft,
    required this.cropTop,
    required this.cropRight,
    required this.cropBottom,
    required this.hasCrop,
    required this.cropPadding,
    required this.maxWidth,
    required this.autoContrast,
    required this.lowLightBoost,
    required this.sharpen,
    required this.jpegQuality,
    required this.blurThreshold,
    required this.darkThreshold,
    required this.brightThreshold,
    required this.analysisWidth,
  });

  factory _EnhancePayload.from(EnhanceRequest request) {
    final ScanBox? crop = request.cropTo;
    return _EnhancePayload(
      bytes: request.bytes,
      cropLeft: crop?.left ?? 0,
      cropTop: crop?.top ?? 0,
      cropRight: crop?.right ?? 0,
      cropBottom: crop?.bottom ?? 0,
      hasCrop: crop != null,
      cropPadding: request.cropPadding,
      maxWidth: request.maxWidth,
      autoContrast: request.autoContrast,
      lowLightBoost: request.lowLightBoost,
      sharpen: request.sharpen,
      jpegQuality: request.jpegQuality,
      blurThreshold: request.quality.blurThreshold,
      darkThreshold: request.quality.darkThreshold,
      brightThreshold: request.quality.brightThreshold,
      analysisWidth: request.quality.analysisWidth,
    );
  }

  final Uint8List bytes;
  final double cropLeft;
  final double cropTop;
  final double cropRight;
  final double cropBottom;
  final bool hasCrop;
  final double cropPadding;
  final int maxWidth;
  final bool autoContrast;
  final bool lowLightBoost;
  final bool sharpen;
  final int jpegQuality;
  final double blurThreshold;
  final double darkThreshold;
  final double brightThreshold;
  final int analysisWidth;

  EnhanceRequest toRequest() => EnhanceRequest(
        bytes: bytes,
        cropTo: hasCrop ? ScanBox(cropLeft, cropTop, cropRight, cropBottom) : null,
        cropPadding: cropPadding,
        maxWidth: maxWidth,
        autoContrast: autoContrast,
        lowLightBoost: lowLightBoost,
        sharpen: sharpen,
        jpegQuality: jpegQuality,
        quality: ImageQualityConfig(
          blurThreshold: blurThreshold,
          darkThreshold: darkThreshold,
          brightThreshold: brightThreshold,
          analysisWidth: analysisWidth,
        ),
      );
}

EnhanceResult? _enhanceIsolate(_EnhancePayload payload) =>
    ImageEnhancer.enhanceSync(payload.toRequest());
