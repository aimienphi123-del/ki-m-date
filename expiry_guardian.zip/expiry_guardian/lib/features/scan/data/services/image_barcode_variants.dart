import 'dart:io';

import 'package:expiry_guardian/features/scan/domain/services/barcode_sweep.dart';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

/// Renders a captured still the other ways round, for [BarcodeSweep].
///
/// The work happens on a background isolate: rotating and re-encoding a
/// twelve-megapixel photograph four times on the UI thread would freeze the
/// screen for seconds, and this runs at the exact moment the employee is
/// waiting to see whether the scan worked.
class ImageBarcodeVariants implements BarcodeVariants {
  const ImageBarcodeVariants();

  /// Barcode work does not need the full sensor: a quarter-turned 1600px
  /// frame still carries far more pixels per bar than any decoder needs, and
  /// re-encoding at that width is what keeps four extra attempts cheap.
  static const int _workingWidth = 1600;

  @override
  Future<List<ScanAttempt>> rotations(String path) =>
      _build(path, <int>[180, 90, 270], enhance: false, tag: 'rot');

  @override
  Future<List<ScanAttempt>> enhanced(String path) =>
      _build(path, <int>[0, 180, 90, 270], enhance: true, tag: 'boosted');

  Future<List<ScanAttempt>> _build(
    String path,
    List<int> turns, {
    required bool enhance,
    required String tag,
  }) async {
    final File source = File(path);
    if (path.isEmpty || !source.existsSync()) return const <ScanAttempt>[];

    try {
      final List<Uint8List> rendered = await compute(
        _renderIsolate,
        _VariantPayload(
          bytes: await source.readAsBytes(),
          turns: turns,
          enhance: enhance,
        ),
      );
      if (rendered.length != turns.length) return const <ScanAttempt>[];

      final Directory dir = source.parent;
      final int stamp = DateTime.now().microsecondsSinceEpoch;
      final List<ScanAttempt> attempts = <ScanAttempt>[];
      for (int i = 0; i < rendered.length; i++) {
        final String variantPath = '${dir.path}/sweep_${stamp}_$tag${turns[i]}.jpg';
        await File(variantPath).writeAsBytes(rendered[i], flush: true);
        attempts.add(ScanAttempt('$tag${turns[i]}', variantPath));
      }
      return attempts;
    } on Object {
      // A still that cannot be re-rendered simply gets no extra attempts.
      // The sweep has already tried it as stored, and the employee can always
      // read the number off the photograph and type it in.
      return const <ScanAttempt>[];
    }
  }
}

/// Isolate-transferable request.
@immutable
class _VariantPayload {
  const _VariantPayload({
    required this.bytes,
    required this.turns,
    required this.enhance,
  });

  final Uint8List bytes;
  final List<int> turns;
  final bool enhance;
}

List<Uint8List> _renderIsolate(_VariantPayload payload) =>
    renderBarcodeVariants(payload.bytes, payload.turns, enhance: payload.enhance);

/// Decodes once, scales once, then turns that one working copy.
///
/// Exposed for tests, which is also why it takes plain arguments: the whole
/// point of the sweep is that these renderings really do differ, and that is
/// only provable by running it.
@visibleForTesting
List<Uint8List> renderBarcodeVariants(
  Uint8List bytes,
  List<int> turns, {
  bool enhance = false,
}) {
  // A truncated or half-written capture does not merely decode to null - the
  // format sniffing throws on its way through the candidate decoders, and an
  // uncaught throw here takes down the isolate rather than costing one
  // attempt.
  final img.Image? decoded;
  try {
    decoded = img.decodeImage(bytes);
  } on Object {
    return const <Uint8List>[];
  }
  if (decoded == null) return const <Uint8List>[];

  img.Image working = img.bakeOrientation(decoded);
  if (working.width > ImageBarcodeVariants._workingWidth) {
    working = img.copyResize(working, width: ImageBarcodeVariants._workingWidth);
  }
  if (enhance) {
    // Grayscale first: a barcode carries no colour, and dropping it stops a
    // coloured print - the blue bars on a drinking-yoghurt bottle, say - from
    // being stretched differently across the channels.
    working = img.grayscale(working);
    working = img.contrast(working, contrast: 140);
  }

  return <Uint8List>[
    for (final int turn in turns)
      img.encodeJpg(
        turn == 0 ? working : img.copyRotate(working, angle: turn),
        quality: 92,
      ),
  ];
}
