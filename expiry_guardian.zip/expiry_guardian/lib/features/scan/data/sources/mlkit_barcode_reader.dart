import 'dart:ui' show Rect, Size;

import 'package:expiry_guardian/core/error/exceptions.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';

/// ML Kit implementation of [BarcodeReader].
///
/// The scanner instance is kept alive between frames - creating one per frame
/// is what makes naive implementations drop to a few frames per second.
class MlKitBarcodeReader implements BarcodeReader {
  MlKitBarcodeReader({required AppLogger logger, List<BarcodeFormat>? formats})
      : _logger = logger,
        _formats = formats ?? const <BarcodeFormat>[BarcodeFormat.all];

  final AppLogger _logger;
  final List<BarcodeFormat> _formats;
  BarcodeScanner? _scanner;

  static const String _tag = 'MlKitBarcodeReader';

  BarcodeScanner get _instance => _scanner ??= BarcodeScanner(formats: _formats);

  @override
  Future<List<ScannedCode>> readFile(String imagePath) async {
    try {
      final List<Barcode> barcodes =
          await _instance.processImage(InputImage.fromFilePath(imagePath));
      return barcodes
          .where((Barcode b) => (b.rawValue ?? '').isNotEmpty)
          .map(_toDomain)
          .toList(growable: false);
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Barcode scan failed', error: error, stackTrace: stackTrace);
      throw CameraPipelineException('barcode_scan_failed', error);
    }
  }

  @override
  Future<List<ScannedCode>> readFrame(CameraFrame frame) async {
    try {
      final List<Barcode> barcodes = await _instance.processImage(
        InputImage.fromBytes(
          bytes: frame.bytes,
          metadata: InputImageMetadata(
            size: Size(frame.width.toDouble(), frame.height.toDouble()),
            rotation: _rotationOf(frame.rotationDegrees),
            format: _inputFormatOf(frame.format),
            bytesPerRow: frame.bytesPerRow,
          ),
        ),
      );
      return barcodes
          .where((Barcode b) => (b.rawValue ?? '').isNotEmpty)
          .map(_toDomain)
          .toList(growable: false);
    } on Object catch (error) {
      // Deliberately not an exception: most frames in a stream carry no
      // readable code, and a blurred or half-exposed buffer is ordinary, not
      // broken. Throwing here would abort the scan on the first bad frame.
      _logger.d(_tag, 'Frame not decodable: $error');
      return const <ScannedCode>[];
    }
  }

  InputImageRotation _rotationOf(int degrees) {
    return switch (degrees % 360) {
      90 => InputImageRotation.rotation90deg,
      180 => InputImageRotation.rotation180deg,
      270 => InputImageRotation.rotation270deg,
      _ => InputImageRotation.rotation0deg,
    };
  }

  InputImageFormat _inputFormatOf(CameraFrameFormat format) {
    return switch (format) {
      CameraFrameFormat.nv21 => InputImageFormat.nv21,
      CameraFrameFormat.yuv420 => InputImageFormat.yuv420,
      CameraFrameFormat.bgra8888 => InputImageFormat.bgra8888,
    };
  }

  ScannedCode _toDomain(Barcode barcode) {
    final Rect box = barcode.boundingBox;
    return ScannedCode(
      rawValue: barcode.rawValue!,
      displayValue: barcode.displayValue,
      format: _formatOf(barcode.format),
      boundingBox: box == Rect.zero
          ? null
          : ScanBox(box.left, box.top, box.right, box.bottom),
    );
  }

  CodeFormat _formatOf(BarcodeFormat format) => switch (format) {
        BarcodeFormat.ean13 => CodeFormat.ean13,
        BarcodeFormat.ean8 => CodeFormat.ean8,
        BarcodeFormat.upca => CodeFormat.upcA,
        BarcodeFormat.upce => CodeFormat.upcE,
        BarcodeFormat.code128 => CodeFormat.code128,
        BarcodeFormat.code39 => CodeFormat.code39,
        BarcodeFormat.code93 => CodeFormat.code93,
        BarcodeFormat.itf => CodeFormat.itf,
        BarcodeFormat.codabar => CodeFormat.codabar,
        BarcodeFormat.dataMatrix => CodeFormat.dataMatrix,
        BarcodeFormat.qrCode => CodeFormat.qrCode,
        BarcodeFormat.pdf417 => CodeFormat.pdf417,
        BarcodeFormat.aztec => CodeFormat.aztec,
        _ => CodeFormat.unknown,
      };

  @override
  Future<void> dispose() async {
    await _scanner?.close();
    _scanner = null;
  }
}
