import 'dart:ui' show Size;

import 'package:expiry_guardian/core/error/exceptions.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// ML Kit implementation of [TextReader].
///
/// Latin script covers Vietnamese and English labels. A second recognizer for
/// Chinese is created lazily, because imported goods are common in Vietnamese
/// stores and their labels are the ones an employee can least easily read.
class MlKitTextReader implements TextReader {
  MlKitTextReader({required AppLogger logger, this.alsoTryChinese = true})
      : _logger = logger;

  final AppLogger _logger;
  final bool alsoTryChinese;

  TextRecognizer? _latin;
  TextRecognizer? _chinese;

  static const String _tag = 'MlKitTextReader';

  @override
  Future<List<RecognisedLine>> readFile(String imagePath) async {
    try {
      return await _read(InputImage.fromFilePath(imagePath));
    } on Object catch (error, stackTrace) {
      _logger.e(_tag, 'Text recognition failed', error: error, stackTrace: stackTrace);
      throw CameraPipelineException('text_recognition_failed', error);
    }
  }

  @override
  Future<List<RecognisedLine>> readFrame(CameraFrame frame) async {
    try {
      return await _read(
        InputImage.fromBytes(
          bytes: frame.bytes,
          metadata: InputImageMetadata(
            size: Size(frame.width.toDouble(), frame.height.toDouble()),
            rotation: _rotationOf(frame.rotationDegrees),
            format: _inputFormatOf(frame.format),
            bytesPerRow: frame.bytesPerRow,
          ),
        ),
      );
    } on Object catch (error) {
      // At streaming rates a frame the recogniser cannot use is the ordinary
      // case, not a fault. Throwing would abort the scan on the first blurred
      // frame - which is every scan.
      _logger.d(_tag, 'Frame not readable: $error');
      return const <RecognisedLine>[];
    }
  }

  Future<List<RecognisedLine>> _read(InputImage image) async {
    final List<RecognisedLine> lines =
        _linesOf(await (_latin ??= TextRecognizer()).processImage(image));
    if (!alsoTryChinese || _looksSufficient(lines)) return lines;

    // Best effort, and deliberately separate from the Latin pass. The Chinese
    // recogniser is an extra chance at an imported label, not a requirement -
    // so if it is unavailable on this handset, or throws for any other reason,
    // the Latin lines that were already read must survive. Letting its failure
    // propagate would discard a perfectly good reading.
    try {
      final List<RecognisedLine> cjk = _linesOf(
        await (_chinese ??= TextRecognizer(script: TextRecognitionScript.chinese))
            .processImage(image),
      );
      return <RecognisedLine>[...lines, ...cjk];
    } on Object catch (error) {
      _logger.w(_tag, 'Chinese pass unavailable, keeping the Latin lines', error: error);
      return lines;
    }
  }

  /// A Latin pass that already produced digits is almost certainly enough; the
  /// extra Chinese pass costs another ~150 ms so it is only worth it when the
  /// first pass found nothing date-like.
  bool _looksSufficient(List<RecognisedLine> lines) {
    return lines.any((RecognisedLine l) => RegExp(r'\d{2}').hasMatch(l.text));
  }

  InputImageRotation _rotationOf(int degrees) {
    return switch (degrees % 360) {
      90 => InputImageRotation.rotation90deg,
      180 => InputImageRotation.rotation180deg,
      270 => InputImageRotation.rotation270deg,
      _ => InputImageRotation.rotation0deg,
    };
  }

  InputImageFormat _inputFormatOf(CameraFrameFormat format) {
    return switch (format) {
      CameraFrameFormat.nv21 => InputImageFormat.nv21,
      CameraFrameFormat.yuv420 => InputImageFormat.yuv420,
      CameraFrameFormat.bgra8888 => InputImageFormat.bgra8888,
    };
  }

  List<RecognisedLine> _linesOf(RecognizedText recognised) {
    final List<RecognisedLine> lines = <RecognisedLine>[];
    for (final TextBlock block in recognised.blocks) {
      for (final TextLine line in block.lines) {
        lines.add(RecognisedLine(
          text: line.text,
          boundingBox: ScanBox(
            line.boundingBox.left,
            line.boundingBox.top,
            line.boundingBox.right,
            line.boundingBox.bottom,
          ),
        ),);
      }
    }
    return lines;
  }

  @override
  Future<void> dispose() async {
    await _latin?.close();
    await _chinese?.close();
    _latin = null;
    _chinese = null;
  }
}
