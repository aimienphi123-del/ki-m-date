import 'package:expiry_guardian/features/scan/domain/entities/camera_frame.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';

/// Reads 1D and 2D codes from an image file or from a live camera frame.
abstract interface class BarcodeReader {
  Future<List<ScannedCode>> readFile(String imagePath);

  /// Reads codes from one live frame.
  ///
  /// A single still photograph is the hardest possible case for a retail
  /// barcode: one chance, and it has to be sharp, square-on and well lit. A
  /// scanner looking at a stream needs only one good frame out of dozens,
  /// which is why reading the stream finds codes that photographing them
  /// never will.
  ///
  /// Implementations return an empty list for a frame they could not decode
  /// rather than throwing - at streaming rates an undecodable frame is the
  /// normal case, not a failure.
  Future<List<ScannedCode>> readFrame(CameraFrame frame);

  Future<void> dispose();
}

/// Reads text lines from an image file or from a live camera frame.
abstract interface class TextReader {
  Future<List<RecognisedLine>> readFile(String imagePath);

  /// Reads text from one live frame.
  ///
  /// Printed expiry dates are small, low-contrast and often on a curved or
  /// shiny surface. Photographing them by hand gives the recogniser a single
  /// attempt at exactly the kind of image it handles worst; reading the stream
  /// gives it many, and keeps the first frame that actually resolves a date.
  ///
  /// Like [BarcodeReader.readFrame], an unreadable frame returns an empty list
  /// rather than throwing.
  Future<List<RecognisedLine>> readFrame(CameraFrame frame);

  Future<void> dispose();
}
