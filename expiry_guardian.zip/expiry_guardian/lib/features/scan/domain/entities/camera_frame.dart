import 'dart:typed_data';

/// How the bytes of a [CameraFrame] are laid out.
///
/// Android hands out NV21 (or full YUV420 planes), iOS hands out BGRA8888.
/// The detector needs to be told which, because it reads the buffer directly
/// rather than decoding an image file.
enum CameraFrameFormat { nv21, yuv420, bgra8888 }

/// One live frame on its way to a detector.
///
/// This exists so the domain layer can describe a camera frame without
/// importing the camera plugin: the presentation layer converts whatever the
/// platform produced into this, and the detector implementation converts it
/// into whatever ML Kit wants. Neither side has to know about the other.
class CameraFrame {
  const CameraFrame({
    required this.bytes,
    required this.width,
    required this.height,
    required this.rotationDegrees,
    required this.bytesPerRow,
    required this.format,
  });

  final Uint8List bytes;
  final int width;
  final int height;

  /// Clockwise rotation, in degrees, needed to stand the frame upright.
  ///
  /// A barcode read from a sideways buffer decodes as nothing at all, so this
  /// is not cosmetic - it is the difference between a scanner that works and
  /// one that never fires.
  final int rotationDegrees;

  final int bytesPerRow;
  final CameraFrameFormat format;
}
