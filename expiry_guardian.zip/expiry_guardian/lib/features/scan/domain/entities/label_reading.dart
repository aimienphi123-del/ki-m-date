/// What a date found on a label refers to.
enum LabelDateKind { expiry, manufacturing, packaging, unknown }

/// Non-fatal observations the review screen shows to the employee.
enum LabelWarning {
  noDatesFound,
  ambiguousDayMonth,
  expiryBeforeManufacturing,
  expiryAlreadyPassed,
  onlyMonthPrinted,
  implausibleYear,
  multipleExpiryCandidates,
}

/// One date extracted from OCR text.
class LabelDate {
  const LabelDate({
    required this.value,
    required this.kind,
    required this.rawText,
    required this.confidence,
    this.hasTime = false,
    this.dayKnown = true,
    this.lineIndex = 0,
  });

  final DateTime value;
  final LabelDateKind kind;

  /// Exactly the substring the parser matched, so the review screen can show
  /// the employee what the camera actually read.
  final String rawText;

  /// 0..1
  final double confidence;
  final bool hasTime;

  /// False when the label printed only a month and year.
  final bool dayKnown;
  final int lineIndex;

  LabelDate copyWith({
    DateTime? value,
    LabelDateKind? kind,
    double? confidence,
    bool? hasTime,
    bool? dayKnown,
  }) {
    return LabelDate(
      value: value ?? this.value,
      kind: kind ?? this.kind,
      rawText: rawText,
      confidence: confidence ?? this.confidence,
      hasTime: hasTime ?? this.hasTime,
      dayKnown: dayKnown ?? this.dayKnown,
      lineIndex: lineIndex,
    );
  }

  @override
  String toString() => 'LabelDate(${kind.name}: $value from "$rawText")';
}

/// The full result of reading one label.
class LabelReading {
  const LabelReading({
    required this.candidates,
    required this.warnings,
    this.expiry,
    this.manufacturing,
    this.batchCode,
    this.sourceText = '',
  });

  const LabelReading.empty()
      : candidates = const <LabelDate>[],
        warnings = const <LabelWarning>[LabelWarning.noDatesFound],
        expiry = null,
        manufacturing = null,
        batchCode = null,
        sourceText = '';

  final List<LabelDate> candidates;
  final List<LabelWarning> warnings;
  final LabelDate? expiry;
  final LabelDate? manufacturing;
  final String? batchCode;
  final String sourceText;

  bool get hasExpiry => expiry != null;

  /// True when the employee must check the result before saving.
  bool get needsReview =>
      expiry == null ||
      expiry!.confidence < 0.75 ||
      warnings.any((LabelWarning w) =>
          w == LabelWarning.ambiguousDayMonth ||
          w == LabelWarning.expiryBeforeManufacturing ||
          w == LabelWarning.expiryAlreadyPassed ||
          w == LabelWarning.multipleExpiryCandidates,);

  @override
  String toString() => 'LabelReading(exp=${expiry?.value}, mfg=${manufacturing?.value}, lot=$batchCode)';
}
