/// Symbology reported by the scanner.
enum CodeFormat {
  ean13,
  ean8,
  upcA,
  upcE,
  code128,
  code39,
  code93,
  itf,
  codabar,
  dataMatrix,
  qrCode,
  pdf417,
  aztec,
  unknown;

  bool get isTwoDimensional =>
      this == CodeFormat.qrCode ||
      this == CodeFormat.dataMatrix ||
      this == CodeFormat.pdf417 ||
      this == CodeFormat.aztec;
}

/// A raw detection straight from the camera.
class ScannedCode {
  const ScannedCode({
    required this.rawValue,
    required this.format,
    this.displayValue,
    this.boundingBox,
  });

  final String rawValue;
  final String? displayValue;
  final CodeFormat format;

  /// Left, top, right, bottom in image pixels; used for automatic cropping.
  final ScanBox? boundingBox;

  @override
  String toString() => 'ScannedCode(${format.name}: $rawValue)';
}

class ScanBox {
  const ScanBox(this.left, this.top, this.right, this.bottom);

  final double left;
  final double top;
  final double right;
  final double bottom;

  double get width => right - left;
  double get height => bottom - top;

  ScanBox inflate(double ratio) {
    final double dx = width * ratio;
    final double dy = height * ratio;
    return ScanBox(left - dx, top - dy, right + dx, bottom + dy);
  }

  ScanBox clampTo(int imageWidth, int imageHeight) {
    return ScanBox(
      left.clamp(0, imageWidth.toDouble()),
      top.clamp(0, imageHeight.toDouble()),
      right.clamp(0, imageWidth.toDouble()),
      bottom.clamp(0, imageHeight.toDouble()),
    );
  }

  static ScanBox? union(Iterable<ScanBox> boxes) {
    ScanBox? result;
    for (final ScanBox box in boxes) {
      if (result == null) {
        result = box;
      } else {
        result = ScanBox(
          box.left < result.left ? box.left : result.left,
          box.top < result.top ? box.top : result.top,
          box.right > result.right ? box.right : result.right,
          box.bottom > result.bottom ? box.bottom : result.bottom,
        );
      }
    }
    return result;
  }
}

/// One line of recognised text with its position.
class RecognisedLine {
  const RecognisedLine({required this.text, this.boundingBox, this.confidence});

  final String text;
  final ScanBox? boundingBox;
  final double? confidence;
}
