import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/services/gs1_parser.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';

/// Where a piece of captured data came from. Shown next to each field on the
/// review screen so the employee always knows what to double-check.
enum FieldSource { barcodeGs1, ocr, catalogDefault, manual, none }

class CapturedField<T> {
  const CapturedField({required this.value, required this.source, this.confidence = 1.0});

  const CapturedField.none()
      : value = null,
        source = FieldSource.none,
        confidence = 0;

  final T? value;
  final FieldSource source;
  final double confidence;

  bool get isPresent => value != null;

  CapturedField<T> overriddenWith(T? newValue) =>
      CapturedField<T>(value: newValue, source: FieldSource.manual);
}

/// Everything one capture produced.
class ScanOutcome {
  const ScanOutcome({
    required this.codes,
    required this.gs1,
    required this.labelReading,
    required this.expiry,
    required this.manufactured,
    required this.batchCode,
    required this.precision,
    required this.quality,
    this.product,
    this.primaryBarcode,
    this.photoPath,
    this.enhancementSteps = const <String>[],
  });

  const ScanOutcome.empty()
      : codes = const <ScannedCode>[],
        gs1 = null,
        labelReading = const LabelReading.empty(),
        expiry = const CapturedField<DateTime>.none(),
        manufactured = const CapturedField<DateTime>.none(),
        batchCode = const CapturedField<String>.none(),
        precision = ExpiryPrecision.day,
        quality = null,
        product = null,
        primaryBarcode = null,
        photoPath = null,
        enhancementSteps = const <String>[];

  final List<ScannedCode> codes;
  final Gs1Data? gs1;
  final LabelReading labelReading;

  final CapturedField<DateTime> expiry;
  final CapturedField<DateTime> manufactured;
  final CapturedField<String> batchCode;
  final ExpiryPrecision precision;

  final ImageQualityReport? quality;

  /// Null when the barcode is not in the store catalog yet - the UI then opens
  /// the "add this product" form. The app never invents a product name.
  final Product? product;

  final String? primaryBarcode;
  final String? photoPath;
  final List<String> enhancementSteps;

  bool get hasBarcode => primaryBarcode != null;
  bool get isKnownProduct => product != null;
  bool get hasExpiry => expiry.isPresent;

  bool get readyToSave => hasBarcode && isKnownProduct && hasExpiry;

  ScanOutcome copyWith({
    List<ScannedCode>? codes,
    Gs1Data? gs1,
    LabelReading? labelReading,
    CapturedField<DateTime>? expiry,
    CapturedField<DateTime>? manufactured,
    CapturedField<String>? batchCode,
    ExpiryPrecision? precision,
    ImageQualityReport? quality,
    Product? product,
    bool clearProduct = false,
    String? primaryBarcode,
    String? photoPath,
    List<String>? enhancementSteps,
  }) {
    return ScanOutcome(
      codes: codes ?? this.codes,
      gs1: gs1 ?? this.gs1,
      labelReading: labelReading ?? this.labelReading,
      expiry: expiry ?? this.expiry,
      manufactured: manufactured ?? this.manufactured,
      batchCode: batchCode ?? this.batchCode,
      precision: precision ?? this.precision,
      quality: quality ?? this.quality,
      product: clearProduct ? null : (product ?? this.product),
      primaryBarcode: primaryBarcode ?? this.primaryBarcode,
      photoPath: photoPath ?? this.photoPath,
      enhancementSteps: enhancementSteps ?? this.enhancementSteps,
    );
  }
}
