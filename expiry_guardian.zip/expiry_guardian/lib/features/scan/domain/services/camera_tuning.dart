/// How far to zoom in when the camera is being used to read something small.
///
/// Phones ship an increasingly wide main lens, and a wide lens is the wrong
/// tool here: an EAN-13 is about three centimetres across, and held at the
/// distance the lens can actually focus at it lands in a narrow strip of a
/// very wide frame. A bar is then a pixel or two and the decoder has nothing
/// to work with - which is exactly what "the scanner does nothing" looks like
/// from behind the counter.
///
/// One and a half times, not two and not the maximum. Past that, digital zoom
/// is upscaling, which adds no detail while costing the field of view the
/// employee needs to find the print. And many phones hand a zoom of two or
/// more to a separate telephoto lens, which cannot focus closer than a forearm
/// away - so the label held at a natural distance turns to blur and nothing is
/// ever read. Below two, every phone stays on the main lens.
double readingZoomLevel({required double min, required double max}) {
  const double wanted = 1.5;
  if (!min.isFinite || !max.isFinite || max <= min) return min;
  return wanted.clamp(min, max);
}
