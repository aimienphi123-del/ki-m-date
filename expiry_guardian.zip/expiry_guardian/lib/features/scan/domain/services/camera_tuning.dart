/// How far to zoom in when the camera is being used to read something small.
///
/// Phones ship an increasingly wide main lens, and a wide lens is the wrong
/// tool here: an EAN-13 is about three centimetres across, and held at the
/// distance the lens can actually focus at it lands in a narrow strip of a
/// very wide frame. A bar is then a pixel or two and the decoder has nothing
/// to work with - which is exactly what "the scanner does nothing" looks like
/// from behind the counter.
///
/// Two-times is deliberate rather than the maximum available: digital zoom
/// past that is upscaling, which adds no detail while costing the field of
/// view the employee needs to find the code in the first place.
double readingZoomLevel({required double min, required double max}) {
  const double wanted = 2.0;
  if (!min.isFinite || !max.isFinite || max <= min) return min;
  return wanted.clamp(min, max);
}
