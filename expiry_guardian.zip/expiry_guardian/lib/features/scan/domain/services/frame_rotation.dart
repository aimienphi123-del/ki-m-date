/// Which way up the phone is being held, as far as the camera is concerned.
enum DeviceTurn {
  portraitUp(0),
  landscapeLeft(90),
  portraitDown(180),
  landscapeRight(270);

  const DeviceTurn(this.degrees);

  final int degrees;
}

/// How far a camera frame has to be turned for a detector to see it upright.
///
/// The sensor orientation on its own is only correct while the handset is held
/// the way the sensor is mounted - portrait, on nearly every phone. Turn the
/// phone sideways, which is the natural way to hold a wide EAN-13 and common
/// for a long printed date line, and the buffer reaches ML Kit a quarter turn
/// out. Barcode decoding sometimes survives that; text recognition does not,
/// which is why a date that reads perfectly in portrait simply stops being
/// found in landscape.
///
/// This is the compensation ML Kit's own guidance prescribes. iOS needs none
/// of it: the frames arrive already oriented, so the sensor orientation is the
/// whole answer there.
int frameRotationDegrees({
  required int sensorOrientation,
  required DeviceTurn deviceTurn,
  required bool isFrontFacing,
  required bool isIOS,
}) {
  if (isIOS) return sensorOrientation % 360;
  if (isFrontFacing) {
    return (sensorOrientation + deviceTurn.degrees) % 360;
  }
  return (sensorOrientation - deviceTurn.degrees + 360) % 360;
}
