import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';

/// Tunable parser behaviour. Every value is a manager-editable setting.
class LabelParserConfig {
  const LabelParserConfig({
    this.dayFirst = true,
    this.maxFutureYears = 10,
    this.maxPastYears = 5,
    this.minimumConfidence = 0.35,
  });

  /// Vietnamese and most European labels print DD/MM. US imports print MM/DD.
  final bool dayFirst;

  /// A parsed year further out than this is rejected as an OCR mistake.
  final int maxFutureYears;
  final int maxPastYears;
  final double minimumConfidence;
}

/// Extracts expiry / manufacturing dates and the batch code from OCR text.
///
/// Pure Dart and fully deterministic, so the whole matrix of real label
/// formats is covered by unit tests rather than by trial and error on a
/// phone. Nothing here guesses a date that is not printed on the label: when
/// no date is found the caller is told so and the employee types it in.
class LabelTextParser {
  const LabelTextParser({this.config = const LabelParserConfig()});

  final LabelParserConfig config;

  // --------------------------------------------------------------- keywords

  static const List<String> expiryKeywords = <String>[
    'HAN SU DUNG',
    'HAN SD',
    'HSD',
    'SU DUNG TRUOC',
    'SU DUNG DEN',
    'TOT NHAT TRUOC',
    'NGAY HET HAN',
    'HET HAN',
    'EXPIRY DATE',
    'EXPIRATION DATE',
    'EXPIRES ON',
    'EXPIRES',
    'EXPIRY',
    'EXP DATE',
    'EXP',
    'BEST BEFORE END',
    'BEST BEFORE',
    'BEST BY',
    'BBE',
    'BB',
    'USE BY',
    'USE BEFORE',
    'SELL BY',
    'VALID UNTIL',
    'ED',
    'E',
  ];

  static const List<String> manufacturingKeywords = <String>[
    'NGAY SAN XUAT',
    'NGAY SX',
    'SAN XUAT',
    'NSX',
    'MFG DATE',
    'MANUFACTURED ON',
    'MANUFACTURING DATE',
    'MFG',
    'MFD',
    'PRODUCTION DATE',
    'PRODUCED ON',
    'PROD DATE',
    'PROD',
    'MD',
  ];

  static const List<String> packagingKeywords = <String>[
    'NGAY DONG GOI',
    'DONG GOI',
    'PACKED ON',
    'PACKED',
    'PACKAGING DATE',
    'PKD',
    'PD',
  ];

  /// CJK label markers, common on imported goods in Vietnamese stores.
  static const Map<String, LabelDateKind> cjkKeywords = <String, LabelDateKind>{
    '生产日期': LabelDateKind.manufacturing,
    '生產日期': LabelDateKind.manufacturing,
    '製造日': LabelDateKind.manufacturing,
    '製造年月日': LabelDateKind.manufacturing,
    '有效期至': LabelDateKind.expiry,
    '有效期限': LabelDateKind.expiry,
    '保质期至': LabelDateKind.expiry,
    '賞味期限': LabelDateKind.expiry,
    '消費期限': LabelDateKind.expiry,
    '유통기한': LabelDateKind.expiry,
    '包装日期': LabelDateKind.packaging,
  };

  static const List<String> batchKeywords = <String>[
    'SO LO SX',
    'SO LO',
    'LO SX',
    'LOT NO',
    'LOT NUMBER',
    'LOT',
    'BATCH NO',
    'BATCH NUMBER',
    'BATCH',
    'B NO',
    'BN',
    'L',
  ];

  static const Map<String, int> monthNames = <String, int>{
    'JAN': 1, 'JANUARY': 1, 'THG1': 1, 'TH1': 1,
    'FEB': 2, 'FEBRUARY': 2, 'THG2': 2, 'TH2': 2,
    'MAR': 3, 'MARCH': 3, 'THG3': 3, 'TH3': 3,
    'APR': 4, 'APRIL': 4, 'THG4': 4, 'TH4': 4,
    'MAY': 5, 'THG5': 5, 'TH5': 5,
    'JUN': 6, 'JUNE': 6, 'THG6': 6, 'TH6': 6,
    'JUL': 7, 'JULY': 7, 'THG7': 7, 'TH7': 7,
    'AUG': 8, 'AUGUST': 8, 'THG8': 8, 'TH8': 8,
    'SEP': 9, 'SEPT': 9, 'SEPTEMBER': 9, 'THG9': 9, 'TH9': 9,
    'OCT': 10, 'OCTOBER': 10, 'THG10': 10, 'TH10': 10,
    'NOV': 11, 'NOVEMBER': 11, 'THG11': 11, 'TH11': 11,
    'DEC': 12, 'DECEMBER': 12, 'THG12': 12, 'TH12': 12,
  };

  // ------------------------------------------------------------------- API

  LabelReading parse(List<String> lines, {required DateTime now}) {
    final List<String> normalised =
        lines.map(normaliseLine).where((String l) => l.isNotEmpty).toList();
    if (normalised.isEmpty) return const LabelReading.empty();

    final List<LabelDate> candidates = <LabelDate>[];
    final Set<LabelWarning> warnings = <LabelWarning>{};
    LabelDateKind carryOverKind = LabelDateKind.unknown;

    for (int i = 0; i < normalised.length; i++) {
      final String line = normalised[i];
      final List<_KeywordHit> hits = _detectKeywords(line);

      final List<_RawMatch> matches = _findDates(line, now);
      if (matches.isEmpty) {
        // "HSD:" alone on its own line applies to the following line.
        carryOverKind = hits.isEmpty ? LabelDateKind.unknown : hits.last.kind;
        continue;
      }
      final LabelDateKind fallbackKind = carryOverKind;
      carryOverKind = LabelDateKind.unknown;

      for (final _RawMatch match in matches) {
        final LabelDateKind kind = _kindForMatch(match, hits, fallbackKind);
        double confidence = 0.5;
        if (kind != LabelDateKind.unknown) confidence += 0.25;
        if (match.fourDigitYear) confidence += 0.1;
        if (match.dayKnown) confidence += 0.1;
        if (match.hasTime) confidence += 0.05;
        if (match.ambiguous) confidence -= 0.25;
        if (match.fromCompactDigits) confidence -= 0.1;

        candidates.add(LabelDate(
          value: match.value,
          kind: kind,
          rawText: match.rawText,
          confidence: confidence.clamp(0.0, 1.0),
          hasTime: match.hasTime,
          dayKnown: match.dayKnown,
          lineIndex: i,
        ),);
        if (match.ambiguous) warnings.add(LabelWarning.ambiguousDayMonth);
        if (!match.dayKnown) warnings.add(LabelWarning.onlyMonthPrinted);
      }
    }

    final List<LabelDate> usable = candidates
        .where((LabelDate c) => c.confidence >= config.minimumConfidence)
        .toList(growable: false);

    if (usable.isEmpty) {
      return LabelReading(
        candidates: candidates,
        warnings: <LabelWarning>[LabelWarning.noDatesFound, ...warnings],
        batchCode: _findBatch(normalised),
        sourceText: normalised.join('\n'),
      );
    }

    final _Resolution resolved = _resolve(usable, now);
    warnings.addAll(resolved.warnings);

    return LabelReading(
      candidates: candidates,
      warnings: warnings.toList(growable: false),
      expiry: resolved.expiry,
      manufacturing: resolved.manufacturing,
      batchCode: _findBatch(normalised),
      sourceText: normalised.join('\n'),
    );
  }

  // ------------------------------------------------------------ normalising

  static const Map<String, String> _diacritics = <String, String>{
    'À': 'A', 'Á': 'A', 'Â': 'A', 'Ã': 'A', 'Ả': 'A', 'Ạ': 'A',
    'Ă': 'A', 'Ằ': 'A', 'Ắ': 'A', 'Ẵ': 'A', 'Ẳ': 'A', 'Ặ': 'A',
    'Ầ': 'A', 'Ấ': 'A', 'Ẫ': 'A', 'Ẩ': 'A', 'Ậ': 'A',
    'È': 'E', 'É': 'E', 'Ê': 'E', 'Ẽ': 'E', 'Ẻ': 'E', 'Ẹ': 'E',
    'Ề': 'E', 'Ế': 'E', 'Ễ': 'E', 'Ể': 'E', 'Ệ': 'E',
    'Ì': 'I', 'Í': 'I', 'Ĩ': 'I', 'Ỉ': 'I', 'Ị': 'I',
    'Ò': 'O', 'Ó': 'O', 'Ô': 'O', 'Õ': 'O', 'Ỏ': 'O', 'Ọ': 'O',
    'Ồ': 'O', 'Ố': 'O', 'Ỗ': 'O', 'Ổ': 'O', 'Ộ': 'O',
    'Ơ': 'O', 'Ờ': 'O', 'Ớ': 'O', 'Ỡ': 'O', 'Ở': 'O', 'Ợ': 'O',
    'Ù': 'U', 'Ú': 'U', 'Ũ': 'U', 'Ủ': 'U', 'Ụ': 'U',
    'Ư': 'U', 'Ừ': 'U', 'Ứ': 'U', 'Ữ': 'U', 'Ử': 'U', 'Ự': 'U',
    'Ỳ': 'Y', 'Ý': 'Y', 'Ỹ': 'Y', 'Ỷ': 'Y', 'Ỵ': 'Y',
    'Đ': 'D',
  };

  /// Uppercases, strips Vietnamese diacritics and collapses whitespace so a
  /// single set of keyword tables covers every way a label can be printed.
  static String normaliseLine(String raw) {
    final StringBuffer buffer = StringBuffer();
    for (final int rune in raw.toUpperCase().runes) {
      final String char = String.fromCharCode(rune);
      buffer.write(_diacritics[char] ?? char);
    }
    return buffer.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  // -------------------------------------------------------------- keywords

  /// Every keyword occurrence on a line, ordered left to right and with
  /// occurrences that sit inside a longer keyword removed, so that
  /// "NSX 010326 HSD 010327" assigns each date to its own label.
  List<_KeywordHit> _detectKeywords(String line) {
    final List<_KeywordHit> hits = <_KeywordHit>[];

    for (final MapEntry<String, LabelDateKind> entry in cjkKeywords.entries) {
      int from = 0;
      while (true) {
        final int index = line.indexOf(entry.key, from);
        if (index < 0) break;
        hits.add(_KeywordHit(entry.value, index, index + entry.key.length));
        from = index + entry.key.length;
      }
    }

    for (final ({List<String> words, LabelDateKind kind}) group
        in <({List<String> words, LabelDateKind kind})>[
      (words: expiryKeywords, kind: LabelDateKind.expiry),
      (words: manufacturingKeywords, kind: LabelDateKind.manufacturing),
      (words: packagingKeywords, kind: LabelDateKind.packaging),
    ]) {
      for (final String word in group.words) {
        int from = 0;
        while (true) {
          final int index = _indexOfWord(line, word, from);
          if (index < 0) break;
          hits.add(_KeywordHit(group.kind, index, index + word.length));
          from = index + word.length;
        }
      }
    }

    hits.sort((_KeywordHit a, _KeywordHit b) {
      final int byStart = a.start.compareTo(b.start);
      return byStart != 0 ? byStart : (b.end - b.start).compareTo(a.end - a.start);
    });

    final List<_KeywordHit> kept = <_KeywordHit>[];
    for (final _KeywordHit hit in hits) {
      final bool covered = kept.any((_KeywordHit k) => hit.start >= k.start && hit.end <= k.end);
      if (!covered) kept.add(hit);
    }
    return kept;
  }

  /// Word-boundary search so "EXPRESS" does not match "EXP" and the single
  /// letter "L" only matches when it stands alone.
  int _indexOfWord(String line, String word, [int from = 0]) {
    int cursor = from;
    while (true) {
      final int index = line.indexOf(word, cursor);
      if (index < 0) return -1;
      final bool startOk = index == 0 || !_isWordChar(line[index - 1]);
      final int after = index + word.length;
      final bool endOk = after >= line.length || !_isWordChar(line[after]);
      if (startOk && endOk) return index;
      cursor = index + 1;
    }
  }

  bool _isWordChar(String c) => RegExp(r'[A-Z0-9]').hasMatch(c);

  /// A keyword owns the dates printed after it, up to the next keyword.
  LabelDateKind _kindForMatch(
    _RawMatch match,
    List<_KeywordHit> hits,
    LabelDateKind fallback,
  ) {
    _KeywordHit? preceding;
    for (final _KeywordHit hit in hits) {
      if (hit.end <= match.start) {
        preceding = hit;
      } else {
        break;
      }
    }
    if (preceding != null) return preceding.kind;
    // "20/12/2026 HSD" - a trailing marker on an otherwise unlabelled line.
    if (hits.length == 1 && match.end <= hits.first.start) return hits.first.kind;
    return fallback;
  }

  // ----------------------------------------------------------- date finding

  static final RegExp _isoPattern =
      RegExp(r'(\d{4})[./\-](\d{1,2})[./\-](\d{1,2})');
  static final RegExp _numericPattern =
      RegExp(r'(\d{1,2})\s*[./\- ]\s*(\d{1,2})\s*[./\- ]\s*(\d{2,4})');
  static final RegExp _monthNamePattern = RegExp(
    '(?:(\\d{1,2})\\s*[.\\-/]?\\s*)?'
    '(${(monthNames.keys.toList()..sort((String a, String b) => b.length.compareTo(a.length))).join('|')})'
    '\\s*[.\\-/]?\\s*(\\d{2,4})',
  );
  static final RegExp _monthYearPattern = RegExp(r'(\d{1,2})\s*[./\-]\s*(\d{4})');
  static final RegExp _compact8Pattern = RegExp(r'(?<!\d)(\d{8})(?!\d)');
  static final RegExp _compact6Pattern = RegExp(r'(?<!\d)(\d{6})(?!\d)');
  static final RegExp _timePattern = RegExp(r'(\d{1,2})\s*[:hH]\s*(\d{2})');

  List<_RawMatch> _findDates(String line, DateTime now) {
    final List<_RawMatch> found = <_RawMatch>[];
    final List<({int start, int end})> consumed = <({int start, int end})>[];

    bool overlaps(int start, int end) => consumed
        .any((({int end, int start}) r) => start < r.end && end > r.start);

    void claim(int start, int end) => consumed.add((start: start, end: end));

    // 1. ISO first - unambiguous.
    for (final RegExpMatch m in _isoPattern.allMatches(line)) {
      if (overlaps(m.start, m.end)) continue;
      final DateTime? value = _buildDate(
        int.parse(m.group(1)!),
        int.parse(m.group(2)!),
        int.parse(m.group(3)!),
        now,
      );
      if (value == null) continue;
      claim(m.start, m.end);
      found.add(_RawMatch(
        value: value,
        rawText: m.group(0)!,
        start: m.start,
        end: m.end,
        fourDigitYear: true,
        dayKnown: true,
      ),);
    }

    // 2. Month names: 20 DEC 2026 / DEC 2026 / 20-THG12-2026
    for (final RegExpMatch m in _monthNamePattern.allMatches(line)) {
      if (overlaps(m.start, m.end)) continue;
      final String token = m.group(2)!;
      final int? month = monthNames[token];
      if (month == null) continue;
      final int year = _expandYear(int.parse(m.group(3)!), now);
      final String? dayText = m.group(1);
      final bool dayKnown = dayText != null;
      final DateTime? value =
          _buildDate(year, month, dayKnown ? int.parse(dayText) : 1, now);
      if (value == null) continue;
      claim(m.start, m.end);
      found.add(_RawMatch(
        value: value,
        rawText: m.group(0)!.trim(),
        start: m.start,
        end: m.end,
        fourDigitYear: m.group(3)!.length == 4,
        dayKnown: dayKnown,
      ),);
    }

    // 3. Numeric triples.
    for (final RegExpMatch m in _numericPattern.allMatches(line)) {
      if (overlaps(m.start, m.end)) continue;
      final int a = int.parse(m.group(1)!);
      final int b = int.parse(m.group(2)!);
      final String yearText = m.group(3)!;
      final int year = _expandYear(int.parse(yearText), now);

      int day;
      int month;
      bool ambiguous = false;
      if (a > 12 && b <= 12) {
        day = a;
        month = b;
      } else if (b > 12 && a <= 12) {
        day = b;
        month = a;
      } else {
        ambiguous = a != b;
        day = config.dayFirst ? a : b;
        month = config.dayFirst ? b : a;
      }
      final DateTime? value = _buildDate(year, month, day, now);
      if (value == null) continue;
      claim(m.start, m.end);
      found.add(_RawMatch(
        value: value,
        rawText: m.group(0)!,
        start: m.start,
        end: m.end,
        fourDigitYear: yearText.length == 4,
        dayKnown: true,
        ambiguous: ambiguous,
      ),);
    }

    // 4. Month/year only: 12/2026
    for (final RegExpMatch m in _monthYearPattern.allMatches(line)) {
      if (overlaps(m.start, m.end)) continue;
      final int month = int.parse(m.group(1)!);
      final int year = int.parse(m.group(2)!);
      final DateTime? value = _buildDate(year, month, 1, now);
      if (value == null) continue;
      claim(m.start, m.end);
      found.add(_RawMatch(
        value: value,
        rawText: m.group(0)!,
        start: m.start,
        end: m.end,
        fourDigitYear: true,
        dayKnown: false,
      ),);
    }

    // 5. Compact YYYYMMDD / DDMMYYYY.
    for (final RegExpMatch m in _compact8Pattern.allMatches(line)) {
      if (overlaps(m.start, m.end)) continue;
      final String digits = m.group(1)!;
      DateTime? value = _buildDate(
        int.parse(digits.substring(0, 4)),
        int.parse(digits.substring(4, 6)),
        int.parse(digits.substring(6, 8)),
        now,
      );
      value ??= _buildDate(
        int.parse(digits.substring(4, 8)),
        int.parse(digits.substring(2, 4)),
        int.parse(digits.substring(0, 2)),
        now,
      );
      if (value == null) continue;
      claim(m.start, m.end);
      found.add(_RawMatch(
        value: value,
        rawText: digits,
        start: m.start,
        end: m.end,
        fourDigitYear: true,
        dayKnown: true,
        fromCompactDigits: true,
      ),);
    }

    // 6. Compact DDMMYY / YYMMDD.
    for (final RegExpMatch m in _compact6Pattern.allMatches(line)) {
      if (overlaps(m.start, m.end)) continue;
      final String digits = m.group(1)!;
      DateTime? value = _buildDate(
        _expandYear(int.parse(digits.substring(4, 6)), now),
        int.parse(digits.substring(2, 4)),
        int.parse(digits.substring(0, 2)),
        now,
      );
      value ??= _buildDate(
        _expandYear(int.parse(digits.substring(0, 2)), now),
        int.parse(digits.substring(2, 4)),
        int.parse(digits.substring(4, 6)),
        now,
      );
      if (value == null) continue;
      claim(m.start, m.end);
      found.add(_RawMatch(
        value: value,
        rawText: digits,
        start: m.start,
        end: m.end,
        dayKnown: true,
        ambiguous: true,
        fromCompactDigits: true,
      ),);
    }

    if (found.isEmpty) return found;

    // Attach a time of day, when one is printed on the same line.
    final RegExpMatch? time = _timePattern.firstMatch(line);
    if (time != null) {
      final int hour = int.parse(time.group(1)!);
      final int minute = int.parse(time.group(2)!);
      if (hour <= 23 && minute <= 59 && !overlaps(time.start, time.end)) {
        for (int i = 0; i < found.length; i++) {
          final _RawMatch match = found[i];
          found[i] = match.withTime(hour, minute);
        }
      }
    }

    found.sort((_RawMatch a, _RawMatch b) => a.start.compareTo(b.start));
    return found;
  }

  int _expandYear(int raw, DateTime now) {
    if (raw >= 1000) return raw;
    if (raw >= 100) return raw; // OCR noise; the plausibility check rejects it.
    final int currentYy = now.year % 100;
    final int century = now.year - currentYy;
    final int difference = raw - currentYy;
    if (difference >= 51) return century - 100 + raw;
    if (difference <= -50) return century + 100 + raw;
    return century + raw;
  }

  DateTime? _buildDate(int year, int month, int day, DateTime now) {
    if (month < 1 || month > 12 || day < 1 || day > 31) return null;
    if (year < now.year - config.maxPastYears) return null;
    if (year > now.year + config.maxFutureYears) return null;
    final DateTime value = DateTime(year, month, day);
    if (value.year != year || value.month != month || value.day != day) return null;
    return value;
  }

  // ------------------------------------------------------------- resolution

  _Resolution _resolve(List<LabelDate> candidates, DateTime now) {
    final Set<LabelWarning> warnings = <LabelWarning>{};
    final List<LabelDate> sorted = List<LabelDate>.of(candidates)
      ..sort((LabelDate a, LabelDate b) => b.confidence.compareTo(a.confidence));

    LabelDate? expiry = sorted.where((LabelDate c) => c.kind == LabelDateKind.expiry).firstOrNull;
    LabelDate? manufacturing =
        sorted.where((LabelDate c) => c.kind == LabelDateKind.manufacturing).firstOrNull;
    manufacturing ??=
        sorted.where((LabelDate c) => c.kind == LabelDateKind.packaging).firstOrNull;

    if (sorted.where((LabelDate c) => c.kind == LabelDateKind.expiry).length > 1) {
      warnings.add(LabelWarning.multipleExpiryCandidates);
    }

    final List<LabelDate> unknown = sorted
        .where((LabelDate c) => c.kind == LabelDateKind.unknown)
        .toList(growable: false);

    if (expiry == null && unknown.isNotEmpty) {
      if (manufacturing == null && unknown.length >= 2) {
        final List<LabelDate> byDate = List<LabelDate>.of(unknown)
          ..sort((LabelDate a, LabelDate b) => a.value.compareTo(b.value));
        manufacturing = byDate.first.copyWith(
          kind: LabelDateKind.manufacturing,
          confidence: byDate.first.confidence * 0.8,
        );
        expiry = byDate.last.copyWith(
          kind: LabelDateKind.expiry,
          confidence: byDate.last.confidence * 0.8,
        );
      } else {
        final LabelDate candidate = unknown.first;
        final bool inFuture = !candidate.value.isBefore(DateTime(now.year, now.month, now.day));
        if (inFuture) {
          expiry = candidate.copyWith(
            kind: LabelDateKind.expiry,
            confidence: candidate.confidence * 0.85,
          );
        } else {
          manufacturing ??= candidate.copyWith(
            kind: LabelDateKind.manufacturing,
            confidence: candidate.confidence * 0.85,
          );
        }
      }
    }

    // A month-only expiry means "good through the end of that month".
    if (expiry != null && !expiry.dayKnown) {
      final DateTime v = expiry.value;
      expiry = expiry.copyWith(value: DateTime(v.year, v.month + 1, 0));
    }

    if (expiry != null && manufacturing != null &&
        !expiry.value.isAfter(manufacturing.value)) {
      warnings.add(LabelWarning.expiryBeforeManufacturing);
    }
    if (expiry != null && expiry.value.isBefore(DateTime(now.year, now.month, now.day))) {
      warnings.add(LabelWarning.expiryAlreadyPassed);
    }

    return _Resolution(expiry: expiry, manufacturing: manufacturing, warnings: warnings);
  }

  // ------------------------------------------------------------------ batch

  static final RegExp _batchValuePattern = RegExp(r'[A-Z0-9][A-Z0-9\-/]{1,19}');

  String? _findBatch(List<String> lines) {
    for (final String line in lines) {
      for (final String keyword in batchKeywords) {
        final int index = _indexOfWord(line, keyword);
        if (index < 0) continue;
        final String tail = line.substring(index + keyword.length);
        final String cleaned = tail.replaceFirst(RegExp(r'^\s*[:.#\-]?\s*'), '');
        final RegExpMatch? value = _batchValuePattern.firstMatch(cleaned);
        if (value == null) continue;
        final String candidate = value.group(0)!;
        // A pure date is not a batch code.
        if (RegExp(r'^\d{1,2}[./\-]\d{1,2}[./\-]\d{2,4}$').hasMatch(candidate)) continue;
        if (candidate.length < 2) continue;
        return candidate;
      }
    }
    return null;
  }
}

class _KeywordHit {
  const _KeywordHit(this.kind, this.start, this.end);
  final LabelDateKind kind;
  final int start;
  final int end;
}

class _RawMatch {
  const _RawMatch({
    required this.value,
    required this.rawText,
    required this.start,
    required this.end,
    this.fourDigitYear = false,
    this.dayKnown = true,
    this.ambiguous = false,
    this.hasTime = false,
    this.fromCompactDigits = false,
  });

  final DateTime value;
  final String rawText;
  final int start;
  final int end;
  final bool fourDigitYear;
  final bool dayKnown;
  final bool ambiguous;
  final bool hasTime;
  final bool fromCompactDigits;

  _RawMatch withTime(int hour, int minute) => _RawMatch(
        value: DateTime(value.year, value.month, value.day, hour, minute),
        rawText: rawText,
        start: start,
        end: end,
        fourDigitYear: fourDigitYear,
        dayKnown: dayKnown,
        ambiguous: ambiguous,
        hasTime: true,
        fromCompactDigits: fromCompactDigits,
      );
}

class _Resolution {
  const _Resolution({required this.warnings, this.expiry, this.manufacturing});
  final LabelDate? expiry;
  final LabelDate? manufacturing;
  final Set<LabelWarning> warnings;
}
