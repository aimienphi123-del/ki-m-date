/// Parsed GS1 Application Identifier payload.
class Gs1Data {
  const Gs1Data({
    this.gtin,
    this.batchOrLot,
    this.serial,
    this.productionDate,
    this.packagingDate,
    this.bestBeforeDate,
    this.expirationDate,
    this.expirationDateTime,
    this.rawElements = const <String, String>{},
  });

  /// AI 01 / 02
  final String? gtin;

  /// AI 10
  final String? batchOrLot;

  /// AI 21
  final String? serial;

  /// AI 11
  final DateTime? productionDate;

  /// AI 13
  final DateTime? packagingDate;

  /// AI 15
  final DateTime? bestBeforeDate;

  /// AI 17
  final DateTime? expirationDate;

  /// AI 7003 - expiry with a time of day, used by fresh-food packers.
  final DateTime? expirationDateTime;

  final Map<String, String> rawElements;

  bool get isEmpty => rawElements.isEmpty;

  /// The date the policy engine should treat as the expiry, preferring the
  /// most specific application identifier available.
  DateTime? get effectiveExpiry => expirationDateTime ?? expirationDate ?? bestBeforeDate;

  bool get expiryHasTime => expirationDateTime != null;

  @override
  String toString() => 'Gs1Data(${rawElements.keys.join(',')})';
}

/// Parses GS1 element strings out of a scanned barcode value.
///
/// Most GS1-128, DataMatrix and QR codes on cases and fresh-food trays carry
/// the expiry date, the batch and the GTIN directly. Reading them means the
/// employee often does not have to OCR the printed label at all.
class Gs1Parser {
  const Gs1Parser();

  /// FNC1 / group separator (ASCII 29).
  static const String groupSeparator = '\u001D';

  /// Application identifier -> data length, for fixed-length identifiers.
  static const Map<String, int> fixedLengthAis = <String, int>{
    '00': 18,
    '01': 14,
    '02': 14,
    '03': 14,
    '04': 16,
    '11': 6,
    '12': 6,
    '13': 6,
    '14': 6,
    '15': 6,
    '16': 6,
    '17': 6,
    '18': 6,
    '19': 6,
    '20': 2,
    '31': 7,
    '32': 7,
    '33': 7,
    '34': 7,
    '35': 7,
    '36': 7,
    '41': 13,
  };

  static const Set<String> variableLengthAis = <String>{
    '10', '21', '22', '30', '37', '90', '91', '92', '93', '94', '95',
    '96', '97', '98', '99', '235', '240', '241', '242', '243', '250',
    '251', '253', '254', '255', '400', '401', '402', '403', '410',
    '411', '412', '413', '414', '415', '416', '417', '420', '421',
    '422', '423', '424', '425', '426', '427', '7003', '7004', '7005',
    '7006', '7007', '7020', '7021', '7022', '8020',
  };

  static const int maxVariableLength = 30;

  /// Cheap test so the caller can skip the full parse for ordinary retail
  /// barcodes (EAN-13, UPC-A, ...), which carry no element strings.
  bool looksLikeGs1(String raw) {
    final String value = normalise(raw);
    if (value.length < 4) return false;
    if (raw.startsWith(']C1') || raw.startsWith(']e0') || raw.startsWith(']d2')) return true;
    if (value.contains(groupSeparator)) return true;
    if (RegExp(r'^\d{8}$|^\d{12,14}$').hasMatch(value)) return false;
    final String prefix2 = value.substring(0, 2);
    return fixedLengthAis.containsKey(prefix2) || variableLengthAis.contains(prefix2);
  }

  Gs1Data parse(String raw, {DateTime? reference}) {
    final String value = normalise(raw);
    final Map<String, String> elements = <String, String>{};
    int index = 0;

    while (index < value.length) {
      if (value[index] == groupSeparator) {
        index++;
        continue;
      }
      final ({String ai, int length})? header = _readAi(value, index);
      if (header == null) break;
      final String ai = header.ai;
      index += header.length;

      final int? fixed = fixedLengthAis[ai];
      final String data;
      if (fixed != null) {
        if (index + fixed > value.length) break;
        data = value.substring(index, index + fixed);
        index += fixed;
      } else {
        int end = value.indexOf(groupSeparator, index);
        if (end < 0) end = value.length;
        final int limit = index + maxVariableLength;
        if (end > limit) end = limit;
        data = value.substring(index, end);
        index = end;
        if (index < value.length && value[index] == groupSeparator) index++;
      }
      elements[ai] = data;
    }

    final DateTime now = reference ?? DateTime.now();
    return Gs1Data(
      gtin: elements['01'] ?? elements['02'],
      batchOrLot: elements['10'],
      serial: elements['21'],
      productionDate: parseGs1Date(elements['11'], now),
      packagingDate: parseGs1Date(elements['13'], now),
      bestBeforeDate: parseGs1Date(elements['15'], now),
      expirationDate: parseGs1Date(elements['17'], now),
      expirationDateTime: _parseGs1DateTime(elements['7003'], now),
      rawElements: elements,
    );
  }

  /// Strips the symbology identifier and normalises the separator characters
  /// that different scanners emit for FNC1.
  String normalise(String raw) {
    String value = raw;
    for (final String symbology in <String>[']C1', ']e0', ']d2', ']Q3', ']C0']) {
      if (value.startsWith(symbology)) {
        value = value.substring(symbology.length);
        break;
      }
    }
    return value
        .replaceAll('{GS}', groupSeparator)
        .replaceAll('<GS>', groupSeparator);
  }

  ({String ai, int length})? _readAi(String value, int index) {
    for (final int length in <int>[4, 3, 2]) {
      if (index + length > value.length) continue;
      final String candidate = value.substring(index, index + length);
      if (!RegExp(r'^\d+$').hasMatch(candidate)) continue;
      if (fixedLengthAis.containsKey(candidate) || variableLengthAis.contains(candidate)) {
        return (ai: candidate, length: length);
      }
    }
    // Unknown identifier: fall back to the two-digit prefix so that parsing
    // degrades gracefully instead of discarding the whole payload.
    if (index + 2 <= value.length &&
        RegExp(r'^\d{2}$').hasMatch(value.substring(index, index + 2))) {
      return (ai: value.substring(index, index + 2), length: 2);
    }
    return null;
  }

  /// GS1 dates are YYMMDD. A day of `00` means "end of that month".
  static DateTime? parseGs1Date(String? value, DateTime reference) {
    if (value == null || value.length != 6 || !RegExp(r'^\d{6}$').hasMatch(value)) return null;
    final int yy = int.parse(value.substring(0, 2));
    final int month = int.parse(value.substring(2, 4));
    final int day = int.parse(value.substring(4, 6));
    if (month < 1 || month > 12) return null;
    final int year = expandYear(yy, reference);
    if (day == 0) return DateTime(year, month + 1, 0);
    if (day > 31) return null;
    final DateTime candidate = DateTime(year, month, day);
    if (candidate.month != month || candidate.day != day) return null;
    return candidate;
  }

  static DateTime? _parseGs1DateTime(String? value, DateTime reference) {
    if (value == null || value.length < 6) return null;
    final DateTime? date = parseGs1Date(value.substring(0, 6), reference);
    if (date == null) return null;
    if (value.length < 10 || !RegExp(r'^\d{10}$').hasMatch(value.substring(0, 10))) return date;
    final int hour = int.parse(value.substring(6, 8));
    final int minute = int.parse(value.substring(8, 10));
    if (hour > 23 || minute > 59) return date;
    return DateTime(date.year, date.month, date.day, hour, minute);
  }

  /// GS1 General Specifications century rule for two-digit years.
  static int expandYear(int yy, DateTime reference) {
    final int currentYy = reference.year % 100;
    final int century = reference.year - currentYy;
    final int difference = yy - currentYy;
    if (difference >= 51) return century - 100 + yy;
    if (difference <= -50) return century + 100 + yy;
    return century + yy;
  }
}
