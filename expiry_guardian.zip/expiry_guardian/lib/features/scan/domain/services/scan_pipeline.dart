import 'dart:io';
import 'dart:typed_data';

import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/scan/data/services/image_enhancer.dart';
import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scan_outcome.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:expiry_guardian/features/scan/domain/services/gs1_parser.dart';
import 'package:expiry_guardian/features/scan/domain/services/image_quality.dart';
import 'package:expiry_guardian/features/scan/domain/services/label_text_parser.dart';

/// Options for one capture, all driven by Settings.
class ScanOptions {
  const ScanOptions({
    this.enhanceImages = true,
    this.keepPhoto = true,
    this.readBarcodes = true,
    this.readText = true,
    this.quality = const ImageQualityConfig(),
    this.parser = const LabelParserConfig(),
  });

  final bool enhanceImages;
  final bool keepPhoto;
  final bool readBarcodes;
  final bool readText;
  final ImageQualityConfig quality;
  final LabelParserConfig parser;
}

/// Runs one captured still through the whole camera-AI chain:
/// quality check -> automatic crop -> enhancement -> barcode -> GS1 ->
/// OCR -> label parsing -> catalog lookup.
///
/// The pipeline reports what it read and how confident it is; it never
/// fabricates a value it did not read.
class ScanPipeline {
  ScanPipeline({
    required BarcodeReader barcodeReader,
    required TextReader textReader,
    required CatalogRepository catalog,
    required Clock clock,
    required AppLogger logger,
    Gs1Parser gs1Parser = const Gs1Parser(),
    ImageEnhancer enhancer = const ImageEnhancer(),
  })  : _barcodeReader = barcodeReader,
        _textReader = textReader,
        _catalog = catalog,
        _clock = clock,
        _logger = logger,
        _gs1 = gs1Parser,
        _enhancer = enhancer;

  final BarcodeReader _barcodeReader;
  final TextReader _textReader;
  final CatalogRepository _catalog;
  final Clock _clock;
  final AppLogger _logger;
  final Gs1Parser _gs1;
  final ImageEnhancer _enhancer;

  static const String _tag = 'ScanPipeline';

  /// [alreadyRead] and [alreadyReadLines] carry what the live viewfinder
  /// decoded before the shutter fired. When either is non-empty the pipeline
  /// trusts it rather than re-reading the still: the stream had dozens of
  /// chances at the label and the photograph gets exactly one.
  Future<Result<ScanOutcome>> process(
    String capturePath, {
    ScanOptions options = const ScanOptions(),
    List<ScannedCode> alreadyRead = const <ScannedCode>[],
    List<RecognisedLine> alreadyReadLines = const <RecognisedLine>[],
  }) async {
    try {
      final DateTime now = _clock.now();
      final File original = File(capturePath);
      final bool hasCapture = capturePath.isNotEmpty && original.existsSync();
      final bool hasLiveReading =
          alreadyRead.isNotEmpty || alreadyReadLines.isNotEmpty;

      // No image and nothing read from the stream is genuinely nothing to work
      // with. But an image that failed to save while the live pass *did* read
      // the label must not throw that reading away - the scan succeeded, only
      // the souvenir photograph did not.
      if (!hasCapture && !hasLiveReading) {
        return Result<ScanOutcome>.err(
          const Failure.validation('capture_missing'),
        );
      }

      // 1. First pass on the untouched capture: locate the code so we know
      //    where to crop, and measure quality. A code the live scanner
      //    already decoded is better than anything this still can give us.
      List<ScannedCode> codes = alreadyRead.isNotEmpty
          ? alreadyRead
          : options.readBarcodes && hasCapture
              ? await _barcodeReader.readFile(capturePath)
              : const <ScannedCode>[];

      final Uint8List rawBytes =
          hasCapture ? await original.readAsBytes() : Uint8List(0);
      ImageQualityReport? quality = hasCapture
          ? ImageEnhancer.inspect(rawBytes, config: options.quality)
          : null;

      String workingPath = capturePath;
      List<String> steps = const <String>[];

      // 2. Enhance when the frame is not already clean, cropping to whatever
      //    the detector found.
      final bool needsWork = hasCapture &&
          options.enhanceImages &&
          (quality == null || !quality.isUsable || quality.isLowContrast);
      if (needsWork) {
        final EnhanceResult? enhanced = await _enhancer.enhance(EnhanceRequest(
          // Whole frame: the expiry date is rarely next to the barcode, so
          // cropping to the code here would throw the date away.
          bytes: rawBytes,
          quality: options.quality,
        ),);
        if (enhanced != null) {
          workingPath = await _writeSibling(capturePath, enhanced.bytes, 'enhanced');
          quality = enhanced.after;
          steps = enhanced.appliedSteps;
          if (codes.isEmpty && options.readBarcodes) {
            codes = await _barcodeReader.readFile(workingPath);
          }
          _logger.d(_tag, 'Enhanced capture: ${steps.join(', ')}');
        }
      }

      // 3. GS1 element strings, when the code carries them.
      Gs1Data? gs1;
      String? primaryBarcode;
      for (final ScannedCode code in codes) {
        if (_gs1.looksLikeGs1(code.rawValue)) {
          final Gs1Data parsed = _gs1.parse(code.rawValue, reference: now);
          if (!parsed.isEmpty) {
            gs1 = parsed;
            primaryBarcode ??= parsed.gtin ?? code.rawValue;
            continue;
          }
        }
        primaryBarcode ??= code.rawValue;
      }

      // 4. OCR the label for anything the barcode did not carry.
      LabelReading reading = const LabelReading.empty();
      final bool needsOcr = options.readText &&
          (gs1?.effectiveExpiry == null || gs1?.batchOrLot == null);
      if (needsOcr) {
        final LabelTextParser parser = LabelTextParser(config: options.parser);
        // Lines the live recogniser already read beat anything a single still
        // can offer, for exactly the reason the barcode path does.
        final List<RecognisedLine> lines = alreadyReadLines.isNotEmpty
            ? alreadyReadLines
            : hasCapture
                ? await _textReader.readFile(workingPath)
                : const <RecognisedLine>[];
        reading = parser.parse(
          lines.map((RecognisedLine l) => l.text).toList(),
          now: now,
        );

        // Second pass: when the full frame produced no expiry, crop to the
        // text region the recogniser did find, enhance it at a much higher
        // effective resolution and read it again. Small printed dates on a
        // large package are exactly the case that needs this.
        if (!reading.hasExpiry && options.enhanceImages && hasCapture) {
          final ScanBox? textRegion = ScanBox.union(
            lines
                .where((RecognisedLine l) => RegExp(r'\d').hasMatch(l.text))
                .map((RecognisedLine l) => l.boundingBox)
                .whereType<ScanBox>(),
          );
          if (textRegion != null && textRegion.width > 24 && textRegion.height > 12) {
            final EnhanceResult? cropped = await _enhancer.enhance(EnhanceRequest(
              bytes: await File(workingPath).readAsBytes(),
              cropTo: textRegion,
              cropPadding: 0.25,
              quality: options.quality,
            ),);
            if (cropped != null) {
              final String croppedPath =
                  await _writeSibling(capturePath, cropped.bytes, 'cropped');
              final List<RecognisedLine> retry = await _textReader.readFile(croppedPath);
              final LabelReading second = parser.parse(
                retry.map((RecognisedLine l) => l.text).toList(),
                now: now,
              );
              steps = <String>[...steps, 'autoCrop', ...cropped.appliedSteps];
              if (second.hasExpiry) {
                reading = second;
                _logger.d(_tag, 'Auto-cropped retry recovered the expiry date');
              }
              if (!options.keepPhoto) {
                await _deleteQuietly(croppedPath);
              }
            }
          }
        }
      }

      // 5. Merge, preferring the machine-readable source.
      final CapturedField<DateTime> expiry = _pickDate(
        gs1Value: gs1?.effectiveExpiry,
        ocrValue: reading.expiry,
      );
      final CapturedField<DateTime> manufactured = _pickDate(
        gs1Value: gs1?.productionDate,
        ocrValue: reading.manufacturing,
      );
      final CapturedField<String> batch = _pickText(
        gs1Value: gs1?.batchOrLot,
        ocrValue: reading.batchCode,
      );

      // 6. Resolve the product from the store's own catalog.
      Product? product;
      if (primaryBarcode != null) {
        final Result<Product?> lookup = await _catalog.findByBarcode(primaryBarcode);
        product = lookup.valueOrNull;
      }

      final ExpiryPrecision precision = _precisionOf(
        product: product,
        gs1: gs1,
        reading: reading,
      );

      if (!options.keepPhoto && workingPath != capturePath) {
        await _deleteQuietly(workingPath);
      }

      return Result<ScanOutcome>.ok(ScanOutcome(
        codes: codes,
        gs1: gs1,
        labelReading: reading,
        expiry: expiry,
        manufactured: manufactured,
        batchCode: batch,
        precision: precision,
        quality: quality,
        product: product,
        primaryBarcode: primaryBarcode,
        photoPath: options.keepPhoto && hasCapture ? workingPath : null,
        enhancementSteps: steps,
      ),);
    } on Object catch (error, stackTrace) {
      _logger.e(_tag, 'Scan pipeline failed', error: error, stackTrace: stackTrace);
      return Result<ScanOutcome>.err(
        Failure.unknown('scan_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  /// Barcode-carried dates are exact; OCR is a best effort.
  CapturedField<DateTime> _pickDate({
    required DateTime? gs1Value,
    required LabelDate? ocrValue,
  }) {
    if (gs1Value != null) {
      return CapturedField<DateTime>(value: gs1Value, source: FieldSource.barcodeGs1);
    }
    if (ocrValue != null) {
      return CapturedField<DateTime>(
        value: ocrValue.value,
        source: FieldSource.ocr,
        confidence: ocrValue.confidence,
      );
    }
    return const CapturedField<DateTime>.none();
  }

  CapturedField<String> _pickText({required String? gs1Value, required String? ocrValue}) {
    if (gs1Value != null && gs1Value.isNotEmpty) {
      return CapturedField<String>(value: gs1Value, source: FieldSource.barcodeGs1);
    }
    if (ocrValue != null && ocrValue.isNotEmpty) {
      return CapturedField<String>(value: ocrValue, source: FieldSource.ocr, confidence: 0.7);
    }
    return const CapturedField<String>.none();
  }

  ExpiryPrecision _precisionOf({
    required Product? product,
    required Gs1Data? gs1,
    required LabelReading reading,
  }) {
    if (gs1?.expiryHasTime ?? false) return ExpiryPrecision.hour;
    if (reading.expiry?.hasTime ?? false) return ExpiryPrecision.hour;
    return product?.expiryPrecision ?? ExpiryPrecision.day;
  }

  Future<void> _deleteQuietly(String path) async {
    try {
      final File file = File(path);
      if (file.existsSync()) await file.delete();
    } on FileSystemException {
      // A leftover temporary file is not worth failing a scan over.
    }
  }

  Future<String> _writeSibling(String originalPath, Uint8List bytes, String suffix) async {
    final int dot = originalPath.lastIndexOf('.');
    final String base = dot < 0 ? originalPath : originalPath.substring(0, dot);
    final String path = '$base.$suffix.jpg';
    await File(path).writeAsBytes(bytes, flush: true);
    return path;
  }

  Future<void> dispose() async {
    await _barcodeReader.dispose();
    await _textReader.dispose();
  }
}
