import 'dart:math' as math;
import 'dart:typed_data';

/// A grayscale view of a frame, ready for cheap numeric analysis.
class GrayFrame {
  const GrayFrame({required this.pixels, required this.width, required this.height});

  final Uint8List pixels;
  final int width;
  final int height;

  int at(int x, int y) => pixels[y * width + x];
}

/// Numeric verdict on one captured frame.
class ImageQualityReport {
  const ImageQualityReport({
    required this.sharpness,
    required this.brightness,
    required this.contrast,
    required this.clippedShadows,
    required this.clippedHighlights,
    required this.blurThreshold,
    required this.darkThreshold,
    required this.brightThreshold,
  });

  /// Variance of the Laplacian. Higher is sharper; typical in-focus label
  /// photos score in the hundreds, a motion-blurred one in the tens.
  final double sharpness;

  /// Mean luminance, 0..255.
  final double brightness;

  /// Standard deviation of luminance, 0..127ish.
  final double contrast;

  /// Fraction of pixels at 0..4 and 250..255.
  final double clippedShadows;
  final double clippedHighlights;

  final double blurThreshold;
  final double darkThreshold;
  final double brightThreshold;

  bool get isBlurry => sharpness < blurThreshold;
  bool get isTooDark => brightness < darkThreshold;
  bool get isTooBright => brightness > brightThreshold;
  bool get isLowContrast => contrast < 25;

  bool get isUsable => !isBlurry && !isTooDark && !isTooBright;

  /// 0..1 - drives the "hold steady" indicator on the camera screen.
  double get score {
    final double sharp = (sharpness / (blurThreshold * 2)).clamp(0.0, 1.0);
    final double exposure = 1.0 -
        ((brightness - (darkThreshold + brightThreshold) / 2).abs() /
                ((brightThreshold - darkThreshold) / 2))
            .clamp(0.0, 1.0);
    final double detail = (contrast / 60).clamp(0.0, 1.0);
    return (sharp * 0.55 + exposure * 0.3 + detail * 0.15).clamp(0.0, 1.0);
  }

  @override
  String toString() =>
      'ImageQualityReport(sharpness=${sharpness.toStringAsFixed(1)}, '
      'brightness=${brightness.toStringAsFixed(1)}, contrast=${contrast.toStringAsFixed(1)})';
}

/// Tuning knobs, all exposed in Settings.
class ImageQualityConfig {
  const ImageQualityConfig({
    this.blurThreshold = 90,
    this.darkThreshold = 70,
    this.brightThreshold = 225,
    this.analysisWidth = 480,
  });

  final double blurThreshold;
  final double darkThreshold;
  final double brightThreshold;

  /// Frames are downscaled to this width before analysis so the maths stays
  /// cheap enough to run on every preview frame.
  final int analysisWidth;
}

/// Pure numeric image analysis - no plugin, no platform channel, fully
/// unit-testable.
class ImageQualityAnalyzer {
  const ImageQualityAnalyzer({this.config = const ImageQualityConfig()});

  final ImageQualityConfig config;

  ImageQualityReport analyze(GrayFrame frame) {
    final double brightness = _mean(frame.pixels);
    final double contrast = _standardDeviation(frame.pixels, brightness);
    final double sharpness = laplacianVariance(frame);
    final ({double highlights, double shadows}) clipped = _clipping(frame.pixels);

    return ImageQualityReport(
      sharpness: sharpness,
      brightness: brightness,
      contrast: contrast,
      clippedShadows: clipped.shadows,
      clippedHighlights: clipped.highlights,
      blurThreshold: config.blurThreshold,
      darkThreshold: config.darkThreshold,
      brightThreshold: config.brightThreshold,
    );
  }

  /// Variance of the 4-neighbour Laplacian response - the standard, cheap
  /// focus measure.
  static double laplacianVariance(GrayFrame frame) {
    if (frame.width < 3 || frame.height < 3) return 0;
    final int count = (frame.width - 2) * (frame.height - 2);
    if (count <= 0) return 0;

    double sum = 0;
    double sumSquares = 0;
    for (int y = 1; y < frame.height - 1; y++) {
      final int row = y * frame.width;
      for (int x = 1; x < frame.width - 1; x++) {
        final int index = row + x;
        final int response = frame.pixels[index - frame.width] +
            frame.pixels[index + frame.width] +
            frame.pixels[index - 1] +
            frame.pixels[index + 1] -
            4 * frame.pixels[index];
        sum += response;
        sumSquares += response * response;
      }
    }
    final double mean = sum / count;
    return (sumSquares / count) - (mean * mean);
  }

  static double _mean(Uint8List pixels) {
    if (pixels.isEmpty) return 0;
    int total = 0;
    for (final int value in pixels) {
      total += value;
    }
    return total / pixels.length;
  }

  static double _standardDeviation(Uint8List pixels, double mean) {
    if (pixels.isEmpty) return 0;
    double sum = 0;
    for (final int value in pixels) {
      final double delta = value - mean;
      sum += delta * delta;
    }
    return math.sqrt(sum / pixels.length);
  }

  static ({double shadows, double highlights}) _clipping(Uint8List pixels) {
    if (pixels.isEmpty) return (shadows: 0, highlights: 0);
    int dark = 0;
    int bright = 0;
    for (final int value in pixels) {
      if (value <= 4) dark++;
      if (value >= 250) bright++;
    }
    return (shadows: dark / pixels.length, highlights: bright / pixels.length);
  }

  /// Percentile pair used by the contrast stretch in [ImageEnhancer].
  static ({int low, int high}) percentileBounds(
    Uint8List pixels, {
    double lowFraction = 0.02,
    double highFraction = 0.98,
  }) {
    if (pixels.isEmpty) return (low: 0, high: 255);
    final List<int> histogram = List<int>.filled(256, 0);
    for (final int value in pixels) {
      histogram[value]++;
    }
    final int lowTarget = (pixels.length * lowFraction).round();
    final int highTarget = (pixels.length * highFraction).round();

    int cumulative = 0;
    int low = 0;
    int high = 255;
    for (int i = 0; i < 256; i++) {
      cumulative += histogram[i];
      if (cumulative >= lowTarget) {
        low = i;
        break;
      }
    }
    cumulative = 0;
    for (int i = 0; i < 256; i++) {
      cumulative += histogram[i];
      if (cumulative >= highTarget) {
        high = i;
        break;
      }
    }
    if (high <= low) {
      low = 0;
      high = 255;
    }
    return (low: low, high: high);
  }
}
