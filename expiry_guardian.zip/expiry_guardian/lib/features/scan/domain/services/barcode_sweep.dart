import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/features/scan/domain/entities/scanned_code.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';

/// One thing worth handing the decoder: a label for the log and the file.
class ScanAttempt {
  const ScanAttempt(this.label, this.path);

  final String label;
  final String path;
}

/// Produces the successive renderings of a still that a stubborn barcode is
/// worth trying.
///
/// Kept behind an interface so the order and the stopping rule below can be
/// tested without decoding a single JPEG.
abstract class BarcodeVariants {
  /// The same photograph turned a quarter, a half and three quarters round.
  Future<List<ScanAttempt>> rotations(String path);

  /// Those same orientations again with the contrast pulled apart and the
  /// edges sharpened - the last resort for a faint or shadowed pack.
  Future<List<ScanAttempt>> enhanced(String path);
}

/// What the sweep found, and which rendering finally gave it up.
class SweepResult {
  const SweepResult(this.codes, this.attempt);

  final List<ScannedCode> codes;

  /// `asStored` when the untouched capture decoded, otherwise the label of
  /// the variant that worked, otherwise `none`.
  final String attempt;

  bool get isEmpty => codes.isEmpty;
}

/// Reads a still at every orientation before giving up on it.
///
/// A phone camera stores the frame the way the handset was held, and a person
/// reaching for a yoghurt lid or a bottle on a shelf does not rotate their
/// wrist to make the print horizontal - the code arrives sideways or upside
/// down. ML Kit sweeps its scanlines across the buffer it is given, so a
/// quarter turn is the difference between a clean read and nothing at all,
/// and the one attempt a photograph gets is otherwise spent at the one
/// orientation the employee happened to hold.
///
/// Order matters and is deliberate: upside down first, because that is what a
/// lid photographed from above produces, then the two quarter turns, then the
/// same four with the image cleaned up.
class BarcodeSweep {
  const BarcodeSweep({
    required BarcodeReader reader,
    required BarcodeVariants variants,
    AppLogger? logger,
  })  : _reader = reader,
        _variants = variants,
        _logger = logger;

  final BarcodeReader _reader;
  final BarcodeVariants _variants;
  final AppLogger? _logger;

  static const String _tag = 'BarcodeSweep';

  Future<SweepResult> read(String path) async {
    if (path.isEmpty) return const SweepResult(<ScannedCode>[], 'none');

    List<ScannedCode> codes = await _tryRead(path);
    if (codes.isNotEmpty) return SweepResult(codes, 'asStored');

    // Turning the picture is cheap next to giving up: the employee's
    // alternative is typing thirteen digits off a curved foil lid.
    for (final ScanAttempt attempt in await _variants.rotations(path)) {
      codes = await _tryRead(attempt.path);
      if (codes.isNotEmpty) {
        _logger?.d(_tag, 'Decoded after ${attempt.label}');
        return SweepResult(codes, attempt.label);
      }
    }

    for (final ScanAttempt attempt in await _variants.enhanced(path)) {
      codes = await _tryRead(attempt.path);
      if (codes.isNotEmpty) {
        _logger?.d(_tag, 'Decoded after ${attempt.label}');
        return SweepResult(codes, attempt.label);
      }
    }

    return const SweepResult(<ScannedCode>[], 'none');
  }

  /// A variant that cannot be decoded - or cannot even be opened - must not
  /// end the sweep: the next orientation is exactly the one that might work.
  Future<List<ScannedCode>> _tryRead(String path) async {
    if (path.isEmpty) return const <ScannedCode>[];
    try {
      return await _reader.readFile(path);
    } on Object catch (error) {
      _logger?.d(_tag, 'Variant $path not decodable: $error');
      return const <ScannedCode>[];
    }
  }
}
