import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product_category.dart';

abstract final class CatalogMapper {
  static Product productFromRow(Map<String, Object?> row) => Product(
        id: row.str('id'),
        barcode: row.strOrNull('barcode'),
        name: row.str('name'),
        brand: row.strOrNull('brand'),
        categoryId: row.strOrNull('category_id'),
        unit: row.strOrNull('unit') ?? 'pcs',
        defaultShelfId: row.strOrNull('default_shelf_id'),
        expiryPrecision: ExpiryPrecision.fromName(row.strOrNull('expiry_precision')),
        defaultShelfLife: row.durationOrNull('default_shelf_life_minutes'),
        unitCost: row.numberOrNull('unit_cost'),
        photoPath: row.strOrNull('photo_path'),
        notes: row.strOrNull('notes'),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
      );

  static Map<String, Object?> productToRow(Product product) => <String, Object?>{
        'id': product.id,
        'barcode': product.barcode,
        'name': product.name,
        'brand': product.brand,
        'category_id': product.categoryId,
        'unit': product.unit,
        'default_shelf_id': product.defaultShelfId,
        'expiry_precision': product.expiryPrecision.name,
        'default_shelf_life_minutes': product.defaultShelfLife?.inMinutes,
        'unit_cost': product.unitCost,
        'photo_path': product.photoPath,
        'notes': product.notes,
        'is_active': boolToInt(product.isActive),
        'created_at': product.createdAt.millisecondsSinceEpoch,
        'updated_at': product.updatedAt.millisecondsSinceEpoch,
      };

  static ProductBarcode barcodeFromRow(Map<String, Object?> row) => ProductBarcode(
        id: row.str('id'),
        productId: row.str('product_id'),
        barcode: row.str('barcode'),
        kind: row.strOrNull('kind') ?? 'unit',
        createdAt: row.dateTime('created_at'),
      );

  static Map<String, Object?> barcodeToRow(ProductBarcode barcode) => <String, Object?>{
        'id': barcode.id,
        'product_id': barcode.productId,
        'barcode': barcode.barcode,
        'kind': barcode.kind,
        'created_at': barcode.createdAt.millisecondsSinceEpoch,
      };

  static ProductCategory categoryFromRow(Map<String, Object?> row) => ProductCategory(
        id: row.str('id'),
        name: row.str('name'),
        parentId: row.strOrNull('parent_id'),
        sortOrder: row.integer('sort_order'),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
      );

  static Map<String, Object?> categoryToRow(ProductCategory category) => <String, Object?>{
        'id': category.id,
        'name': category.name,
        'parent_id': category.parentId,
        'sort_order': category.sortOrder,
        'is_active': boolToInt(category.isActive),
        'created_at': category.createdAt.millisecondsSinceEpoch,
        'updated_at': category.updatedAt.millisecondsSinceEpoch,
      };
}
