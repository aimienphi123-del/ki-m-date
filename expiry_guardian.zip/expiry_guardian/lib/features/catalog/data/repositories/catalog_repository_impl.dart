import 'dart:async';

import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/catalog/data/models/catalog_mapper.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product_category.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:sqflite/sqflite.dart';

class CatalogRepositoryImpl implements CatalogRepository {
  CatalogRepositoryImpl({
    required AppDatabase database,
    required Clock clock,
    required IdGenerator ids,
    required SyncQueue syncQueue,
    required AppLogger logger,
  })  : _database = database,
        _clock = clock,
        _ids = ids,
        _syncQueue = syncQueue,
        _logger = logger;

  final AppDatabase _database;
  final Clock _clock;
  final IdGenerator _ids;
  final SyncQueue _syncQueue;
  final AppLogger _logger;

  static const String _tag = 'CatalogRepository';

  @override
  Future<Result<Product?>> findByBarcode(String barcode) async {
    final String code = barcode.trim();
    if (code.isEmpty) return const Result<Product?>.ok(null);
    return _guard(() async {
      final List<Map<String, Object?>> direct = await _database.db.query(
        Tables.products,
        where: 'barcode = ?',
        whereArgs: <Object?>[code],
        limit: 1,
      );
      if (direct.isNotEmpty) return CatalogMapper.productFromRow(direct.first);

      final List<Map<String, Object?>> viaAlias = await _database.db.rawQuery(
        '''
        SELECT p.* FROM ${Tables.products} p
        JOIN ${Tables.productBarcodes} b ON b.product_id = p.id
        WHERE b.barcode = ?
        LIMIT 1
        ''',
        <Object?>[code],
      );
      return viaAlias.isEmpty ? null : CatalogMapper.productFromRow(viaAlias.first);
    });
  }

  @override
  Future<Result<Product?>> findById(String id) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db
          .query(Tables.products, where: 'id = ?', whereArgs: <Object?>[id], limit: 1);
      return rows.isEmpty ? null : CatalogMapper.productFromRow(rows.first);
    });
  }

  @override
  Future<Result<List<Product>>> search(ProductQuery query) async {
    return _guard(() async {
      final List<String> clauses = <String>[];
      final List<Object?> args = <Object?>[];
      if (!query.includeInactive) clauses.add('is_active = 1');
      if (query.categoryId != null) {
        clauses.add('category_id = ?');
        args.add(query.categoryId);
      }
      final String? text = query.text?.trim();
      if (text != null && text.isNotEmpty) {
        clauses.add("(name LIKE ? ESCAPE '\\' OR brand LIKE ? ESCAPE '\\' OR barcode LIKE ? ESCAPE '\\')");
        final String like = likeArgument(text);
        args.addAll(<Object?>[like, like, like]);
      }
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.products,
        where: clauses.isEmpty ? null : clauses.join(' AND '),
        whereArgs: args.isEmpty ? null : args,
        orderBy: 'name COLLATE NOCASE',
        limit: query.limit,
        offset: query.offset,
      );
      return rows.map(CatalogMapper.productFromRow).toList();
    });
  }

  @override
  Future<Result<int>> countProducts({bool includeInactive = false}) async {
    return _guard(() => countOf(
          _database.db,
          'SELECT COUNT(*) FROM ${Tables.products}${includeInactive ? '' : ' WHERE is_active = 1'}',
        ),);
  }

  @override
  Future<Result<Product>> createProduct(
    Product draft, {
    List<String> extraBarcodes = const <String>[],
  }) async {
    if (draft.name.trim().isEmpty) {
      return const Result<Product>.err(Failure.validation('name_required'));
    }
    return _guard(() async {
      final DateTime now = _clock.now();
      final Product product = Product(
        id: draft.id.isEmpty ? _ids.newId() : draft.id,
        barcode: draft.barcode?.trim().isEmpty ?? true ? null : draft.barcode!.trim(),
        name: draft.name.trim(),
        brand: draft.brand?.trim(),
        categoryId: draft.categoryId,
        unit: draft.unit,
        defaultShelfId: draft.defaultShelfId,
        expiryPrecision: draft.expiryPrecision,
        defaultShelfLife: draft.defaultShelfLife,
        unitCost: draft.unitCost,
        photoPath: draft.photoPath,
        notes: draft.notes,
        isActive: draft.isActive,
        createdAt: now,
        updatedAt: now,
      );
      await _database.write(<String>{Tables.products, Tables.productBarcodes},
          (Transaction txn) async {
        await txn.insert(Tables.products, CatalogMapper.productToRow(product));
        for (final String code in <String>{
          ...extraBarcodes.map((String c) => c.trim()).where((String c) => c.isNotEmpty),
        }) {
          if (code == product.barcode) continue;
          await txn.insert(
            Tables.productBarcodes,
            CatalogMapper.barcodeToRow(ProductBarcode(
              id: _ids.newId(),
              productId: product.id,
              barcode: code,
              kind: 'unit',
              createdAt: now,
            ),),
            conflictAlgorithm: ConflictAlgorithm.ignore,
          );
        }
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.products,
        entityId: product.id,
        payload: CatalogMapper.productToRow(product),
      );
      _logger.i(_tag, 'Created product ${product.name}');
      return product;
    });
  }

  @override
  Future<Result<Product>> updateProduct(Product product) async {
    if (product.name.trim().isEmpty) {
      return const Result<Product>.err(Failure.validation('name_required'));
    }
    return _guard(() async {
      final Product updated = product.copyWith(updatedAt: _clock.now());
      await _database.write(<String>{Tables.products}, (Transaction txn) async {
        await txn.update(
          Tables.products,
          CatalogMapper.productToRow(updated),
          where: 'id = ?',
          whereArgs: <Object?>[updated.id],
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.products,
        entityId: updated.id,
        payload: CatalogMapper.productToRow(updated),
      );
      return updated;
    });
  }

  @override
  Future<Result<void>> deleteProduct(String id) async {
    return _guard(() async {
      final int inUse = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE product_id = ?',
        <Object?>[id],
      );
      if (inUse > 0) {
        // Keep referential history intact; retire instead of deleting.
        await _database.write(<String>{Tables.products}, (Transaction txn) async {
          await txn.update(
            Tables.products,
            <String, Object?>{
              'is_active': 0,
              'updated_at': _clock.now().millisecondsSinceEpoch,
            },
            where: 'id = ?',
            whereArgs: <Object?>[id],
          );
        });
      } else {
        await _database.write(<String>{Tables.products, Tables.productBarcodes},
            (Transaction txn) async {
          await txn.delete(Tables.products, where: 'id = ?', whereArgs: <Object?>[id]);
        });
      }
      await _syncQueue.enqueueDelete(entity: Tables.products, entityId: id);
    });
  }

  @override
  Future<Result<List<ProductBarcode>>> barcodesOf(String productId) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.productBarcodes,
        where: 'product_id = ?',
        whereArgs: <Object?>[productId],
        orderBy: 'created_at ASC',
      );
      return rows.map(CatalogMapper.barcodeFromRow).toList();
    });
  }

  @override
  Future<Result<void>> addBarcode({
    required String productId,
    required String barcode,
    String kind = 'unit',
  }) async {
    final String code = barcode.trim();
    if (code.isEmpty) return const Result<void>.err(Failure.validation('barcode_required'));
    final Result<Product?> owner = await findByBarcode(code);
    if (owner.isOk && owner.unwrap() != null && owner.unwrap()!.id != productId) {
      return const Result<void>.err(Failure.duplicate('barcode_taken'));
    }
    return _guard(() async {
      final ProductBarcode entry = ProductBarcode(
        id: _ids.newId(),
        productId: productId,
        barcode: code,
        kind: kind,
        createdAt: _clock.now(),
      );
      await _database.write(<String>{Tables.productBarcodes}, (Transaction txn) async {
        await txn.insert(Tables.productBarcodes, CatalogMapper.barcodeToRow(entry));
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.productBarcodes,
        entityId: entry.id,
        payload: CatalogMapper.barcodeToRow(entry),
      );
    });
  }

  @override
  Future<Result<void>> removeBarcode(String barcodeId) async {
    return _guard(() async {
      await _database.write(<String>{Tables.productBarcodes}, (Transaction txn) async {
        await txn.delete(Tables.productBarcodes, where: 'id = ?', whereArgs: <Object?>[barcodeId]);
      });
      await _syncQueue.enqueueDelete(entity: Tables.productBarcodes, entityId: barcodeId);
    });
  }

  @override
  Future<Result<List<ProductCategory>>> listCategories({bool includeInactive = false}) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.categories,
        where: includeInactive ? null : 'is_active = 1',
        orderBy: 'sort_order ASC, name COLLATE NOCASE',
      );
      return rows.map(CatalogMapper.categoryFromRow).toList();
    });
  }

  @override
  Future<Result<ProductCategory>> createCategory({required String name, String? parentId}) async {
    final String clean = name.trim();
    if (clean.isEmpty) {
      return const Result<ProductCategory>.err(Failure.validation('name_required'));
    }
    return _guard(() async {
      final DateTime now = _clock.now();
      final int order = await countOf(
            _database.db,
            'SELECT COALESCE(MAX(sort_order), 0) FROM ${Tables.categories}',
          ) +
          10;
      final ProductCategory category = ProductCategory(
        id: _ids.newId(),
        name: clean,
        parentId: parentId,
        sortOrder: order,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      );
      await _database.write(<String>{Tables.categories}, (Transaction txn) async {
        await txn.insert(Tables.categories, CatalogMapper.categoryToRow(category));
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.categories,
        entityId: category.id,
        payload: CatalogMapper.categoryToRow(category),
      );
      return category;
    });
  }

  @override
  Future<Result<ProductCategory>> updateCategory(ProductCategory category) async {
    return _guard(() async {
      final ProductCategory updated = category.copyWith(updatedAt: _clock.now());
      await _database.write(<String>{Tables.categories}, (Transaction txn) async {
        await txn.update(
          Tables.categories,
          CatalogMapper.categoryToRow(updated),
          where: 'id = ?',
          whereArgs: <Object?>[updated.id],
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.categories,
        entityId: updated.id,
        payload: CatalogMapper.categoryToRow(updated),
      );
      return updated;
    });
  }

  @override
  Future<Result<void>> deleteCategory(String id) async {
    return _guard(() async {
      await _database.write(<String>{Tables.categories, Tables.products}, (Transaction txn) async {
        await txn.delete(Tables.categories, where: 'id = ?', whereArgs: <Object?>[id]);
      });
      await _syncQueue.enqueueDelete(entity: Tables.categories, entityId: id);
    });
  }

  @override
  Stream<void> watchCatalog() {
    return _database.changes.where((String table) =>
        table == Tables.products ||
        table == Tables.productBarcodes ||
        table == Tables.categories,);
  }

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } on DatabaseException catch (error, stackTrace) {
      if (error.isUniqueConstraintError()) {
        return Result<T>.err(const Failure.duplicate('barcode_taken'));
      }
      return Result<T>.err(
        Failure.database('Catalog operation failed', cause: error, stackTrace: stackTrace),
      );
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Catalog operation failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('Catalog operation failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
