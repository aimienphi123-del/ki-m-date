import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product_category.dart';
import 'package:expiry_guardian/features/catalog/presentation/viewmodels/catalog_view_model.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_list_view_model.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Create or edit a catalog entry.
///
/// Reached the first time an unknown barcode is scanned: the employee types
/// the name once and every later scan of that code resolves instantly and
/// offline. The app never fills these fields from an outside source.
class ProductFormPage extends ConsumerStatefulWidget {
  const ProductFormPage({this.existing, this.initialBarcode, super.key});

  final Product? existing;
  final String? initialBarcode;

  static Future<Product?> open(
    BuildContext context, {
    Product? existing,
    String? initialBarcode,
  }) {
    return Navigator.of(context).push<Product>(
      MaterialPageRoute<Product>(
        builder: (_) => ProductFormPage(existing: existing, initialBarcode: initialBarcode),
        fullscreenDialog: existing == null,
      ),
    );
  }

  @override
  ConsumerState<ProductFormPage> createState() => _ProductFormPageState();
}

class _ProductFormPageState extends ConsumerState<ProductFormPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late final TextEditingController _name =
      TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _brand =
      TextEditingController(text: widget.existing?.brand ?? '');
  late final TextEditingController _barcode = TextEditingController(
    text: widget.existing?.barcode ?? widget.initialBarcode ?? '',
  );
  late final TextEditingController _unit =
      TextEditingController(text: widget.existing?.unit ?? 'pcs');
  late final TextEditingController _cost = TextEditingController(
    text: widget.existing?.unitCost?.toString() ?? '',
  );
  late final TextEditingController _shelfLifeDays = TextEditingController(
    text: widget.existing?.defaultShelfLife?.inDays.toString() ?? '',
  );

  late String? _categoryId = widget.existing?.categoryId;
  late String? _shelfId = widget.existing?.defaultShelfId;
  late ExpiryPrecision _precision = widget.existing?.expiryPrecision ?? ExpiryPrecision.day;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _brand.dispose();
    _barcode.dispose();
    _unit.dispose();
    _cost.dispose();
    _shelfLifeDays.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _busy = true;
      _error = null;
    });

    final Clock clock = ref.read(clockProvider);
    final DateTime now = clock.now();
    final int? shelfLifeDays = int.tryParse(_shelfLifeDays.text.trim());

    final Product draft = Product(
      id: widget.existing?.id ?? '',
      barcode: _barcode.text.trim().isEmpty ? null : _barcode.text.trim(),
      name: _name.text.trim(),
      brand: _brand.text.trim().isEmpty ? null : _brand.text.trim(),
      categoryId: _categoryId,
      unit: _unit.text.trim().isEmpty ? 'pcs' : _unit.text.trim(),
      defaultShelfId: _shelfId,
      expiryPrecision: _precision,
      defaultShelfLife: shelfLifeDays == null ? null : Duration(days: shelfLifeDays),
      unitCost: double.tryParse(_cost.text.trim().replaceAll(',', '.')),
      photoPath: widget.existing?.photoPath,
      notes: widget.existing?.notes,
      isActive: true,
      createdAt: widget.existing?.createdAt ?? now,
      updatedAt: now,
    );

    final Result<Product> result = widget.existing == null
        ? await ref.read(catalogRepositoryProvider).createProduct(draft)
        : await ref.read(catalogRepositoryProvider).updateProduct(
              draft.copyWith(
                clearCategory: _categoryId == null,
                clearDefaultShelf: _shelfId == null,
                clearUnitCost: _cost.text.trim().isEmpty,
                clearDefaultShelfLife: shelfLifeDays == null,
              ),
            );

    if (!mounted) return;
    final Failure? failure = result.failureOrNull;
    if (failure != null) {
      setState(() {
        _busy = false;
        _error = describeFailure(context, failure);
      });
      return;
    }
    Navigator.of(context).pop(result.valueOrNull);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final List<ProductCategory> categories =
        ref.watch(categoriesProvider).valueOrNull ?? const <ProductCategory>[];
    final List<ShelfLocation> shelves =
        ref.watch(shelfLocationsProvider).valueOrNull ?? const <ShelfLocation>[];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.existing == null ? l10n.t(K.catalogNewProduct) : l10n.t(K.catalogEditProduct),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(Dimens.gutter),
          children: <Widget>[
            if (widget.existing == null)
              NoticeBanner(
                icon: Icons.lightbulb_outline,
                message: l10n.t(K.scanUnknownProductHint),
              ),
            const SizedBox(height: Dimens.gapM),
            TextFormField(
              controller: _barcode,
              decoration: InputDecoration(labelText: l10n.t(K.recordBarcode)),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: Dimens.gapM),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(labelText: l10n.t(K.recordProduct)),
              validator: (String? v) =>
                  (v ?? '').trim().isEmpty ? l10n.t(K.errorNameRequired) : null,
            ),
            const SizedBox(height: Dimens.gapM),
            TextFormField(
              controller: _brand,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText: '${l10n.t(K.recordBrand)} (${l10n.t(K.commonOptional)})',
              ),
            ),
            const SizedBox(height: Dimens.gapM),
            DropdownButtonFormField<String?>(
              initialValue: _categoryId,
              isExpanded: true,
              decoration: InputDecoration(labelText: l10n.t(K.recordCategory)),
              items: <DropdownMenuItem<String?>>[
                DropdownMenuItem<String?>(child: Text(l10n.t(K.commonNone))),
                for (final ProductCategory category in categories)
                  DropdownMenuItem<String?>(
                    value: category.id,
                    child: Text(category.name, overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (String? value) => setState(() => _categoryId = value),
            ),
            const SizedBox(height: Dimens.gapM),
            DropdownButtonFormField<String?>(
              initialValue: selectableShelfId(_shelfId, shelves),
              isExpanded: true,
              decoration: InputDecoration(labelText: l10n.t(K.catalogDefaultShelf)),
              items: <DropdownMenuItem<String?>>[
                DropdownMenuItem<String?>(child: Text(l10n.t(K.commonNone))),
                for (final ShelfLocation location in shelves)
                  DropdownMenuItem<String?>(
                    value: location.shelf.id,
                    child: Text(location.label, overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (String? value) => setState(() => _shelfId = value),
            ),
            const SizedBox(height: Dimens.gapM),
            Text(l10n.t(K.catalogExpiryPrecision),
                style: Theme.of(context).textTheme.labelLarge,),
            const SizedBox(height: Dimens.gapS),
            SegmentedButton<ExpiryPrecision>(
              segments: <ButtonSegment<ExpiryPrecision>>[
                ButtonSegment<ExpiryPrecision>(
                  value: ExpiryPrecision.day,
                  label: Text(l10n.t(K.recordDaily)),
                  icon: const Icon(Icons.calendar_today),
                ),
                ButtonSegment<ExpiryPrecision>(
                  value: ExpiryPrecision.hour,
                  label: Text(l10n.t(K.recordHourly)),
                  icon: const Icon(Icons.schedule),
                ),
              ],
              selected: <ExpiryPrecision>{_precision},
              onSelectionChanged: (Set<ExpiryPrecision> selection) =>
                  setState(() => _precision = selection.first),
            ),
            const SizedBox(height: Dimens.gapM),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextFormField(
                    controller: _unit,
                    decoration: InputDecoration(labelText: l10n.t(K.recordUnit)),
                  ),
                ),
                const SizedBox(width: Dimens.gapM),
                Expanded(
                  child: TextFormField(
                    controller: _cost,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: l10n.t(K.recordUnitCost)),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                l10n.t(K.catalogUnitCostHint),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
            ),
            const SizedBox(height: Dimens.gapM),
            TextFormField(
              controller: _shelfLifeDays,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: '${l10n.t(K.catalogDefaultShelfLife)} (${l10n.t(K.commonOptional)})',
                helperText: l10n.t(K.catalogDefaultShelfLifeHint),
                helperMaxLines: 2,
                suffixText: l10n.t(K.timeDays, <String, Object?>{'count': ''}).trim(),
              ),
            ),
            if (_error != null) ...<Widget>[
              const SizedBox(height: Dimens.gapM),
              NoticeBanner(
                tone: NoticeTone.danger,
                icon: Icons.error_outline,
                message: _error!,
              ),
            ],
            const SizedBox(height: Dimens.gapL),
            FilledButton.icon(
              onPressed: _busy ? null : _submit,
              icon: _busy
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2.5),
                    )
                  : const Icon(Icons.check),
              label: Text(l10n.t(K.commonSave)),
            ),
          ],
        ),
      ),
    );
  }
}
