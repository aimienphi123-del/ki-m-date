import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The search box on the picker. Local to this screen so it does not disturb
/// the catalog screen's own search.
final StateProvider<String> productPickerQueryProvider =
    StateProvider<String>((Ref ref) => '');

final FutureProvider<List<Product>> productPickerResultsProvider =
    FutureProvider<List<Product>>((Ref ref) async {
  ref.watch(catalogChangesProvider);
  final String text = ref.watch(productPickerQueryProvider);
  final Result<List<Product>> result = await ref
      .watch(catalogRepositoryProvider)
      .search(ProductQuery(text: text.trim().isEmpty ? null : text.trim(), limit: 200));
  return result.fold((Failure f) => throw f, (List<Product> v) => v);
});

/// Pick a product the store already knows.
///
/// Goods-in used to offer only "scan the barcode" and "type the barcode",
/// which both assume the code is readable and known. Most of the time the
/// employee simply knows what the product is, and the store has had it before
/// - so the fastest path is to show them the list and let them tap it.
class ProductPickerPage extends ConsumerStatefulWidget {
  const ProductPickerPage({super.key});

  static Future<Product?> open(BuildContext context) {
    return Navigator.of(context).push<Product>(
      MaterialPageRoute<Product>(
        builder: (_) => const ProductPickerPage(),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  ConsumerState<ProductPickerPage> createState() => _ProductPickerPageState();
}

class _ProductPickerPageState extends ConsumerState<ProductPickerPage> {
  final TextEditingController _search = TextEditingController();

  @override
  void initState() {
    super.initState();
    // A picker that remembers the last screen's search would open filtered to
    // something the employee did not type.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(productPickerQueryProvider.notifier).state = '';
    });
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<Product>> results =
        ref.watch(productPickerResultsProvider);
    final String query = ref.watch(productPickerQueryProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.scanPickProduct))),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(Dimens.gutter),
            child: TextField(
              controller: _search,
              autofocus: true,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                labelText: l10n.t(K.scanSearchProduct),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _search.clear();
                          ref.read(productPickerQueryProvider.notifier).state = '';
                        },
                      ),
              ),
              onChanged: (String value) =>
                  ref.read(productPickerQueryProvider.notifier).state = value,
            ),
          ),
          Expanded(
            child: results.when(
              // Keep the list on screen while a new search runs, rather than
              // blanking it on every keystroke.
              skipLoadingOnReload: true,
              loading: () => const LoadingView(),
              error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
              data: (List<Product> products) {
                if (products.isEmpty) {
                  return EmptyState(
                    icon: Icons.inventory_2_outlined,
                    title: l10n.t(
                      query.trim().isEmpty ? K.scanNoProducts : K.scanNoProductMatch,
                    ),
                    message: '',
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(
                    Dimens.gutter,
                    0,
                    Dimens.gutter,
                    Dimens.gapXl,
                  ),
                  itemCount: products.length,
                  separatorBuilder: (_, __) => const SizedBox(height: Dimens.gapS),
                  itemBuilder: (BuildContext context, int index) {
                    final Product product = products[index];
                    return AppCard(
                      onTap: () => Navigator.of(context).pop(product),
                      child: Row(
                        children: <Widget>[
                          ProductAvatar(
                            path: product.photoPath,
                            label: product.displayName,
                          ),
                          const SizedBox(width: Dimens.gapM),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  product.displayName,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleSmall
                                      ?.copyWith(fontWeight: FontWeight.w700),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  product.barcode ?? l10n.t(K.catalogNoBarcode),
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onSurfaceVariant,
                                      ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// The product's picture, or its initials when there is none.
///
/// Shared by the stock list and the picker so a lot looks the same wherever it
/// is shown.
class ProductAvatar extends StatelessWidget {
  const ProductAvatar({
    required this.path,
    required this.label,
    this.size = 52,
    super.key,
  });

  final String? path;
  final String label;
  final double size;

  @override
  Widget build(BuildContext context) {
    final String? current = path;
    final bool hasPhoto = current != null && current.isNotEmpty;

    return ClipRRect(
      borderRadius: BorderRadius.circular(Dimens.radiusSmall),
      child: SizedBox(
        width: size,
        height: size,
        child: hasPhoto
            ? Image.file(
                File(current),
                fit: BoxFit.cover,
                // A photo the OS cleaned up must not blank the row.
                errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                    _Initials(label: label),
              )
            : _Initials(label: label),
      ),
    );
  }
}

class _Initials extends StatelessWidget {
  const _Initials({required this.label});

  final String label;

  String get _initials {
    final List<String> words = label
        .trim()
        .split(RegExp(r'\s+'))
        .where((String w) => w.isNotEmpty)
        .toList();
    if (words.isEmpty) return '?';
    if (words.length == 1) return words.first.characters.first.toUpperCase();
    return (words.first.characters.first + words[1].characters.first).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ColoredBox(
      color: theme.colorScheme.surfaceContainerHighest,
      child: Center(
        child: Text(
          _initials,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}
