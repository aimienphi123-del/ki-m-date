import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/presentation/pages/product_form_page.dart';
import 'package:expiry_guardian/features/catalog/presentation/viewmodels/catalog_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The store's own product catalog: every entry was created by someone here.
class CatalogPage extends ConsumerStatefulWidget {
  const CatalogPage({super.key});

  @override
  ConsumerState<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends ConsumerState<CatalogPage> {
  final TextEditingController _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<Product>> products = ref.watch(catalogProductsProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.catalogTitle)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(68),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              0,
              Dimens.gutter,
              Dimens.gapM,
            ),
            child: TextField(
              controller: _search,
              onChanged: (String value) =>
                  ref.read(catalogSearchProvider.notifier).state = value,
              decoration: InputDecoration(
                hintText: l10n.t(K.inventorySearchHint),
                prefixIcon: const Icon(Icons.search),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => ProductFormPage.open(context),
        icon: const Icon(Icons.add),
        label: Text(l10n.t(K.catalogNewProduct)),
      ),
      body: products.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
        data: (List<Product> value) {
          if (value.isEmpty) {
            return EmptyState(
              icon: Icons.category_outlined,
              title: l10n.t(K.catalogEmpty),
              message: l10n.t(K.catalogEmptyHint),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              Dimens.gapS,
              Dimens.gutter,
              Dimens.gapXl * 3,
            ),
            itemCount: value.length,
            separatorBuilder: (_, __) => const SizedBox(height: Dimens.gapS),
            itemBuilder: (BuildContext context, int index) {
              final Product product = value[index];
              return AppCard(
                onTap: () => ProductFormPage.open(context, existing: product),
                child: Row(
                  children: <Widget>[
                    Icon(
                      product.expiryPrecision.isHourly
                          ? Icons.schedule
                          : Icons.calendar_today,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: Dimens.gapM),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            product.displayName,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            <String>[
                              if (product.barcode != null) product.barcode!,
                              product.unit,
                              if (product.defaultShelfLife != null)
                                l10n.shelfLife(product.defaultShelfLife!),
                            ].join(' · '),
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
