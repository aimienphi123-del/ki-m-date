import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product_category.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final FutureProvider<List<ProductCategory>> categoriesProvider =
    FutureProvider<List<ProductCategory>>((Ref ref) async {
  ref.watch(catalogChangesProvider);
  final Result<List<ProductCategory>> result =
      await ref.watch(catalogRepositoryProvider).listCategories();
  return result.fold((Failure f) => throw f, (List<ProductCategory> v) => v);
});

final StateProvider<String> catalogSearchProvider = StateProvider<String>((Ref ref) => '');

final FutureProvider<List<Product>> catalogProductsProvider =
    FutureProvider<List<Product>>((Ref ref) async {
  ref.watch(catalogChangesProvider);
  final String text = ref.watch(catalogSearchProvider);
  final Result<List<Product>> result = await ref
      .watch(catalogRepositoryProvider)
      .search(ProductQuery(text: text.isEmpty ? null : text, limit: 200));
  return result.fold((Failure f) => throw f, (List<Product> v) => v);
});

final FutureProviderFamily<Product?, String> productByBarcodeProvider =
    FutureProvider.family<Product?, String>((Ref ref, String barcode) async {
  ref.watch(catalogChangesProvider);
  final Result<Product?> result =
      await ref.watch(catalogRepositoryProvider).findByBarcode(barcode);
  return result.fold((Failure f) => throw f, (Product? v) => v);
});
