import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product_category.dart';

class ProductQuery {
  const ProductQuery({
    this.text,
    this.categoryId,
    this.includeInactive = false,
    this.limit = 100,
    this.offset = 0,
  });

  final String? text;
  final String? categoryId;
  final bool includeInactive;
  final int limit;
  final int offset;
}

abstract interface class CatalogRepository {
  /// Resolves a scanned code against the store catalog. Returns `null` when the
  /// barcode has never been seen - the caller then opens the "new product"
  /// form. No external database is contacted and nothing is invented.
  Future<Result<Product?>> findByBarcode(String barcode);

  Future<Result<Product?>> findById(String id);

  Future<Result<List<Product>>> search(ProductQuery query);

  Future<Result<int>> countProducts({bool includeInactive = false});

  Future<Result<Product>> createProduct(Product draft, {List<String> extraBarcodes = const <String>[]});

  Future<Result<Product>> updateProduct(Product product);

  Future<Result<void>> deleteProduct(String id);

  Future<Result<List<ProductBarcode>>> barcodesOf(String productId);

  Future<Result<void>> addBarcode({
    required String productId,
    required String barcode,
    String kind = 'unit',
  });

  Future<Result<void>> removeBarcode(String barcodeId);

  Future<Result<List<ProductCategory>>> listCategories({bool includeInactive = false});

  Future<Result<ProductCategory>> createCategory({required String name, String? parentId});

  Future<Result<ProductCategory>> updateCategory(ProductCategory category);

  Future<Result<void>> deleteCategory(String id);

  Stream<void> watchCatalog();
}
