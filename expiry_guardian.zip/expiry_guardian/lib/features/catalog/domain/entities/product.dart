import 'package:expiry_guardian/core/domain/expiry_precision.dart';

/// A catalog entry. Created the first time a barcode is scanned; from then on
/// every scan of that barcode resolves to this row instantly and offline.
class Product {
  const Product({
    required this.id,
    required this.name,
    required this.unit,
    required this.expiryPrecision,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
    this.barcode,
    this.brand,
    this.categoryId,
    this.defaultShelfId,
    this.defaultShelfLife,
    this.unitCost,
    this.photoPath,
    this.barcodePhotoPath,
    this.notes,
  });

  final String id;

  /// Primary barcode. Additional codes (case / inner pack) live in
  /// `product_barcodes`.
  final String? barcode;

  final String name;
  final String? brand;
  final String? categoryId;

  /// pcs, box, kg, ...
  final String unit;

  final String? defaultShelfId;

  /// Whether this product's labels carry a time of day (fresh food) or only a
  /// date. Drives which policy rules can match.
  final ExpiryPrecision expiryPrecision;

  /// Optional. When set, the intake screen can pre-fill the expiry date from
  /// the manufacturing date and warn when an OCR result is implausible.
  final Duration? defaultShelfLife;

  /// Cost of one [unit], used to price destruction losses. Null until someone
  /// enters it - the app never invents a price.
  final double? unitCost;

  /// Picture of the product's face - what the app shows as its avatar, so the
  /// next person can match a lot on the shelf by sight rather than by code.
  final String? photoPath;

  /// Picture of the barcode itself, kept whether or not a decoder could read
  /// it. When nobody's scanner can manage the code, this is what backs up the
  /// number somebody typed in by hand.
  final String? barcodePhotoPath;

  final String? notes;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get hasCost => unitCost != null && unitCost! > 0;

  String get displayName => brand == null || brand!.isEmpty ? name : '$brand $name';

  Product copyWith({
    String? barcode,
    bool clearBarcode = false,
    String? name,
    String? brand,
    String? categoryId,
    bool clearCategory = false,
    String? unit,
    String? defaultShelfId,
    bool clearDefaultShelf = false,
    ExpiryPrecision? expiryPrecision,
    Duration? defaultShelfLife,
    bool clearDefaultShelfLife = false,
    double? unitCost,
    bool clearUnitCost = false,
    String? photoPath,
    bool clearPhoto = false,
    String? barcodePhotoPath,
    bool clearBarcodePhoto = false,
    String? notes,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return Product(
      id: id,
      barcode: clearBarcode ? null : (barcode ?? this.barcode),
      name: name ?? this.name,
      brand: brand ?? this.brand,
      categoryId: clearCategory ? null : (categoryId ?? this.categoryId),
      unit: unit ?? this.unit,
      defaultShelfId: clearDefaultShelf ? null : (defaultShelfId ?? this.defaultShelfId),
      expiryPrecision: expiryPrecision ?? this.expiryPrecision,
      defaultShelfLife:
          clearDefaultShelfLife ? null : (defaultShelfLife ?? this.defaultShelfLife),
      unitCost: clearUnitCost ? null : (unitCost ?? this.unitCost),
      photoPath: clearPhoto ? null : (photoPath ?? this.photoPath),
      barcodePhotoPath:
          clearBarcodePhoto ? null : (barcodePhotoPath ?? this.barcodePhotoPath),
      notes: notes ?? this.notes,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() => 'Product($name${barcode == null ? '' : ' / $barcode'})';
}

/// An extra barcode pointing at the same product (case code, inner pack, a
/// re-labelled import).
class ProductBarcode {
  const ProductBarcode({
    required this.id,
    required this.productId,
    required this.barcode,
    required this.kind,
    required this.createdAt,
  });

  final String id;
  final String productId;
  final String barcode;

  /// unit | inner | case
  final String kind;
  final DateTime createdAt;
}
