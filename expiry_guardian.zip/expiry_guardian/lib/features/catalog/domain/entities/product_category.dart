class ProductCategory {
  const ProductCategory({
    required this.id,
    required this.name,
    required this.sortOrder,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
    this.parentId,
  });

  final String id;
  final String name;
  final String? parentId;
  final int sortOrder;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  ProductCategory copyWith({
    String? name,
    String? parentId,
    bool clearParent = false,
    int? sortOrder,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return ProductCategory(
      id: id,
      name: name ?? this.name,
      parentId: clearParent ? null : (parentId ?? this.parentId),
      sortOrder: sortOrder ?? this.sortOrder,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() => 'ProductCategory($name)';
}
