import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/notification_workflow_page.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Reminder behaviour, plus the two Android permissions the reminders need.
class NotificationSettingsPage extends ConsumerStatefulWidget {
  const NotificationSettingsPage({super.key});

  @override
  ConsumerState<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends ConsumerState<NotificationSettingsPage> {
  bool? _hasPermission;
  bool? _canScheduleExact;
  int? _scheduledCount;

  @override
  void initState() {
    super.initState();
    _refreshPermissions();
  }

  Future<void> _refreshPermissions() async {
    final NotificationGateway gateway =
        ref.read(dependenciesProvider).notificationGateway;
    final bool granted = await gateway.hasPermission();
    final bool exact = await gateway.canScheduleExactAlarms();
    final List<int> pending = await gateway.pendingIds();
    if (!mounted) return;
    setState(() {
      _hasPermission = granted;
      _canScheduleExact = exact;
      _scheduledCount = pending.length;
    });
  }

  Future<void> _save(NotificationPreferences preferences) async {
    await ref.read(settingsStoreProvider).writeAll(preferences.toSettings());
    ref.read(settingsRevisionProvider.notifier).bump();
    await _reschedule();
  }

  /// The ceiling on pending OS alarms.
  ///
  /// Exposed because it is the one knob that trades reminder depth against how
  /// long a reschedule takes, and the right answer depends on how much stock a
  /// particular store carries.
  Future<void> _editMaxScheduled(NotificationPreferences preferences) async {
    final AppLocalizations l10n = context.l10n;
    final TextEditingController field =
        TextEditingController(text: preferences.maxScheduled.toString());
    final int? picked = await showDialog<int>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.notifMaxScheduled)),
        content: TextField(
          controller: field,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: l10n.t(K.notifMaxScheduled),
            helperText: l10n.t(K.notifMaxScheduledHint),
            helperMaxLines: 3,
          ),
          onSubmitted: (String value) =>
              Navigator.of(context).pop(int.tryParse(value.trim())),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.of(context).pop(int.tryParse(field.text.trim())),
            child: Text(l10n.t(K.commonSave)),
          ),
        ],
      ),
    );
    field.dispose();
    if (picked == null) return;
    await _save(preferences.copyWith(maxScheduled: picked.clamp(20, 450)));
  }

  Future<void> _reschedule() async {
    final Result<NotificationPlan> result =
        await ref.read(dependenciesProvider).notificationPlanner.reschedule(
              preferences: ref.read(notificationPreferencesProvider),
              strings: ref.read(stringsProvider),
            );
    if (!mounted) return;
    final NotificationPlan? plan = result.valueOrNull;
    setState(() => _scheduledCount = plan?.total);
    if (plan != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            context.l10n.t(K.notifScheduled, <String, Object?>{'count': plan.total}),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    ref.watch(settingsRevisionProvider);
    final NotificationPreferences preferences = ref.watch(notificationPreferencesProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.notifTitle))),
      body: ListView(
        padding: const EdgeInsets.all(Dimens.gutter),
        children: <Widget>[
          if (_hasPermission == false)
            NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.notifications_off_outlined,
              message: l10n.t(K.notifPermissionNeeded),
              action: TextButton(
                onPressed: () async {
                  await ref
                      .read(dependenciesProvider)
                      .notificationGateway
                      .requestPermission();
                  await _refreshPermissions();
                },
                child: Text(l10n.t(K.notifGrant)),
              ),
            ),
          if (_canScheduleExact == false) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.alarm,
              message: l10n.t(K.notifExactAlarmNeeded),
              action: TextButton(
                onPressed: () async {
                  await ref
                      .read(dependenciesProvider)
                      .notificationGateway
                      .requestExactAlarmPermission();
                  await _refreshPermissions();
                },
                child: Text(l10n.t(K.notifGrant)),
              ),
            ),
          ],
          SectionHeader(title: l10n.t(K.notifDailyDigest)),
          AppCard(
            child: Column(
              children: <Widget>[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.notifDailyDigest)),
                  value: preferences.dailyDigestEnabled,
                  onChanged: (bool value) =>
                      _save(preferences.copyWith(dailyDigestEnabled: value)),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.notifDailyDigestTime)),
                  trailing: Text(
                    _formatMinutes(preferences.dailyDigestMinutes),
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  onTap: () async {
                    final TimeOfDay? picked = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(
                        hour: preferences.dailyDigestMinutes ~/ 60,
                        minute: preferences.dailyDigestMinutes % 60,
                      ),
                    );
                    if (picked == null) return;
                    await _save(preferences.copyWith(
                      dailyDigestMinutes: picked.hour * 60 + picked.minute,
                    ),);
                  },
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.notifPerItem)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.notifPerItem)),
                  value: preferences.perItemEnabled,
                  onChanged: (bool value) =>
                      _save(preferences.copyWith(perItemEnabled: value)),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.timeline),
                  title: Text(l10n.t(K.notifWorkflow)),
                  subtitle: Text(l10n.t(K.notifWorkflowSubtitle)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => NotificationWorkflowPage.open(context),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.speed_outlined),
                  title: Text(l10n.t(K.notifMaxScheduled)),
                  subtitle: Text(l10n.t(K.notifMaxScheduledHint)),
                  trailing: Text(
                    '${preferences.maxScheduled}',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  onTap: () => _editMaxScheduled(preferences),
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.notifQuietHours)),
          AppCard(
            child: Column(
              children: <Widget>[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.notifQuietHours)),
                  subtitle: Text(l10n.t(K.notifQuietHoursHint)),
                  value: preferences.hasQuietHours,
                  onChanged: (bool value) => _save(
                    value
                        ? preferences.copyWith(
                            quietStartMinutes: 22 * 60,
                            quietEndMinutes: 6 * 60,
                          )
                        : preferences.copyWith(
                            clearQuietStart: true,
                            clearQuietEnd: true,
                          ),
                  ),
                ),
                if (preferences.hasQuietHours) ...<Widget>[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('${l10n.t(K.notifQuietHours)} - ${l10n.t(K.commonNext)}'),
                    trailing: Text(_formatMinutes(preferences.quietStartMinutes!)),
                    onTap: () async {
                      final TimeOfDay? picked = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay(
                          hour: preferences.quietStartMinutes! ~/ 60,
                          minute: preferences.quietStartMinutes! % 60,
                        ),
                      );
                      if (picked == null) return;
                      await _save(preferences.copyWith(
                        quietStartMinutes: picked.hour * 60 + picked.minute,
                      ),);
                    },
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('${l10n.t(K.notifQuietHours)} - ${l10n.t(K.commonDone)}'),
                    trailing: Text(_formatMinutes(preferences.quietEndMinutes!)),
                    onTap: () async {
                      final TimeOfDay? picked = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay(
                          hour: preferences.quietEndMinutes! ~/ 60,
                          minute: preferences.quietEndMinutes! % 60,
                        ),
                      );
                      if (picked == null) return;
                      await _save(preferences.copyWith(
                        quietEndMinutes: picked.hour * 60 + picked.minute,
                      ),);
                    },
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: Dimens.gapL),
          if (_scheduledCount != null)
            Text(
              l10n.t(K.notifScheduled, <String, Object?>{'count': _scheduledCount}),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          const SizedBox(height: Dimens.gapS),
          FilledButton.tonalIcon(
            onPressed: _reschedule,
            icon: const Icon(Icons.refresh),
            label: Text(l10n.t(K.commonRefresh)),
          ),
        ],
      ),
    );
  }

  static String _formatMinutes(int minutes) =>
      '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';
}
