import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Tuning for the camera-AI pipeline. Every threshold the recogniser uses is
/// on this screen; none of them is compiled into the app.
class ScanSettingsPage extends ConsumerWidget {
  const ScanSettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);

    Future<void> write(String key, Object? value) async {
      await settings.write(key, value);
      ref.read(settingsRevisionProvider.notifier).bump();
    }

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.settingsScanning))),
      body: ListView(
        padding: const EdgeInsets.all(Dimens.gutter),
        children: <Widget>[
          AppCard(
            child: Column(
              children: <Widget>[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.scanAutoAdvance)),
                  subtitle: Text(l10n.t(K.scanAutoAdvanceHint)),
                  value: settings.readBool(
                    SettingKeys.scanAutoAdvance,
                    SettingDefaults.scanAutoAdvance,
                  ),
                  onChanged: (bool value) => write(SettingKeys.scanAutoAdvance, value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.settingsEnhanceImages)),
                  value: settings.readBool(
                    SettingKeys.scanEnhanceImages,
                    SettingDefaults.scanEnhanceImages,
                  ),
                  onChanged: (bool value) => write(SettingKeys.scanEnhanceImages, value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.settingsKeepPhotos)),
                  value: settings.readBool(
                    SettingKeys.scanKeepPhotos,
                    SettingDefaults.scanKeepPhotos,
                  ),
                  onChanged: (bool value) => write(SettingKeys.scanKeepPhotos, value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.settingsDayFirst)),
                  subtitle: Text(l10n.t(K.settingsDayFirstHint)),
                  value: settings.readBool(
                    SettingKeys.scanDayFirstDates,
                    SettingDefaults.scanDayFirstDates,
                  ),
                  onChanged: (bool value) => write(SettingKeys.scanDayFirstDates, value),
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.scanQualityGood)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _SliderSetting(
                  label: l10n.t(K.settingsBlurThreshold),
                  value: settings.readDouble(
                    SettingKeys.scanBlurThreshold,
                    SettingDefaults.scanBlurThreshold,
                  ),
                  min: 20,
                  max: 300,
                  onChanged: (double value) => write(SettingKeys.scanBlurThreshold, value),
                ),
                _SliderSetting(
                  label: l10n.t(K.settingsDarkThreshold),
                  value: settings.readDouble(
                    SettingKeys.scanLowLightThreshold,
                    SettingDefaults.scanLowLightThreshold,
                  ),
                  min: 20,
                  max: 160,
                  onChanged: (double value) =>
                      write(SettingKeys.scanLowLightThreshold, value),
                ),
                _SliderSetting(
                  label: l10n.t(K.settingsMaxFutureYears),
                  value: settings
                      .readInt(
                        SettingKeys.scanMaxFutureYears,
                        SettingDefaults.scanMaxFutureYears,
                      )
                      .toDouble(),
                  min: 1,
                  max: 25,
                  decimals: 0,
                  onChanged: (double value) =>
                      write(SettingKeys.scanMaxFutureYears, value.round()),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SliderSetting extends StatefulWidget {
  const _SliderSetting({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.decimals = 0,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final int decimals;
  final ValueChanged<double> onChanged;

  @override
  State<_SliderSetting> createState() => _SliderSettingState();
}

class _SliderSettingState extends State<_SliderSetting> {
  late double _value = widget.value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(child: Text(widget.label)),
            Text(
              _value.toStringAsFixed(widget.decimals),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
        Slider(
          value: _value.clamp(widget.min, widget.max),
          min: widget.min,
          max: widget.max,
          onChanged: (double value) => setState(() => _value = value),
          onChangeEnd: widget.onChanged,
        ),
      ],
    );
  }
}
