import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/notifications/notification_workflow_repository.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:expiry_guardian/shared/widgets/duration_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Every reminder stage, as editable rows.
///
/// Feature 1 of Phase X: two days before, one day before, at the deadline, then
/// hourly until somebody confirms - none of it hardcoded. A manager can change
/// each offset, each repeat interval, the repeat cap, and can add or retire
/// stages entirely.
final FutureProvider<List<NotificationStage>> notificationStagesProvider =
    FutureProvider<List<NotificationStage>>((Ref ref) async {
  ref.watch(notificationStageChangesProvider);
  final Result<List<NotificationStage>> result =
      await ref.watch(notificationWorkflowRepositoryProvider).listStages();
  return result.valueOrNull ?? const <NotificationStage>[];
});

class NotificationWorkflowPage extends ConsumerWidget {
  const NotificationWorkflowPage({super.key});

  static Future<void> open(BuildContext context) => Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const NotificationWorkflowPage()),
      );

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<NotificationStage>> stages = ref.watch(notificationStagesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.notifWorkflow)),
        actions: <Widget>[
          PopupMenuButton<String>(
            onSelected: (String value) async {
              if (value != 'defaults') return;
              await ref.read(notificationWorkflowRepositoryProvider).restoreDefaults();
              ref.invalidate(notificationStagesProvider);
              if (!context.mounted) return;
              showAppSnack(context, l10n.t(K.notifStageRestored));
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'defaults',
                child: Text(l10n.t(K.notifStageRestoreDefaults)),
              ),
            ],
          ),
        ],
      ),
      body: stages.when(
        loading: () => const LoadingView(),
        error: (Object error, StackTrace stack) => ErrorView(message: error.toString()),
        data: (List<NotificationStage> value) => _StageList(stages: value),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => StageEditorPage.open(context),
        icon: const Icon(Icons.add_alert_outlined),
        label: Text(l10n.t(K.notifStageNew)),
      ),
    );
  }
}

class _StageList extends ConsumerWidget {
  const _StageList({required this.stages});

  final List<NotificationStage> stages;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final int active = stages.where((NotificationStage s) => s.isActive).length;
    final int perLot = stages
        .where((NotificationStage s) => s.isActive)
        .fold(0, (int sum, NotificationStage s) => sum + s.occurrences);

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gapXl * 4,
      ),
      children: <Widget>[
        NoticeBanner(icon: Icons.timeline, message: l10n.t(K.notifWorkflowSubtitle)),
        const SizedBox(height: Dimens.gapM),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(l10n.t(K.notifStageCount, <String, Object?>{'count': active})),
              const SizedBox(height: Dimens.gapXs),
              Text(
                l10n.t(K.notifStagePlannedPerLot, <String, Object?>{'count': perLot}),
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
        SectionHeader(title: l10n.t(K.notifWorkflow)),
        if (stages.isEmpty)
          EmptyState(
            icon: Icons.notifications_off_outlined,
            title: l10n.t(K.notifStageNew),
            message: l10n.t(K.notifWorkflowSubtitle),
          )
        else
          for (final NotificationStage stage in stages)
            Padding(
              padding: const EdgeInsets.only(bottom: Dimens.gapS),
              child: _StageCard(stage: stage),
            ),
      ],
    );
  }
}

class _StageCard extends ConsumerWidget {
  const _StageCard({required this.stage});

  final NotificationStage stage;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    return AppCard(
      onTap: () => StageEditorPage.open(context, stage: stage),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(_iconFor(stage.kind), color: theme.colorScheme.primary),
          const SizedBox(width: Dimens.gapM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  stageName(l10n, stage),
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                ),
                Text(
                  describeStageOffset(l10n, stage),
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                if (stage.kind.isRepeating)
                  Text(
                    '${l10n.t(K.notifStageRepeatEvery)}: '
                    '${l10n.duration(stage.repeatEvery ?? const Duration(hours: 1))}'
                    ' · ${l10n.t(K.notifStageMaxRepeats)}: ${stage.maxRepeats ?? 1}',
                    style: theme.textTheme.bodySmall,
                  ),
              ],
            ),
          ),
          Switch(
            value: stage.isActive,
            onChanged: (bool value) async {
              await ref.read(notificationWorkflowRepositoryProvider).upsert(
                    stage.copyWith(isActive: value, updatedAt: ref.read(clockProvider).now()),
                  );
              ref.invalidate(notificationStagesProvider);
            },
          ),
        ],
      ),
    );
  }

  static IconData _iconFor(NotificationStageKind kind) => switch (kind) {
        NotificationStageKind.earlyWarning => Icons.schedule_outlined,
        NotificationStageKind.finalReminder => Icons.alarm_outlined,
        NotificationStageKind.mandatory => Icons.priority_high,
        NotificationStageKind.repeatUntilConfirmed => Icons.repeat,
      };
}

/// The stage's name in the language the app is running in.
String stageName(AppLocalizations l10n, NotificationStage stage) {
  final String name = l10n.locale.languageCode == 'en' ? stage.nameEn : stage.nameVi;
  return name.isEmpty ? l10n.t(stageKindKey(stage.kind)) : name;
}

String stageKindKey(NotificationStageKind kind) => switch (kind) {
      NotificationStageKind.earlyWarning => K.notifStageKindEarlyWarning,
      NotificationStageKind.finalReminder => K.notifStageKindFinalReminder,
      NotificationStageKind.mandatory => K.notifStageKindMandatory,
      NotificationStageKind.repeatUntilConfirmed => K.notifStageKindRepeatUntilConfirmed,
    };

String describeStageOffset(AppLocalizations l10n, NotificationStage stage) {
  if (stage.offset == Duration.zero) return l10n.t(K.notifStageOffsetAt);
  if (stage.offset.isNegative) {
    return l10n.t(K.notifStageOffsetBefore, <String, Object?>{
      'duration': l10n.duration(-stage.offset),
    });
  }
  return l10n.t(K.notifStageOffsetAfter, <String, Object?>{
    'duration': l10n.duration(stage.offset),
  });
}

/// Create or edit one stage.
class StageEditorPage extends ConsumerStatefulWidget {
  const StageEditorPage({this.stage, super.key});

  final NotificationStage? stage;

  static Future<void> open(BuildContext context, {NotificationStage? stage}) =>
      Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => StageEditorPage(stage: stage)),
      );

  @override
  ConsumerState<StageEditorPage> createState() => _StageEditorPageState();
}

class _StageEditorPageState extends ConsumerState<StageEditorPage> {
  late final TextEditingController _nameVi;
  late final TextEditingController _nameEn;
  late NotificationStageKind _kind;
  late bool _after;
  late Duration _magnitude;
  late Duration _repeatEvery;
  late int _maxRepeats;
  late bool _isActive;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final NotificationStage? stage = widget.stage;
    _nameVi = TextEditingController(text: stage?.nameVi ?? '');
    _nameEn = TextEditingController(text: stage?.nameEn ?? '');
    _kind = stage?.kind ?? NotificationStageKind.earlyWarning;
    _after = (stage?.offset ?? const Duration(days: -1)) > Duration.zero;
    _magnitude = stage == null
        ? const Duration(days: 1)
        : (stage.offset.isNegative ? -stage.offset : stage.offset);
    _repeatEvery = stage?.repeatEvery ?? const Duration(hours: 1);
    _maxRepeats = stage?.maxRepeats ?? 24;
    _isActive = stage?.isActive ?? true;
  }

  @override
  void dispose() {
    _nameVi.dispose();
    _nameEn.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final bool isNew = widget.stage == null;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(isNew ? K.notifStageNew : K.notifStageEdit)),
        actions: <Widget>[
          if (!isNew)
            IconButton(
              tooltip: l10n.t(K.commonDelete),
              icon: const Icon(Icons.delete_outline),
              onPressed: _saving ? null : _delete,
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(Dimens.gutter),
        children: <Widget>[
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                DropdownButtonFormField<NotificationStageKind>(
                  initialValue: _kind,
                  decoration: InputDecoration(labelText: l10n.t(K.notifWorkflow)),
                  items: <DropdownMenuItem<NotificationStageKind>>[
                    for (final NotificationStageKind kind in NotificationStageKind.values)
                      DropdownMenuItem<NotificationStageKind>(
                        value: kind,
                        child: Text(l10n.t(stageKindKey(kind))),
                      ),
                  ],
                  onChanged: (NotificationStageKind? value) {
                    if (value == null) return;
                    setState(() {
                      _kind = value;
                      // A chase-up only makes sense after the deadline.
                      if (value.isRepeating) _after = true;
                    });
                  },
                ),
                const SizedBox(height: Dimens.gapM),
                TextField(
                  controller: _nameVi,
                  decoration: InputDecoration(
                    labelText: '${l10n.t(K.notifStageName)} (VI)',
                  ),
                ),
                const SizedBox(height: Dimens.gapS),
                TextField(
                  controller: _nameEn,
                  decoration: InputDecoration(
                    labelText: '${l10n.t(K.notifStageName)} (EN)',
                  ),
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.notifStageOffset)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SegmentedButton<bool>(
                  segments: <ButtonSegment<bool>>[
                    ButtonSegment<bool>(value: false, label: Text(l10n.t(K.notifStageBefore))),
                    ButtonSegment<bool>(value: true, label: Text(l10n.t(K.notifStageAfter))),
                  ],
                  selected: <bool>{_after},
                  onSelectionChanged: _kind.isRepeating
                      ? null
                      : (Set<bool> value) => setState(() => _after = value.first),
                ),
                const SizedBox(height: Dimens.gapM),
                DurationField(
                  label: l10n.t(K.notifStageOffset),
                  value: _magnitude,
                  onChanged: (Duration? value) =>
                      setState(() => _magnitude = value ?? Duration.zero),
                ),
              ],
            ),
          ),
          if (_kind.isRepeating) ...<Widget>[
            SectionHeader(title: l10n.t(K.notifStageRepeatEvery)),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  DurationField(
                    label: l10n.t(K.notifStageRepeatEvery),
                    value: _repeatEvery,
                    onChanged: (Duration? value) => setState(
                      () => _repeatEvery = value ?? const Duration(hours: 1),
                    ),
                  ),
                  const SizedBox(height: Dimens.gapM),
                  TextFormField(
                    initialValue: '$_maxRepeats',
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: l10n.t(K.notifStageMaxRepeats)),
                    onChanged: (String value) =>
                        _maxRepeats = int.tryParse(value.trim()) ?? _maxRepeats,
                  ),
                  const SizedBox(height: Dimens.gapS),
                  Text(
                    l10n.t(K.notifStageRepeatNote),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: Dimens.gapM),
          AppCard(
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(l10n.t(K.notifStageActive)),
              value: _isActive,
              onChanged: (bool value) => setState(() => _isActive = value),
            ),
          ),
          const SizedBox(height: Dimens.gapL),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: const Icon(Icons.check),
            label: Text(l10n.t(K.commonSave)),
          ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final Clock clock = ref.read(clockProvider);
    final DateTime now = clock.now();
    final Duration offset = _after ? _magnitude : -_magnitude;
    final NotificationStage? existing = widget.stage;

    final NotificationStage stage = existing == null
        ? NotificationStage(
            id: '',
            sortOrder: (offset.inMinutes + 100000) ~/ 60,
            kind: _kind,
            nameVi: _nameVi.text.trim(),
            nameEn: _nameEn.text.trim(),
            offset: offset,
            repeatEvery: _kind.isRepeating ? _repeatEvery : null,
            maxRepeats: _kind.isRepeating ? _maxRepeats : null,
            isActive: _isActive,
            createdAt: now,
            updatedAt: now,
          )
        : existing.copyWith(
            kind: _kind,
            nameVi: _nameVi.text.trim(),
            nameEn: _nameEn.text.trim(),
            offset: offset,
            repeatEvery: _kind.isRepeating ? _repeatEvery : null,
            clearRepeatEvery: !_kind.isRepeating,
            maxRepeats: _kind.isRepeating ? _maxRepeats : null,
            clearMaxRepeats: !_kind.isRepeating,
            isActive: _isActive,
            updatedAt: now,
          );

    final NotificationWorkflowRepository repository =
        ref.read(notificationWorkflowRepositoryProvider);
    final Result<NotificationStage> result = await repository.upsert(stage);
    ref.invalidate(notificationStagesProvider);
    if (!mounted) return;
    setState(() => _saving = false);
    if (result.isErr) {
      showAppSnack(context, describeFailure(context, result.failureOrNull!), isError: true);
      return;
    }
    Navigator.of(context).pop();
  }

  Future<void> _delete() async {
    final NotificationStage? stage = widget.stage;
    if (stage == null) return;
    final bool confirmed = await confirmDialog(
      context,
      title: context.l10n.t(K.commonDelete),
      message: stageName(context.l10n, stage),
    );
    if (!confirmed) return;
    await ref.read(notificationWorkflowRepositoryProvider).delete(stage.id);
    ref.invalidate(notificationStagesProvider);
    if (!mounted) return;
    Navigator.of(context).pop();
  }
}
