import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/audit/presentation/pages/audit_trail_page.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/backup/presentation/pages/backup_page.dart';
import 'package:expiry_guardian/features/escalation/presentation/pages/escalation_rules_page.dart';
import 'package:expiry_guardian/features/reports/presentation/pages/export_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/notification_settings_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/notification_workflow_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/scan_settings_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/sync_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/users_page.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Everything a manager or administrator can configure.
class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    final Set<Permission> permissions = ref.watch(permissionsProvider);
    final AppUser? user = ref.watch(sessionProvider).valueOrNull?.user;
    final Locale locale = ref.watch(localeProvider);
    final ThemeMode themeMode = ref.watch(themeModeProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.settingsTitle))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gapXl * 3,
        ),
        children: <Widget>[
          if (user != null)
            AppCard(
              child: Row(
                children: <Widget>[
                  CircleAvatar(
                    child: Text(user.displayName.characters.first.toUpperCase()),
                  ),
                  const SizedBox(width: Dimens.gapM),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          user.displayName,
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          '${user.username} · ${l10n.t(switch (user.role) {
                            UserRole.employee => K.authRoleEmployee,
                            UserRole.manager => K.authRoleManager,
                            UserRole.admin => K.authRoleAdmin,
                          },)}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => ref.read(sessionProvider.notifier).signOut(),
                    icon: const Icon(Icons.logout),
                    label: Text(l10n.t(K.authSignOut)),
                  ),
                ],
              ),
            ),
          SectionHeader(title: l10n.t(K.settingsGeneral)),
          AppCard(
            child: Column(
              children: <Widget>[
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.language),
                  title: Text(l10n.t(K.settingsLanguage)),
                  trailing: SegmentedButton<String>(
                    showSelectedIcon: false,
                    segments: const <ButtonSegment<String>>[
                      ButtonSegment<String>(value: 'vi', label: Text('VI')),
                      ButtonSegment<String>(value: 'en', label: Text('EN')),
                    ],
                    selected: <String>{locale.languageCode},
                    onSelectionChanged: (Set<String> selection) => ref
                        .read(localeProvider.notifier)
                        .setLocale(Locale(selection.first)),
                  ),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.brightness_6_outlined),
                  title: Text(l10n.t(K.settingsTheme)),
                  subtitle: Text(l10n.t(switch (themeMode) {
                    ThemeMode.light => K.settingsThemeLight,
                    ThemeMode.dark => K.settingsThemeDark,
                    ThemeMode.system => K.settingsThemeSystem,
                  },),),
                  onTap: () => _pickThemeMode(context, ref, themeMode),
                ),
                _TextSettingTile(
                  icon: Icons.storefront_outlined,
                  label: l10n.t(K.settingsStoreName),
                  settingKey: SettingKeys.storeName,
                  fallback: '',
                ),
                _TextSettingTile(
                  icon: Icons.attach_money,
                  label: l10n.t(K.settingsCurrency),
                  settingKey: SettingKeys.currencySymbol,
                  fallback: SettingDefaults.currencySymbol,
                ),
                // Both appear on the masthead of every exported report.
                _TextSettingTile(
                  icon: Icons.apartment_outlined,
                  label: l10n.t(K.settingsCompany),
                  settingKey: SettingKeys.companyName,
                  fallback: '',
                ),
                _TextSettingTile(
                  icon: Icons.qr_code_2_outlined,
                  label: l10n.t(K.settingsStoreCode),
                  settingKey: SettingKeys.storeCode,
                  fallback: '',
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsDevice)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _TextSettingTile(
                  icon: Icons.smartphone_outlined,
                  label: l10n.t(K.settingsDeviceName),
                  settingKey: SettingKeys.deviceLabel,
                  fallback: '',
                ),
                Padding(
                  padding: const EdgeInsets.only(top: Dimens.gapXs),
                  child: Text(
                    l10n.t(K.settingsDeviceNameHint),
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: Dimens.gapXs),
                  child: Text(
                    '${l10n.t(K.auditDevice)}: '
                    '${ref.watch(deviceIdentityProvider).current.shortId}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsScanning)),
          AppCard(
            child: Column(
              children: <Widget>[
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.center_focus_strong_outlined),
                  title: Text(l10n.t(K.settingsScanning)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const ScanSettingsPage()),
                  ),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.notifications_outlined),
                  title: Text(l10n.t(K.notifTitle)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const NotificationSettingsPage(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsWorkflow)),
          AppCard(
            child: Column(
              children: <Widget>[
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.timeline),
                  title: Text(l10n.t(K.notifWorkflow)),
                  subtitle: Text(l10n.t(K.notifWorkflowSubtitle)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => NotificationWorkflowPage.open(context),
                ),
                if (permissions.contains(Permission.manageEscalations))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.supervisor_account_outlined),
                    title: Text(l10n.t(K.escalationRules)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => EscalationRulesPage.open(context),
                  ),
                if (permissions.contains(Permission.viewAuditTrail))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.history_edu_outlined),
                    title: Text(l10n.t(K.settingsAudit)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => AuditTrailPage.open(context),
                  ),
                if (permissions.contains(Permission.exportReports))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.description_outlined),
                    title: Text(l10n.t(K.settingsExport)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => ExportPage.open(context),
                  ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsDestroyRules)),
          AppCard(
            child: Column(
              children: <Widget>[
                _BoolSettingTile(
                  label: l10n.t(K.settingsRequirePhoto),
                  settingKey: SettingKeys.requirePhotoOnDestroy,
                  fallback: SettingDefaults.requirePhotoOnDestroy,
                ),
                _BoolSettingTile(
                  label: l10n.t(K.settingsRequireReason),
                  settingKey: SettingKeys.requireReasonOnDestroy,
                  fallback: SettingDefaults.requireReasonOnDestroy,
                ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsInsights)),
          AppCard(
            child: Column(
              children: <Widget>[
                _IntSettingTile(
                  label: l10n.t(K.settingsLookbackDays),
                  settingKey: SettingKeys.insightsLookbackDays,
                  fallback: SettingDefaults.insightsLookbackDays,
                ),
                _IntSettingTile(
                  label: l10n.t(K.settingsForecastDays),
                  settingKey: SettingKeys.insightsForecastDays,
                  fallback: SettingDefaults.insightsForecastDays,
                ),
                _IntSettingTile(
                  label: l10n.t(K.settingsMinimumSamples),
                  settingKey: SettingKeys.insightsMinimumSamples,
                  fallback: SettingDefaults.insightsMinimumSamples,
                ),
              ],
            ),
          ),
          if (permissions.contains(Permission.manageUsers)) ...<Widget>[
            SectionHeader(title: l10n.t(K.settingsUsers)),
            AppCard(
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.group_outlined),
                title: Text(l10n.t(K.settingsUsers)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const UsersPage()),
                ),
              ),
            ),
          ],
          SectionHeader(title: l10n.t(K.settingsData)),
          AppCard(
            child: Column(
              children: <Widget>[
                // First in this section on purpose: it is the only thing here
                // that can bring a shop's data back, and the reset below is
                // the only thing that can take it away.
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.backup_outlined),
                  title: Text(l10n.t(K.backupTitle)),
                  subtitle: Text(l10n.t(K.backupSubtitle)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const BackupPage()),
                  ),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.sync),
                  title: Text(l10n.t(K.syncTitle)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const SyncPage()),
                  ),
                ),
                if (permissions.contains(Permission.resetData))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      Icons.delete_sweep_outlined,
                      color: Theme.of(context).colorScheme.error,
                    ),
                    title: Text(
                      l10n.t(K.settingsResetData),
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                    onTap: () => _confirmReset(context, ref),
                  ),
              ],
            ),
          ),
          SectionHeader(title: l10n.t(K.settingsAbout)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(l10n.t(K.appName),
                    style: Theme.of(context).textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.w700),),
                Text(l10n.t(K.appTagline)),
                const SizedBox(height: Dimens.gapS),
                Text(
                  l10n.t(K.settingsVersion, <String, Object?>{
                    'version': ref.watch(dependenciesProvider).appVersion,
                    'build': ref.watch(dependenciesProvider).appBuild,
                  }),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                Text(
                  '${l10n.t(K.notifDailyDigestTime)}: '
                  '${_formatMinutes(settings.readInt(SettingKeys.dailyDigestMinutes, SettingDefaults.dailyDigestMinutes))}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static String _formatMinutes(int minutes) =>
      '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';

  Future<void> _pickThemeMode(BuildContext context, WidgetRef ref, ThemeMode current) async {
    final AppLocalizations l10n = context.l10n;
    final ThemeMode? picked = await showDialog<ThemeMode>(
      context: context,
      builder: (BuildContext context) => SimpleDialog(
        title: Text(l10n.t(K.settingsTheme)),
        children: ThemeMode.values
            .map((ThemeMode mode) => SimpleDialogOption(
                  onPressed: () => Navigator.of(context).pop(mode),
                  child: ListTile(
                    leading: Icon(
                      mode == current ? Icons.radio_button_checked : Icons.radio_button_off,
                    ),
                    title: Text(l10n.t(switch (mode) {
                      ThemeMode.light => K.settingsThemeLight,
                      ThemeMode.dark => K.settingsThemeDark,
                      ThemeMode.system => K.settingsThemeSystem,
                    },),),
                  ),
                ),)
            .toList(growable: false),
      ),
    );
    if (picked != null) await ref.read(themeModeProvider.notifier).setMode(picked);
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final AppLocalizations l10n = context.l10n;
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.settingsResetData)),
        content: Text(l10n.t(K.settingsResetDataWarning)),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(l10n.t(K.commonDelete)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await ref.read(dependenciesProvider).database.wipeOperationalData();
    await ref.read(dependenciesProvider).notificationPlanner.cancelAll();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(l10n.t(K.settingsResetDone))));
  }
}

class _BoolSettingTile extends ConsumerWidget {
  const _BoolSettingTile({
    required this.label,
    required this.settingKey,
    required this.fallback,
  });

  final String label;
  final String settingKey;
  final bool fallback;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      value: settings.readBool(settingKey, fallback),
      onChanged: (bool value) async {
        await settings.write(settingKey, value);
        ref.read(settingsRevisionProvider.notifier).bump();
      },
    );
  }
}

class _IntSettingTile extends ConsumerWidget {
  const _IntSettingTile({
    required this.label,
    required this.settingKey,
    required this.fallback,
  });

  final String label;
  final String settingKey;
  final int fallback;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    final int value = settings.readInt(settingKey, fallback);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      trailing: Text('$value', style: const TextStyle(fontWeight: FontWeight.w700)),
      onTap: () async {
        final int? next = await _promptForInt(context, label, value);
        if (next == null) return;
        await settings.write(settingKey, next);
        ref.read(settingsRevisionProvider.notifier).bump();
      },
    );
  }
}

class _TextSettingTile extends ConsumerWidget {
  const _TextSettingTile({
    required this.icon,
    required this.label,
    required this.settingKey,
    required this.fallback,
  });

  final IconData icon;
  final String label;
  final String settingKey;
  final String fallback;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    final String value = settings.readString(settingKey, fallback);
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon),
      title: Text(label),
      subtitle: Text(value.isEmpty ? context.l10n.t(K.commonNotSet) : value),
      onTap: () async {
        final String? next = await _promptForText(context, label, value);
        if (next == null) return;
        await settings.write(settingKey, next);
        ref.read(settingsRevisionProvider.notifier).bump();
      },
    );
  }
}

Future<int?> _promptForInt(BuildContext context, String label, int current) async {
  final AppLocalizations l10n = context.l10n;
  final TextEditingController controller = TextEditingController(text: current.toString());
  final int? value = await showDialog<int>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: Text(label),
      content: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        autofocus: true,
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.t(K.commonCancel)),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(int.tryParse(controller.text.trim())),
          child: Text(l10n.t(K.commonSave)),
        ),
      ],
    ),
  );
  controller.dispose();
  return value;
}

Future<String?> _promptForText(BuildContext context, String label, String current) async {
  final AppLocalizations l10n = context.l10n;
  final TextEditingController controller = TextEditingController(text: current);
  final String? value = await showDialog<String>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: Text(label),
      content: TextField(controller: controller, autofocus: true),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.t(K.commonCancel)),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(controller.text.trim()),
          child: Text(l10n.t(K.commonSave)),
        ),
      ],
    ),
  );
  controller.dispose();
  return value;
}
