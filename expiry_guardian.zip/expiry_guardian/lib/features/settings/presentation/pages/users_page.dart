import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final FutureProvider<List<AppUser>> usersProvider =
    FutureProvider<List<AppUser>>((Ref ref) async {
  final Result<List<AppUser>> result =
      await ref.watch(authRepositoryProvider).listUsers(includeInactive: true);
  return result.fold((Failure f) => throw f, (List<AppUser> v) => v);
});

String roleLabel(AppLocalizations l10n, UserRole role) => l10n.t(switch (role) {
      UserRole.employee => K.authRoleEmployee,
      UserRole.manager => K.authRoleManager,
      UserRole.admin => K.authRoleAdmin,
    },);

String roleDescription(AppLocalizations l10n, UserRole role) => l10n.t(switch (role) {
      UserRole.employee => K.authRoleEmployeeDesc,
      UserRole.manager => K.authRoleManagerDesc,
      UserRole.admin => K.authRoleAdminDesc,
    },);

/// Staff accounts and what each role may do.
class UsersPage extends ConsumerWidget {
  const UsersPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<AppUser>> users = ref.watch(usersProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.settingsUsers))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _createUser(context, ref),
        icon: const Icon(Icons.person_add_alt),
        label: Text(l10n.t(K.settingsNewUser)),
      ),
      body: users.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
        data: (List<AppUser> value) => ListView(
          padding: const EdgeInsets.fromLTRB(
            Dimens.gutter,
            Dimens.gutter,
            Dimens.gutter,
            Dimens.gapXl * 3,
          ),
          children: <Widget>[
            for (final UserRole role in UserRole.values)
              Padding(
                padding: const EdgeInsets.only(bottom: Dimens.gapS),
                child: AppCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        roleLabel(l10n, role),
                        style: Theme.of(context).textTheme.titleSmall
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        roleDescription(l10n, role),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ),
            SectionHeader(title: l10n.t(K.settingsUsers)),
            for (final AppUser user in value)
              Padding(
                padding: const EdgeInsets.only(bottom: Dimens.gapS),
                child: AppCard(
                  child: Row(
                    children: <Widget>[
                      CircleAvatar(
                        backgroundColor: user.isActive
                            ? Theme.of(context).colorScheme.primaryContainer
                            : Theme.of(context).colorScheme.surfaceContainerHighest,
                        child: Text(user.displayName.characters.first.toUpperCase()),
                      ),
                      const SizedBox(width: Dimens.gapM),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              user.displayName,
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                decoration:
                                    user.isActive ? null : TextDecoration.lineThrough,
                              ),
                            ),
                            Text('${user.username} · ${roleLabel(l10n, user.role)}'),
                          ],
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (String action) async {
                          switch (action) {
                            case 'role':
                              await _changeRole(context, ref, user);
                            case 'password':
                              await _changePassword(context, ref, user);
                            case 'toggle':
                              await ref.read(authRepositoryProvider).setActive(
                                    userId: user.id,
                                    isActive: !user.isActive,
                                  );
                              ref.invalidate(usersProvider);
                          }
                        },
                        itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                          PopupMenuItem<String>(
                            value: 'role',
                            child: Text(l10n.t(K.authRole)),
                          ),
                          PopupMenuItem<String>(
                            value: 'password',
                            child: Text(l10n.t(K.authChangePassword)),
                          ),
                          PopupMenuItem<String>(
                            value: 'toggle',
                            child: Text(
                              user.isActive
                                  ? l10n.t(K.settingsDeactivate)
                                  : l10n.t(K.settingsActivate),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _createUser(BuildContext context, WidgetRef ref) async {
    final AppLocalizations l10n = context.l10n;
    final TextEditingController displayName = TextEditingController();
    final TextEditingController username = TextEditingController();
    final TextEditingController password = TextEditingController();
    UserRole role = UserRole.employee;

    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) => AlertDialog(
          title: Text(l10n.t(K.settingsNewUser)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  controller: displayName,
                  decoration: InputDecoration(labelText: l10n.t(K.authDisplayName)),
                ),
                const SizedBox(height: Dimens.gapM),
                TextField(
                  controller: username,
                  autocorrect: false,
                  decoration: InputDecoration(labelText: l10n.t(K.authUsername)),
                ),
                const SizedBox(height: Dimens.gapM),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: InputDecoration(labelText: l10n.t(K.authPassword)),
                ),
                const SizedBox(height: Dimens.gapM),
                DropdownButtonFormField<UserRole>(
                  initialValue: role,
                  decoration: InputDecoration(labelText: l10n.t(K.authRole)),
                  items: UserRole.values
                      .map((UserRole r) => DropdownMenuItem<UserRole>(
                            value: r,
                            child: Text(roleLabel(l10n, r)),
                          ),)
                      .toList(growable: false),
                  onChanged: (UserRole? value) =>
                      setState(() => role = value ?? UserRole.employee),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text(l10n.t(K.commonCancel)),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: Text(l10n.t(K.commonSave)),
            ),
          ],
        ),
      ),
    );

    final String name = displayName.text;
    final String login = username.text;
    final String secret = password.text;
    displayName.dispose();
    username.dispose();
    password.dispose();
    if (confirmed != true) return;

    final Result<AppUser> result = await ref.read(authRepositoryProvider).createUser(
          username: login,
          displayName: name,
          password: secret,
          role: role,
        );
    ref.invalidate(usersProvider);
    if (!context.mounted) return;
    final Failure? failure = result.failureOrNull;
    if (failure != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(describeFailure(context, failure))));
    }
  }

  Future<void> _changeRole(BuildContext context, WidgetRef ref, AppUser user) async {
    final AppLocalizations l10n = context.l10n;
    final UserRole? picked = await showDialog<UserRole>(
      context: context,
      builder: (BuildContext context) => SimpleDialog(
        title: Text(l10n.t(K.authRole)),
        children: UserRole.values
            .map((UserRole role) => SimpleDialogOption(
                  onPressed: () => Navigator.of(context).pop(role),
                  child: ListTile(
                    leading: Icon(
                      role == user.role
                          ? Icons.radio_button_checked
                          : Icons.radio_button_off,
                    ),
                    title: Text(roleLabel(l10n, role)),
                    subtitle: Text(roleDescription(l10n, role)),
                  ),
                ),)
            .toList(growable: false),
      ),
    );
    if (picked == null) return;
    await ref.read(authRepositoryProvider).updateUser(user.copyWith(role: picked));
    ref.invalidate(usersProvider);
  }

  Future<void> _changePassword(BuildContext context, WidgetRef ref, AppUser user) async {
    final AppLocalizations l10n = context.l10n;
    final TextEditingController password = TextEditingController();
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.authChangePassword)),
        content: TextField(
          controller: password,
          obscureText: true,
          autofocus: true,
          decoration: InputDecoration(labelText: l10n.t(K.authNewPassword)),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(l10n.t(K.commonSave)),
          ),
        ],
      ),
    );
    final String secret = password.text;
    password.dispose();
    if (confirmed != true) return;

    final Result<void> result = await ref
        .read(authRepositoryProvider)
        .changePassword(userId: user.id, newPassword: secret);
    if (!context.mounted) return;
    final Failure? failure = result.failureOrNull;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          failure == null
              ? l10n.t(K.authPasswordChanged)
              : describeFailure(context, failure),
        ),
      ),
    );
  }
}
