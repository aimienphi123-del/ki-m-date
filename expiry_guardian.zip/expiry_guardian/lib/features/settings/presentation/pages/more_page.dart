import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/audit/presentation/pages/audit_trail_page.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/catalog/presentation/pages/catalog_page.dart';
import 'package:expiry_guardian/features/dashboard/presentation/pages/dashboard_page.dart';
import 'package:expiry_guardian/features/escalation/presentation/pages/manager_dashboard_page.dart';
import 'package:expiry_guardian/features/insights/presentation/pages/insights_page.dart';
import 'package:expiry_guardian/features/locations/presentation/pages/locations_page.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/disposal_calculator_page.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/policy_page.dart';
import 'package:expiry_guardian/features/reports/presentation/pages/export_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/settings_page.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The hub for everything that is not a daily task: dashboard, catalog,
/// locations, the policy handbook, predictions and settings.
class MorePage extends ConsumerWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final Set<Permission> permissions = ref.watch(permissionsProvider);

    final List<_MoreEntry> entries = <_MoreEntry>[
      _MoreEntry(
        icon: Icons.dashboard_outlined,
        title: l10n.t(K.dashboardTitle),
        builder: (_) => const DashboardPage(),
      ),
      _MoreEntry(
        icon: Icons.insights_outlined,
        title: l10n.t(K.insightsTitle),
        builder: (_) => const InsightsPage(),
      ),
      if (permissions.contains(Permission.manageCatalog))
        _MoreEntry(
          icon: Icons.category_outlined,
          title: l10n.t(K.catalogTitle),
          builder: (_) => const CatalogPage(),
        ),
      if (permissions.contains(Permission.manageLocations))
        _MoreEntry(
          icon: Icons.store_mall_directory_outlined,
          title: l10n.t(K.locationsTitle),
          builder: (_) => const LocationsPage(),
        ),
      if (permissions.contains(Permission.manageEscalations))
        _MoreEntry(
          icon: Icons.supervisor_account_outlined,
          title: l10n.t(K.escalationDashboard),
          subtitle: l10n.t(K.escalationSubtitle),
          builder: (_) => const ManagerDashboardPage(),
        ),
      if (permissions.contains(Permission.viewAuditTrail))
        _MoreEntry(
          icon: Icons.history_edu_outlined,
          title: l10n.t(K.auditTitle),
          subtitle: l10n.t(K.auditSubtitle),
          builder: (_) => const AuditTrailPage(),
        ),
      if (permissions.contains(Permission.exportReports))
        _MoreEntry(
          icon: Icons.description_outlined,
          title: l10n.t(K.exportTitle),
          builder: (_) => const ExportPage(),
        ),
      // Deliberately available to everyone, unlike the policy editor: working
      // out a destroy deadline is a shop-floor job, changing the handbook is
      // not. It only reads the policy.
      _MoreEntry(
        icon: Icons.calculate_outlined,
        title: l10n.t(K.calcTitle),
        subtitle: l10n.t(K.calcSubtitle),
        builder: (_) => const DisposalCalculatorPage(),
      ),
      if (permissions.contains(Permission.editPolicy))
        _MoreEntry(
          icon: Icons.rule_folder_outlined,
          title: l10n.t(K.policyTitle),
          subtitle: l10n.t(K.policySubtitle),
          builder: (_) => const PolicyPage(),
        ),
      _MoreEntry(
        icon: Icons.settings_outlined,
        title: l10n.t(K.settingsTitle),
        builder: (_) => const SettingsPage(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.navMore))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gapXl * 3,
        ),
        children: entries
            .map((_MoreEntry entry) => Padding(
                  padding: const EdgeInsets.only(bottom: Dimens.gapS),
                  child: AppCard(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: entry.builder),
                    ),
                    child: Row(
                      children: <Widget>[
                        Icon(entry.icon, color: Theme.of(context).colorScheme.primary),
                        const SizedBox(width: Dimens.gapM),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                entry.title,
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(fontWeight: FontWeight.w700),
                              ),
                              if (entry.subtitle != null)
                                Text(
                                  entry.subtitle!,
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                        color:
                                            Theme.of(context).colorScheme.onSurfaceVariant,
                                      ),
                                ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right),
                      ],
                    ),
                  ),
                ),)
            .toList(growable: false),
      ),
    );
  }
}

class _MoreEntry {
  const _MoreEntry({
    required this.icon,
    required this.title,
    required this.builder,
    this.subtitle,
  });

  final IconData icon;
  final String title;
  final String? subtitle;
  final WidgetBuilder builder;
}
