import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/sync/sync_engine.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Honest status of the local-first store.
///
/// In this build no backend is configured, so the screen says exactly that and
/// shows how many changes are queued and ready to upload the day one is.
class SyncPage extends ConsumerStatefulWidget {
  const SyncPage({super.key});

  @override
  ConsumerState<SyncPage> createState() => _SyncPageState();
}

class _SyncPageState extends ConsumerState<SyncPage> {
  int? _pending;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final int count = await ref.read(dependenciesProvider).syncQueue.pendingCount();
    if (mounted) setState(() => _pending = count);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final SyncEngine engine = ref.watch(dependenciesProvider).syncEngine;
    final SyncStatus status = ref.watch(syncStatusProvider).valueOrNull ?? engine.currentStatus;
    final bool configured = ref.watch(dependenciesProvider).remoteGateway.isConfigured;

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.syncTitle))),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.all(Dimens.gutter),
          children: <Widget>[
            if (!configured)
              NoticeBanner(
                icon: Icons.cloud_off_outlined,
                message: l10n.t(K.syncOfflineOnlyBody),
              ),
            const SizedBox(height: Dimens.gapM),
            AppCard(
              child: Column(
                children: <Widget>[
                  DetailRow(
                    icon: Icons.info_outline,
                    label: l10n.t(K.commonStatus),
                    value: configured
                        ? l10n.t(switch (status.phase) {
                            SyncPhase.idle => K.syncPhaseIdle,
                            SyncPhase.checking => K.syncPhaseChecking,
                            SyncPhase.pushing => K.syncPhasePushing,
                            SyncPhase.pulling => K.syncPhasePulling,
                            SyncPhase.backingOff => K.syncPhaseBackingOff,
                            SyncPhase.offlineOnly => K.syncOfflineOnly,
                            SyncPhase.error => K.syncPhaseError,
                          },)
                        : l10n.t(K.syncOfflineOnly),
                  ),
                  DetailRow(
                    icon: Icons.wifi_tethering,
                    label: l10n.t(K.syncOnline),
                    value: status.online ? l10n.t(K.commonYes) : l10n.t(K.commonNo),
                  ),
                  DetailRow(
                    icon: Icons.upload_file_outlined,
                    label: l10n.t(K.syncPending, <String, Object?>{
                      'count': _pending ?? status.pendingChanges,
                    }),
                    value: '${_pending ?? status.pendingChanges}',
                  ),
                  DetailRow(
                    icon: Icons.history,
                    label: l10n.t(K.syncLastSuccess, <String, Object?>{'time': ''}).trim(),
                    value: status.lastSuccessAt == null
                        ? l10n.t(K.syncNever)
                        : l10n.dateTime(status.lastSuccessAt!),
                  ),
                  if (status.lastError != null)
                    DetailRow(
                      icon: Icons.error_outline,
                      label: l10n.t(K.syncPhaseError),
                      value: status.lastError!,
                      valueColor: Theme.of(context).colorScheme.error,
                    ),
                ],
              ),
            ),
            const SizedBox(height: Dimens.gapL),
            FilledButton.tonalIcon(
              onPressed: configured
                  ? () async {
                      await engine.syncNow();
                      await _refresh();
                    }
                  : null,
              icon: const Icon(Icons.sync),
              label: Text(l10n.t(K.syncSyncNow)),
            ),
          ],
        ),
      ),
    );
  }
}
