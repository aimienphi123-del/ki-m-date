import 'dart:convert';

import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The filter the audit screen is showing.
final NotifierProvider<AuditFilter, AuditQuery> auditQueryProvider =
    NotifierProvider<AuditFilter, AuditQuery>(AuditFilter.new);

class AuditFilter extends Notifier<AuditQuery> {
  @override
  AuditQuery build() => const AuditQuery();

  void setActions(Set<AuditAction> actions) => state = state.copyWith(actions: actions);

  void setText(String? text) => state = (text == null || text.trim().isEmpty)
      ? state.copyWith(clearText: true)
      : state.copyWith(text: text.trim());

  void clear() => state = const AuditQuery();
}

final FutureProvider<List<AuditEntry>> auditEntriesProvider =
    FutureProvider<List<AuditEntry>>((Ref ref) async {
  ref.watch(auditChangesProvider);
  final Result<List<AuditEntry>> result =
      await ref.watch(auditRepositoryProvider).query(ref.watch(auditQueryProvider));
  return result.valueOrNull ?? const <AuditEntry>[];
});

/// Feature 4: the append-only log, readable on the phone.
///
/// Nothing on this screen can edit or delete a line - the repository has no
/// such method and the table has triggers that abort any attempt. The verify
/// button re-hashes the whole chain and says exactly where it breaks, if it
/// ever does.
class AuditTrailPage extends ConsumerWidget {
  const AuditTrailPage({super.key});

  static Future<void> open(BuildContext context) => Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const AuditTrailPage()),
      );

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<AuditEntry>> entries = ref.watch(auditEntriesProvider);
    final AuditQuery query = ref.watch(auditQueryProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.auditTitle)),
        actions: <Widget>[
          IconButton(
            tooltip: l10n.t(K.auditVerify),
            icon: const Icon(Icons.verified_user_outlined),
            onPressed: () => _verify(context, ref),
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gapS,
            ),
            child: Column(
              children: <Widget>[
                NoticeBanner(icon: Icons.lock_outline, message: l10n.t(K.auditImmutableNote)),
                const SizedBox(height: Dimens.gapS),
                TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: l10n.t(K.commonSearch),
                    border: const OutlineInputBorder(),
                    isDense: true,
                  ),
                  onSubmitted: (String value) =>
                      ref.read(auditQueryProvider.notifier).setText(value),
                ),
                const SizedBox(height: Dimens.gapS),
                SizedBox(
                  height: 40,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: <Widget>[
                      FilterChip(
                        label: Text(l10n.t(K.commonAll)),
                        selected: query.actions.isEmpty,
                        onSelected: (_) =>
                            ref.read(auditQueryProvider.notifier).setActions(const <AuditAction>{}),
                      ),
                      for (final AuditAction action in _highlighted)
                        Padding(
                          padding: const EdgeInsets.only(left: Dimens.gapS),
                          child: FilterChip(
                            label: Text(l10n.t(auditActionKey(action))),
                            selected: query.actions.contains(action),
                            onSelected: (bool on) {
                              final Set<AuditAction> next = <AuditAction>{...query.actions};
                              on ? next.add(action) : next.remove(action);
                              ref.read(auditQueryProvider.notifier).setActions(next);
                            },
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: entries.when(
              loading: () => const LoadingView(),
              error: (Object error, StackTrace stack) => ErrorView(message: error.toString()),
              data: (List<AuditEntry> value) => value.isEmpty
                  ? EmptyState(icon: Icons.history_toggle_off, title: l10n.t(K.auditEmpty))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(
                        Dimens.gutter,
                        0,
                        Dimens.gutter,
                        Dimens.gapXl,
                      ),
                      itemCount: value.length,
                      itemBuilder: (BuildContext context, int index) => Padding(
                        padding: const EdgeInsets.only(bottom: Dimens.gapS),
                        child: _AuditCard(entry: value[index]),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  /// The handful worth one tap on a phone; the rest are reachable by search.
  static const List<AuditAction> _highlighted = <AuditAction>[
    AuditAction.destroyConfirmed,
    AuditAction.escalationRaised,
    AuditAction.managerOverride,
    AuditAction.recordCreated,
    AuditAction.policyRuleEdited,
    AuditAction.reportExported,
  ];

  Future<void> _verify(BuildContext context, WidgetRef ref) async {
    final AppLocalizations l10n = context.l10n;
    final Result<AuditIntegrityReport> result =
        await ref.read(auditRepositoryProvider).verifyChain();
    if (!context.mounted) return;
    result.fold(
      (_) => showAppSnack(context, l10n.t(K.errorGeneric), isError: true),
      (AuditIntegrityReport report) => showAppSnack(
        context,
        report.isIntact
            ? l10n.t(K.auditIntact, <String, Object?>{'count': report.entriesChecked})
            : l10n.t(K.auditBroken, <String, Object?>{
                'sequence': report.firstBrokenSequence ?? 0,
              }),
        isError: !report.isIntact,
      ),
    );
  }
}

class _AuditCard extends StatelessWidget {
  const _AuditCard({required this.entry});

  final AuditEntry entry;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final bool hasChange = entry.previousValue != null || entry.newValue != null;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Text(
                '#${entry.sequence}',
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  l10n.t(auditActionKey(entry.action)),
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              Text(l10n.dateTime(entry.occurredAt), style: theme.textTheme.bodySmall),
            ],
          ),
          if ((entry.entityLabel ?? '').isNotEmpty)
            Text(entry.entityLabel!, style: theme.textTheme.bodyMedium),
          const SizedBox(height: Dimens.gapXs),
          Text(
            <String>[
              '${l10n.t(K.auditActor)}: ${entry.actorName ?? l10n.t(K.commonUnknown)}',
              if ((entry.deviceId ?? '').isNotEmpty)
                '${l10n.t(K.auditDevice)}: ${_shortId(entry.deviceId!)}',
            ].join('  ·  '),
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          if ((entry.note ?? '').isNotEmpty) ...<Widget>[
            const SizedBox(height: Dimens.gapXs),
            Text(entry.note!, style: theme.textTheme.bodySmall),
          ],
          if (hasChange)
            Theme(
              data: theme.copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                tilePadding: EdgeInsets.zero,
                childrenPadding: EdgeInsets.zero,
                title: Text(
                  l10n.t(K.auditNewValue),
                  style: theme.textTheme.bodySmall,
                ),
                children: <Widget>[
                  if (entry.previousValue != null)
                    _ValueBlock(label: l10n.t(K.auditPreviousValue), value: entry.previousValue!),
                  if (entry.newValue != null)
                    _ValueBlock(label: l10n.t(K.auditNewValue), value: entry.newValue!),
                ],
              ),
            ),
        ],
      ),
    );
  }

  static String _shortId(String id) => id.length <= 8 ? id : id.substring(0, 8);
}

class _ValueBlock extends StatelessWidget {
  const _ValueBlock({required this.label, required this.value});

  final String label;
  final Map<String, Object?> value;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: const EdgeInsets.only(bottom: Dimens.gapS),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(label, style: theme.textTheme.labelSmall),
            Text(
              const JsonEncoder.withIndent('  ').convert(value),
              style: theme.textTheme.bodySmall?.copyWith(fontFamily: 'monospace'),
            ),
          ],
        ),
      ),
    );
  }
}

/// The localization key for each action. Kept next to the screen that shows
/// them so a new [AuditAction] fails to compile until it has a label.
String auditActionKey(AuditAction action) => switch (action) {
      AuditAction.productCreated => K.auditActionProductCreated,
      AuditAction.productUpdated => K.auditActionProductUpdated,
      AuditAction.productDeleted => K.auditActionProductDeleted,
      AuditAction.recordCreated => K.auditActionRecordCreated,
      AuditAction.recordScanned => K.auditActionRecordScanned,
      AuditAction.recordEdited => K.auditActionRecordEdited,
      AuditAction.recordMoved => K.auditActionRecordMoved,
      AuditAction.quantityAdjusted => K.auditActionQuantityAdjusted,
      AuditAction.recordClosed => K.auditActionRecordClosed,
      AuditAction.destroyReminderScheduled => K.auditActionDestroyReminderScheduled,
      AuditAction.destroyReminderFired => K.auditActionDestroyReminderFired,
      AuditAction.destroyConfirmed => K.auditActionDestroyConfirmed,
      AuditAction.escalationRaised => K.auditActionEscalationRaised,
      AuditAction.escalationNotified => K.auditActionEscalationNotified,
      AuditAction.escalationAcknowledged => K.auditActionEscalationAcknowledged,
      AuditAction.escalationResolved => K.auditActionEscalationResolved,
      AuditAction.managerOverride => K.auditActionManagerOverride,
      AuditAction.policyEdited => K.auditActionPolicyEdited,
      AuditAction.policyRuleEdited => K.auditActionPolicyRuleEdited,
      AuditAction.policyRecalculated => K.auditActionPolicyRecalculated,
      AuditAction.notificationStageEdited => K.auditActionNotificationStageEdited,
      AuditAction.escalationRuleEdited => K.auditActionEscalationRuleEdited,
      AuditAction.locationEdited => K.auditActionLocationEdited,
      AuditAction.settingChanged => K.auditActionSettingChanged,
      AuditAction.userCreated => K.auditActionUserCreated,
      AuditAction.userUpdated => K.auditActionUserUpdated,
      AuditAction.userSignedIn => K.auditActionUserSignedIn,
      AuditAction.userSignedOut => K.auditActionUserSignedOut,
      AuditAction.passwordChanged => K.auditActionPasswordChanged,
      AuditAction.reportExported => K.auditActionReportExported,
      AuditAction.dataReset => K.auditActionDataReset,
    };
