import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';

/// Translates between `policies` / `policy_rules` rows and domain entities.
abstract final class PolicyMapper {
  static DestroyPolicy fromRows(
    Map<String, Object?> policyRow,
    List<Map<String, Object?>> ruleRows,
  ) {
    return DestroyPolicy(
      id: policyRow.str('id'),
      name: policyRow.str('name'),
      version: policyRow.integer('version'),
      isActive: policyRow.boolean('is_active'),
      basis: ShelfLifeBasis.fromName(policyRow.strOrNull('basis')),
      fallbackToIntakeBasis: policyRow.boolean('fallback_to_intake_basis'),
      dateExpiryAtEndOfDay: policyRow.boolean('date_expiry_at_end_of_day'),
      normalizeDestroyTimeMinutes: policyRow.intOrNull('normalize_destroy_time_minutes'),
      fallbackLeadTime: Duration(minutes: policyRow.integer('fallback_lead_minutes')),
      thresholds: PriorityThresholds(
        destroySoonWindow: Duration(minutes: policyRow.integer('destroy_soon_window_minutes')),
        approachingWindow: Duration(minutes: policyRow.integer('approaching_window_minutes')),
      ),
      notes: policyRow.strOrNull('notes') ?? '',
      createdAt: policyRow.dateTime('created_at'),
      updatedAt: policyRow.dateTime('updated_at'),
      rules: ruleRows.map(ruleFromRow).toList(),
    );
  }

  static Map<String, Object?> toRow(DestroyPolicy policy) {
    return <String, Object?>{
      'id': policy.id,
      'name': policy.name,
      'version': policy.version,
      'is_active': boolToInt(policy.isActive),
      'basis': policy.basis.name,
      'fallback_to_intake_basis': boolToInt(policy.fallbackToIntakeBasis),
      'date_expiry_at_end_of_day': boolToInt(policy.dateExpiryAtEndOfDay),
      'normalize_destroy_time_minutes': policy.normalizeDestroyTimeMinutes,
      'fallback_lead_minutes': policy.fallbackLeadTime.inMinutes,
      'destroy_soon_window_minutes': policy.thresholds.destroySoonWindow.inMinutes,
      'approaching_window_minutes': policy.thresholds.approachingWindow.inMinutes,
      'notes': policy.notes,
      'created_at': policy.createdAt.millisecondsSinceEpoch,
      'updated_at': policy.updatedAt.millisecondsSinceEpoch,
    };
  }

  static PolicyRule ruleFromRow(Map<String, Object?> row) {
    return PolicyRule(
      id: row.str('id'),
      policyId: row.str('policy_id'),
      sortOrder: row.integer('sort_order'),
      nameVi: row.str('name_vi'),
      nameEn: row.str('name_en'),
      leadTime: Duration(minutes: row.integer('lead_minutes')),
      minShelfLife: row.durationOrNull('min_minutes'),
      minInclusive: row.boolean('min_inclusive'),
      maxShelfLife: row.durationOrNull('max_minutes'),
      maxInclusive: row.boolean('max_inclusive'),
      matchesHourlyExpiry: row.boolean('matches_hourly'),
      isActive: row.boolean('is_active'),
    );
  }

  static Map<String, Object?> ruleToRow(PolicyRule rule) {
    return <String, Object?>{
      'id': rule.id,
      'policy_id': rule.policyId,
      'sort_order': rule.sortOrder,
      'name_vi': rule.nameVi,
      'name_en': rule.nameEn,
      'lead_minutes': rule.leadTime.inMinutes,
      'min_minutes': rule.minShelfLife?.inMinutes,
      'min_inclusive': boolToInt(rule.minInclusive),
      'max_minutes': rule.maxShelfLife?.inMinutes,
      'max_inclusive': boolToInt(rule.maxInclusive),
      'matches_hourly': boolToInt(rule.matchesHourlyExpiry),
      'is_active': boolToInt(rule.isActive),
    };
  }
}
