import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/exceptions.dart';
import 'package:expiry_guardian/features/policy/data/models/policy_mapper.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:sqflite/sqflite.dart';

abstract interface class PolicyLocalDataSource {
  Future<DestroyPolicy?> findActive();
  Future<DestroyPolicy?> findById(String id);
  Future<List<DestroyPolicy>> findAll();
  Future<void> insertPolicy(DestroyPolicy policy);
  Future<void> updatePolicy(DestroyPolicy policy);
  Future<void> upsertRule(PolicyRule rule);
  Future<void> deleteRule(String ruleId);
  Future<void> setActive(String policyId);
  Future<int> countPolicies();
}

class SqflitePolicyDataSource implements PolicyLocalDataSource {
  const SqflitePolicyDataSource(this._database);

  final AppDatabase _database;

  @override
  Future<int> countPolicies() async {
    final List<Map<String, Object?>> rows =
        await _database.db.rawQuery('SELECT COUNT(*) AS c FROM ${Tables.policies}');
    return (rows.first['c'] as int?) ?? 0;
  }

  @override
  Future<DestroyPolicy?> findActive() async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.policies,
      where: 'is_active = 1',
      orderBy: 'updated_at DESC',
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return _hydrate(rows.first);
  }

  @override
  Future<DestroyPolicy?> findById(String id) async {
    final List<Map<String, Object?>> rows =
        await _database.db.query(Tables.policies, where: 'id = ?', whereArgs: <Object?>[id]);
    if (rows.isEmpty) return null;
    return _hydrate(rows.first);
  }

  @override
  Future<List<DestroyPolicy>> findAll() async {
    final List<Map<String, Object?>> rows =
        await _database.db.query(Tables.policies, orderBy: 'is_active DESC, name COLLATE NOCASE');
    final List<DestroyPolicy> result = <DestroyPolicy>[];
    for (final Map<String, Object?> row in rows) {
      result.add(await _hydrate(row));
    }
    return result;
  }

  Future<DestroyPolicy> _hydrate(Map<String, Object?> policyRow) async {
    final List<Map<String, Object?>> ruleRows = await _database.db.query(
      Tables.policyRules,
      where: 'policy_id = ?',
      whereArgs: <Object?>[policyRow['id']],
      orderBy: 'sort_order ASC',
    );
    return PolicyMapper.fromRows(policyRow, ruleRows);
  }

  @override
  Future<void> insertPolicy(DestroyPolicy policy) async {
    await _database.write(<String>{Tables.policies, Tables.policyRules}, (Transaction txn) async {
      await txn.insert(Tables.policies, PolicyMapper.toRow(policy));
      for (final PolicyRule rule in policy.rules) {
        await txn.insert(Tables.policyRules, PolicyMapper.ruleToRow(rule));
      }
    });
  }

  @override
  Future<void> updatePolicy(DestroyPolicy policy) async {
    await _database.write(<String>{Tables.policies, Tables.policyRules}, (Transaction txn) async {
      final int updated = await txn.update(
        Tables.policies,
        PolicyMapper.toRow(policy),
        where: 'id = ?',
        whereArgs: <Object?>[policy.id],
      );
      if (updated == 0) {
        throw RecordNotFoundException('policy', policy.id);
      }
      await txn.delete(Tables.policyRules, where: 'policy_id = ?', whereArgs: <Object?>[policy.id]);
      for (final PolicyRule rule in policy.rules) {
        await txn.insert(Tables.policyRules, PolicyMapper.ruleToRow(rule));
      }
    });
  }

  @override
  Future<void> upsertRule(PolicyRule rule) async {
    await _database.write(<String>{Tables.policyRules}, (Transaction txn) async {
      await txn.insert(
        Tables.policyRules,
        PolicyMapper.ruleToRow(rule),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  @override
  Future<void> deleteRule(String ruleId) async {
    await _database.write(<String>{Tables.policyRules}, (Transaction txn) async {
      await txn.delete(Tables.policyRules, where: 'id = ?', whereArgs: <Object?>[ruleId]);
    });
  }

  @override
  Future<void> setActive(String policyId) async {
    await _database.write(<String>{Tables.policies}, (Transaction txn) async {
      await txn.update(Tables.policies, <String, Object?>{'is_active': 0});
      final int updated = await txn.update(
        Tables.policies,
        <String, Object?>{'is_active': 1},
        where: 'id = ?',
        whereArgs: <Object?>[policyId],
      );
      if (updated == 0) throw RecordNotFoundException('policy', policyId);
    });
  }
}
