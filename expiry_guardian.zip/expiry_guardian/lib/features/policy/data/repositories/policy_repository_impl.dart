import 'dart:async';

import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/exceptions.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/policy/data/datasources/policy_local_datasource.dart';
import 'package:expiry_guardian/features/policy/data/models/policy_mapper.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/repositories/policy_repository.dart';

class PolicyRepositoryImpl implements PolicyRepository {
  PolicyRepositoryImpl({
    required PolicyLocalDataSource local,
    required AppDatabase database,
    required Clock clock,
    required SyncQueue syncQueue,
    required AppLogger logger,
  })  : _local = local,
        _database = database,
        _clock = clock,
        _syncQueue = syncQueue,
        _logger = logger;

  final PolicyLocalDataSource _local;
  final AppDatabase _database;
  final Clock _clock;
  final SyncQueue _syncQueue;
  final AppLogger _logger;

  static const String _tag = 'PolicyRepository';

  @override
  Future<Result<DestroyPolicy>> getActivePolicy() async {
    return _guard(() async {
      final DestroyPolicy? policy = await _local.findActive();
      if (policy == null) {
        throw const RecordNotFoundException('policy', 'active');
      }
      return policy;
    });
  }

  @override
  Future<Result<DestroyPolicy>> getPolicy(String id) async {
    return _guard(() async {
      final DestroyPolicy? policy = await _local.findById(id);
      if (policy == null) throw RecordNotFoundException('policy', id);
      return policy;
    });
  }

  @override
  Future<Result<List<DestroyPolicy>>> listPolicies() => _guard(_local.findAll);

  @override
  Future<Result<DestroyPolicy>> savePolicy(DestroyPolicy policy) async {
    return _guard(() async {
      final DestroyPolicy? existing = await _local.findById(policy.id);
      final DestroyPolicy toSave = policy.copyWith(
        updatedAt: _clock.now(),
        version: existing == null ? policy.version : existing.version + 1,
      );
      if (existing == null) {
        await _local.insertPolicy(toSave);
      } else {
        await _local.updatePolicy(toSave);
      }
      await _syncQueue.enqueueUpsert(
        entity: Tables.policies,
        entityId: toSave.id,
        payload: <String, Object?>{
          'policy': PolicyMapper.toRow(toSave),
          'rules': toSave.rules.map(PolicyMapper.ruleToRow).toList(),
        },
      );
      _logger.i(_tag, 'Saved policy ${toSave.name} v${toSave.version}');
      return toSave;
    });
  }

  @override
  Future<Result<DestroyPolicy>> upsertRule(String policyId, PolicyRule rule) async {
    final Result<DestroyPolicy> current = await getPolicy(policyId);
    if (current.isErr) return current;
    final DestroyPolicy policy = current.unwrap();
    final List<PolicyRule> rules = List<PolicyRule>.of(policy.rules);
    final int index = rules.indexWhere((PolicyRule r) => r.id == rule.id);
    if (index >= 0) {
      rules[index] = rule;
    } else {
      rules.add(rule);
    }
    return savePolicy(policy.copyWith(rules: rules));
  }

  @override
  Future<Result<DestroyPolicy>> deleteRule(String policyId, String ruleId) async {
    final Result<DestroyPolicy> current = await getPolicy(policyId);
    if (current.isErr) return current;
    final DestroyPolicy policy = current.unwrap();
    final List<PolicyRule> rules =
        policy.rules.where((PolicyRule r) => r.id != ruleId).toList(growable: false);
    if (rules.length == policy.rules.length) {
      return Result<DestroyPolicy>.err(Failure.notFound('Rule $ruleId not found'));
    }
    return savePolicy(policy.copyWith(rules: rules));
  }

  @override
  Future<Result<DestroyPolicy>> reorderRules(String policyId, List<String> orderedRuleIds) async {
    final Result<DestroyPolicy> current = await getPolicy(policyId);
    if (current.isErr) return current;
    final DestroyPolicy policy = current.unwrap();
    final Map<String, PolicyRule> byId = <String, PolicyRule>{
      for (final PolicyRule r in policy.rules) r.id: r,
    };
    final List<PolicyRule> reordered = <PolicyRule>[];
    int order = 10;
    for (final String id in orderedRuleIds) {
      final PolicyRule? rule = byId.remove(id);
      if (rule != null) {
        reordered.add(rule.copyWith(sortOrder: order));
        order += 10;
      }
    }
    // Anything the caller forgot keeps its relative order at the end.
    for (final PolicyRule leftover in byId.values) {
      reordered.add(leftover.copyWith(sortOrder: order));
      order += 10;
    }
    return savePolicy(policy.copyWith(rules: reordered));
  }

  @override
  Future<Result<void>> setActivePolicy(String policyId) async {
    return _guard(() async {
      await _local.setActive(policyId);
      await _syncQueue.enqueueUpsert(
        entity: Tables.settings,
        entityId: 'active_policy',
        payload: <String, Object?>{'policy_id': policyId},
      );
    });
  }

  @override
  Stream<DestroyPolicy> watchActivePolicy() async* {
    final DestroyPolicy? initial = await _local.findActive();
    if (initial != null) yield initial;
    await for (final String table in _database.changes) {
      if (table == Tables.policies || table == Tables.policyRules) {
        final DestroyPolicy? next = await _local.findActive();
        if (next != null) yield next;
      }
    }
  }

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } on RecordNotFoundException catch (e) {
      return Result<T>.err(Failure.notFound(e.toString()));
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Policy operation failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('Policy operation failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
