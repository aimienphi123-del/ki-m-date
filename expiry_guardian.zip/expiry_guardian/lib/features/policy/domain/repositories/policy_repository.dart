import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';

abstract interface class PolicyRepository {
  /// The policy currently in force. Guaranteed non-null after bootstrap.
  Future<Result<DestroyPolicy>> getActivePolicy();

  Future<Result<List<DestroyPolicy>>> listPolicies();

  Future<Result<DestroyPolicy>> getPolicy(String id);

  /// Persists edits and bumps [DestroyPolicy.version].
  Future<Result<DestroyPolicy>> savePolicy(DestroyPolicy policy);

  Future<Result<DestroyPolicy>> upsertRule(String policyId, PolicyRule rule);

  Future<Result<DestroyPolicy>> deleteRule(String policyId, String ruleId);

  Future<Result<DestroyPolicy>> reorderRules(String policyId, List<String> orderedRuleIds);

  Future<Result<void>> setActivePolicy(String policyId);

  /// Emits whenever any policy row changes so open screens refresh.
  Stream<DestroyPolicy> watchActivePolicy();
}
