import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';

/// A complete, versioned destruction handbook.
///
/// Exactly one policy is active at a time. Editing an active policy bumps
/// [version]; every inventory record stores the policy id + version that
/// produced its destroy instant, so an audit can always explain *why* a given
/// unit had to go on a given day.
class DestroyPolicy {
  const DestroyPolicy({
    required this.id,
    required this.name,
    required this.rules,
    required this.createdAt,
    required this.updatedAt,
    this.version = 1,
    this.isActive = true,
    this.basis = ShelfLifeBasis.manufacturingToExpiry,
    this.fallbackToIntakeBasis = true,
    this.dateExpiryAtEndOfDay = true,
    this.normalizeDestroyTimeMinutes,
    this.fallbackLeadTime = Duration.zero,
    this.thresholds = const PriorityThresholds(),
    this.notes = '',
  });

  final String id;
  final String name;

  /// Sorted ascending by [PolicyRule.sortOrder]; first match wins.
  final List<PolicyRule> rules;

  final DateTime createdAt;
  final DateTime updatedAt;
  final int version;
  final bool isActive;

  final ShelfLifeBasis basis;

  /// When the preferred basis cannot be computed (no manufacturing date on the
  /// label) fall back to `expiry - goods receipt` instead of refusing.
  final bool fallbackToIntakeBasis;

  /// A "20/12/2026" label means the goods are good *through* 20 December, so
  /// the expiry instant is the end of that day. Set to false for companies
  /// that read a date label as "expires at 00:00 of that day".
  final bool dateExpiryAtEndOfDay;

  /// Optional: snap the destroy instant of day-precision units to a fixed time
  /// of day (minutes from midnight) so the morning list is stable.
  /// `null` = keep exact arithmetic.
  final int? normalizeDestroyTimeMinutes;

  /// Applied when no rule matches. Zero means "destroy at the expiry instant".
  final Duration fallbackLeadTime;

  final PriorityThresholds thresholds;
  final String notes;

  List<PolicyRule> get activeRulesInOrder =>
      (rules.where((PolicyRule r) => r.isActive).toList()
        ..sort((PolicyRule a, PolicyRule b) => a.sortOrder.compareTo(b.sortOrder)));

  List<PolicyRule> get allRulesInOrder =>
      (List<PolicyRule>.of(rules)..sort((PolicyRule a, PolicyRule b) => a.sortOrder.compareTo(b.sortOrder)));

  DestroyPolicy copyWith({
    String? id,
    String? name,
    List<PolicyRule>? rules,
    DateTime? createdAt,
    DateTime? updatedAt,
    int? version,
    bool? isActive,
    ShelfLifeBasis? basis,
    bool? fallbackToIntakeBasis,
    bool? dateExpiryAtEndOfDay,
    int? normalizeDestroyTimeMinutes,
    bool clearNormalizeDestroyTime = false,
    Duration? fallbackLeadTime,
    PriorityThresholds? thresholds,
    String? notes,
  }) {
    return DestroyPolicy(
      id: id ?? this.id,
      name: name ?? this.name,
      rules: rules ?? this.rules,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      version: version ?? this.version,
      isActive: isActive ?? this.isActive,
      basis: basis ?? this.basis,
      fallbackToIntakeBasis: fallbackToIntakeBasis ?? this.fallbackToIntakeBasis,
      dateExpiryAtEndOfDay: dateExpiryAtEndOfDay ?? this.dateExpiryAtEndOfDay,
      normalizeDestroyTimeMinutes: clearNormalizeDestroyTime
          ? null
          : (normalizeDestroyTimeMinutes ?? this.normalizeDestroyTimeMinutes),
      fallbackLeadTime: fallbackLeadTime ?? this.fallbackLeadTime,
      thresholds: thresholds ?? this.thresholds,
      notes: notes ?? this.notes,
    );
  }

  @override
  String toString() => 'DestroyPolicy($name v$version, ${rules.length} rules)';
}
