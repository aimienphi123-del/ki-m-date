/// Urgency bucket shown throughout the UI as a colour.
enum PriorityLevel {
  /// Already past the expiry instant - should never happen if the destroy
  /// tasks were completed, so it is tracked separately as a policy breach.
  expired,

  /// The destroy instant has passed. Destroy immediately.
  destroyNow,

  /// Destroy instant is within the "orange" window (default 24 hours).
  destroySoon,

  /// Destroy instant is within the "yellow" window (default 72 hours).
  approaching,

  /// Nothing to do yet.
  safe;

  /// Sort weight: the most urgent bucket first.
  int get rank => switch (this) {
        PriorityLevel.destroyNow => 0,
        PriorityLevel.expired => 1,
        PriorityLevel.destroySoon => 2,
        PriorityLevel.approaching => 3,
        PriorityLevel.safe => 4,
      };

  bool get isActionable =>
      this == PriorityLevel.destroyNow ||
      this == PriorityLevel.expired ||
      this == PriorityLevel.destroySoon;

  static PriorityLevel fromName(String? value) => switch (value) {
        'expired' => PriorityLevel.expired,
        'destroyNow' => PriorityLevel.destroyNow,
        'destroySoon' => PriorityLevel.destroySoon,
        'approaching' => PriorityLevel.approaching,
        _ => PriorityLevel.safe,
      };
}

/// Configurable widths of the yellow / orange bands.
class PriorityThresholds {
  const PriorityThresholds({
    this.destroySoonWindow = const Duration(hours: 24),
    this.approachingWindow = const Duration(days: 3),
  });

  /// Orange band: destroy instant is this close.
  final Duration destroySoonWindow;

  /// Yellow band: destroy instant is this close.
  final Duration approachingWindow;

  PriorityThresholds copyWith({Duration? destroySoonWindow, Duration? approachingWindow}) {
    return PriorityThresholds(
      destroySoonWindow: destroySoonWindow ?? this.destroySoonWindow,
      approachingWindow: approachingWindow ?? this.approachingWindow,
    );
  }

  @override
  String toString() =>
      'PriorityThresholds(orange=$destroySoonWindow, yellow=$approachingWindow)';
}
