import 'package:expiry_guardian/core/domain/expiry_precision.dart';

/// One configurable row of the company destruction handbook.
///
/// A rule matches when **either**
///   * [matchesHourlyExpiry] is set and the unit has an hourly expiry, **or**
///   * the unit's shelf life falls inside `[minShelfLife, maxShelfLife]`
///     with the inclusivity flags applied.
///
/// Nothing about the default handbook is compiled in: every field below is a
/// column in `policy_rules`, editable by a manager.
class PolicyRule {
  const PolicyRule({
    required this.id,
    required this.policyId,
    required this.sortOrder,
    required this.nameVi,
    required this.nameEn,
    required this.leadTime,
    this.minShelfLife,
    this.minInclusive = true,
    this.maxShelfLife,
    this.maxInclusive = false,
    this.matchesHourlyExpiry = false,
    this.isActive = true,
  });

  final String id;
  final String policyId;

  /// Rules are evaluated ascending; the first match wins.
  final int sortOrder;

  final String nameVi;
  final String nameEn;

  /// How long **before** the expiry instant the unit must be destroyed.
  final Duration leadTime;

  /// `null` means "no lower bound".
  final Duration? minShelfLife;
  final bool minInclusive;

  /// `null` means "no upper bound".
  final Duration? maxShelfLife;
  final bool maxInclusive;

  /// When true the rule also captures every hourly-expiry unit, whatever its
  /// shelf life. This is how "IF product has hourly expiry OR expiry <= 7 days"
  /// is expressed without hard-coding it.
  final bool matchesHourlyExpiry;

  final bool isActive;

  /// True when this rule has no bounds at all - i.e. it is a catch-all.
  bool get isCatchAll => minShelfLife == null && maxShelfLife == null && !matchesHourlyExpiry;

  bool matches({required Duration shelfLife, required ExpiryPrecision precision}) {
    if (!isActive) return false;
    if (matchesHourlyExpiry && precision.isHourly) return true;
    return containsShelfLife(shelfLife);
  }

  bool containsShelfLife(Duration shelfLife) {
    final Duration? min = minShelfLife;
    final Duration? max = maxShelfLife;
    if (min != null) {
      final bool ok = minInclusive ? shelfLife >= min : shelfLife > min;
      if (!ok) return false;
    }
    if (max != null) {
      final bool ok = maxInclusive ? shelfLife <= max : shelfLife < max;
      if (!ok) return false;
    }
    return true;
  }

  PolicyRule copyWith({
    String? id,
    String? policyId,
    int? sortOrder,
    String? nameVi,
    String? nameEn,
    Duration? leadTime,
    Duration? minShelfLife,
    bool clearMinShelfLife = false,
    bool? minInclusive,
    Duration? maxShelfLife,
    bool clearMaxShelfLife = false,
    bool? maxInclusive,
    bool? matchesHourlyExpiry,
    bool? isActive,
  }) {
    return PolicyRule(
      id: id ?? this.id,
      policyId: policyId ?? this.policyId,
      sortOrder: sortOrder ?? this.sortOrder,
      nameVi: nameVi ?? this.nameVi,
      nameEn: nameEn ?? this.nameEn,
      leadTime: leadTime ?? this.leadTime,
      minShelfLife: clearMinShelfLife ? null : (minShelfLife ?? this.minShelfLife),
      minInclusive: minInclusive ?? this.minInclusive,
      maxShelfLife: clearMaxShelfLife ? null : (maxShelfLife ?? this.maxShelfLife),
      maxInclusive: maxInclusive ?? this.maxInclusive,
      matchesHourlyExpiry: matchesHourlyExpiry ?? this.matchesHourlyExpiry,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  String toString() => 'PolicyRule($sortOrder, $nameEn, lead=$leadTime)';
}
