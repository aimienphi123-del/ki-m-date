/// Which span the policy engine measures to classify a product.
///
/// The rules in the company handbook ("products with a 3 year shelf life are
/// destroyed one month early") talk about the *designed* shelf life of the
/// product, not about how much time is left on the day it is scanned.
enum ShelfLifeBasis {
  /// expiry - manufacturing date. The true designed shelf life.
  manufacturingToExpiry,

  /// expiry - goods-receipt date. Used when the label carries no
  /// manufacturing date, which is common on imported goods.
  intakeToExpiry;

  static ShelfLifeBasis fromName(String? value) => switch (value) {
        'intakeToExpiry' => ShelfLifeBasis.intakeToExpiry,
        _ => ShelfLifeBasis.manufacturingToExpiry,
      };
}
