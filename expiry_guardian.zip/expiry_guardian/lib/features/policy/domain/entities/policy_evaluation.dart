import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';

/// Everything the engine needs about one unit of stock.
class PolicyInput {
  const PolicyInput({
    required this.expiry,
    required this.receivedAt,
    required this.precision,
    this.manufacturedAt,
  });

  /// The date (or date-time for hourly goods) printed on the label.
  final DateTime expiry;

  /// When the goods were booked into the store.
  final DateTime receivedAt;

  final ExpiryPrecision precision;

  /// Optional - many labels omit it.
  final DateTime? manufacturedAt;
}

/// The engine's verdict for one unit.
class PolicyDecision {
  const PolicyDecision({
    required this.expiryInstant,
    required this.destroyAt,
    required this.leadTime,
    required this.shelfLife,
    required this.basisUsed,
    required this.matchedRule,
    required this.usedFallbackLeadTime,
    required this.policyId,
    required this.policyVersion,
  });

  /// The exact instant the goods stop being sellable, after applying
  /// [DestroyPolicy.dateExpiryAtEndOfDay] to day-precision labels.
  final DateTime expiryInstant;

  /// The instant the unit must be pulled from the shelf and destroyed.
  final DateTime destroyAt;

  final Duration leadTime;
  final Duration shelfLife;
  final ShelfLifeBasis basisUsed;

  /// `null` when no rule matched and the policy fallback was applied.
  final PolicyRule? matchedRule;
  final bool usedFallbackLeadTime;

  final String policyId;
  final int policyVersion;

  @override
  String toString() =>
      'PolicyDecision(destroyAt=$destroyAt, lead=$leadTime, rule=${matchedRule?.nameEn ?? 'fallback'})';
}

/// Live urgency of one unit at a given instant.
class PriorityAssessment {
  const PriorityAssessment({
    required this.level,
    required this.timeUntilDestroy,
    required this.timeUntilExpiry,
  });

  final PriorityLevel level;

  /// Negative when the destroy instant has already passed.
  final Duration timeUntilDestroy;

  /// Negative when the goods have already expired.
  final Duration timeUntilExpiry;

  bool get isOverdue => timeUntilDestroy.isNegative;
  bool get isExpired => timeUntilExpiry.isNegative;

  @override
  String toString() => 'PriorityAssessment(${level.name}, in $timeUntilDestroy)';
}
