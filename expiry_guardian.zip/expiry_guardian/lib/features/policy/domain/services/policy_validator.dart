import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';

enum PolicyIssueSeverity { warning, error }

enum PolicyIssueCode {
  noActiveRules,
  negativeLeadTime,
  invertedRange,
  coverageGap,
  overlappingRules,
  noCatchAll,
  leadTimeExceedsShelfLife,
  duplicateSortOrder,
}

class PolicyIssue {
  const PolicyIssue({
    required this.code,
    required this.severity,
    this.ruleIds = const <String>[],
    this.detail = const <String, Object?>{},
  });

  final PolicyIssueCode code;
  final PolicyIssueSeverity severity;
  final List<String> ruleIds;
  final Map<String, Object?> detail;

  @override
  String toString() => 'PolicyIssue(${code.name}, ${severity.name}, $detail)';
}

/// Checks a policy the manager is editing before it is saved.
///
/// Catching a coverage gap here is what stops a whole shelf-life band from
/// silently falling through to the fallback lead time.
class PolicyValidator {
  const PolicyValidator();

  List<PolicyIssue> validate(DestroyPolicy policy) {
    final List<PolicyIssue> issues = <PolicyIssue>[];
    final List<PolicyRule> active = policy.activeRulesInOrder;

    if (active.isEmpty) {
      issues.add(const PolicyIssue(
        code: PolicyIssueCode.noActiveRules,
        severity: PolicyIssueSeverity.error,
      ),);
      return issues;
    }

    final Map<int, List<String>> byOrder = <int, List<String>>{};
    for (final PolicyRule rule in active) {
      byOrder.putIfAbsent(rule.sortOrder, () => <String>[]).add(rule.id);

      if (rule.leadTime.isNegative) {
        issues.add(PolicyIssue(
          code: PolicyIssueCode.negativeLeadTime,
          severity: PolicyIssueSeverity.error,
          ruleIds: <String>[rule.id],
        ),);
      }
      final Duration? min = rule.minShelfLife;
      final Duration? max = rule.maxShelfLife;
      if (min != null && max != null && min > max) {
        issues.add(PolicyIssue(
          code: PolicyIssueCode.invertedRange,
          severity: PolicyIssueSeverity.error,
          ruleIds: <String>[rule.id],
        ),);
      }
      if (max != null && rule.leadTime > max) {
        issues.add(PolicyIssue(
          code: PolicyIssueCode.leadTimeExceedsShelfLife,
          severity: PolicyIssueSeverity.warning,
          ruleIds: <String>[rule.id],
          detail: <String, Object?>{'leadMinutes': rule.leadTime.inMinutes, 'maxMinutes': max.inMinutes},
        ),);
      }
    }

    for (final MapEntry<int, List<String>> entry in byOrder.entries) {
      if (entry.value.length > 1) {
        issues.add(PolicyIssue(
          code: PolicyIssueCode.duplicateSortOrder,
          severity: PolicyIssueSeverity.warning,
          ruleIds: entry.value,
          detail: <String, Object?>{'sortOrder': entry.key},
        ),);
      }
    }

    issues.addAll(_coverageIssues(active));
    return issues;
  }

  /// Walks the shelf-life axis and reports the first uncovered band and any
  /// band claimed by two rules.
  List<PolicyIssue> _coverageIssues(List<PolicyRule> active) {
    final List<PolicyIssue> issues = <PolicyIssue>[];
    final bool hasUnbounded = active.any((PolicyRule r) => r.maxShelfLife == null);
    if (!hasUnbounded) {
      issues.add(const PolicyIssue(
        code: PolicyIssueCode.noCatchAll,
        severity: PolicyIssueSeverity.warning,
      ),);
    }

    // Probe every boundary +/- 1 minute plus a few representative points.
    final Set<int> probes = <int>{0, 1};
    for (final PolicyRule rule in active) {
      for (final Duration? bound in <Duration?>[rule.minShelfLife, rule.maxShelfLife]) {
        if (bound == null) continue;
        final int m = bound.inMinutes;
        probes.addAll(<int>[m - 1, m, m + 1]);
      }
    }
    probes.removeWhere((int m) => m < 0);

    final List<int> sorted = probes.toList()..sort();
    for (final int minutes in sorted) {
      final Duration probe = Duration(minutes: minutes);
      final List<PolicyRule> hits =
          active.where((PolicyRule r) => r.containsShelfLife(probe)).toList();
      if (hits.isEmpty) {
        issues.add(PolicyIssue(
          code: PolicyIssueCode.coverageGap,
          severity: PolicyIssueSeverity.warning,
          detail: <String, Object?>{'shelfLifeMinutes': minutes},
        ),);
        break;
      }
      if (hits.length > 1) {
        issues.add(PolicyIssue(
          code: PolicyIssueCode.overlappingRules,
          severity: PolicyIssueSeverity.warning,
          ruleIds: hits.map((PolicyRule r) => r.id).toList(),
          detail: <String, Object?>{'shelfLifeMinutes': minutes},
        ),);
        break;
      }
    }
    return issues;
  }
}
