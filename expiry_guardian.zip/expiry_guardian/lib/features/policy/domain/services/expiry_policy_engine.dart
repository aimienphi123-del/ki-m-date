import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';

/// Pure, side-effect-free implementation of the company destruction handbook.
///
/// No thresholds, windows or lead times are compiled in: every number comes
/// from the [DestroyPolicy] argument, which a manager edits at runtime.
abstract interface class ExpiryPolicyEngine {
  /// Computes the destroy instant for one unit of stock.
  PolicyDecision evaluate(DestroyPolicy policy, PolicyInput input);

  /// Computes the live urgency bucket of a unit at [now].
  PriorityAssessment assess({
    required DestroyPolicy policy,
    required DateTime now,
    required DateTime destroyAt,
    required DateTime expiryInstant,
  });

  /// Resolves the expiry *instant* from a possibly date-only label.
  DateTime resolveExpiryInstant(DestroyPolicy policy, DateTime expiry, ExpiryPrecision precision);

  /// The span the policy measures for classification.
  Duration shelfLifeOf(DestroyPolicy policy, PolicyInput input);
}

class DefaultExpiryPolicyEngine implements ExpiryPolicyEngine {
  const DefaultExpiryPolicyEngine();

  @override
  DateTime resolveExpiryInstant(DestroyPolicy policy, DateTime expiry, ExpiryPrecision precision) {
    if (precision.isHourly) return expiry;
    final DateTime midnight = DateTime(expiry.year, expiry.month, expiry.day);
    if (!policy.dateExpiryAtEndOfDay) return midnight;
    // Good "through" the printed day - the last sellable millisecond.
    return midnight
        .add(const Duration(days: 1))
        .subtract(const Duration(milliseconds: 1));
  }

  @override
  Duration shelfLifeOf(DestroyPolicy policy, PolicyInput input) {
    final DateTime expiryInstant = resolveExpiryInstant(policy, input.expiry, input.precision);
    final ShelfLifeBasis basis = _basisFor(policy, input);
    final DateTime start = switch (basis) {
      ShelfLifeBasis.manufacturingToExpiry => input.manufacturedAt ?? input.receivedAt,
      ShelfLifeBasis.intakeToExpiry => input.receivedAt,
    };
    final Duration span = expiryInstant.difference(start);
    return span.isNegative ? Duration.zero : span;
  }

  ShelfLifeBasis _basisFor(DestroyPolicy policy, PolicyInput input) {
    if (policy.basis == ShelfLifeBasis.manufacturingToExpiry && input.manufacturedAt == null) {
      return policy.fallbackToIntakeBasis
          ? ShelfLifeBasis.intakeToExpiry
          : ShelfLifeBasis.manufacturingToExpiry;
    }
    return policy.basis;
  }

  @override
  PolicyDecision evaluate(DestroyPolicy policy, PolicyInput input) {
    final DateTime expiryInstant = resolveExpiryInstant(policy, input.expiry, input.precision);
    final ShelfLifeBasis basis = _basisFor(policy, input);
    final Duration shelfLife = shelfLifeOf(policy, input);

    PolicyRule? matched;
    for (final PolicyRule rule in policy.activeRulesInOrder) {
      if (rule.matches(shelfLife: shelfLife, precision: input.precision)) {
        matched = rule;
        break;
      }
    }

    final Duration lead = matched?.leadTime ?? policy.fallbackLeadTime;
    DateTime destroyAt = expiryInstant.subtract(lead);

    // Optional stabilisation of the morning list for day-precision goods.
    final int? normalizeMinutes = policy.normalizeDestroyTimeMinutes;
    if (normalizeMinutes != null && !input.precision.isHourly) {
      final DateTime snapped = DateTime(
        destroyAt.year,
        destroyAt.month,
        destroyAt.day,
        normalizeMinutes ~/ 60,
        normalizeMinutes % 60,
      );
      // Never push a destroy instant later than the raw one - that would let
      // goods sit on the shelf past the handbook deadline.
      destroyAt = snapped.isAfter(destroyAt) ? snapped.subtract(const Duration(days: 1)) : snapped;
    }

    // A destroy instant can never be after the expiry instant.
    if (destroyAt.isAfter(expiryInstant)) destroyAt = expiryInstant;

    return PolicyDecision(
      expiryInstant: expiryInstant,
      destroyAt: destroyAt,
      leadTime: lead,
      shelfLife: shelfLife,
      basisUsed: basis,
      matchedRule: matched,
      usedFallbackLeadTime: matched == null,
      policyId: policy.id,
      policyVersion: policy.version,
    );
  }

  @override
  PriorityAssessment assess({
    required DestroyPolicy policy,
    required DateTime now,
    required DateTime destroyAt,
    required DateTime expiryInstant,
  }) {
    final Duration untilDestroy = destroyAt.difference(now);
    final Duration untilExpiry = expiryInstant.difference(now);

    final PriorityLevel level;
    if (!untilExpiry.isNegative && !untilDestroy.isNegative) {
      if (untilDestroy <= policy.thresholds.destroySoonWindow) {
        level = PriorityLevel.destroySoon;
      } else if (untilDestroy <= policy.thresholds.approachingWindow) {
        level = PriorityLevel.approaching;
      } else {
        level = PriorityLevel.safe;
      }
    } else if (untilExpiry.isNegative) {
      level = PriorityLevel.expired;
    } else {
      level = PriorityLevel.destroyNow;
    }

    return PriorityAssessment(
      level: level,
      timeUntilDestroy: untilDestroy,
      timeUntilExpiry: untilExpiry,
    );
  }
}
