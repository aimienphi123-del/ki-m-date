import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';

/// Builds the handbook the app ships with on first run.
///
/// These are **starting values only** - they are written into the database as
/// ordinary editable rows. Nothing in the engine, the UI or the reports reads
/// this class again after the first launch.
class DefaultPolicyFactory {
  const DefaultPolicyFactory(this._ids, this._clock);

  final IdGenerator _ids;
  final Clock _clock;

  static const Duration sevenDays = Duration(days: 7);
  static const Duration oneMonth = Duration(days: 30);
  static const Duration sixMonths = Duration(days: 180);
  static const Duration oneYear = Duration(days: 365);
  static const Duration threeYears = Duration(days: 1095);

  DestroyPolicy build({String? policyId, String name = 'Chính sách mặc định'}) {
    final String id = policyId ?? _ids.newId();
    final DateTime now = _clock.now();

    final List<PolicyRule> rules = <PolicyRule>[
      PolicyRule(
        id: _ids.newId(),
        policyId: id,
        sortOrder: 10,
        nameVi: 'Hàng theo giờ hoặc hạn dùng ≤ 7 ngày',
        nameEn: 'Hourly goods or shelf life ≤ 7 days',
        matchesHourlyExpiry: true,
        minShelfLife: Duration.zero,
        minInclusive: true,
        maxShelfLife: sevenDays,
        maxInclusive: true,
        leadTime: const Duration(hours: 2),
      ),
      PolicyRule(
        id: _ids.newId(),
        policyId: id,
        sortOrder: 20,
        nameVi: 'Hạn dùng trên 7 ngày và dưới 1 tháng',
        nameEn: 'Shelf life over 7 days and under 1 month',
        minShelfLife: sevenDays,
        minInclusive: false,
        maxShelfLife: oneMonth,
        maxInclusive: false,
        leadTime: const Duration(days: 1),
      ),
      PolicyRule(
        id: _ids.newId(),
        policyId: id,
        sortOrder: 30,
        nameVi: 'Hạn dùng từ 1 tháng đến dưới 6 tháng',
        nameEn: 'Shelf life from 1 month to under 6 months',
        minShelfLife: oneMonth,
        minInclusive: true,
        maxShelfLife: sixMonths,
        maxInclusive: false,
        leadTime: const Duration(days: 3),
      ),
      PolicyRule(
        id: _ids.newId(),
        policyId: id,
        sortOrder: 40,
        nameVi: 'Hạn dùng từ 6 tháng đến dưới 1 năm',
        nameEn: 'Shelf life from 6 months to under 1 year',
        minShelfLife: sixMonths,
        minInclusive: true,
        maxShelfLife: oneYear,
        maxInclusive: false,
        leadTime: const Duration(days: 5),
      ),
      PolicyRule(
        id: _ids.newId(),
        policyId: id,
        sortOrder: 50,
        nameVi: 'Hạn dùng từ 1 năm đến dưới 3 năm',
        nameEn: 'Shelf life from 1 year to under 3 years',
        minShelfLife: oneYear,
        minInclusive: true,
        maxShelfLife: threeYears,
        maxInclusive: false,
        leadTime: const Duration(days: 7),
      ),
      PolicyRule(
        id: _ids.newId(),
        policyId: id,
        sortOrder: 60,
        nameVi: 'Hạn dùng từ 3 năm trở lên',
        nameEn: 'Shelf life of 3 years or more',
        minShelfLife: threeYears,
        minInclusive: true,
        leadTime: const Duration(days: 30),
      ),
    ];

    return DestroyPolicy(
      id: id,
      name: name,
      rules: rules,
      createdAt: now,
      updatedAt: now,
      basis: ShelfLifeBasis.manufacturingToExpiry,
      fallbackToIntakeBasis: true,
      dateExpiryAtEndOfDay: true,
      fallbackLeadTime: const Duration(days: 1),
      thresholds: const PriorityThresholds(),
      notes: '',
    );
  }
}
