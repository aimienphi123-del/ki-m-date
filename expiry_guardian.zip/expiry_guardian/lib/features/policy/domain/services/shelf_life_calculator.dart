import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';

/// The units a stated shelf life can be written in.
///
/// Hours and days are exact spans. Months and years are *calendar* steps: one
/// month after 31 January is 28 February, not 3 March, and a destroy date that
/// jumped into the following month would be a bug an employee could not
/// explain to an auditor.
enum ShelfLifeUnit { hour, day, month, year }

/// Which end of the shelf life is known.
enum CalculatorAnchor {
  /// The printed expiry is known; work backwards to the production date.
  expiry,

  /// The production date is known; work forwards to the expiry.
  manufacturing,
}

/// What the employee typed in.
class ShelfLifeQuery {
  const ShelfLifeQuery.fromBothDates({
    required DateTime manufacturing,
    required DateTime expiry,
    this.hasTimeOfDay = false,
    this.isHourlyGoods = false,
  })  : anchor = CalculatorAnchor.expiry,
        manufacturingInput = manufacturing,
        expiryInput = expiry,
        statedValue = null,
        statedUnit = ShelfLifeUnit.day;

  /// Only the printed expiry is known - no production date, no stated shelf
  /// life. There is deliberately no destroy instant for this: see
  /// [ShelfLifeCalculator].
  const ShelfLifeQuery.expiryOnly({
    required DateTime expiry,
    this.hasTimeOfDay = false,
    this.isHourlyGoods = false,
  })  : anchor = CalculatorAnchor.expiry,
        manufacturingInput = null,
        expiryInput = expiry,
        statedValue = null,
        statedUnit = ShelfLifeUnit.day;

  /// One date plus the shelf life printed on the packaging.
  const ShelfLifeQuery.fromOneDateAndSpan({
    required this.anchor,
    required DateTime date,
    required double value,
    required ShelfLifeUnit unit,
    this.hasTimeOfDay = false,
    this.isHourlyGoods = false,
  })  : manufacturingInput = anchor == CalculatorAnchor.manufacturing ? date : null,
        expiryInput = anchor == CalculatorAnchor.expiry ? date : null,
        statedValue = value,
        statedUnit = unit;

  final CalculatorAnchor anchor;
  final DateTime? manufacturingInput;
  final DateTime? expiryInput;

  /// `null` in the both-dates mode, where the span is measured rather than
  /// stated.
  final double? statedValue;
  final ShelfLifeUnit statedUnit;

  /// Whether the times of day the employee entered mean anything. With this
  /// off the dates are treated as whole days, exactly as the policy treats a
  /// date-only label.
  final bool hasTimeOfDay;

  /// The SOP goods - steamed buns, sausages, anything counted in hours. These
  /// are destroyed a fixed time before the printed moment whatever their shelf
  /// life, which is what the hourly rule in the policy exists for.
  final bool isHourlyGoods;
}

/// The answer, with enough of the working shown that a manager can check it.
class ShelfLifeResult {
  const ShelfLifeResult({
    required this.manufacturing,
    required this.expiryInstant,
    required this.destroyAt,
    required this.leadTime,
    required this.shelfLifeForClassification,
    required this.matchedRule,
    required this.usedFallbackLeadTime,
    required this.isHourlyGoods,
    this.measuredShelfLife,
  });

  /// `null` when the employee has not given a production date and none could
  /// be derived - the calculator says so rather than inventing one.
  final DateTime? manufacturing;

  final DateTime expiryInstant;

  /// `null` when the shelf life is unknown, because a destroy instant cannot
  /// be worked out without it.
  final DateTime? destroyAt;
  final Duration? leadTime;

  /// The span the rule was chosen by. For a *stated* shelf life this is the
  /// nominal span ("1 month" is one month, even in February); for two measured
  /// dates it is the real elapsed span.
  final Duration? shelfLifeForClassification;

  /// The real elapsed span between the two dates, when both are known.
  final Duration? measuredShelfLife;

  final PolicyRule? matchedRule;
  final bool usedFallbackLeadTime;
  final bool isHourlyGoods;

  bool get isComplete => destroyAt != null;

  /// True when the answer carries a meaningful time of day, which is what
  /// decides whether the UI prints one.
  bool get hasMeaningfulTime =>
      leadTime != null && leadTime! < const Duration(days: 1);
}

/// Works out a destroy instant from whatever the employee actually knows.
///
/// This is the calculator behind the "destruction calculator" screen. It is
/// deliberately *not* a second copy of the handbook: every threshold and every
/// lead time is read out of the [DestroyPolicy] rows the manager edits, using
/// the same [PolicyRule.containsShelfLife] predicate the live engine uses, and
/// the same end-of-day convention for date-only labels. A manager who changes
/// a band sees the calculator change with it - two sets of numbers that could
/// drift apart is the one thing this must never become.
///
/// It differs from the live engine in exactly two deliberate ways:
///
///  * a clock time typed into the calculator does not make the goods hourly.
///    Only the SOP switch does. Otherwise entering "22:00" on a two-year tin
///    would quietly pull it into the 2-hour band.
///  * the morning-list normalisation (`normalizeDestroyTimeMinutes`) is not
///    applied. That setting stabilises the real worklist; a what-if answer
///    should show the raw handbook instant.
class ShelfLifeCalculator {
  const ShelfLifeCalculator();

  /// Nominal lengths used *only* to classify a stated shelf life.
  ///
  /// A packet that says "1 month" belongs in the one-month band whether it was
  /// made in February or in July. Measuring 28 real days and dropping it into
  /// the under-a-month band would apply the wrong rule to a product whose
  /// label is perfectly clear.
  static const double _daysPerMonth = 30.4167;
  static const double _daysPerYear = 365.25;

  ShelfLifeResult evaluate(DestroyPolicy policy, ShelfLifeQuery query) {
    final _Anchors anchors = _resolveAnchors(policy, query);

    final Duration? classifyBy = anchors.nominalShelfLife;
    final PolicyRule? rule = _ruleFor(
      policy,
      shelfLife: classifyBy,
      isHourlyGoods: query.isHourlyGoods,
    );

    // No shelf life and not hourly goods means there is nothing to classify
    // by. Saying so beats answering with the shortest band and sending stock
    // to the bin early, or the longest and leaving it on the shelf.
    if (rule == null && classifyBy == null && !query.isHourlyGoods) {
      return ShelfLifeResult(
        manufacturing: anchors.manufacturing,
        expiryInstant: anchors.expiryInstant,
        destroyAt: null,
        leadTime: null,
        shelfLifeForClassification: null,
        measuredShelfLife: anchors.measuredShelfLife,
        matchedRule: null,
        usedFallbackLeadTime: false,
        isHourlyGoods: query.isHourlyGoods,
      );
    }

    final Duration lead = rule?.leadTime ?? policy.fallbackLeadTime;
    DateTime destroyAt = anchors.expiryInstant.subtract(lead);
    // A destroy instant after the expiry would mean holding stock past the
    // handbook deadline, which the handbook can never intend.
    if (destroyAt.isAfter(anchors.expiryInstant)) destroyAt = anchors.expiryInstant;

    return ShelfLifeResult(
      manufacturing: anchors.manufacturing,
      expiryInstant: anchors.expiryInstant,
      destroyAt: destroyAt,
      leadTime: lead,
      shelfLifeForClassification: classifyBy,
      measuredShelfLife: anchors.measuredShelfLife,
      matchedRule: rule,
      usedFallbackLeadTime: rule == null,
      isHourlyGoods: query.isHourlyGoods,
    );
  }

  PolicyRule? _ruleFor(
    DestroyPolicy policy, {
    required Duration? shelfLife,
    required bool isHourlyGoods,
  }) {
    final List<PolicyRule> rules = policy.activeRulesInOrder;
    if (isHourlyGoods) {
      for (final PolicyRule rule in rules) {
        if (rule.matchesHourlyExpiry) return rule;
      }
      // A policy with no hourly rule falls through to the span, which is the
      // honest answer: the manager has not written a rule for these goods.
    }
    if (shelfLife == null) return null;
    for (final PolicyRule rule in rules) {
      if (rule.containsShelfLife(shelfLife)) return rule;
    }
    return null;
  }

  _Anchors _resolveAnchors(DestroyPolicy policy, ShelfLifeQuery query) {
    final double? stated = query.statedValue;

    // Both dates given: measure the span.
    if (stated == null) {
      final DateTime expiryInstant = _expiryInstantOf(policy, query);
      final DateTime? manufacturing = query.manufacturingInput;
      if (manufacturing == null) {
        return _Anchors(expiryInstant: expiryInstant, manufacturing: null);
      }
      final DateTime start = query.hasTimeOfDay
          ? manufacturing
          : DateTime(manufacturing.year, manufacturing.month, manufacturing.day);
      final Duration span = expiryInstant.difference(start);
      final Duration measured = span.isNegative ? Duration.zero : span;
      return _Anchors(
        expiryInstant: expiryInstant,
        manufacturing: start,
        measuredShelfLife: measured,
        nominalShelfLife: measured,
      );
    }

    // One date plus a stated span: derive the other end with calendar
    // arithmetic, and classify by the nominal span rather than by however
    // many days the calendar happened to supply.
    final Duration nominal = _nominalOf(stated, query.statedUnit);

    if (query.anchor == CalculatorAnchor.expiry) {
      final DateTime expiryInstant = _expiryInstantOf(policy, query);
      final DateTime printedExpiry = query.hasTimeOfDay
          ? query.expiryInput!
          : DateTime(
              query.expiryInput!.year,
              query.expiryInput!.month,
              query.expiryInput!.day,
            );
      final DateTime manufacturing =
          _shift(printedExpiry, -stated, query.statedUnit);
      return _Anchors(
        expiryInstant: expiryInstant,
        manufacturing: manufacturing,
        measuredShelfLife: expiryInstant.difference(manufacturing),
        nominalShelfLife: nominal,
      );
    }

    final DateTime manufacturing = query.hasTimeOfDay
        ? query.manufacturingInput!
        : DateTime(
            query.manufacturingInput!.year,
            query.manufacturingInput!.month,
            query.manufacturingInput!.day,
          );
    final DateTime derivedExpiry = _shift(manufacturing, stated, query.statedUnit);
    final DateTime expiryInstant = _resolveInstant(
      policy,
      derivedExpiry,
      hasTimeOfDay: query.hasTimeOfDay,
    );
    return _Anchors(
      expiryInstant: expiryInstant,
      manufacturing: manufacturing,
      measuredShelfLife: expiryInstant.difference(manufacturing),
      nominalShelfLife: nominal,
    );
  }

  DateTime _expiryInstantOf(DestroyPolicy policy, ShelfLifeQuery query) {
    return _resolveInstant(
      policy,
      query.expiryInput!,
      hasTimeOfDay: query.hasTimeOfDay,
    );
  }

  /// The same convention the live engine uses: a date-only label is good
  /// *through* the printed day, so the expiry instant is its last millisecond.
  DateTime _resolveInstant(
    DestroyPolicy policy,
    DateTime expiry, {
    required bool hasTimeOfDay,
  }) {
    if (hasTimeOfDay) return expiry;
    final DateTime midnight = DateTime(expiry.year, expiry.month, expiry.day);
    if (!policy.dateExpiryAtEndOfDay) return midnight;
    return midnight
        .add(const Duration(days: 1))
        .subtract(const Duration(milliseconds: 1));
  }

  Duration _nominalOf(double value, ShelfLifeUnit unit) {
    return switch (unit) {
      ShelfLifeUnit.hour => Duration(minutes: (value * 60).round()),
      ShelfLifeUnit.day => Duration(minutes: (value * 24 * 60).round()),
      ShelfLifeUnit.month =>
        Duration(minutes: (value * _daysPerMonth * 24 * 60).round()),
      ShelfLifeUnit.year =>
        Duration(minutes: (value * _daysPerYear * 24 * 60).round()),
    };
  }

  DateTime _shift(DateTime from, double value, ShelfLifeUnit unit) {
    return switch (unit) {
      ShelfLifeUnit.hour =>
        from.add(Duration(minutes: (value * 60).round())),
      ShelfLifeUnit.day =>
        from.add(Duration(minutes: (value * 24 * 60).round())),
      ShelfLifeUnit.month => shiftCalendarMonths(from, value),
      ShelfLifeUnit.year => shiftCalendarMonths(from, value * 12),
    };
  }

  /// Shifts by a possibly fractional number of calendar months.
  ///
  /// Rounding the span to whole months first made the derived date disagree
  /// with the span the employee typed: "0,5 tháng" landed a whole month out
  /// and "1,5 tháng" two. The whole months are calendar steps as before; the
  /// leftover fraction is measured against the month it actually falls in, so
  /// half a month from 1 January is half of January, not a fixed 15.2 days.
  static DateTime shiftCalendarMonths(DateTime from, double months) {
    final int whole = months.truncate();
    final double fraction = months - whole;
    final DateTime shifted = addCalendarMonths(from, whole);
    if (fraction == 0) return shifted;
    final DateTime neighbour = addCalendarMonths(shifted, fraction.isNegative ? -1 : 1);
    final int spanMinutes = neighbour.difference(shifted).inMinutes.abs();
    return shifted.add(Duration(minutes: (spanMinutes * fraction).round()));
  }

  /// Adds whole calendar months, clamping to the end of the target month.
  ///
  /// `DateTime(2026, 2, 31)` silently becomes 3 March in Dart, which would
  /// hand an employee a destroy date in the wrong month. 31 January plus one
  /// month is 28 February here.
  static DateTime addCalendarMonths(DateTime from, int months) {
    final int total = from.year * 12 + (from.month - 1) + months;
    final int year = (total / 12).floor();
    final int month = total - year * 12 + 1;
    // Day zero of the following month is the last day of this one.
    final int lastDay = DateTime(year, month + 1, 0).day;
    return DateTime(
      year,
      month,
      from.day < lastDay ? from.day : lastDay,
      from.hour,
      from.minute,
      from.second,
      from.millisecond,
    );
  }
}

class _Anchors {
  const _Anchors({
    required this.expiryInstant,
    required this.manufacturing,
    this.measuredShelfLife,
    this.nominalShelfLife,
  });

  final DateTime expiryInstant;
  final DateTime? manufacturing;
  final Duration? measuredShelfLife;
  final Duration? nominalShelfLife;
}
