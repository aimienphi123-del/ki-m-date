import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_actions.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/policy/domain/entities/shelf_life_basis.dart';
import 'package:expiry_guardian/features/policy/domain/services/policy_validator.dart';
import 'package:expiry_guardian/features/policy/presentation/pages/rule_editor_page.dart';
import 'package:expiry_guardian/features/policy/presentation/viewmodels/policy_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:expiry_guardian/shared/widgets/duration_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The manager's control panel for the destruction handbook.
class PolicyPage extends ConsumerWidget {
  const PolicyPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<DestroyPolicy> policy = ref.watch(activePolicyProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.policyTitle))),
      body: policy.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
        data: (DestroyPolicy value) => _PolicyBody(policy: value),
      ),
      floatingActionButton: policy.valueOrNull == null
          ? null
          : FloatingActionButton.extended(
              onPressed: () => RuleEditorPage.open(context, policy: policy.value!),
              icon: const Icon(Icons.add),
              label: Text(l10n.t(K.policyNewRule)),
            ),
    );
  }
}

class _PolicyBody extends ConsumerWidget {
  const _PolicyBody({required this.policy});

  final DestroyPolicy policy;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final List<PolicyIssue> issues = ref.watch(policyIssuesProvider);
    final PolicyEditor editor = ref.read(policyEditorProvider);

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gapXl * 4,
      ),
      children: <Widget>[
        NoticeBanner(icon: Icons.tune, message: l10n.t(K.policySubtitle)),
        const SizedBox(height: Dimens.gapM),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                policy.name,
                style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
              ),
              Text(
                l10n.t(K.policyVersion, <String, Object?>{'version': policy.version}),
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
        if (issues.isNotEmpty) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            tone: issues.any((PolicyIssue i) => i.severity == PolicyIssueSeverity.error)
                ? NoticeTone.danger
                : NoticeTone.warning,
            icon: Icons.rule,
            message: l10n.t(K.policyIssuesFound, <String, Object?>{'count': issues.length}),
          ),
          for (final PolicyIssue issue in issues)
            Padding(
              padding: const EdgeInsets.only(top: Dimens.gapXs),
              child: Text(
                '· ${l10n.t(describePolicyIssue(issue), <String, Object?>{
                      'days': ((issue.detail['shelfLifeMinutes'] as int?) ?? 0) ~/ 1440,
                    })}',
                style: theme.textTheme.bodySmall,
              ),
            ),
        ] else ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(icon: Icons.verified_outlined, message: l10n.t(K.policyNoIssues)),
        ],
        SectionHeader(title: l10n.t(K.policyRules)),
        for (final PolicyRule rule in policy.allRulesInOrder)
          Padding(
            padding: const EdgeInsets.only(bottom: Dimens.gapS),
            child: _RuleCard(policy: policy, rule: rule),
          ),
        SectionHeader(title: l10n.t(K.policyBasis)),
        AppCard(
          child: Column(
            children: <Widget>[
              RadioGroup<ShelfLifeBasis>(
                groupValue: policy.basis,
                onChanged: (ShelfLifeBasis? value) {
                  if (value != null) editor.save(policy.copyWith(basis: value));
                },
                child: Column(
                  children: <Widget>[
                    RadioListTile<ShelfLifeBasis>(
                      contentPadding: EdgeInsets.zero,
                      value: ShelfLifeBasis.manufacturingToExpiry,
                      title: Text(l10n.t(K.policyBasisManufacturing)),
                    ),
                    RadioListTile<ShelfLifeBasis>(
                      contentPadding: EdgeInsets.zero,
                      value: ShelfLifeBasis.intakeToExpiry,
                      title: Text(l10n.t(K.policyBasisIntake)),
                    ),
                  ],
                ),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: policy.fallbackToIntakeBasis,
                title: Text(l10n.t(K.policyFallbackBasis)),
                onChanged: (bool value) =>
                    editor.save(policy.copyWith(fallbackToIntakeBasis: value)),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: policy.dateExpiryAtEndOfDay,
                title: Text(l10n.t(K.policyEndOfDay)),
                onChanged: (bool value) =>
                    editor.save(policy.copyWith(dateExpiryAtEndOfDay: value)),
              ),
            ],
          ),
        ),
        SectionHeader(title: l10n.t(K.policyThresholds)),
        AppCard(
          child: Column(
            children: <Widget>[
              DurationField(
                label: l10n.t(K.policyOrangeWindow),
                value: policy.thresholds.destroySoonWindow,
                onChanged: (Duration? value) => editor.save(
                  policy.copyWith(
                    thresholds:
                        policy.thresholds.copyWith(destroySoonWindow: value ?? Duration.zero),
                  ),
                ),
              ),
              const SizedBox(height: Dimens.gapM),
              DurationField(
                label: l10n.t(K.policyYellowWindow),
                value: policy.thresholds.approachingWindow,
                onChanged: (Duration? value) => editor.save(
                  policy.copyWith(
                    thresholds:
                        policy.thresholds.copyWith(approachingWindow: value ?? Duration.zero),
                  ),
                ),
              ),
              const SizedBox(height: Dimens.gapM),
              DurationField(
                label: l10n.t(K.policyFallbackLead),
                value: policy.fallbackLeadTime,
                onChanged: (Duration? value) =>
                    editor.save(policy.copyWith(fallbackLeadTime: value ?? Duration.zero)),
              ),
              const SizedBox(height: Dimens.gapM),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: policy.normalizeDestroyTimeMinutes != null,
                title: Text(l10n.t(K.policyNormalizeTime)),
                subtitle: Text(l10n.t(K.policyNormalizeTimeHint)),
                onChanged: (bool value) => editor.save(
                  policy.copyWith(
                    normalizeDestroyTimeMinutes: value ? 7 * 60 : null,
                    clearNormalizeDestroyTime: !value,
                  ),
                ),
              ),
              if (policy.normalizeDestroyTimeMinutes != null)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.policyNormalizeTime)),
                  trailing: Text(_formatMinutes(policy.normalizeDestroyTimeMinutes!)),
                  onTap: () async {
                    final TimeOfDay? picked = await showTimePicker(
                      context: context,
                      initialTime: TimeOfDay(
                        hour: policy.normalizeDestroyTimeMinutes! ~/ 60,
                        minute: policy.normalizeDestroyTimeMinutes! % 60,
                      ),
                    );
                    if (picked == null) return;
                    await editor.save(
                      policy.copyWith(
                        normalizeDestroyTimeMinutes: picked.hour * 60 + picked.minute,
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
        SectionHeader(
          title: l10n.t(K.policyPreview),
          subtitle: l10n.t(K.policyPreviewHint),
        ),
        _PolicyPreview(policy: policy),
        const SizedBox(height: Dimens.gapL),
        FilledButton.tonalIcon(
          onPressed: () async {
            final Result<int> result =
                await ref.read(inventoryActionsProvider).recalculateAfterPolicyChange();
            if (!context.mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  result.isOk
                      ? l10n.t(K.policyRecalculated,
                          <String, Object?>{'count': result.unwrap()},)
                      : l10n.t(K.errorGeneric),
                ),
              ),
            );
          },
          icon: const Icon(Icons.sync),
          label: Text(l10n.t(K.policyRecalculate)),
        ),
      ],
    );
  }

  String _formatMinutes(int minutes) =>
      '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';
}

class _RuleCard extends ConsumerWidget {
  const _RuleCard({required this.policy, required this.rule});

  final DestroyPolicy policy;
  final PolicyRule rule;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final PolicyEditor editor = ref.read(policyEditorProvider);

    final String range = <String>[
      if (rule.minShelfLife != null)
        '${rule.minInclusive ? '≥' : '>'} ${l10n.shelfLife(rule.minShelfLife!)}',
      if (rule.maxShelfLife != null)
        '${rule.maxInclusive ? '≤' : '<'} ${l10n.shelfLife(rule.maxShelfLife!)}',
      if (rule.minShelfLife == null && rule.maxShelfLife == null) l10n.t(K.commonAll),
    ].join('  ·  ');

    return AppCard(
      onTap: () => RuleEditorPage.open(context, policy: policy, rule: rule),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  l10n.isVietnamese ? rule.nameVi : rule.nameEn,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    decoration: rule.isActive ? null : TextDecoration.lineThrough,
                  ),
                ),
              ),
              Switch(
                value: rule.isActive,
                onChanged: (bool value) =>
                    editor.upsertRule(policy.id, rule.copyWith(isActive: value)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(range, style: theme.textTheme.bodySmall),
          if (rule.matchesHourlyExpiry)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                l10n.t(K.policyMatchesHourly),
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.primary),
              ),
            ),
          const SizedBox(height: Dimens.gapS),
          Row(
            children: <Widget>[
              Icon(Icons.timer_outlined, size: 16, color: theme.colorScheme.primary),
              const SizedBox(width: 4),
              Text(
                '${l10n.t(K.policyLeadTime)}: ${l10n.duration(rule.leadTime)}',
                style: theme.textTheme.bodyMedium
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PolicyPreview extends ConsumerStatefulWidget {
  const _PolicyPreview({required this.policy});

  final DestroyPolicy policy;

  @override
  ConsumerState<_PolicyPreview> createState() => _PolicyPreviewState();
}

class _PolicyPreviewState extends ConsumerState<_PolicyPreview> {
  DateTime? _manufactured;
  DateTime? _expiry;
  ExpiryPrecision _precision = ExpiryPrecision.day;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final DateTime now = ref.read(clockProvider).now();
    final DateTime expiry = _expiry ?? now.add(const Duration(days: 90));

    final PolicyDecision decision = ref.read(policyEditorProvider).preview(
          policy: widget.policy,
          expiry: expiry,
          manufactured: _manufactured,
          precision: _precision,
        );

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(l10n.t(K.recordManufacturedAt)),
            subtitle: Text(
              _manufactured == null ? l10n.t(K.commonNotSet) : l10n.date(_manufactured!),
            ),
            trailing: const Icon(Icons.event),
            onTap: () async {
              final DateTime? picked = await showDatePicker(
                context: context,
                initialDate: _manufactured ?? now,
                firstDate: DateTime(now.year - 5),
                lastDate: DateTime(now.year + 15),
              );
              if (picked != null) setState(() => _manufactured = picked);
            },
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(l10n.t(K.recordExpiryAt)),
            subtitle: Text(l10n.date(expiry)),
            trailing: const Icon(Icons.event),
            onTap: () async {
              final DateTime? picked = await showDatePicker(
                context: context,
                initialDate: expiry,
                firstDate: DateTime(now.year - 5),
                lastDate: DateTime(now.year + 15),
              );
              if (picked != null) setState(() => _expiry = picked);
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _precision.isHourly,
            title: Text(l10n.t(K.recordHourly)),
            onChanged: (bool value) => setState(
              () => _precision = value ? ExpiryPrecision.hour : ExpiryPrecision.day,
            ),
          ),
          const Divider(),
          Text(
            l10n.t(K.policyPreviewResult, <String, Object?>{
              'rule': decision.matchedRule == null
                  ? l10n.t(K.recordFallbackRule)
                  : (l10n.isVietnamese
                      ? decision.matchedRule!.nameVi
                      : decision.matchedRule!.nameEn),
              'destroyAt': l10n.dateTime(decision.destroyAt),
            }),
            style: Theme.of(context).textTheme.bodyLarge
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: Dimens.gapXs),
          Text(
            '${l10n.t(K.recordShelfLife)}: ${l10n.shelfLife(decision.shelfLife)} · '
            '${l10n.t(K.recordLeadTime)}: ${l10n.duration(decision.leadTime)}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: Dimens.gapS),
          Wrap(
            spacing: Dimens.gapS,
            runSpacing: Dimens.gapS,
            children: PriorityLevel.values
                .map((PriorityLevel level) => PriorityBadge(level: level, compact: true))
                .toList(growable: false),
          ),
        ],
      ),
    );
  }
}
