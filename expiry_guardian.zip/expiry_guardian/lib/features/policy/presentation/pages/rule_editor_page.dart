import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/presentation/viewmodels/policy_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:expiry_guardian/shared/widgets/duration_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Add or change one rule of the handbook. Every boundary, its inclusivity and
/// the lead time are editable - none of it is compiled into the app.
class RuleEditorPage extends ConsumerStatefulWidget {
  const RuleEditorPage({required this.policy, this.rule, super.key});

  final DestroyPolicy policy;
  final PolicyRule? rule;

  static Future<void> open(
    BuildContext context, {
    required DestroyPolicy policy,
    PolicyRule? rule,
  }) {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => RuleEditorPage(policy: policy, rule: rule),
        fullscreenDialog: rule == null,
      ),
    );
  }

  @override
  ConsumerState<RuleEditorPage> createState() => _RuleEditorPageState();
}

class _RuleEditorPageState extends ConsumerState<RuleEditorPage> {
  late final TextEditingController _nameVi =
      TextEditingController(text: widget.rule?.nameVi ?? '');
  late final TextEditingController _nameEn =
      TextEditingController(text: widget.rule?.nameEn ?? '');
  late final TextEditingController _sortOrder = TextEditingController(
    text: (widget.rule?.sortOrder ?? _nextSortOrder()).toString(),
  );

  late Duration? _min = widget.rule?.minShelfLife;
  late Duration? _max = widget.rule?.maxShelfLife;
  late bool _minInclusive = widget.rule?.minInclusive ?? true;
  late bool _maxInclusive = widget.rule?.maxInclusive ?? false;
  late bool _hasMin = widget.rule?.minShelfLife != null;
  late bool _hasMax = widget.rule?.maxShelfLife != null;
  late Duration _lead = widget.rule?.leadTime ?? const Duration(days: 1);
  late bool _matchesHourly = widget.rule?.matchesHourlyExpiry ?? false;
  late bool _isActive = widget.rule?.isActive ?? true;

  bool _busy = false;
  String? _error;

  int _nextSortOrder() {
    final List<PolicyRule> rules = widget.policy.allRulesInOrder;
    return rules.isEmpty ? 10 : rules.last.sortOrder + 10;
  }

  @override
  void dispose() {
    _nameVi.dispose();
    _nameEn.dispose();
    _sortOrder.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final AppLocalizations l10n = context.l10n;
    if (_nameVi.text.trim().isEmpty && _nameEn.text.trim().isEmpty) {
      setState(() => _error = l10n.t(K.errorNameRequired));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });

    final PolicyRule rule = PolicyRule(
      id: widget.rule?.id ?? ref.read(policyEditorProvider).newRuleId(),
      policyId: widget.policy.id,
      sortOrder: int.tryParse(_sortOrder.text.trim()) ?? _nextSortOrder(),
      nameVi: _nameVi.text.trim().isEmpty ? _nameEn.text.trim() : _nameVi.text.trim(),
      nameEn: _nameEn.text.trim().isEmpty ? _nameVi.text.trim() : _nameEn.text.trim(),
      leadTime: _lead,
      minShelfLife: _hasMin ? _min : null,
      minInclusive: _minInclusive,
      maxShelfLife: _hasMax ? _max : null,
      maxInclusive: _maxInclusive,
      matchesHourlyExpiry: _matchesHourly,
      isActive: _isActive,
    );

    final Result<DestroyPolicy> result =
        await ref.read(policyEditorProvider).upsertRule(widget.policy.id, rule);

    if (!mounted) return;
    final Failure? failure = result.failureOrNull;
    if (failure != null) {
      setState(() {
        _busy = false;
        _error = describeFailure(context, failure);
      });
      return;
    }
    Navigator.of(context).pop();
  }

  Future<void> _delete() async {
    final PolicyRule? rule = widget.rule;
    if (rule == null) return;
    setState(() => _busy = true);
    await ref.read(policyEditorProvider).deleteRule(widget.policy.id, rule.id);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.rule == null ? l10n.t(K.policyNewRule) : l10n.t(K.policyEditRule)),
        actions: <Widget>[
          if (widget.rule != null)
            IconButton(
              onPressed: _busy ? null : _delete,
              icon: const Icon(Icons.delete_outline),
              tooltip: l10n.t(K.commonDelete),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(Dimens.gutter),
        children: <Widget>[
          TextField(
            controller: _nameVi,
            decoration: InputDecoration(labelText: '${l10n.t(K.policyRuleName)} (VI)'),
          ),
          const SizedBox(height: Dimens.gapM),
          TextField(
            controller: _nameEn,
            decoration: InputDecoration(labelText: '${l10n.t(K.policyRuleName)} (EN)'),
          ),
          SectionHeader(title: l10n.t(K.recordShelfLife)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _hasMin,
            title: Text(l10n.t(K.policyShelfLifeFrom)),
            subtitle: Text(_hasMin ? '' : l10n.t(K.policyNoLowerBound)),
            onChanged: (bool value) => setState(() => _hasMin = value),
          ),
          if (_hasMin) ...<Widget>[
            DurationField(
              label: l10n.t(K.policyShelfLifeFrom),
              value: _min ?? Duration.zero,
              onChanged: (Duration? value) => _min = value,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _minInclusive,
              title: Text(_minInclusive
                  ? l10n.t(K.policyInclusive)
                  : l10n.t(K.policyExclusive),),
              onChanged: (bool value) => setState(() => _minInclusive = value),
            ),
          ],
          const Divider(),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _hasMax,
            title: Text(l10n.t(K.policyShelfLifeTo)),
            subtitle: Text(_hasMax ? '' : l10n.t(K.policyNoUpperBound)),
            onChanged: (bool value) => setState(() => _hasMax = value),
          ),
          if (_hasMax) ...<Widget>[
            DurationField(
              label: l10n.t(K.policyShelfLifeTo),
              value: _max ?? const Duration(days: 30),
              onChanged: (Duration? value) => _max = value,
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _maxInclusive,
              title: Text(_maxInclusive
                  ? l10n.t(K.policyInclusive)
                  : l10n.t(K.policyExclusive),),
              onChanged: (bool value) => setState(() => _maxInclusive = value),
            ),
          ],
          SectionHeader(title: l10n.t(K.policyLeadTime)),
          DurationField(
            label: l10n.t(K.policyLeadTime),
            value: _lead,
            onChanged: (Duration? value) => _lead = value ?? Duration.zero,
          ),
          const SizedBox(height: Dimens.gapM),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _matchesHourly,
            title: Text(l10n.t(K.policyMatchesHourly)),
            onChanged: (bool value) => setState(() => _matchesHourly = value),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _isActive,
            title: Text(l10n.t(K.policyRuleActive)),
            onChanged: (bool value) => setState(() => _isActive = value),
          ),
          const SizedBox(height: Dimens.gapM),
          TextField(
            controller: _sortOrder,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: l10n.t(K.inventorySort)),
          ),
          if (_error != null) ...<Widget>[
            const SizedBox(height: Dimens.gapM),
            NoticeBanner(
              tone: NoticeTone.danger,
              icon: Icons.error_outline,
              message: _error!,
            ),
          ],
          const SizedBox(height: Dimens.gapL),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: _busy
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2.5),
                  )
                : const Icon(Icons.check),
            label: Text(l10n.t(K.commonSave)),
          ),
        ],
      ),
    );
  }
}
