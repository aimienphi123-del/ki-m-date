import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/services/shelf_life_calculator.dart';
import 'package:expiry_guardian/features/scan/presentation/viewmodels/scan_flow_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

/// The destruction calculator: two dates in, one deadline out.
///
/// Every employee already does this arithmetic in their head or on a phone
/// calculator several times a shift, and getting it wrong either bins saleable
/// stock or leaves expired stock on the shelf. The numbers come from the
/// active [DestroyPolicy], so this screen and the schedule the app actually
/// enforces can never give two different answers.
/// What the calculator hands back when it is used to fill in an expiry.
class CalculatorPick {
  const CalculatorPick({
    required this.expiry,
    required this.hasTimeOfDay,
    this.manufacturing,
  });

  /// The expiry as it would be printed on the pack - a plain date unless the
  /// employee asked for a time of day. Deliberately not the policy's expiry
  /// *instant*: a record stores what the label says and lets the engine derive
  /// the instant from the precision, so handing back the end-of-day instant
  /// here would store a different thing than the label shows.
  final DateTime expiry;

  /// `null` when only the printed expiry was entered.
  final DateTime? manufacturing;

  final bool hasTimeOfDay;
}

class DisposalCalculatorPage extends ConsumerStatefulWidget {
  const DisposalCalculatorPage({
    this.pickMode = false,
    this.initialExpiry,
    this.initialManufacturing,
    super.key,
  });

  /// Opened to answer "what expiry should this lot have?" rather than to
  /// browse. The screen then confirms with a result instead of writing
  /// straight into the goods-in draft.
  final bool pickMode;

  final DateTime? initialExpiry;
  final DateTime? initialManufacturing;

  static Future<void> open(BuildContext context) {
    return Navigator.of(context).push<void>(
      MaterialPageRoute<void>(builder: (_) => const DisposalCalculatorPage()),
    );
  }

  /// Opens the calculator as the way to enter an expiry, and returns what the
  /// employee settled on.
  static Future<CalculatorPick?> pick(
    BuildContext context, {
    DateTime? expiry,
    DateTime? manufacturing,
  }) {
    return Navigator.of(context).push<CalculatorPick>(
      MaterialPageRoute<CalculatorPick>(
        builder: (_) => DisposalCalculatorPage(
          pickMode: true,
          initialExpiry: expiry,
          initialManufacturing: manufacturing,
        ),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  ConsumerState<DisposalCalculatorPage> createState() =>
      _DisposalCalculatorPageState();
}

/// How the employee is telling the app about the dates.
///
/// [printedExpiry] is the ordinary case and the reason the calculator can
/// replace a bare date picker outright: most packs print the expiry, and that
/// mode is exactly "pick a date" with the destroy deadline shown underneath.
enum _Mode { printedExpiry, bothDates, oneDateAndSpan }

class _DisposalCalculatorPageState
    extends ConsumerState<DisposalCalculatorPage> {
  _Mode _mode = _Mode.bothDates;
  bool _useTime = false;
  bool _isSop = false;

  late DateTime _manufacturing;
  late DateTime _expiry;
  TimeOfDay _manufacturingTime = const TimeOfDay(hour: 6, minute: 0);
  TimeOfDay _expiryTime = const TimeOfDay(hour: 22, minute: 0);

  CalculatorAnchor _anchor = CalculatorAnchor.expiry;
  ShelfLifeUnit _unit = ShelfLifeUnit.day;
  final TextEditingController _span = TextEditingController(text: '20');

  @override
  void initState() {
    super.initState();
    final DateTime today = ref.read(clockProvider).now();
    final DateTime? seedExpiry = widget.initialExpiry;
    final DateTime? seedMade = widget.initialManufacturing;

    _expiry = seedExpiry == null
        ? DateTime(today.year, today.month, today.day)
        : DateTime(seedExpiry.year, seedExpiry.month, seedExpiry.day);
    _manufacturing = seedMade == null
        ? _expiry.subtract(const Duration(days: 20))
        : DateTime(seedMade.year, seedMade.month, seedMade.day);

    if (seedExpiry != null &&
        (seedExpiry.hour != 0 || seedExpiry.minute != 0)) {
      _useTime = true;
      _expiryTime = TimeOfDay(hour: seedExpiry.hour, minute: seedExpiry.minute);
    }
    if (seedMade != null) _mode = _Mode.bothDates;
    if (widget.pickMode && seedMade == null) _mode = _Mode.printedExpiry;
  }

  @override
  void dispose() {
    _span.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------------ input

  DateTime get _manufacturingInstant => _useTime
      ? DateTime(
          _manufacturing.year,
          _manufacturing.month,
          _manufacturing.day,
          _manufacturingTime.hour,
          _manufacturingTime.minute,
        )
      : _manufacturing;

  DateTime get _expiryInstant => _useTime
      ? DateTime(
          _expiry.year,
          _expiry.month,
          _expiry.day,
          _expiryTime.hour,
          _expiryTime.minute,
        )
      : _expiry;

  double get _spanValue => double.tryParse(_span.text.trim().replaceAll(',', '.')) ?? 0;

  ShelfLifeQuery _buildQuery() {
    if (_mode == _Mode.printedExpiry) {
      return ShelfLifeQuery.expiryOnly(
        expiry: _expiryInstant,
        hasTimeOfDay: _useTime,
        isHourlyGoods: _isSop,
      );
    }
    if (_mode == _Mode.bothDates) {
      return ShelfLifeQuery.fromBothDates(
        manufacturing: _manufacturingInstant,
        expiry: _expiryInstant,
        hasTimeOfDay: _useTime,
        isHourlyGoods: _isSop,
      );
    }
    return ShelfLifeQuery.fromOneDateAndSpan(
      anchor: _anchor,
      date: _anchor == CalculatorAnchor.expiry
          ? _expiryInstant
          : _manufacturingInstant,
      value: _spanValue,
      unit: _unit,
      hasTimeOfDay: _useTime,
      isHourlyGoods: _isSop,
    );
  }

  /// The POS-style keys add to whatever is already there, which is how a shop
  /// assistant reaches "27" without hunting across a numeric keyboard.
  void _addToSpan(int amount) {
    final double next = _spanValue + amount;
    setState(() {
      _span.text = next == next.roundToDouble()
          ? next.round().toString()
          : next.toString();
    });
    HapticFeedback.selectionClick();
  }

  Future<void> _pickDate({required bool manufacturing}) async {
    final DateTime current = manufacturing ? _manufacturing : _expiry;
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: current,
      firstDate: DateTime(current.year - 10),
      lastDate: DateTime(current.year + 10),
    );
    if (picked == null) return;
    setState(() {
      if (manufacturing) {
        _manufacturing = DateTime(picked.year, picked.month, picked.day);
      } else {
        _expiry = DateTime(picked.year, picked.month, picked.day);
      }
    });
  }

  Future<void> _pickTime({required bool manufacturing}) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: manufacturing ? _manufacturingTime : _expiryTime,
    );
    if (picked == null) return;
    setState(() {
      if (manufacturing) {
        _manufacturingTime = picked;
      } else {
        _expiryTime = picked;
      }
    });
  }

  // ----------------------------------------------------------------- output

  /// The expiry to hand back: the date the employee entered, or the one the
  /// calculator derived from a production date plus a shelf life.
  DateTime _pickedExpiry(ShelfLifeResult result) {
    final bool derived = _mode == _Mode.oneDateAndSpan &&
        _anchor == CalculatorAnchor.manufacturing;
    if (!derived) return _expiryInstant;
    final DateTime instant = result.expiryInstant;
    // With no time of day the instant is the last millisecond of the printed
    // day; the label just says the day.
    return _useTime
        ? instant
        : DateTime(instant.year, instant.month, instant.day);
  }

  void _confirmPick(ShelfLifeResult result) {
    Navigator.of(context).pop(CalculatorPick(
      expiry: _pickedExpiry(result),
      manufacturing: _mode == _Mode.printedExpiry ? null : result.manufacturing,
      hasTimeOfDay: _useTime,
    ),);
  }

  Future<void> _applyToIntake(ShelfLifeResult result) async {
    final AppLocalizations l10n = context.l10n;
    final ScanFlowController flow = ref.read(scanFlowProvider.notifier);
    flow.setExpiry(result.expiryInstant);
    final DateTime? made = result.manufacturing;
    if (made != null) flow.setManufactured(made);
    if (!mounted) return;
    showAppSnack(context, l10n.t(K.calcAppliedToIntake));
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<DestroyPolicy> policy = ref.watch(activePolicyProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(widget.pickMode ? K.calcPickTitle : K.calcTitle)),
      ),
      body: policy.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
        data: (DestroyPolicy value) => _body(context, value),
      ),
    );
  }

  Widget _body(BuildContext context, DestroyPolicy policy) {
    final AppLocalizations l10n = context.l10n;
    final ShelfLifeResult result =
        const ShelfLifeCalculator().evaluate(policy, _buildQuery());

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gapXl * 2,
      ),
      children: <Widget>[
        Text(
          l10n.t(widget.pickMode ? K.calcPickSubtitle : K.calcSubtitle),
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
        ),
        const SizedBox(height: Dimens.gapM),
        SegmentedButton<_Mode>(
          direction: Axis.vertical,
          segments: <ButtonSegment<_Mode>>[
            ButtonSegment<_Mode>(
              value: _Mode.printedExpiry,
              label: Text(l10n.t(K.calcModePrinted), textAlign: TextAlign.center),
            ),
            ButtonSegment<_Mode>(
              value: _Mode.bothDates,
              label: Text(l10n.t(K.calcModeBoth), textAlign: TextAlign.center),
            ),
            ButtonSegment<_Mode>(
              value: _Mode.oneDateAndSpan,
              label: Text(l10n.t(K.calcModeSpan), textAlign: TextAlign.center),
            ),
          ],
          selected: <_Mode>{_mode},
          showSelectedIcon: false,
          onSelectionChanged: (Set<_Mode> next) =>
              setState(() => _mode = next.first),
        ),
        const SizedBox(height: Dimens.gapM),
        AppCard(
          child: Column(
            children: <Widget>[
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l10n.t(K.calcUseTime)),
                subtitle: Text(l10n.t(K.calcUseTimeHint)),
                value: _useTime,
                onChanged: (bool v) => setState(() => _useTime = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l10n.t(K.calcSop)),
                subtitle: Text(l10n.t(K.calcSopHint)),
                value: _isSop,
                onChanged: (bool v) => setState(() => _isSop = v),
              ),
            ],
          ),
        ),
        const SizedBox(height: Dimens.gapM),
        switch (_mode) {
          _Mode.printedExpiry => _printedExpiryCard(context),
          _Mode.bothDates => _bothDatesCard(context),
          _Mode.oneDateAndSpan => _spanCard(context),
        },
        const SizedBox(height: Dimens.gapM),
        if (widget.pickMode)
          _pickResultCard(context, result)
        else
          _resultCard(context, result),
        const SizedBox(height: Dimens.gapM),
        if (widget.pickMode)
          FilledButton.icon(
            onPressed: () => _confirmPick(result),
            icon: const Icon(Icons.check),
            label: Text(l10n.t(K.calcPickConfirm)),
          )
        else if (result.isComplete)
          OutlinedButton.icon(
            onPressed: () => _applyToIntake(result),
            icon: const Icon(Icons.inventory_2_outlined),
            label: Text(l10n.t(K.calcApplyToIntake)),
          ),
        const SizedBox(height: Dimens.gapS),
        Text(
          l10n.t(K.calcPolicyNote),
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
        ),
      ],
    );
  }

  Widget _printedExpiryCard(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return AppCard(
      child: _dateRow(
        context,
        label: l10n.t(K.calcHsd),
        date: _expiry,
        time: _expiryTime,
        onDate: () => _pickDate(manufacturing: false),
        onTime: () => _pickTime(manufacturing: false),
      ),
    );
  }

  /// The answer, trimmed to what matters when the point is to fill in a lot:
  /// the expiry itself, with the destroy deadline underneath as a sanity
  /// check rather than as the headline.
  Widget _pickResultCard(BuildContext context, ShelfLifeResult result) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            l10n.t(K.calcPickResultExpiry),
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: Dimens.gapXs),
          Text(
            _stamp(l10n, _pickedExpiry(result), withTime: _useTime),
            style: theme.textTheme.headlineSmall
                ?.copyWith(fontWeight: FontWeight.w900),
          ),
          if (result.manufacturing != null && _mode != _Mode.printedExpiry) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            DetailRow(
              label: l10n.t(K.calcNsx),
              value: _stamp(l10n, result.manufacturing!, withTime: _useTime),
            ),
          ],
          if (result.destroyAt != null) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            Text(
              l10n.t(K.calcPickPreviewDestroy, <String, Object?>{
                'when': _stamp(
                  l10n,
                  result.destroyAt!,
                  withTime: result.hasMeaningfulTime || _useTime,
                ),
              }),
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.error,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _bothDatesCard(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _dateRow(
            context,
            label: l10n.t(K.calcNsx),
            date: _manufacturing,
            time: _manufacturingTime,
            onDate: () => _pickDate(manufacturing: true),
            onTime: () => _pickTime(manufacturing: true),
          ),
          const SizedBox(height: Dimens.gapM),
          _dateRow(
            context,
            label: l10n.t(K.calcHsd),
            date: _expiry,
            time: _expiryTime,
            onDate: () => _pickDate(manufacturing: false),
            onTime: () => _pickTime(manufacturing: false),
          ),
        ],
      ),
    );
  }

  Widget _spanCard(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final bool fromExpiry = _anchor == CalculatorAnchor.expiry;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SegmentedButton<CalculatorAnchor>(
            segments: <ButtonSegment<CalculatorAnchor>>[
              ButtonSegment<CalculatorAnchor>(
                value: CalculatorAnchor.expiry,
                label: Text(l10n.t(K.calcAnchorExpiry), textAlign: TextAlign.center),
              ),
              ButtonSegment<CalculatorAnchor>(
                value: CalculatorAnchor.manufacturing,
                label: Text(l10n.t(K.calcAnchorMfg), textAlign: TextAlign.center),
              ),
            ],
            selected: <CalculatorAnchor>{_anchor},
            showSelectedIcon: false,
            onSelectionChanged: (Set<CalculatorAnchor> next) =>
                setState(() => _anchor = next.first),
          ),
          const SizedBox(height: Dimens.gapM),
          _dateRow(
            context,
            label: fromExpiry ? l10n.t(K.calcHsd) : l10n.t(K.calcNsx),
            date: fromExpiry ? _expiry : _manufacturing,
            time: fromExpiry ? _expiryTime : _manufacturingTime,
            onDate: () => _pickDate(manufacturing: !fromExpiry),
            onTime: () => _pickTime(manufacturing: !fromExpiry),
          ),
          const SizedBox(height: Dimens.gapM),
          // With SOP goods the shelf life does not change the answer, so the
          // field is dimmed rather than removed - the employee can see that
          // the app knows it is irrelevant instead of wondering where it went.
          Opacity(
            opacity: _isSop ? 0.4 : 1,
            child: IgnorePointer(
              ignoring: _isSop,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    l10n.t(K.calcSpanLabel),
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  const SizedBox(height: Dimens.gapS),
                  Row(
                    children: <Widget>[
                      Expanded(
                        flex: 3,
                        child: TextField(
                          controller: _span,
                          keyboardType:
                              const TextInputType.numberWithOptions(decimal: true),
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(fontWeight: FontWeight.w800),
                          decoration: const InputDecoration(isDense: true),
                          onChanged: (_) => setState(() {}),
                        ),
                      ),
                      const SizedBox(width: Dimens.gapS),
                      Expanded(
                        flex: 2,
                        child: DropdownButtonFormField<ShelfLifeUnit>(
                          initialValue: _unit,
                          isExpanded: true,
                          decoration: const InputDecoration(isDense: true),
                          items: <DropdownMenuItem<ShelfLifeUnit>>[
                            DropdownMenuItem<ShelfLifeUnit>(
                              value: ShelfLifeUnit.hour,
                              child: Text(l10n.t(K.calcUnitHour)),
                            ),
                            DropdownMenuItem<ShelfLifeUnit>(
                              value: ShelfLifeUnit.day,
                              child: Text(l10n.t(K.calcUnitDay)),
                            ),
                            DropdownMenuItem<ShelfLifeUnit>(
                              value: ShelfLifeUnit.month,
                              child: Text(l10n.t(K.calcUnitMonth)),
                            ),
                            DropdownMenuItem<ShelfLifeUnit>(
                              value: ShelfLifeUnit.year,
                              child: Text(l10n.t(K.calcUnitYear)),
                            ),
                          ],
                          onChanged: (ShelfLifeUnit? v) =>
                              setState(() => _unit = v ?? _unit),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: Dimens.gapS),
                  Wrap(
                    spacing: Dimens.gapS,
                    runSpacing: Dimens.gapS,
                    children: <Widget>[
                      for (final int step in <int>[1, 2, 5, 10, 20, 50])
                        OutlinedButton(
                          onPressed: () => _addToSpan(step),
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size(56, 44),
                            padding: EdgeInsets.zero,
                          ),
                          child: Text('+$step'),
                        ),
                      OutlinedButton(
                        onPressed: () {
                          setState(() => _span.text = '0');
                          HapticFeedback.selectionClick();
                        },
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size(64, 44),
                          padding: EdgeInsets.zero,
                          foregroundColor: Theme.of(context).colorScheme.error,
                        ),
                        child: Text(l10n.t(K.calcClear)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _dateRow(
    BuildContext context, {
    required String label,
    required DateTime date,
    required TimeOfDay time,
    required VoidCallback onDate,
    required VoidCallback onTime,
  }) {
    final AppLocalizations l10n = context.l10n;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(label, style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: Dimens.gapS),
        Row(
          children: <Widget>[
            Expanded(
              flex: 3,
              child: OutlinedButton.icon(
                onPressed: onDate,
                icon: const Icon(Icons.calendar_today, size: 18),
                label: Text(_weekdayAndDate(l10n, date)),
              ),
            ),
            if (_useTime) ...<Widget>[
              const SizedBox(width: Dimens.gapS),
              Expanded(
                flex: 2,
                child: OutlinedButton.icon(
                  onPressed: onTime,
                  icon: const Icon(Icons.schedule, size: 18),
                  label: Text(
                    '${time.hour.toString().padLeft(2, '0')}:'
                    '${time.minute.toString().padLeft(2, '0')}',
                  ),
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _resultCard(BuildContext context, ShelfLifeResult result) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          DetailRow(
            label: l10n.t(K.calcNsx),
            value: result.manufacturing == null
                ? '—'
                : _stamp(l10n, result.manufacturing!, withTime: _useTime),
          ),
          DetailRow(
            label: l10n.t(K.calcHsd),
            value: _stamp(
              l10n,
              result.expiryInstant,
              withTime: _useTime || result.isHourlyGoods,
            ),
          ),
          const Divider(height: Dimens.gapL),
          Text(
            l10n.t(K.calcResultDestroy),
            style: theme.textTheme.labelMedium?.copyWith(
              color: theme.colorScheme.error,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: Dimens.gapXs),
          if (result.destroyAt == null)
            NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.help_outline,
              message: l10n.t(K.calcNeedShelfLife),
            )
          else
            Text(
              _stamp(
                l10n,
                result.destroyAt!,
                // A sub-daily lead only makes sense with the clock shown.
                withTime: result.hasMeaningfulTime || _useTime,
              ),
              style: theme.textTheme.headlineSmall?.copyWith(
                color: theme.colorScheme.error,
                fontWeight: FontWeight.w900,
              ),
            ),
          if (result.matchedRule != null) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            Wrap(
              spacing: Dimens.gapS,
              runSpacing: Dimens.gapXs,
              children: <Widget>[
                Chip(
                  visualDensity: VisualDensity.compact,
                  label: Text(
                    '${l10n.t(K.calcResultRule)}: '
                    '${l10n.isVietnamese ? result.matchedRule!.nameVi : result.matchedRule!.nameEn}'
                    ' (−${l10n.duration(result.matchedRule!.leadTime)})',
                  ),
                ),
                if (result.measuredShelfLife != null)
                  Chip(
                    visualDensity: VisualDensity.compact,
                    label: Text(l10n.t(K.calcShelfLife, <String, Object?>{
                      'days': l10n.number(
                        result.measuredShelfLife!.inMinutes / (60 * 24),
                        decimals: 1,
                      ),
                    }),),
                  ),
              ],
            ),
          ],
          if (result.usedFallbackLeadTime && result.isComplete) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            NoticeBanner(
              tone: NoticeTone.warning,
              icon: Icons.rule_folder_outlined,
              message: l10n.t(K.calcUsedFallback),
            ),
          ],
        ],
      ),
    );
  }

  String _weekdayAndDate(AppLocalizations l10n, DateTime value) {
    return '${DateFormat.EEEE(l10n.locale.languageCode).format(value)}, ${l10n.date(value)}';
  }

  String _stamp(AppLocalizations l10n, DateTime value, {required bool withTime}) {
    final String base = _weekdayAndDate(l10n, value);
    if (!withTime) return base;
    final String hh = value.hour.toString().padLeft(2, '0');
    final String mm = value.minute.toString().padLeft(2, '0');
    return '$hh:$mm · $base';
  }
}
