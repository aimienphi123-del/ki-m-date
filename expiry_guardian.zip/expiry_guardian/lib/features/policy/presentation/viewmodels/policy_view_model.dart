import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/services/policy_validator.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Validation issues for the policy currently in force.
final Provider<List<PolicyIssue>> policyIssuesProvider = Provider<List<PolicyIssue>>((Ref ref) {
  final DestroyPolicy? policy = ref.watch(activePolicyProvider).valueOrNull;
  if (policy == null) return const <PolicyIssue>[];
  return const PolicyValidator().validate(policy);
});

/// Write operations on the handbook.
class PolicyEditor {
  const PolicyEditor(this._ref);

  final Ref _ref;

  Future<Result<DestroyPolicy>> save(DestroyPolicy policy) =>
      _ref.read(policyRepositoryProvider).savePolicy(policy);

  Future<Result<DestroyPolicy>> upsertRule(String policyId, PolicyRule rule) =>
      _ref.read(policyRepositoryProvider).upsertRule(policyId, rule);

  Future<Result<DestroyPolicy>> deleteRule(String policyId, String ruleId) =>
      _ref.read(policyRepositoryProvider).deleteRule(policyId, ruleId);

  Future<Result<DestroyPolicy>> reorder(String policyId, List<String> orderedIds) =>
      _ref.read(policyRepositoryProvider).reorderRules(policyId, orderedIds);

  String newRuleId() => _ref.read(dependenciesProvider).ids.newId();

  /// Runs the engine on a hypothetical lot so a manager can see the effect of
  /// an edit before saving it.
  PolicyDecision preview({
    required DestroyPolicy policy,
    required DateTime expiry,
    DateTime? manufactured,
    ExpiryPrecision precision = ExpiryPrecision.day,
  }) {
    return _ref.read(policyEngineProvider).evaluate(
          policy,
          PolicyInput(
            expiry: expiry,
            receivedAt: _ref.read(clockProvider).now(),
            precision: precision,
            manufacturedAt: manufactured,
          ),
        );
  }
}

final Provider<PolicyEditor> policyEditorProvider = Provider<PolicyEditor>(PolicyEditor.new);

/// Localised description of a validation issue.
String describePolicyIssue(PolicyIssue issue) => switch (issue.code) {
      PolicyIssueCode.noActiveRules => 'policy.issue.noActiveRules',
      PolicyIssueCode.negativeLeadTime => 'policy.issue.negativeLeadTime',
      PolicyIssueCode.invertedRange => 'policy.issue.invertedRange',
      PolicyIssueCode.coverageGap => 'policy.issue.coverageGap',
      PolicyIssueCode.overlappingRules => 'policy.issue.overlappingRules',
      PolicyIssueCode.noCatchAll => 'policy.issue.noCatchAll',
      PolicyIssueCode.leadTimeExceedsShelfLife => 'policy.issue.leadTimeExceedsShelfLife',
      PolicyIssueCode.duplicateSortOrder => 'policy.issue.duplicateSortOrder',
    };

Failure? policyFailure(Result<Object?> result) => result.failureOrNull;
