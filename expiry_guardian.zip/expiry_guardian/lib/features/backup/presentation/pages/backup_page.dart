import 'dart:io';

import 'package:android_file_picker/android_file_picker.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_scope.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/backup/presentation/viewmodels/backup_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:file_picker_platform_interface/file_picker_platform_interface.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// What the confirmation dialog hands back: the employee agreed, and chose how.
class _Decision {
  const _Decision(this.mode);
  final ImportMode mode;
}

/// The one screen that moves a shop's data between phones.
///
/// Stock and rules are two separate halves, each with its own export and its
/// own import, because they are moved for different reasons and one must never
/// silently rewrite the other. Importing is always three steps - choose, read,
/// confirm - and the confirmation sets what the file holds against what the
/// phone holds before anything changes.
class BackupPage extends ConsumerStatefulWidget {
  const BackupPage({super.key});

  @override
  ConsumerState<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends ConsumerState<BackupPage> {
  @override
  void initState() {
    super.initState();
    // Providers must not be modified while the tree is building.
    Future<void>.microtask(
      () => ref.read(backupProvider.notifier).refreshSaved(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final BackupState state = ref.watch(backupProvider);

    ref.listen<BackupState>(backupProvider, (BackupState? was, BackupState now) {
      final BackupData? pending = now.pending;
      if (pending != null && was?.pending != pending) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          _confirm(pending);
        });
      }
    });

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.backupTitle))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gapXl,
        ),
        children: <Widget>[
          NoticeBanner(
            message: l10n.t(K.backupWarnSingleDevice),
            icon: Icons.phonelink_lock_outlined,
            tone: NoticeTone.warning,
          ),
          _ScopeCard(
            scope: BackupScope.data,
            title: l10n.t(K.backupDataTitle),
            body: l10n.t(K.backupDataBody),
            state: state,
            onExport: () => _export(BackupScope.data),
            onImport: () => _pick(BackupScope.data),
            onShare: _share,
          ),
          _ScopeCard(
            scope: BackupScope.rules,
            title: l10n.t(K.backupRulesTitle),
            body: l10n.t(K.backupRulesBody),
            state: state,
            onExport: () => _export(BackupScope.rules),
            onImport: () => _pick(BackupScope.rules),
            onShare: _share,
          ),

          if (state.failure != null) ...<Widget>[
            const SizedBox(height: Dimens.gapL),
            NoticeBanner(
              message: _messageFor(l10n, state.failure!),
              icon: Icons.error_outline,
              tone: NoticeTone.danger,
            ),
          ],

          if (state.report != null) ...<Widget>[
            SectionHeader(title: l10n.t(K.backupRestoreDone)),
            _ReportCard(report: state.report!, onShare: _share),
          ],

          if (state.saved.isNotEmpty) ...<Widget>[
            SectionHeader(
              title: l10n.t(K.backupSavedBackups),
              subtitle: l10n.t(K.backupSavedHint),
            ),
            AppCard(
              padding: EdgeInsets.zero,
              child: Column(
                children: <Widget>[
                  for (final SavedBackup saved in state.saved)
                    _SavedTile(
                      saved: saved,
                      enabled: !state.busy,
                      onImport: (BackupScope scope) => _choose(saved.path, scope),
                      onShare: () => _share(saved.path),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _export(BackupScope scope) async {
    final String? path = await ref.read(backupProvider.notifier).export(scope);
    if (path == null || !mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(context.l10n.t(K.backupExportDone))),
    );
    // Offered straight away: a backup that never leaves the phone does not
    // survive the phone.
    await _share(path);
  }

  Future<void> _share(String path) async {
    if (path.isEmpty || !File(path).existsSync()) return;
    await Share.shareXFiles(<XFile>[XFile(path)]);
  }

  Future<void> _choose(String path, BackupScope scope) =>
      ref.read(backupProvider.notifier).choose(path, scope);

  /// Hands the chosen file to the controller as a real file on disk.
  ///
  /// Android's document picker returns a `content://` grant rather than a
  /// path - the file usually sits in Downloads, in a chat app's storage or on
  /// a memory card, none of which this app may read directly - so the bytes
  /// are copied into its own folder first and everything downstream works on
  /// an ordinary file.
  Future<void> _pick(BackupScope scope) async {
    final PlatformFile? picked = await FilePickerAndroid().pickFile();
    if (picked == null) return;

    final BackupController controller = ref.read(backupProvider.notifier);
    try {
      final Directory staging = Directory(
        p.join((await getApplicationDocumentsDirectory()).path, 'incoming'),
      );
      if (!staging.existsSync()) await staging.create(recursive: true);
      final File landed = File(p.join(staging.path, picked.name));
      await landed.writeAsBytes(await picked.readAsBytes(), flush: true);
      await controller.choose(landed.path, scope);
    } on Object {
      // The picker can hand back a grant that is already gone - a file
      // deleted between the tap and the read. Report it the same way as any
      // other unreadable file rather than taking the screen down.
      await controller.choose('', scope);
    }
  }

  String _messageFor(AppLocalizations l10n, Failure failure) {
    final String key = 'backup.error.${failure.message}';
    if (!l10n.has(key)) return l10n.t(K.errorGeneric);

    final Map<String, Object?> params = <String, Object?>{};
    final Object? wanted = failure.context['wanted'];
    if (wanted is String) params['wanted'] = _scopeName(l10n, wanted);
    final Object? has = failure.context['has'];
    if (has is List) {
      params['has'] = has.isEmpty
          ? '-'
          : has.map((Object? s) => _scopeName(l10n, '$s')).join(', ');
    }
    return l10n.t(key, params);
  }

  String _scopeName(AppLocalizations l10n, String wire) =>
      BackupScope.fromWire(wire) == BackupScope.rules
          ? l10n.t(K.backupScopeRules)
          : l10n.t(K.backupScopeData);

  Future<void> _confirm(BackupData data) async {
    final BackupState state = ref.read(backupProvider);
    final BackupScope? scope = state.scope;
    if (scope == null) return;

    final _Decision? decision = await showDialog<_Decision>(
      context: context,
      builder: (BuildContext context) => _ConfirmDialog(
        scope: scope,
        data: data,
        live: state.pendingLive,
      ),
    );
    if (!mounted) return;

    final BackupController controller = ref.read(backupProvider.notifier);
    if (decision == null) {
      controller.discard();
      return;
    }
    final bool done = await controller.confirm(mode: decision.mode);
    if (!done || !mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(context.l10n.t(K.backupRestoreDone))),
    );
  }
}

/// One half of the shop: what it is, and the two buttons that move it.
class _ScopeCard extends StatelessWidget {
  const _ScopeCard({
    required this.scope,
    required this.title,
    required this.body,
    required this.state,
    required this.onExport,
    required this.onImport,
    required this.onShare,
  });

  final BackupScope scope;
  final String title;
  final String body;
  final BackupState state;
  final VoidCallback onExport;
  final VoidCallback onImport;
  final void Function(String path) onShare;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final bool exporting =
        state.busyWith(scope) && state.stage == BackupStage.exporting;
    final bool importing = state.busyWith(scope) &&
        (state.stage == BackupStage.inspecting ||
            state.stage == BackupStage.restoring);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SectionHeader(title: title),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(body),
              const SizedBox(height: Dimens.gapM),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: state.busy ? null : onExport,
                  icon: exporting ? const _Spinner() : const Icon(Icons.save_alt),
                  label: Text(
                    l10n.t(exporting ? K.backupExporting : exportLabelKey(scope)),
                  ),
                ),
              ),
              const SizedBox(height: Dimens.gapS),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: state.busy ? null : onImport,
                  icon: importing ? const _Spinner() : const Icon(Icons.folder_open),
                  label: Text(
                    l10n.t(
                      state.busyWith(scope) && state.stage == BackupStage.restoring
                          ? K.backupImporting
                          : importLabelKey(scope),
                    ),
                  ),
                ),
              ),
              if (state.lastExportPath != null &&
                  state.lastExportScope == scope) ...<Widget>[
                const SizedBox(height: Dimens.gapM),
                _FileRow(
                  path: state.lastExportPath!,
                  label: l10n.t(K.backupLastBackup),
                  onShare: () => onShare(state.lastExportPath!),
                  shareLabel: l10n.t(K.backupShare),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  static String exportLabelKey(BackupScope scope) => scope == BackupScope.data
      ? K.backupExportData
      : K.backupExportRules;

  static String importLabelKey(BackupScope scope) => scope == BackupScope.data
      ? K.backupImportData
      : K.backupImportRules;
}

class _Spinner extends StatelessWidget {
  const _Spinner();

  @override
  Widget build(BuildContext context) => const SizedBox(
        width: 18,
        height: 18,
        child: CircularProgressIndicator(strokeWidth: 2),
      );
}

class _ReportCard extends StatelessWidget {
  const _ReportCard({required this.report, required this.onShare});

  final RestoreReport report;
  final void Function(String path) onShare;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final String? safety = report.safetyCopyPath;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _Line(
            label: l10n.t(K.backupRowsRestored),
            value: '${report.rowsRestored}',
          ),
          if (report.rowsSkipped > 0) ...<Widget>[
            _Line(
              label: l10n.t(K.backupRowsSkipped),
              value: '${report.rowsSkipped}',
            ),
            Text(
              l10n.t(K.backupRowsSkippedHint),
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          if (report.scope == BackupScope.data)
            _Line(
              label: l10n.t(K.backupPhotosRestored),
              value: '${report.photosRestored}',
            ),
          if (report.auditKept) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            Text(
              l10n.t(K.backupAuditKept),
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
          if (safety != null) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            // Named rather than merely mentioned: this file is the way back if
            // the wrong archive was loaded.
            _FileRow(
              path: safety,
              label: l10n.t(K.backupSafetyCopy),
              onShare: () => onShare(safety),
              shareLabel: l10n.t(K.backupShare),
            ),
          ],
        ],
      ),
    );
  }
}

class _SavedTile extends StatelessWidget {
  const _SavedTile({
    required this.saved,
    required this.enabled,
    required this.onImport,
    required this.onShare,
  });

  final SavedBackup saved;
  final bool enabled;
  final void Function(BackupScope scope) onImport;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final String kb = (saved.bytes / 1024).toStringAsFixed(saved.bytes < 10240 ? 1 : 0);
    return ListTile(
      leading: const Icon(Icons.inventory_2_outlined),
      title: Text(saved.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${l10n.dateTime(saved.modified)} · $kb KB'),
      trailing: PopupMenuButton<int>(
        enabled: enabled,
        onSelected: (int choice) {
          switch (choice) {
            case 0:
              onImport(BackupScope.data);
            case 1:
              onImport(BackupScope.rules);
            default:
              onShare();
          }
        },
        itemBuilder: (BuildContext context) => <PopupMenuEntry<int>>[
          PopupMenuItem<int>(value: 0, child: Text(l10n.t(K.backupMenuImportData))),
          PopupMenuItem<int>(value: 1, child: Text(l10n.t(K.backupMenuImportRules))),
          PopupMenuItem<int>(value: 2, child: Text(l10n.t(K.backupShare))),
        ],
      ),
    );
  }
}

/// Shows what the file holds beside what the phone holds, so a backup from the
/// wrong day - or the wrong shop - is caught here rather than afterwards.
class _ConfirmDialog extends StatefulWidget {
  const _ConfirmDialog({
    required this.scope,
    required this.data,
    required this.live,
  });

  final BackupScope scope;
  final BackupData data;
  final Map<String, int> live;

  @override
  State<_ConfirmDialog> createState() => _ConfirmDialogState();
}

class _ConfirmDialogState extends State<_ConfirmDialog> {
  ImportMode _mode = ImportMode.merge;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final bool isData = widget.scope == BackupScope.data;
    final bool replacing = !isData || _mode == ImportMode.replace;

    final List<(String, String)> rows = isData
        ? <(String, String)>[
            (K.backupProducts, Tables.products),
            (K.backupLots, Tables.inventoryRecords),
            (K.backupShelves, Tables.shelves),
            (K.backupDestructions, Tables.destructions),
          ]
        : <(String, String)>[
            (K.backupPolicies, Tables.policies),
            (K.backupPolicyRules, Tables.policyRules),
            (K.backupStages, Tables.notificationStages),
            (K.backupEscalationRules, Tables.escalationRules),
          ];

    final TextStyle? head = Theme.of(context)
        .textTheme
        .labelLarge
        ?.copyWith(fontWeight: FontWeight.w700);

    return AlertDialog(
      title: Text(
        l10n.t(
          isData ? K.backupImportData : K.backupImportRules,
        ),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            _Line(
              label: l10n.t(K.backupCreatedAt),
              value: l10n.dateTime(widget.data.createdAt),
            ),
            if (widget.data.appVersion.isNotEmpty)
              _Line(
                label: l10n.t(K.backupFromVersion),
                value: widget.data.appVersion,
              ),
            const SizedBox(height: Dimens.gapM),
            Row(
              children: <Widget>[
                const Expanded(child: SizedBox.shrink()),
                SizedBox(
                  width: 72,
                  child: Text(l10n.t(K.backupInFile), style: head, textAlign: TextAlign.end),
                ),
                SizedBox(
                  width: 72,
                  child: Text(l10n.t(K.backupOnPhone), style: head, textAlign: TextAlign.end),
                ),
              ],
            ),
            for (final (String label, String table) in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(
                  children: <Widget>[
                    Expanded(child: Text(l10n.t(label))),
                    SizedBox(
                      width: 72,
                      child: Text('${widget.data.rowsIn(table)}', textAlign: TextAlign.end),
                    ),
                    SizedBox(
                      width: 72,
                      child: Text('${widget.live[table] ?? 0}', textAlign: TextAlign.end),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: Dimens.gapM),
            if (isData) ...<Widget>[
              Text(l10n.t(K.backupModeTitle), style: head),
              RadioGroup<ImportMode>(
                groupValue: _mode,
                onChanged: (ImportMode? m) => setState(() => _mode = m ?? _mode),
                child: Column(
                  children: <Widget>[
                    RadioListTile<ImportMode>(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      value: ImportMode.merge,
                      title: Text(l10n.t(K.backupModeMerge)),
                      subtitle: Text(l10n.t(K.backupModeMergeHint)),
                    ),
                    RadioListTile<ImportMode>(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      value: ImportMode.replace,
                      title: Text(l10n.t(K.backupModeReplace)),
                      subtitle: Text(l10n.t(K.backupModeReplaceHint)),
                    ),
                  ],
                ),
              ),
            ] else
              Text(l10n.t(K.backupConfirmRulesBody)),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(l10n.t(K.commonCancel)),
        ),
        FilledButton(
          style: replacing
              ? FilledButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.error,
                  foregroundColor: Theme.of(context).colorScheme.onError,
                )
              : null,
          onPressed: () => Navigator.of(context).pop(_Decision(_mode)),
          child: Text(l10n.t(K.backupConfirmAction)),
        ),
      ],
    );
  }
}

class _Line extends StatelessWidget {
  const _Line({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(child: Text(label)),
          const SizedBox(width: Dimens.gapS),
          Text(
            value,
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _FileRow extends StatelessWidget {
  const _FileRow({
    required this.path,
    required this.label,
    required this.onShare,
    required this.shareLabel,
  });

  final String path;
  final String label;
  final VoidCallback onShare;
  final String shareLabel;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Row(
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                label,
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              Text(
                p.basename(path),
                style: theme.textTheme.bodyMedium
                    ?.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        TextButton.icon(
          onPressed: onShare,
          icon: const Icon(Icons.ios_share),
          label: Text(shareLabel),
        ),
      ],
    );
  }
}
