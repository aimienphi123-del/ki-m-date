import 'dart:io';

import 'package:android_file_picker/android_file_picker.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/presentation/viewmodels/backup_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:file_picker_platform_interface/file_picker_platform_interface.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// The one screen that can put a shop's data back after a lost phone.
///
/// The two halves are deliberately asymmetric. Backing up is one button and
/// cannot go wrong. Restoring replaces everything, so it is three steps -
/// choose, read, confirm - and the screen shows what the file actually holds
/// before the employee agrees to it.
class BackupPage extends ConsumerWidget {
  const BackupPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final BackupState state = ref.watch(backupProvider);

    ref.listen<BackupState>(backupProvider, (BackupState? was, BackupState now) {
      final BackupData? pending = now.pending;
      if (pending != null && was?.pending != pending) {
        unawaitedConfirm(context, ref, pending);
      }
    });

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.backupTitle))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gapXl,
        ),
        children: <Widget>[
          NoticeBanner(
            message: l10n.t(K.backupWarnSingleDevice),
            icon: Icons.phonelink_lock_outlined,
            tone: NoticeTone.warning,
          ),
          const SizedBox(height: Dimens.gapL),

          SectionHeader(title: l10n.t(K.backupExportTitle)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(l10n.t(K.backupExportBody)),
                const SizedBox(height: Dimens.gapM),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: state.busy
                            ? null
                            : () => _export(context, ref),
                        icon: state.stage == BackupStage.exporting
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.save_alt),
                        label: Text(
                          l10n.t(
                            state.stage == BackupStage.exporting
                                ? K.backupExporting
                                : K.backupExportAction,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                if (state.lastExportPath != null) ...<Widget>[
                  const SizedBox(height: Dimens.gapM),
                  _FileRow(
                    path: state.lastExportPath!,
                    label: l10n.t(K.backupLastBackup),
                    onShare: () => _share(state.lastExportPath!),
                    shareLabel: l10n.t(K.backupShare),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: Dimens.gapL),
          SectionHeader(title: l10n.t(K.backupImportTitle)),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(l10n.t(K.backupImportBody)),
                const SizedBox(height: Dimens.gapM),
                OutlinedButton.icon(
                  onPressed: state.busy ? null : () => _pick(context, ref),
                  icon: state.stage == BackupStage.restoring ||
                          state.stage == BackupStage.inspecting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.folder_open),
                  label: Text(
                    l10n.t(
                      state.stage == BackupStage.restoring
                          ? K.backupImporting
                          : K.backupImportAction,
                    ),
                  ),
                ),
              ],
            ),
          ),

          if (state.failure != null) ...<Widget>[
            const SizedBox(height: Dimens.gapL),
            NoticeBanner(
              message: _messageFor(l10n, state.failure!),
              icon: Icons.error_outline,
              tone: NoticeTone.danger,
            ),
          ],

          if (state.report != null) ...<Widget>[
            const SizedBox(height: Dimens.gapL),
            SectionHeader(title: l10n.t(K.backupRestoreDone)),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  _Line(
                    label: l10n.t(K.backupRowsRestored),
                    value: '${state.report!.rowsRestored}',
                  ),
                  _Line(
                    label: l10n.t(K.backupPhotosRestored),
                    value: '${state.report!.photosRestored}',
                  ),
                  const SizedBox(height: Dimens.gapS),
                  // Named rather than merely mentioned: this file is the way
                  // back if the wrong archive was restored.
                  _FileRow(
                    path: state.report!.safetyCopyPath,
                    label: l10n.t(K.backupSafetyCopy),
                    onShare: () => _share(state.report!.safetyCopyPath),
                    shareLabel: l10n.t(K.backupShare),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _export(BuildContext context, WidgetRef ref) async {
    final String? path = await ref.read(backupProvider.notifier).export();
    if (path == null || !context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(context.l10n.t(K.backupExportDone))),
    );
    // Offered straight away: a backup that never leaves the phone does not
    // survive the phone.
    await _share(path);
  }

  Future<void> _share(String path) async {
    if (path.isEmpty || !File(path).existsSync()) return;
    await Share.shareXFiles(<XFile>[XFile(path)]);
  }

  /// Hands the chosen file to the controller as a real file on disk.
  ///
  /// Android's document picker returns a `content://` grant rather than a
  /// path - the file usually sits in Downloads, in a chat app's storage or on
  /// a memory card, none of which this app may read directly - so the bytes
  /// are copied into its own folder first and everything downstream works on
  /// an ordinary file.
  Future<void> _pick(BuildContext context, WidgetRef ref) async {
    final PlatformFile? picked = await FilePickerAndroid().pickFile();
    if (picked == null) return;

    final BackupController controller = ref.read(backupProvider.notifier);
    try {
      final Directory staging = Directory(
        p.join((await getApplicationDocumentsDirectory()).path, 'incoming'),
      );
      if (!staging.existsSync()) await staging.create(recursive: true);
      final File landed = File(p.join(staging.path, picked.name));
      await landed.writeAsBytes(await picked.readAsBytes(), flush: true);
      await controller.choose(landed.path);
    } on Object {
      // The picker can hand back a grant that is already gone - a file
      // deleted between the tap and the read. Report it the same way as any
      // other unreadable file rather than taking the screen down.
      await controller.choose('');
    }
  }

  String _messageFor(AppLocalizations l10n, Failure failure) {
    final String key = 'backup.error.${failure.message}';
    final String text = l10n.t(key);
    // `t` echoes the key back when it knows nothing about it, which would put
    // `backup.error.something` on a shop floor.
    return text == key ? l10n.t(K.errorGeneric) : text;
  }

  void unawaitedConfirm(
    BuildContext context,
    WidgetRef ref,
    BackupData pending,
  ) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!context.mounted) return;
      _confirm(context, ref, pending);
    });
  }

  Future<void> _confirm(
    BuildContext context,
    WidgetRef ref,
    BackupData data,
  ) async {
    final AppLocalizations l10n = context.l10n;
    final bool? go = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.backupConfirmTitle)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(l10n.t(K.backupConfirmBody)),
              const SizedBox(height: Dimens.gapM),
              Text(
                l10n.t(K.backupFileInfo),
                style: Theme.of(context)
                    .textTheme
                    .labelLarge
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: Dimens.gapS),
              // What is actually in the file, so a backup from the wrong day
              // or the wrong shop is caught here rather than afterwards.
              _Line(
                label: l10n.t(K.backupCreatedAt),
                value: l10n.dateTime(data.createdAt),
              ),
              if (data.appVersion.isNotEmpty)
                _Line(
                  label: l10n.t(K.backupFromVersion),
                  value: data.appVersion,
                ),
              _Line(
                label: l10n.t(K.backupProducts),
                value: '${data.rowsIn(Tables.products)}',
              ),
              _Line(
                label: l10n.t(K.backupLots),
                value: '${data.rowsIn(Tables.inventoryRecords)}',
              ),
              _Line(
                label: l10n.t(K.backupDestructions),
                value: '${data.rowsIn(Tables.destructions)}',
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(l10n.t(K.backupConfirmAction)),
          ),
        ],
      ),
    );

    if (go != true) {
      ref.read(backupProvider.notifier).discard();
      return;
    }
    final bool done = await ref.read(backupProvider.notifier).confirm();
    if (!done || !context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(context.l10n.t(K.backupRestoreDone))),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(child: Text(label)),
          const SizedBox(width: Dimens.gapS),
          Text(
            value,
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class _FileRow extends StatelessWidget {
  const _FileRow({
    required this.path,
    required this.label,
    required this.onShare,
    required this.shareLabel,
  });

  final String path;
  final String label;
  final VoidCallback onShare;
  final String shareLabel;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Row(
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                label,
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              Text(
                p.basename(path),
                style: theme.textTheme.bodyMedium
                    ?.copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        TextButton.icon(
          onPressed: onShare,
          icon: const Icon(Icons.ios_share),
          label: Text(shareLabel),
        ),
      ],
    );
  }
}
