import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// What the backup screen is doing right now.
enum BackupStage { idle, exporting, inspecting, restoring }

class BackupState {
  const BackupState({
    this.stage = BackupStage.idle,
    this.lastExportPath,
    this.pending,
    this.pendingPath,
    this.report,
    this.failure,
  });

  final BackupStage stage;

  /// The archive the last export wrote, so it can be shared without being
  /// made again.
  final String? lastExportPath;

  /// A file the employee chose, already read and vouched for but not yet
  /// applied. Nothing is replaced until this has been shown to them.
  final BackupData? pending;
  final String? pendingPath;

  final RestoreReport? report;
  final Failure? failure;

  bool get busy => stage != BackupStage.idle;

  BackupState copyWith({
    BackupStage? stage,
    String? lastExportPath,
    BackupData? pending,
    String? pendingPath,
    RestoreReport? report,
    Failure? failure,
    bool clearPending = false,
    bool clearFailure = false,
    bool clearReport = false,
  }) {
    return BackupState(
      stage: stage ?? this.stage,
      lastExportPath: lastExportPath ?? this.lastExportPath,
      pending: clearPending ? null : pending ?? this.pending,
      pendingPath: clearPending ? null : pendingPath ?? this.pendingPath,
      report: clearReport ? null : report ?? this.report,
      failure: clearFailure ? null : failure ?? this.failure,
    );
  }
}

class BackupController extends StateNotifier<BackupState> {
  BackupController(this._repository) : super(const BackupState());

  final BackupRepository _repository;

  Future<String?> export() async {
    state = state.copyWith(
      stage: BackupStage.exporting,
      clearFailure: true,
      clearReport: true,
    );
    final Result<String> result = await _repository.export();
    return result.fold(
      (Failure failure) {
        state = state.copyWith(stage: BackupStage.idle, failure: failure);
        return null;
      },
      (String path) {
        state = state.copyWith(stage: BackupStage.idle, lastExportPath: path);
        return path;
      },
    );
  }

  /// Reads a chosen file and holds it. Deliberately separate from [confirm]:
  /// the employee sees what the file contains - which shop, which day, how
  /// many lots - before anything is replaced.
  Future<void> choose(String path) async {
    state = state.copyWith(
      stage: BackupStage.inspecting,
      clearFailure: true,
      clearReport: true,
      clearPending: true,
    );
    final Result<BackupData> result = await _repository.inspect(path);
    result.fold(
      (Failure failure) =>
          state = state.copyWith(stage: BackupStage.idle, failure: failure),
      (BackupData data) => state = state.copyWith(
        stage: BackupStage.idle,
        pending: data,
        pendingPath: path,
      ),
    );
  }

  void discard() => state = state.copyWith(clearPending: true, clearFailure: true);

  Future<bool> confirm() async {
    final String? path = state.pendingPath;
    if (path == null) return false;
    state = state.copyWith(stage: BackupStage.restoring, clearFailure: true);
    final Result<RestoreReport> result = await _repository.restore(path);
    return result.fold(
      (Failure failure) {
        state = state.copyWith(stage: BackupStage.idle, failure: failure);
        return false;
      },
      (RestoreReport report) {
        state = state.copyWith(
          stage: BackupStage.idle,
          report: report,
          clearPending: true,
        );
        return true;
      },
    );
  }
}

final StateNotifierProvider<BackupController, BackupState> backupProvider =
    StateNotifierProvider<BackupController, BackupState>(
  (Ref ref) => BackupController(ref.watch(backupRepositoryProvider)),
);
