import 'package:expiry_guardian/core/di/dependencies.dart';
import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_scope.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// What the backup screen is doing right now.
enum BackupStage { idle, exporting, inspecting, restoring }

class BackupState {
  const BackupState({
    this.stage = BackupStage.idle,
    this.scope,
    this.lastExportPath,
    this.lastExportScope,
    this.pending,
    this.pendingPath,
    this.pendingLive = const <String, int>{},
    this.report,
    this.failure,
    this.saved = const <SavedBackup>[],
  });

  final BackupStage stage;

  /// Which half the current operation is about, so only that section shows
  /// its spinner.
  final BackupScope? scope;

  /// The archive the last export wrote, so it can be shared without being
  /// made again.
  final String? lastExportPath;
  final BackupScope? lastExportScope;

  /// A file the employee chose, already read and vouched for but not yet
  /// applied. Nothing is replaced until this has been shown to them.
  final BackupData? pending;
  final String? pendingPath;

  /// What the phone holds now, for the same tables - the other side of the
  /// comparison the confirmation draws.
  final Map<String, int> pendingLive;

  final RestoreReport? report;
  final Failure? failure;
  final List<SavedBackup> saved;

  bool get busy => stage != BackupStage.idle;

  bool busyWith(BackupScope s) => busy && scope == s;

  BackupState copyWith({
    BackupStage? stage,
    BackupScope? scope,
    String? lastExportPath,
    BackupScope? lastExportScope,
    BackupData? pending,
    String? pendingPath,
    Map<String, int>? pendingLive,
    RestoreReport? report,
    Failure? failure,
    List<SavedBackup>? saved,
    bool clearPending = false,
    bool clearFailure = false,
    bool clearReport = false,
  }) {
    return BackupState(
      stage: stage ?? this.stage,
      scope: scope ?? this.scope,
      lastExportPath: lastExportPath ?? this.lastExportPath,
      lastExportScope: lastExportScope ?? this.lastExportScope,
      pending: clearPending ? null : pending ?? this.pending,
      pendingPath: clearPending ? null : pendingPath ?? this.pendingPath,
      pendingLive: clearPending
          ? const <String, int>{}
          : pendingLive ?? this.pendingLive,
      report: clearReport ? null : report ?? this.report,
      failure: clearFailure ? null : failure ?? this.failure,
      saved: saved ?? this.saved,
    );
  }
}

/// Runs after an import has changed the database, to bring everything that
/// was holding on to the old state up to date.
typedef AfterImport = Future<void> Function(BackupScope scope);

class BackupController extends StateNotifier<BackupState> {
  BackupController(this._repository, {AfterImport? afterImport})
      : _afterImport = afterImport,
        super(const BackupState());

  final BackupRepository _repository;
  final AfterImport? _afterImport;

  Future<void> refreshSaved() async {
    state = state.copyWith(saved: await _repository.savedBackups());
  }

  Future<String?> export(BackupScope scope) async {
    state = state.copyWith(
      stage: BackupStage.exporting,
      scope: scope,
      clearFailure: true,
      clearReport: true,
    );
    final Result<String> result = await _repository.export(scope);
    final String? path = result.fold(
      (Failure failure) {
        state = state.copyWith(stage: BackupStage.idle, failure: failure);
        return null;
      },
      (String path) => path,
    );
    if (path == null) return null;
    state = state.copyWith(
      stage: BackupStage.idle,
      lastExportPath: path,
      lastExportScope: scope,
      saved: await _repository.savedBackups(),
    );
    return path;
  }

  /// Reads a chosen file and holds it. Deliberately separate from [confirm]:
  /// the employee sees what the file contains - which day, how many lots - set
  /// against what the phone holds now, before anything is changed.
  Future<void> choose(String path, BackupScope scope) async {
    state = state.copyWith(
      stage: BackupStage.inspecting,
      scope: scope,
      clearFailure: true,
      clearReport: true,
      clearPending: true,
    );
    final Result<BackupData> result = await _repository.inspect(path);
    final BackupData? data = result.valueOrNull;
    if (data == null) {
      state = state.copyWith(
        stage: BackupStage.idle,
        failure: result.failureOrNull,
      );
      return;
    }

    // Refused here, before any dialog: a rules file offered to the data import
    // (or the other way round) would otherwise look like it was about to work.
    if (!data.carries(scope)) {
      state = state.copyWith(
        stage: BackupStage.idle,
        failure: Failure.validation(
          'backup_wrong_scope',
          context: <String, Object?>{
            'wanted': scope.name,
            'has': <String>[
              for (final BackupScope s in BackupScope.values)
                if (data.carries(s)) s.name,
            ],
          },
        ),
      );
      return;
    }

    final Result<Map<String, int>> live = await _repository.liveCounts(scope);
    state = state.copyWith(
      stage: BackupStage.idle,
      pending: data,
      pendingPath: path,
      pendingLive: live.valueOrNull ?? const <String, int>{},
    );
  }

  void discard() =>
      state = state.copyWith(clearPending: true, clearFailure: true);

  Future<bool> confirm({ImportMode mode = ImportMode.merge}) async {
    final String? path = state.pendingPath;
    final BackupScope? scope = state.scope;
    if (path == null || scope == null) return false;

    state = state.copyWith(stage: BackupStage.restoring, clearFailure: true);
    final Result<RestoreReport> result =
        await _repository.restore(path, scope, mode: mode);
    final RestoreReport? report = result.valueOrNull;
    if (report == null) {
      state = state.copyWith(
        stage: BackupStage.idle,
        failure: result.failureOrNull,
      );
      return false;
    }

    // The alarms registered with Android, the cached settings and every screen
    // built from them describe the state before the import. Left alone, old
    // reminders keep firing for lots that were replaced and the new lots have
    // none.
    try {
      await _afterImport?.call(scope);
    } on Object {
      // The import itself succeeded; a refresh that failed is repaired by the
      // next change that reschedules, and must not turn a success into an error.
    }

    state = state.copyWith(
      stage: BackupStage.idle,
      report: report,
      clearPending: true,
      saved: await _repository.savedBackups(),
    );
    return true;
  }
}

final StateNotifierProvider<BackupController, BackupState> backupProvider =
    StateNotifierProvider<BackupController, BackupState>((Ref ref) {
  return BackupController(
    ref.watch(backupRepositoryProvider),
    afterImport: (BackupScope scope) async {
      final Dependencies deps = ref.read(dependenciesProvider);
      // Settings are cached in memory; the import wrote straight to the table.
      await deps.settings.load();
      ref.read(settingsRevisionProvider.notifier).bump();

      final Result<NotificationPlan> plan =
          await deps.notificationPlanner.reschedule(
        preferences: ref.read(notificationPreferencesProvider),
        strings: ref.read(stringsProvider),
      );
      if (plan.isErr) {
        deps.logger.w(
          'Backup',
          'Reminder refresh after import failed: ${plan.failureOrNull?.message}',
        );
      }
    },
  );
});
