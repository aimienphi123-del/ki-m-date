import 'dart:convert';

import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';

/// Turns a backup into text and back, and refuses anything it cannot vouch for.
///
/// This is the whole trust boundary of the restore: the file arrives from a
/// phone's Downloads folder, a chat app or a memory card, and the next thing
/// that happens is the shop's live data being replaced by it. Everything that
/// can be checked before that point is checked here, where it can be tested
/// without a database.
class BackupCodec {
  const BackupCodec();

  static const String fileMarker = 'expiry_guardian_backup';

  String encode(BackupData data) {
    return const JsonEncoder.withIndent('  ').convert(<String, Object?>{
      'marker': fileMarker,
      'formatVersion': data.formatVersion,
      'schemaVersion': data.schemaVersion,
      'appVersion': data.appVersion,
      'createdAt': data.createdAt.toUtc().toIso8601String(),
      'photos': data.photoNames,
      'tables': data.tables,
    });
  }

  /// [currentSchemaVersion] is the schema of the build doing the restoring.
  Result<BackupData> decode(String source, {required int currentSchemaVersion}) {
    final Object? raw;
    try {
      raw = jsonDecode(source);
    } on FormatException {
      return Result<BackupData>.err(
        const Failure.validation('backup_not_json'),
      );
    }
    if (raw is! Map<String, Object?>) {
      return Result<BackupData>.err(const Failure.validation('backup_not_json'));
    }

    // A file that is valid JSON but is not ours would otherwise restore an
    // empty shop over a full one.
    if (raw['marker'] != fileMarker) {
      return Result<BackupData>.err(
        const Failure.validation('backup_not_ours'),
      );
    }

    final int? formatVersion = _asInt(raw['formatVersion']);
    if (formatVersion == null || formatVersion < 1) {
      return Result<BackupData>.err(
        const Failure.validation('backup_not_ours'),
      );
    }
    if (formatVersion > BackupData.currentFormatVersion) {
      return Result<BackupData>.err(
        const Failure.validation('backup_too_new'),
      );
    }

    final int? schemaVersion = _asInt(raw['schemaVersion']);
    if (schemaVersion == null || schemaVersion < 1) {
      return Result<BackupData>.err(
        const Failure.validation('backup_not_ours'),
      );
    }
    // Rows written by a build that knows tables and columns this one does not
    // cannot be restored faithfully, and half-restoring them is worse than
    // refusing: the shop would be told its data was back when some of it was
    // silently dropped.
    if (schemaVersion > currentSchemaVersion) {
      return Result<BackupData>.err(
        Failure.validation(
          'backup_too_new',
          context: <String, Object?>{
            'backup': schemaVersion,
            'app': currentSchemaVersion,
          },
        ),
      );
    }

    final Object? tablesRaw = raw['tables'];
    if (tablesRaw is! Map<String, Object?>) {
      return Result<BackupData>.err(const Failure.validation('backup_no_tables'));
    }

    final Map<String, List<Map<String, Object?>>> tables =
        <String, List<Map<String, Object?>>>{};
    for (final MapEntry<String, Object?> entry in tablesRaw.entries) {
      final Object? rows = entry.value;
      if (rows is! List<Object?>) {
        return Result<BackupData>.err(
          Failure.validation(
            'backup_table_corrupt',
            context: <String, Object?>{'table': entry.key},
          ),
        );
      }
      final List<Map<String, Object?>> parsed = <Map<String, Object?>>[];
      for (final Object? row in rows) {
        if (row is! Map<String, Object?>) {
          return Result<BackupData>.err(
            Failure.validation(
              'backup_table_corrupt',
              context: <String, Object?>{'table': entry.key},
            ),
          );
        }
        parsed.add(row);
      }
      tables[entry.key] = parsed;
    }

    final DateTime createdAt =
        DateTime.tryParse(raw['createdAt'] as String? ?? '')?.toLocal() ??
            DateTime.fromMillisecondsSinceEpoch(0);

    return Result<BackupData>.ok(BackupData(
      formatVersion: formatVersion,
      schemaVersion: schemaVersion,
      appVersion: raw['appVersion'] as String? ?? '',
      createdAt: createdAt,
      tables: tables,
      photoNames: <String>[
        for (final Object? name in (raw['photos'] as List<Object?>? ?? const <Object?>[]))
          if (name is String) name,
      ],
    ),);
  }

  /// Narrows [row] to what the live table can actually take.
  ///
  /// A backup taken before a column existed is missing it, and one taken from
  /// an older build may carry a column since dropped. Both are ordinary once
  /// a store has been running for a while, and neither should cost the shop
  /// its data - so the intersection is inserted and the rest ignored.
  static Map<String, Object?> fitToColumns(
    Map<String, Object?> row,
    Set<String> columns,
  ) {
    return <String, Object?>{
      for (final MapEntry<String, Object?> cell in row.entries)
        if (columns.contains(cell.key)) cell.key: cell.value,
    };
  }

  static int? _asInt(Object? value) => switch (value) {
        final int v => v,
        final double v => v.toInt(),
        final String v => int.tryParse(v),
        _ => null,
      };
}
