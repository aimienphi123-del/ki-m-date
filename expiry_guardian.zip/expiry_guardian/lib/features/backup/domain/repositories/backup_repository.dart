import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';

/// What a finished restore did.
class RestoreReport {
  const RestoreReport({
    required this.rowsRestored,
    required this.photosRestored,
    required this.safetyCopyPath,
    this.skippedTables = const <String>[],
  });

  final int rowsRestored;
  final int photosRestored;

  /// Where the data that was replaced was put first. A restore is the one
  /// action in this app that destroys something on purpose, so it is never
  /// done without the previous state being written out where it can be
  /// restored in turn.
  final String safetyCopyPath;

  /// Tables the file carried that this build no longer has. Reported rather
  /// than hidden: it is the shop's evidence that something was left behind.
  final List<String> skippedTables;
}

abstract class BackupRepository {
  /// Writes every table and every photograph into one archive and returns its
  /// path.
  ///
  /// [prefix] names the file. Never reuses a name that is already on disk, so
  /// a second export in the same minute cannot replace the first - and the
  /// copy taken before a restore cannot overwrite the archive being restored.
  Future<Result<String>> export({String prefix});

  /// Reads an archive far enough to describe it, changing nothing.
  Future<Result<BackupData>> inspect(String archivePath);

  /// Replaces everything with the contents of [archivePath].
  Future<Result<RestoreReport>> restore(String archivePath);
}
