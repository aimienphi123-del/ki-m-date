import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_scope.dart';

/// What a finished import did.
class RestoreReport {
  const RestoreReport({
    required this.scope,
    required this.mode,
    required this.rowsRestored,
    required this.rowsSkipped,
    required this.photosRestored,
    this.safetyCopyPath,
    this.auditKept = false,
  });

  final BackupScope scope;
  final ImportMode mode;
  final int rowsRestored;

  /// Rows the file held that were not loaded: already present, or naming a
  /// parent that is not there. Reported, never hidden - it is the shop's
  /// evidence of what was left out.
  final int rowsSkipped;
  final int photosRestored;

  /// Where what was replaced was put first. Only a replace deletes anything,
  /// so only a replace has one.
  final String? safetyCopyPath;

  /// The audit log on this phone was kept rather than overwritten, because
  /// its entries are chained to each other and a second chain cannot be
  /// spliced into it.
  final bool auditKept;
}

/// A backup sitting in the app's own folder.
class SavedBackup {
  const SavedBackup({
    required this.path,
    required this.name,
    required this.bytes,
    required this.modified,
  });

  final String path;
  final String name;
  final int bytes;
  final DateTime modified;
}

abstract class BackupRepository {
  /// Writes one half of the shop into an archive and returns its path.
  ///
  /// Never reuses a name already on disk, so a second export in the same
  /// minute cannot replace the first - and the copy taken before a replace
  /// cannot overwrite the archive being restored.
  Future<Result<String>> export(BackupScope scope, {String? prefix});

  /// Reads an archive far enough to describe it, changing nothing.
  Future<Result<BackupData>> inspect(String archivePath);

  /// How many rows each table of [scope] holds on this phone right now - the
  /// other side of the comparison the confirmation shows.
  Future<Result<Map<String, int>>> liveCounts(BackupScope scope);

  /// Loads [scope]'s half of [archivePath].
  ///
  /// Only ever touches the tables of [scope], and of those only the ones the
  /// file actually carries: a table the file says nothing about is left alone
  /// rather than emptied. [mode] applies to data; the rulebook is always
  /// replaced whole, because two rulebooks do not merge into one.
  Future<Result<RestoreReport>> restore(
    String archivePath,
    BackupScope scope, {
    ImportMode mode = ImportMode.merge,
  });

  /// Archives kept on this phone, newest first.
  Future<List<SavedBackup>> savedBackups();
}
