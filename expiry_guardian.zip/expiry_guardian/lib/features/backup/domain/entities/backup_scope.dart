import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';

/// A backup is one of two independent things, never both at once.
///
/// **Data** is what the shop has *got*: areas, shelves, products, lots and the
/// history of what was destroyed. **Rules** is how the shop *decides*: the
/// destruction policy and its rules, the reminder timeline, escalation and the
/// settings.
///
/// They are separate because they change for different reasons and are moved
/// for different reasons. Stock is brought across from a spreadsheet or a
/// printed report; the rulebook is copied between stores or recovered after a
/// mistake. Tying them into one file meant that bringing in some stock quietly
/// replaced the rulebook with whatever the file happened to hold - which, for a
/// file that held no rules at all, was nothing.
enum BackupScope {
  data(<String>[
    Tables.areas,
    Tables.shelves,
    Tables.categories,
    Tables.products,
    Tables.productBarcodes,
    Tables.inventoryRecords,
    Tables.recordEvents,
    Tables.destructions,
    Tables.escalations,
    Tables.auditLog,
  ]),
  rules(<String>[
    Tables.policies,
    Tables.policyRules,
    Tables.notificationStages,
    Tables.escalationRules,
    Tables.settings,
  ]);

  const BackupScope(this.tables);

  /// Parents first, so rows can be inserted straight down the list.
  final List<String> tables;

  /// What the files are called, readable in a downloads folder.
  String get fileStem => switch (this) {
        BackupScope.data => 'du-lieu',
        BackupScope.rules => 'quy-tac',
      };

  static BackupScope? fromWire(Object? value) => switch (value) {
        'data' => BackupScope.data,
        'rules' => BackupScope.rules,
        _ => null,
      };
}

/// How a data import treats what is already on the phone.
enum ImportMode {
  /// Adds what the file holds and leaves everything already here untouched.
  /// A row whose id - or barcode, or lot code - is already taken is skipped.
  /// This cannot lose anything, which is why it is the default.
  merge,

  /// Clears the scope first, then loads the file. The only mode that deletes,
  /// so it is the only one that takes a safety copy.
  replace,
}

/// The facts about the schema that decide what a backup may carry.
abstract final class BackupRules {
  /// Tables no backup touches, in either direction.
  ///
  /// * `users` holds password hashes and salts. A file that is shared over a
  ///   chat app must not carry them, and a restore that replaced them could
  ///   lock the shop out of its own phone.
  /// * `scheduled_notifications` mirrors the alarms the phone has registered
  ///   with Android. It is rebuilt from the lots and the rules, and copying it
  ///   would describe alarms the new phone does not have.
  /// * `document_exports` points at report files that exist on one phone only.
  /// * `sync_outbox` is a queue for a backend that does not exist yet.
  static const Set<String> neverBackedUp = <String>{
    Tables.users,
    Tables.scheduledNotifications,
    Tables.documentExports,
    Tables.syncOutbox,
  };

  /// Settings that describe *this phone*, not the shop.
  ///
  /// `device.id` names the handset on every destruction it confirms - restore
  /// it onto a second phone and two devices share one identity. The permission
  /// flags record what Android granted *this* handset; carrying `granted: true`
  /// to a phone that was never asked stops the app asking, and no reminder ever
  /// fires.
  static const Set<String> deviceBoundSettings = <String>{
    SettingKeys.deviceId,
    SettingKeys.deviceLabel,
    SettingKeys.notificationPermissionAsked,
    SettingKeys.notificationPermissionGranted,
    SettingKeys.exactAlarmPermissionAsked,
  };

  /// Tables the database refuses to delete from.
  static const Set<String> appendOnly = <String>{Tables.auditLog};

  /// Which tables die with their parent.
  ///
  /// Replacing the products without replacing the lots would leave lots naming
  /// products that no longer exist; the same goes down the whole tree.
  static const Map<String, List<String>> cascadeChildren =
      <String, List<String>>{
    Tables.areas: <String>[Tables.shelves],
    Tables.products: <String>[
      Tables.productBarcodes,
      Tables.inventoryRecords,
      Tables.recordEvents,
      Tables.destructions,
      Tables.escalations,
    ],
    Tables.inventoryRecords: <String>[
      Tables.recordEvents,
      Tables.destructions,
      Tables.escalations,
    ],
    Tables.policies: <String>[Tables.policyRules],
  };

  /// Which parent a child row must still have, or the row is unusable.
  static const Map<String, List<(String column, String parent)>> parents =
      <String, List<(String, String)>>{
    Tables.shelves: <(String, String)>[('area_id', Tables.areas)],
    Tables.productBarcodes: <(String, String)>[('product_id', Tables.products)],
    Tables.inventoryRecords: <(String, String)>[('product_id', Tables.products)],
    Tables.recordEvents: <(String, String)>[('record_id', Tables.inventoryRecords)],
    Tables.destructions: <(String, String)>[('record_id', Tables.inventoryRecords)],
    Tables.escalations: <(String, String)>[('record_id', Tables.inventoryRecords)],
    Tables.policyRules: <(String, String)>[('policy_id', Tables.policies)],
  };

  /// Every table a replace has to empty, given what the file carries.
  static List<String> tablesToClear(BackupScope scope, Set<String> carried) {
    final Set<String> clear = <String>{};
    void add(String table) {
      if (!scope.tables.contains(table) || !clear.add(table)) return;
      for (final String child in cascadeChildren[table] ?? const <String>[]) {
        add(child);
      }
    }

    for (final String table in carried) {
      add(table);
    }
    return <String>[
      for (final String table in scope.tables)
        if (clear.contains(table)) table,
    ];
  }
}
