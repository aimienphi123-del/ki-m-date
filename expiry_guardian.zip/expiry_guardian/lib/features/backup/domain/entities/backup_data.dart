/// Everything one backup carries, already parsed.
///
/// Deliberately a plain map of table name to rows rather than a typed model
/// per table: a backup has to survive the app gaining a column, and the
/// restore decides column by column what the current schema can accept.
class BackupData {
  const BackupData({
    required this.formatVersion,
    required this.schemaVersion,
    required this.appVersion,
    required this.createdAt,
    required this.tables,
    this.photoNames = const <String>[],
  });

  /// Version of the envelope below, not of the app or the database. Bumped
  /// only when the shape of the file itself changes.
  static const int currentFormatVersion = 1;

  final int formatVersion;

  /// The database schema the rows were read out of. A backup from a newer
  /// build than the one restoring it cannot be trusted and is refused.
  final int schemaVersion;

  final String appVersion;
  final DateTime createdAt;
  final Map<String, List<Map<String, Object?>>> tables;

  /// File names inside the archive's `photos/` folder.
  final List<String> photoNames;

  int get rowCount =>
      tables.values.fold(0, (int sum, List<Map<String, Object?>> r) => sum + r.length);

  int rowsIn(String table) => tables[table]?.length ?? 0;
}
