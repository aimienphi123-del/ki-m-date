import 'package:expiry_guardian/features/backup/domain/entities/backup_scope.dart';

/// Everything one backup carries, already parsed.
///
/// Deliberately a plain map of table name to rows rather than a typed model
/// per table: a backup has to survive the app gaining a column, and the
/// restore decides column by column what the current schema can accept.
class BackupData {
  const BackupData({
    required this.formatVersion,
    required this.schemaVersion,
    required this.appVersion,
    required this.createdAt,
    required this.tables,
    this.declaredScope,
    this.photoNames = const <String>[],
  });

  /// Version of the envelope, not of the app or the database.
  ///
  /// 2 added the scope. Version 1 files - everything the first backup screen
  /// ever wrote - carry both halves in one archive and are still readable: each
  /// import takes only its own half out of them.
  static const int currentFormatVersion = 2;

  final int formatVersion;

  /// The database schema the rows were read out of. A backup from a newer
  /// build than the one restoring it cannot be trusted and is refused.
  final int schemaVersion;

  final String appVersion;
  final DateTime createdAt;
  final Map<String, List<Map<String, Object?>>> tables;

  /// What the exporter said it was writing. `null` for a version 1 file.
  /// Informational: what an import acts on is which tables are really there.
  final BackupScope? declaredScope;

  /// File names inside the archive's `photos/` folder.
  final List<String> photoNames;

  int get rowCount =>
      tables.values.fold(0, (int sum, List<Map<String, Object?>> r) => sum + r.length);

  int rowsIn(String table) => tables[table]?.length ?? 0;

  /// Whether the file speaks for any table of [scope].
  ///
  /// This, not [declaredScope], is what gates an import: a handmade file that
  /// claims nothing but carries products is still data.
  bool carries(BackupScope scope) => scope.tables.any(tables.containsKey);

  /// The tables of [scope] the file speaks for.
  Set<String> carriedIn(BackupScope scope) =>
      <String>{for (final String t in scope.tables) if (tables.containsKey(t)) t};
}
