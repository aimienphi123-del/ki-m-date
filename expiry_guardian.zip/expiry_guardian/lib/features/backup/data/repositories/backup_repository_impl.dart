import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/migrations.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/backup/domain/services/backup_codec.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Reads and writes the whole shop as one `.zip`.
///
/// The archive holds `backup.json` - every row of every table - and a
/// `photos/` folder carrying the files those rows point at. The photographs
/// have to travel with the data: a destruction record whose evidence
/// photograph is missing is not a record of anything, and the paths inside
/// the rows are absolute and belong to the phone that wrote them, so they are
/// rewritten on the way back in.
class BackupRepositoryImpl implements BackupRepository {
  BackupRepositoryImpl({
    required AppDatabase database,
    required Clock clock,
    required AppLogger logger,
    required Future<Directory> Function() documentsDirectory,
    String appVersion = '',
    BackupCodec codec = const BackupCodec(),
  })  : _database = database,
        _clock = clock,
        _logger = logger,
        _documents = documentsDirectory,
        _appVersion = appVersion,
        _codec = codec;

  final AppDatabase _database;
  final Clock _clock;
  final AppLogger _logger;
  final Future<Directory> Function() _documents;
  final String _appVersion;
  final BackupCodec _codec;

  static const String _tag = 'BackupRepository';
  static const String _jsonEntry = 'backup.json';
  static const String _photoFolder = 'photos';

  /// Every table that holds something a shop would miss.
  ///
  /// Ordered parents first so a restore can insert straight down the list.
  /// `sync_outbox` is deliberately absent: it is a queue of work for a backend
  /// that does not exist yet, and replaying one shop's queue onto another
  /// phone would be wrong rather than merely useless.
  static const List<String> backedUpTables = <String>[
    Tables.users,
    Tables.areas,
    Tables.shelves,
    Tables.categories,
    Tables.policies,
    Tables.policyRules,
    Tables.products,
    Tables.productBarcodes,
    Tables.inventoryRecords,
    Tables.recordEvents,
    Tables.destructions,
    Tables.settings,
    Tables.notificationStages,
    Tables.escalationRules,
    Tables.escalations,
    Tables.scheduledNotifications,
    Tables.auditLog,
    Tables.documentExports,
  ];

  /// Tables the database itself refuses to let anyone delete from.
  ///
  /// The audit log is tamper-evident on purpose - a trigger aborts every
  /// UPDATE and DELETE - and a restore must not be the one hole in that. So
  /// these are never cleared: the backup's entries are added to whatever the
  /// phone already has, and an entry that is already present is left alone.
  /// A restore can therefore give a shop its history back without ever being
  /// able to erase a line of it.
  static const Set<String> appendOnlyTables = <String>{Tables.auditLog};

  /// Columns that hold a path to a file this app owns.
  static const Map<String, List<String>> _photoColumns = <String, List<String>>{
    Tables.products: <String>['photo_path', 'barcode_photo_path'],
    Tables.inventoryRecords: <String>['photo_path'],
    Tables.destructions: <String>['photo_path'],
  };

  @override
  Future<Result<String>> export({String prefix = 'kiem-date'}) async {
    try {
      final BackupData data = await _readEverything();
      final Directory documents = await _documents();
      final Directory outputDir = Directory(p.join(documents.path, 'backups'));
      if (!outputDir.existsSync()) await outputDir.create(recursive: true);

      final String path = _freePath(outputDir, prefix, _clock.now());
      await File(path).writeAsBytes(await _pack(data), flush: true);
      _logger.i(_tag, 'Exported ${data.rowCount} rows to $path');
      return Result<String>.ok(path);
    } on Object catch (error, stackTrace) {
      _logger.e(_tag, 'Export failed', error: error, stackTrace: stackTrace);
      return Result<String>.err(
        Failure.io('backup_export_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  @override
  Future<Result<BackupData>> inspect(String archivePath) async {
    try {
      final Archive archive = _open(archivePath);
      final ArchiveFile? entry = _entry(archive, _jsonEntry);
      if (entry == null) {
        return Result<BackupData>.err(
          const Failure.validation('backup_not_ours'),
        );
      }
      return _codec.decode(
        utf8.decode(entry.content as List<int>, allowMalformed: true),
        currentSchemaVersion: Migrations.latestVersion,
      );
    } on Object catch (error, stackTrace) {
      _logger.w(_tag, 'Could not read $archivePath: $error');
      return Result<BackupData>.err(
        Failure.validation(
          'backup_unreadable',
          context: <String, Object?>{'cause': '$error', 'stack': '$stackTrace'},
        ),
      );
    }
  }

  @override
  Future<Result<RestoreReport>> restore(String archivePath) async {
    final Result<BackupData> read = await inspect(archivePath);
    return read.fold(
      Result<RestoreReport>.err,
      (BackupData data) => _apply(data, archivePath),
    );
  }

  Future<Result<RestoreReport>> _apply(
    BackupData data,
    String archivePath,
  ) async {
    late final String safetyCopy;
    try {
      // Nothing is destroyed before the current state is safely on disk. If
      // the file turns out to hold a different shop, or an older day than the
      // employee thought, this is the way back.
      final Result<String> safety = await export(prefix: 'truoc-khi-nap');
      final Object? failure = safety.fold(
        (Failure f) => f,
        (String _) => null,
      );
      if (failure is Failure) return Result<RestoreReport>.err(failure);
      safetyCopy = safety.fold((Failure _) => '', (String path) => path);
    } on Object catch (error, stackTrace) {
      return Result<RestoreReport>.err(
        Failure.io('backup_safety_copy_failed', cause: error, stackTrace: stackTrace),
      );
    }

    try {
      final Directory documents = await _documents();
      final Directory captures = Directory(p.join(documents.path, 'captures'));
      if (!captures.existsSync()) await captures.create(recursive: true);

      final int photos = await _restorePhotos(archivePath, captures);
      final Map<String, Set<String>> columns = await _liveColumns();
      final List<String> skipped = <String>[
        for (final String table in data.tables.keys)
          if (!columns.containsKey(table)) table,
      ];

      final Database db = _database.db;
      // Foreign keys are switched off around the whole replacement rather than
      // inside it: the rows are internally consistent by construction, and
      // enforcing order across eighteen tables would make an ordinary restore
      // fail on a shop whose data is merely unusual. SQLite ignores the pragma
      // inside a transaction, so it has to be set out here.
      await db.execute('PRAGMA foreign_keys = OFF');
      int written = 0;
      try {
        await db.transaction((Transaction txn) async {
          for (final String table in backedUpTables.reversed) {
            if (appendOnlyTables.contains(table)) continue;
            await txn.delete(table);
          }
          for (final String table in backedUpTables) {
            final List<Map<String, Object?>>? rows = data.tables[table];
            if (rows == null || rows.isEmpty) continue;
            final Set<String> live = columns[table]!;
            for (final Map<String, Object?> row in rows) {
              final Map<String, Object?> fitted =
                  BackupCodec.fitToColumns(row, live);
              if (fitted.isEmpty) continue;
              // `replace` is a delete plus an insert, which the append-only
              // trigger rightly aborts; `ignore` keeps the line already on
              // the phone and adds the ones it was missing.
              final int id = await txn.insert(
                table,
                _rewritePhotoPaths(table, fitted, captures.path),
                conflictAlgorithm: appendOnlyTables.contains(table)
                    ? ConflictAlgorithm.ignore
                    : ConflictAlgorithm.replace,
              );
              if (id != 0) written++;
            }
          }
        });
      } finally {
        await db.execute('PRAGMA foreign_keys = ON');
      }

      _database.notifyChanged(backedUpTables);
      _logger.i(_tag, 'Restored $written rows and $photos photos');
      return Result<RestoreReport>.ok(RestoreReport(
        rowsRestored: written,
        photosRestored: photos,
        safetyCopyPath: safetyCopy,
        skippedTables: skipped,
      ),);
    } on Object catch (error, stackTrace) {
      _logger.e(_tag, 'Restore failed', error: error, stackTrace: stackTrace);
      return Result<RestoreReport>.err(
        Failure.database('backup_restore_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  Future<BackupData> _readEverything() async {
    final Database db = _database.db;
    final Map<String, Set<String>> columns = await _liveColumns();
    final Map<String, List<Map<String, Object?>>> tables =
        <String, List<Map<String, Object?>>>{};
    final Set<String> photoNames = <String>{};

    for (final String table in backedUpTables) {
      if (!columns.containsKey(table)) continue;
      final List<Map<String, Object?>> rows = await db.query(table);
      tables[table] = rows;
      for (final String column in _photoColumns[table] ?? const <String>[]) {
        for (final Map<String, Object?> row in rows) {
          final Object? value = row[column];
          if (value is String && value.isNotEmpty) photoNames.add(value);
        }
      }
    }

    return BackupData(
      formatVersion: BackupData.currentFormatVersion,
      schemaVersion: Migrations.latestVersion,
      appVersion: _appVersion,
      createdAt: _clock.now(),
      tables: tables,
      photoNames: photoNames.map(p.basename).toList(growable: false),
    );
  }

  Future<Uint8List> _pack(BackupData data) async {
    final Archive archive = Archive();
    final List<int> json = utf8.encode(_codec.encode(data));
    archive.addFile(ArchiveFile(_jsonEntry, json.length, json));

    final Set<String> added = <String>{};
    for (final MapEntry<String, List<String>> entry in _photoColumns.entries) {
      for (final Map<String, Object?> row in data.tables[entry.key] ?? const <Map<String, Object?>>[]) {
        for (final String column in entry.value) {
          final Object? value = row[column];
          if (value is! String || value.isEmpty) continue;
          final String name = p.basename(value);
          if (!added.add(name)) continue;
          final File source = File(value);
          // A photograph the OS already reclaimed is not a reason to refuse
          // the shop a backup of everything else.
          if (!source.existsSync()) continue;
          final Uint8List bytes = await source.readAsBytes();
          archive.addFile(
            ArchiveFile('$_photoFolder/$name', bytes.length, bytes),
          );
        }
      }
    }

    return Uint8List.fromList(ZipEncoder().encode(archive));
  }

  Future<int> _restorePhotos(String archivePath, Directory captures) async {
    final Archive archive = _open(archivePath);
    int restored = 0;
    for (final ArchiveFile file in archive.files) {
      if (!file.isFile) continue;
      if (!file.name.startsWith('$_photoFolder/')) continue;
      final String name = p.basename(file.name);
      if (name.isEmpty) continue;
      await File(p.join(captures.path, name))
          .writeAsBytes(file.content as List<int>, flush: true);
      restored++;
    }
    return restored;
  }

  /// Points every stored path at this phone's own captures folder.
  Map<String, Object?> _rewritePhotoPaths(
    String table,
    Map<String, Object?> row,
    String capturesPath,
  ) {
    final List<String>? columns = _photoColumns[table];
    if (columns == null) return row;
    final Map<String, Object?> out = Map<String, Object?>.of(row);
    for (final String column in columns) {
      final Object? value = out[column];
      if (value is! String || value.isEmpty) continue;
      out[column] = p.join(capturesPath, p.basename(value));
    }
    return out;
  }

  /// What each table can actually take on this build.
  Future<Map<String, Set<String>>> _liveColumns() async {
    final Database db = _database.db;
    final Map<String, Set<String>> columns = <String, Set<String>>{};
    for (final String table in backedUpTables) {
      final List<Map<String, Object?>> info =
          await db.rawQuery('PRAGMA table_info($table)');
      if (info.isEmpty) continue;
      columns[table] = <String>{
        for (final Map<String, Object?> row in info) row['name']! as String,
      };
    }
    return columns;
  }

  Archive _open(String archivePath) =>
      ZipDecoder().decodeBytes(File(archivePath).readAsBytesSync());

  ArchiveFile? _entry(Archive archive, String name) {
    for (final ArchiveFile file in archive.files) {
      if (file.name == name && file.isFile) return file;
    }
    return null;
  }

  /// A name in [dir] that is not already taken.
  ///
  /// Two backups a minute apart used to land on the same name, and the second
  /// silently replaced the first. That is merely annoying for an ordinary
  /// export and destructive for the safety copy taken during a restore: it
  /// could overwrite the very archive being restored, leaving the shop with
  /// neither its old data nor the file it was trying to bring back.
  String _freePath(Directory dir, String prefix, DateTime at) {
    final String stamp = _stamp(at);
    String candidate = p.join(dir.path, '$prefix-$stamp.zip');
    int suffix = 2;
    while (File(candidate).existsSync()) {
      candidate = p.join(dir.path, '$prefix-$stamp-$suffix.zip');
      suffix++;
    }
    return candidate;
  }

  /// `2026-09-14_1830`, which sorts and reads the same way round.
  String _stamp(DateTime at) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${at.year}-${two(at.month)}-${two(at.day)}'
        '_${two(at.hour)}${two(at.minute)}';
  }
}
