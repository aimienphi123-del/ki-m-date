import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/migrations.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_data.dart';
import 'package:expiry_guardian/features/backup/domain/entities/backup_scope.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/backup/domain/services/backup_codec.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Reads and writes the shop as `.zip` archives, one half at a time.
///
/// An archive holds `backup.json` - every row of the tables in its scope - and,
/// for stock, a `photos/` folder carrying the files those rows point at. The
/// photographs travel with the data because a destruction record whose
/// evidence photograph is missing is not a record of anything; the paths in
/// the rows are absolute and belong to the phone that wrote them, so they are
/// rewritten on the way back in.
class BackupRepositoryImpl implements BackupRepository {
  BackupRepositoryImpl({
    required AppDatabase database,
    required Clock clock,
    required AppLogger logger,
    required Future<Directory> Function() documentsDirectory,
    String appVersion = '',
    BackupCodec codec = const BackupCodec(),
  })  : _database = database,
        _clock = clock,
        _logger = logger,
        _documents = documentsDirectory,
        _appVersion = appVersion,
        _codec = codec;

  final AppDatabase _database;
  final Clock _clock;
  final AppLogger _logger;
  final Future<Directory> Function() _documents;
  final String _appVersion;
  final BackupCodec _codec;

  static const String _tag = 'BackupRepository';
  static const String _jsonEntry = 'backup.json';
  static const String _photoFolder = 'photos';
  static const String _backupsFolder = 'backups';

  /// Columns that hold a path to a file this app owns.
  static const Map<String, List<String>> _photoColumns = <String, List<String>>{
    Tables.products: <String>['photo_path', 'barcode_photo_path'],
    Tables.inventoryRecords: <String>['photo_path'],
    Tables.destructions: <String>['photo_path'],
  };

  // ---------------------------------------------------------------- export

  @override
  Future<Result<String>> export(BackupScope scope, {String? prefix}) async {
    try {
      final BackupData data = await _read(scope);
      final Directory outputDir = await _backupsDirectory();
      final String path =
          _freePath(outputDir, prefix ?? scope.fileStem, _clock.now());
      await File(path).writeAsBytes(await _pack(data), flush: true);
      _logger.i(_tag, 'Exported ${data.rowCount} ${scope.name} rows to $path');
      return Result<String>.ok(path);
    } on Object catch (error, stackTrace) {
      _logger.e(_tag, 'Export failed', error: error, stackTrace: stackTrace);
      return Result<String>.err(
        Failure.io('backup_export_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  Future<BackupData> _read(BackupScope scope) async {
    final Database db = _database.db;
    final Map<String, Set<String>> columns = await _liveColumns(scope);
    final Map<String, List<Map<String, Object?>>> tables =
        <String, List<Map<String, Object?>>>{};
    final Set<String> photoNames = <String>{};

    for (final String table in scope.tables) {
      if (!columns.containsKey(table)) continue;
      List<Map<String, Object?>> rows = await db.query(
        table,
        orderBy: table == Tables.auditLog ? 'seq ASC' : null,
      );
      if (table == Tables.settings) {
        // What describes this phone stays on this phone.
        rows = <Map<String, Object?>>[
          for (final Map<String, Object?> row in rows)
            if (!BackupRules.deviceBoundSettings.contains(row['key'])) row,
        ];
      }
      tables[table] = rows;
      for (final String column in _photoColumns[table] ?? const <String>[]) {
        for (final Map<String, Object?> row in rows) {
          final Object? value = row[column];
          if (value is String && value.isNotEmpty) photoNames.add(value);
        }
      }
    }

    return BackupData(
      formatVersion: BackupData.currentFormatVersion,
      schemaVersion: Migrations.latestVersion,
      appVersion: _appVersion,
      createdAt: _clock.now(),
      tables: tables,
      declaredScope: scope,
      photoNames: photoNames.map(p.basename).toList(growable: false),
    );
  }

  Future<Uint8List> _pack(BackupData data) async {
    final Archive archive = Archive();
    final List<int> json = utf8.encode(_codec.encode(data));
    archive.addFile(ArchiveFile(_jsonEntry, json.length, json));

    final Set<String> added = <String>{};
    for (final MapEntry<String, List<String>> entry in _photoColumns.entries) {
      for (final Map<String, Object?> row
          in data.tables[entry.key] ?? const <Map<String, Object?>>[]) {
        for (final String column in entry.value) {
          final Object? value = row[column];
          if (value is! String || value.isEmpty) continue;
          final String name = p.basename(value);
          if (!added.add(name)) continue;
          final File source = File(value);
          // A photograph the OS already reclaimed is not a reason to refuse
          // the shop a backup of everything else.
          if (!source.existsSync()) continue;
          final Uint8List bytes = await source.readAsBytes();
          archive.addFile(ArchiveFile('$_photoFolder/$name', bytes.length, bytes));
        }
      }
    }
    return Uint8List.fromList(ZipEncoder().encode(archive));
  }

  // --------------------------------------------------------------- inspect

  @override
  Future<Result<BackupData>> inspect(String archivePath) async {
    try {
      final Archive archive = _open(archivePath);
      final ArchiveFile? entry = _entry(archive, _jsonEntry);
      if (entry == null) {
        return Result<BackupData>.err(const Failure.validation('backup_not_ours'));
      }
      return _codec.decode(
        utf8.decode(entry.content as List<int>, allowMalformed: true),
        currentSchemaVersion: Migrations.latestVersion,
      );
    } on Object catch (error, stackTrace) {
      _logger.w(_tag, 'Could not read $archivePath: $error');
      return Result<BackupData>.err(
        Failure.validation(
          'backup_unreadable',
          context: <String, Object?>{'cause': '$error', 'stack': '$stackTrace'},
        ),
      );
    }
  }

  @override
  Future<Result<Map<String, int>>> liveCounts(BackupScope scope) async {
    try {
      final Map<String, Set<String>> columns = await _liveColumns(scope);
      final Map<String, int> counts = <String, int>{};
      for (final String table in scope.tables) {
        if (!columns.containsKey(table)) continue;
        counts[table] = await _count(_database.db, table);
      }
      return Result<Map<String, int>>.ok(counts);
    } on Object catch (error, stackTrace) {
      return Result<Map<String, int>>.err(
        Failure.database('backup_count_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  @override
  Future<List<SavedBackup>> savedBackups() async {
    final Directory dir = await _backupsDirectory();
    final List<SavedBackup> found = <SavedBackup>[
      for (final FileSystemEntity entity in dir.listSync())
        if (entity is File && entity.path.toLowerCase().endsWith('.zip'))
          SavedBackup(
            path: entity.path,
            name: p.basename(entity.path),
            bytes: entity.lengthSync(),
            modified: entity.lastModifiedSync(),
          ),
    ];
    found.sort((SavedBackup a, SavedBackup b) => b.modified.compareTo(a.modified));
    return found;
  }

  // --------------------------------------------------------------- restore

  @override
  Future<Result<RestoreReport>> restore(
    String archivePath,
    BackupScope scope, {
    ImportMode mode = ImportMode.merge,
  }) async {
    final Result<BackupData> read = await inspect(archivePath);
    return read.fold(
      Result<RestoreReport>.err,
      (BackupData data) => _apply(data, archivePath, scope, mode),
    );
  }

  Future<Result<RestoreReport>> _apply(
    BackupData data,
    String archivePath,
    BackupScope scope,
    ImportMode requested,
  ) async {
    // The check that keeps the two halves apart. A file that carries none of
    // this scope's tables has nothing to say about it, and "replace the rules
    // with nothing" is exactly the failure this split exists to prevent.
    if (!data.carries(scope)) {
      return Result<RestoreReport>.err(
        Failure.validation(
          'backup_wrong_scope',
          context: <String, Object?>{
            'wanted': scope.name,
            'has': <String>[
              for (final BackupScope s in BackupScope.values)
                if (data.carries(s)) s.name,
            ],
          },
        ),
      );
    }

    // Two rulebooks do not merge into one; the file's replaces this phone's.
    final ImportMode mode =
        scope == BackupScope.rules ? ImportMode.replace : requested;
    final Set<String> carried = data.carriedIn(scope);

    // A policy table that arrives empty would replace the working policy with
    // none at all, and the app only seeds a default on first launch.
    if (mode == ImportMode.replace &&
        carried.contains(Tables.policies) &&
        data.rowsIn(Tables.policies) == 0) {
      return Result<RestoreReport>.err(
        const Failure.validation('backup_rules_incomplete'),
      );
    }

    String? safetyCopy;
    if (mode == ImportMode.replace) {
      // Nothing is destroyed before the current state is safely on disk.
      final Result<String> safety =
          await export(scope, prefix: 'truoc-khi-nap-${scope.fileStem}');
      final Failure? failed = safety.failureOrNull;
      if (failed != null) {
        return Result<RestoreReport>.err(
          Failure.io('backup_safety_copy_failed', cause: failed),
        );
      }
      safetyCopy = safety.valueOrNull;
    }

    try {
      final Directory documents = await _documents();
      final Directory captures = Directory(p.join(documents.path, 'captures'));
      int photos = 0;
      if (scope == BackupScope.data) {
        if (!captures.existsSync()) await captures.create(recursive: true);
        photos = await _restorePhotos(archivePath, captures);
      }

      final Map<String, Set<String>> columns = await _liveColumns(scope);
      final Database db = _database.db;
      int written = 0;
      int skipped = 0;
      bool auditKept = false;

      // Foreign keys are switched off around the whole load: the parent checks
      // below do the job explicitly, row by row, and say what they skipped.
      // SQLite ignores the pragma inside a transaction, so it is set out here.
      await db.execute('PRAGMA foreign_keys = OFF');
      try {
        await db.transaction((Transaction txn) async {
          if (mode == ImportMode.replace) {
            final List<String> clear =
                BackupRules.tablesToClear(scope, carried).reversed.toList();
            for (final String table in clear) {
              if (BackupRules.appendOnly.contains(table)) continue;
              if (table == Tables.settings) {
                await txn.delete(
                  table,
                  where:
                      'key NOT IN (${List<String>.filled(BackupRules.deviceBoundSettings.length, '?').join(',')})',
                  whereArgs: BackupRules.deviceBoundSettings.toList(),
                );
              } else {
                await txn.delete(table);
              }
            }
          }

          for (final String table in scope.tables) {
            final List<Map<String, Object?>>? rows = data.tables[table];
            if (rows == null || rows.isEmpty) continue;
            final Set<String>? live = columns[table];
            if (live == null) {
              // A table this build no longer has.
              skipped += rows.length;
              continue;
            }

            if (table == Tables.auditLog) {
              // The entries are chained to one another, so a second chain
              // cannot be spliced into the first without breaking both. Load
              // the file's only into an empty log.
              if (await _count(txn, table) > 0) {
                auditKept = true;
                skipped += rows.length;
                continue;
              }
              rows.sort((Map<String, Object?> a, Map<String, Object?> b) =>
                  ((a['seq'] as num?) ?? 0).compareTo((b['seq'] as num?) ?? 0),);
            }

            // Read from the database rather than from the file: the parents
            // were loaded earlier in this same transaction, and a parent that
            // was skipped (already present, say) is still a valid parent.
            final Map<String, Set<String>> parentIds = <String, Set<String>>{};
            for (final (String _, String parent)
                in BackupRules.parents[table] ?? const <(String, String)>[]) {
              parentIds[parent] ??= await _ids(txn, parent);
            }

            for (final Map<String, Object?> row in rows) {
              if (table == Tables.settings &&
                  BackupRules.deviceBoundSettings.contains(row['key'])) {
                continue;
              }
              final Map<String, Object?> fitted = BackupCodec.fitToColumns(row, live);
              if (fitted.isEmpty) continue;

              bool orphan = false;
              for (final (String column, String parent)
                  in BackupRules.parents[table] ?? const <(String, String)>[]) {
                if (!(parentIds[parent]?.contains(fitted[column]) ?? false)) {
                  orphan = true;
                }
              }
              if (orphan) {
                skipped++;
                continue;
              }

              await txn.insert(
                table,
                scope == BackupScope.data
                    ? _rewritePhotoPaths(table, fitted, captures.path)
                    : fitted,
                conflictAlgorithm: mode == ImportMode.merge
                    ? ConflictAlgorithm.ignore
                    : ConflictAlgorithm.replace,
              );
              final int changed =
                  Sqflite.firstIntValue(await txn.rawQuery('SELECT changes()')) ?? 0;
              if (changed > 0) {
                written++;
              } else {
                skipped++;
              }
            }
          }

          if (scope == BackupScope.data) await _mendReferences(txn);
        });
      } finally {
        await db.execute('PRAGMA foreign_keys = ON');
      }

      _database.notifyChanged(scope.tables);
      _logger.i(
        _tag,
        'Imported ${scope.name} ($mode): $written rows, $skipped skipped, $photos photos',
      );
      return Result<RestoreReport>.ok(RestoreReport(
        scope: scope,
        mode: mode,
        rowsRestored: written,
        rowsSkipped: skipped,
        photosRestored: photos,
        safetyCopyPath: safetyCopy,
        auditKept: auditKept,
      ),);
    } on Object catch (error, stackTrace) {
      _logger.e(_tag, 'Import failed', error: error, stackTrace: stackTrace);
      return Result<RestoreReport>.err(
        Failure.database('backup_restore_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  /// Clears references that now point at nothing.
  ///
  /// Only ever nulls a nullable pointer: a lot keeps existing without its
  /// shelf, a product without its category.
  Future<void> _mendReferences(Transaction txn) async {
    await txn.execute(
      'UPDATE ${Tables.inventoryRecords} SET shelf_id = NULL '
      'WHERE shelf_id IS NOT NULL AND shelf_id NOT IN (SELECT id FROM ${Tables.shelves})',
    );
    await txn.execute(
      'UPDATE ${Tables.inventoryRecords} SET area_id = NULL '
      'WHERE area_id IS NOT NULL AND area_id NOT IN (SELECT id FROM ${Tables.areas})',
    );
    await txn.execute(
      'UPDATE ${Tables.products} SET default_shelf_id = NULL '
      'WHERE default_shelf_id IS NOT NULL AND default_shelf_id NOT IN (SELECT id FROM ${Tables.shelves})',
    );
    await txn.execute(
      'UPDATE ${Tables.products} SET category_id = NULL '
      'WHERE category_id IS NOT NULL AND category_id NOT IN (SELECT id FROM ${Tables.categories})',
    );
  }

  Future<int> _restorePhotos(String archivePath, Directory captures) async {
    final Archive archive = _open(archivePath);
    int restored = 0;
    for (final ArchiveFile file in archive.files) {
      if (!file.isFile || !file.name.startsWith('$_photoFolder/')) continue;
      final String name = p.basename(file.name);
      if (name.isEmpty) continue;
      await File(p.join(captures.path, name))
          .writeAsBytes(file.content as List<int>, flush: true);
      restored++;
    }
    return restored;
  }

  /// Points every stored path at this phone's own captures folder.
  Map<String, Object?> _rewritePhotoPaths(
    String table,
    Map<String, Object?> row,
    String capturesPath,
  ) {
    final List<String>? columns = _photoColumns[table];
    if (columns == null) return row;
    final Map<String, Object?> out = Map<String, Object?>.of(row);
    for (final String column in columns) {
      final Object? value = out[column];
      if (value is! String || value.isEmpty) continue;
      out[column] = p.join(capturesPath, p.basename(value));
    }
    return out;
  }

  // --------------------------------------------------------------- helpers

  /// What each table of [scope] can actually take on this build.
  Future<Map<String, Set<String>>> _liveColumns(BackupScope scope) async {
    final Database db = _database.db;
    final Map<String, Set<String>> columns = <String, Set<String>>{};
    for (final String table in scope.tables) {
      final List<Map<String, Object?>> info =
          await db.rawQuery('PRAGMA table_info($table)');
      if (info.isEmpty) continue;
      columns[table] = <String>{
        for (final Map<String, Object?> row in info) row['name']! as String,
      };
    }
    return columns;
  }

  Future<int> _count(DatabaseExecutor db, String table) async {
    final List<Map<String, Object?>> rows =
        await db.rawQuery('SELECT COUNT(*) AS n FROM $table');
    return (rows.single['n']! as num).toInt();
  }

  Future<Set<String>> _ids(DatabaseExecutor db, String table) async {
    final List<Map<String, Object?>> rows =
        await db.rawQuery('SELECT id FROM $table');
    return <String>{for (final Map<String, Object?> r in rows) '${r['id']}'};
  }

  Future<Directory> _backupsDirectory() async {
    final Directory documents = await _documents();
    final Directory dir = Directory(p.join(documents.path, _backupsFolder));
    if (!dir.existsSync()) await dir.create(recursive: true);
    return dir;
  }

  Archive _open(String archivePath) =>
      ZipDecoder().decodeBytes(File(archivePath).readAsBytesSync());

  ArchiveFile? _entry(Archive archive, String name) {
    for (final ArchiveFile file in archive.files) {
      if (file.name == name && file.isFile) return file;
    }
    return null;
  }

  /// A name in [dir] that is not already taken.
  ///
  /// Two backups a minute apart used to land on the same name, and the second
  /// silently replaced the first. That is merely annoying for an ordinary
  /// export and destructive for the safety copy taken during a replace.
  String _freePath(Directory dir, String prefix, DateTime at) {
    final String stamp = _stamp(at);
    String candidate = p.join(dir.path, '$prefix-$stamp.zip');
    int suffix = 2;
    while (File(candidate).existsSync()) {
      candidate = p.join(dir.path, '$prefix-$stamp-$suffix.zip');
      suffix++;
    }
    return candidate;
  }

  /// `2026-09-14_1830`, which sorts and reads the same way round.
  String _stamp(DateTime at) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${at.year}-${two(at.month)}-${two(at.day)}'
        '_${two(at.hour)}${two(at.minute)}';
  }
}
