import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/services/escalation_engine.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:sqflite/sqflite.dart';

abstract final class EscalationMapper {
  static EscalationRule ruleFromRow(Map<String, Object?> row) => EscalationRule(
        id: row.str('id'),
        sortOrder: row.integer('sort_order'),
        nameVi: row.str('name_vi'),
        nameEn: row.str('name_en'),
        delayAfterDestroy: Duration(minutes: row.integer('delay_after_destroy_minutes')),
        notifyRole: UserRole.fromName(row.strOrNull('notify_role')),
        severity: EscalationSeverity.fromName(row.strOrNull('severity')),
        repeatEvery: row.durationOrNull('repeat_every_minutes'),
        maxRepeats: row.intOrNull('max_repeats'),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
      );

  static Map<String, Object?> ruleToRow(EscalationRule rule) => <String, Object?>{
        'id': rule.id,
        'sort_order': rule.sortOrder,
        'name_vi': rule.nameVi,
        'name_en': rule.nameEn,
        'delay_after_destroy_minutes': rule.delayAfterDestroy.inMinutes,
        'notify_role': rule.notifyRole.name,
        'severity': rule.severity.name,
        'repeat_every_minutes': rule.repeatEvery?.inMinutes,
        'max_repeats': rule.maxRepeats,
        'is_active': boolToInt(rule.isActive),
        'created_at': rule.createdAt.millisecondsSinceEpoch,
        'updated_at': rule.updatedAt.millisecondsSinceEpoch,
      };

  static Escalation fromRow(Map<String, Object?> row) => Escalation(
        id: row.str('id'),
        recordId: row.str('record_id'),
        ruleId: row.strOrNull('rule_id'),
        level: row.integer('level'),
        severity: EscalationSeverity.fromName(row.strOrNull('severity')),
        notifyRole: UserRole.fromName(row.strOrNull('notify_role')),
        dueAt: row.dateTime('due_at'),
        raisedAt: row.dateTime('raised_at'),
        resolvedAt: row.dateTimeOrNull('resolved_at'),
        resolution: row.strOrNull('resolution') == null
            ? null
            : EscalationResolution.fromName(row.strOrNull('resolution')),
        acknowledgedBy: row.strOrNull('acknowledged_by'),
        note: row.strOrNull('note'),
        createdAt: row.dateTime('created_at'),
      );

  static Map<String, Object?> toRow(Escalation escalation) => <String, Object?>{
        'id': escalation.id,
        'record_id': escalation.recordId,
        'rule_id': escalation.ruleId,
        'level': escalation.level,
        'severity': escalation.severity.name,
        'notify_role': escalation.notifyRole.name,
        'due_at': escalation.dueAt.millisecondsSinceEpoch,
        'raised_at': escalation.raisedAt.millisecondsSinceEpoch,
        'resolved_at': dateToMillis(escalation.resolvedAt),
        'resolution': escalation.resolution?.name,
        'acknowledged_by': escalation.acknowledgedBy,
        'note': escalation.note,
        'created_at': escalation.createdAt.millisecondsSinceEpoch,
      };
}

class EscalationRepositoryImpl implements EscalationRepository {
  const EscalationRepositoryImpl({
    required AppDatabase database,
    required InventoryRepository inventory,
    required EscalationEngine engine,
    required Clock clock,
    required IdGenerator ids,
    required SyncQueue syncQueue,
    required AuditRepository audit,
    required AppLogger logger,
    required String? Function() currentUserId,
  })  : _database = database,
        _inventory = inventory,
        _engine = engine,
        _clock = clock,
        _ids = ids,
        _syncQueue = syncQueue,
        _audit = audit,
        _logger = logger,
        _currentUserId = currentUserId;

  final AppDatabase _database;
  final InventoryRepository _inventory;
  final EscalationEngine _engine;
  final Clock _clock;
  final IdGenerator _ids;
  final SyncQueue _syncQueue;
  final AuditRepository _audit;
  final AppLogger _logger;
  final String? Function() _currentUserId;

  static const String _tag = 'EscalationRepository';

  // ------------------------------------------------------------------ rules

  @override
  Future<Result<List<EscalationRule>>> listRules({bool includeInactive = true}) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.escalationRules,
        where: includeInactive ? null : 'is_active = 1',
        orderBy: 'sort_order ASC',
      );
      return rows.map(EscalationMapper.ruleFromRow).toList(growable: false);
    });
  }

  @override
  Future<Result<int>> countRules() =>
      _guard(() => countOf(_database.db, 'SELECT COUNT(*) FROM ${Tables.escalationRules}'));

  @override
  Future<Result<EscalationRule>> upsertRule(EscalationRule rule) async {
    return _guard(() async {
      final List<Map<String, Object?>> existing = await _database.db.query(
        Tables.escalationRules,
        where: 'id = ?',
        whereArgs: <Object?>[rule.id],
        limit: 1,
      );
      final EscalationRule saved = rule.copyWith(updatedAt: _clock.now());
      await _database.write(<String>{Tables.escalationRules}, (Transaction txn) async {
        await txn.insert(
          Tables.escalationRules,
          EscalationMapper.ruleToRow(saved),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.escalationRules,
        entityId: saved.id,
        payload: EscalationMapper.ruleToRow(saved),
      );
      await _audit.append(AuditDraft(
        action: AuditAction.escalationRuleEdited,
        entity: Tables.escalationRules,
        entityId: saved.id,
        entityLabel: saved.nameVi,
        previousValue: existing.isEmpty
            ? null
            : EscalationMapper.ruleToRow(EscalationMapper.ruleFromRow(existing.first)),
        newValue: EscalationMapper.ruleToRow(saved),
      ),);
      return saved;
    });
  }

  @override
  Future<Result<void>> deleteRule(String ruleId) async {
    return _guard(() async {
      await _database.write(<String>{Tables.escalationRules}, (Transaction txn) async {
        await txn.delete(Tables.escalationRules, where: 'id = ?', whereArgs: <Object?>[ruleId]);
      });
      await _syncQueue.enqueueDelete(entity: Tables.escalationRules, entityId: ruleId);
      await _audit.append(AuditDraft(
        action: AuditAction.escalationRuleEdited,
        entity: Tables.escalationRules,
        entityId: ruleId,
        note: 'deleted',
      ),);
    });
  }

  @override
  Future<Result<void>> restoreDefaultRules() async {
    return _guard(() async {
      final DateTime now = _clock.now();
      final List<EscalationRule> rules =
          DefaultEscalationRules.build(newId: _ids.newId, now: now);
      await _database.write(<String>{Tables.escalationRules}, (Transaction txn) async {
        await txn.delete(Tables.escalationRules);
        for (final EscalationRule rule in rules) {
          await txn.insert(Tables.escalationRules, EscalationMapper.ruleToRow(rule));
        }
      });
      await _audit.append(const AuditDraft(
        action: AuditAction.escalationRuleEdited,
        entity: Tables.escalationRules,
        note: 'restored defaults',
      ),);
    });
  }

  // ----------------------------------------------------------------- alerts

  @override
  Future<Result<List<Escalation>>> raiseDue() async {
    final Result<List<EscalationRule>> rulesResult = await listRules(includeInactive: false);
    if (rulesResult.isErr) return Result<List<Escalation>>.err(rulesResult.failureOrNull!);
    final List<EscalationRule> rules = rulesResult.unwrap();
    if (rules.isEmpty) return const Result<List<Escalation>>.ok(<Escalation>[]);

    final DateTime now = _clock.now();
    final Result<List<InventoryItemView>> overdue = await _inventory.search(
      InventoryQuery(
        statuses: const <InventoryStatus>{InventoryStatus.active},
        destroyBefore: now,
        sort: InventorySort.destroyDate,
        limit: 2000,
      ),
    );
    if (overdue.isErr) return Result<List<Escalation>>.err(overdue.failureOrNull!);

    return _guard(() async {
      final List<Map<String, Object?>> raisedRows = await _database.db.query(
        Tables.escalations,
        columns: <String>['record_id', 'level'],
      );
      final Set<String> alreadyRaised = raisedRows
          .map((Map<String, Object?> r) =>
              EscalationEngine.key(r.str('record_id'), r.integer('level')),)
          .toSet();

      final List<EscalationCandidate> candidates = _engine.candidates(
        openOverdueItems: overdue.unwrap(),
        rules: rules,
        alreadyRaised: alreadyRaised,
        now: now,
      );
      if (candidates.isEmpty) return const <Escalation>[];

      final List<Escalation> created = <Escalation>[];
      final List<AuditDraft> audits = <AuditDraft>[];

      await _database.write(<String>{Tables.escalations}, (Transaction txn) async {
        for (final EscalationCandidate candidate in candidates) {
          final Escalation escalation = Escalation(
            id: _ids.newId(),
            recordId: candidate.item.record.id,
            ruleId: candidate.rule.id,
            level: candidate.level,
            severity: candidate.rule.severity,
            notifyRole: candidate.rule.notifyRole,
            dueAt: candidate.dueAt,
            raisedAt: now,
            createdAt: now,
          );
          await txn.insert(
            Tables.escalations,
            EscalationMapper.toRow(escalation),
            conflictAlgorithm: ConflictAlgorithm.ignore,
          );
          created.add(escalation);
          audits.add(AuditDraft(
            action: AuditAction.escalationRaised,
            entity: Tables.escalations,
            entityId: escalation.id,
            entityLabel: candidate.item.product.displayName,
            newValue: <String, Object?>{
              'recordId': escalation.recordId,
              'recordCode': candidate.item.record.code,
              'level': escalation.level,
              'severity': escalation.severity.name,
              'dueAt': escalation.dueAt.toIso8601String(),
              'destroyAt': candidate.item.record.destroyAt.toIso8601String(),
            },
            actorId: null,
            actorName: 'system',
            actorRole: 'system',
          ),);
        }
      });

      await _audit.appendAll(audits);
      for (final Escalation escalation in created) {
        await _syncQueue.enqueueUpsert(
          entity: Tables.escalations,
          entityId: escalation.id,
          payload: EscalationMapper.toRow(escalation),
        );
      }
      _logger.i(_tag, 'Raised ${created.length} escalation(s)');
      return created;
    });
  }

  @override
  Future<Result<List<EscalationView>>> listOpen() => _list('resolved_at IS NULL', 500);

  @override
  Future<Result<List<EscalationView>>> listResolved({int limit = 100}) =>
      _list('resolved_at IS NOT NULL', limit);

  Future<Result<List<EscalationView>>> _list(String where, int limit) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.escalations,
        where: where,
        orderBy: 'severity ASC, due_at ASC',
        limit: limit,
      );
      final List<EscalationView> views = <EscalationView>[];
      for (final Map<String, Object?> row in rows) {
        final Escalation escalation = EscalationMapper.fromRow(row);
        final Result<InventoryItemView?> item =
            await _inventory.findView(escalation.recordId);
        views.add(EscalationView(escalation: escalation, item: item.valueOrNull));
      }
      return views;
    });
  }

  @override
  Future<Result<int>> openCount({EscalationSeverity? severity}) async {
    return _guard(() async {
      if (severity == null) {
        return countOf(
          _database.db,
          'SELECT COUNT(*) FROM ${Tables.escalations} WHERE resolved_at IS NULL',
        );
      }
      return countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.escalations} '
        'WHERE resolved_at IS NULL AND severity = ?',
        <Object?>[severity.name],
      );
    });
  }

  @override
  Future<Result<Escalation>> acknowledge({
    required String escalationId,
    String? note,
  }) =>
      _close(
        escalationId: escalationId,
        resolution: EscalationResolution.acknowledged,
        note: note,
        action: AuditAction.escalationAcknowledged,
      );

  @override
  Future<Result<Escalation>> managerOverride({
    required String escalationId,
    required String reason,
  }) {
    if (reason.trim().isEmpty) {
      return Future<Result<Escalation>>.value(
        const Result<Escalation>.err(Failure.validation('override_reason_required')),
      );
    }
    return _close(
      escalationId: escalationId,
      resolution: EscalationResolution.override,
      note: reason.trim(),
      action: AuditAction.managerOverride,
    );
  }

  Future<Result<Escalation>> _close({
    required String escalationId,
    required EscalationResolution resolution,
    required AuditAction action,
    String? note,
  }) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.escalations,
        where: 'id = ?',
        whereArgs: <Object?>[escalationId],
        limit: 1,
      );
      if (rows.isEmpty) throw StateError('escalation_not_found');
      final Escalation before = EscalationMapper.fromRow(rows.first);
      final Escalation after = before.copyWith(
        resolvedAt: _clock.now(),
        resolution: resolution,
        acknowledgedBy: _currentUserId(),
        note: note,
      );

      await _database.write(<String>{Tables.escalations}, (Transaction txn) async {
        await txn.update(
          Tables.escalations,
          EscalationMapper.toRow(after),
          where: 'id = ?',
          whereArgs: <Object?>[escalationId],
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.escalations,
        entityId: after.id,
        payload: EscalationMapper.toRow(after),
      );
      await _audit.append(AuditDraft(
        action: action,
        entity: Tables.escalations,
        entityId: after.id,
        previousValue: EscalationMapper.toRow(before),
        newValue: EscalationMapper.toRow(after),
        note: note,
      ),);
      return after;
    });
  }

  @override
  Future<Result<int>> resolveForRecord({
    required String recordId,
    required EscalationResolution resolution,
    String? note,
  }) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.escalations,
        where: 'record_id = ? AND resolved_at IS NULL',
        whereArgs: <Object?>[recordId],
      );
      if (rows.isEmpty) return 0;

      final DateTime now = _clock.now();
      final List<AuditDraft> audits = <AuditDraft>[];
      await _database.write(<String>{Tables.escalations}, (Transaction txn) async {
        for (final Map<String, Object?> row in rows) {
          final Escalation before = EscalationMapper.fromRow(row);
          final Escalation after = before.copyWith(
            resolvedAt: now,
            resolution: resolution,
            acknowledgedBy: _currentUserId(),
            note: note,
          );
          await txn.update(
            Tables.escalations,
            EscalationMapper.toRow(after),
            where: 'id = ?',
            whereArgs: <Object?>[after.id],
          );
          audits.add(AuditDraft(
            action: AuditAction.escalationResolved,
            entity: Tables.escalations,
            entityId: after.id,
            previousValue: EscalationMapper.toRow(before),
            newValue: EscalationMapper.toRow(after),
            note: note,
          ),);
        }
      });
      await _audit.appendAll(audits);
      return rows.length;
    });
  }

  @override
  Stream<void> watch() => _database.changes.where(
        (String table) => table == Tables.escalations || table == Tables.escalationRules,
      );

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } on StateError catch (error) {
      return Result<T>.err(Failure.validation(error.message));
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Escalation operation failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('escalation_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
