import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/escalation/presentation/pages/escalation_rules_page.dart';
import 'package:expiry_guardian/features/escalation/presentation/viewmodels/manager_view_model.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/presentation/pages/record_detail_page.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Feature 3's manager-facing half: every lot that passed its destroy deadline
/// without a confirmation, raised automatically, and the two ways a manager can
/// close one - take ownership, or override with a written reason.
class ManagerDashboardPage extends ConsumerWidget {
  const ManagerDashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final bool canManage = ref.watch(permissionsProvider).contains(Permission.manageEscalations);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(l10n.t(K.escalationDashboard)),
          bottom: TabBar(
            tabs: <Widget>[
              Tab(text: l10n.t(K.escalationOpen)),
              Tab(text: l10n.t(K.escalationResolvedTab)),
            ],
          ),
          actions: <Widget>[
            IconButton(
              tooltip: l10n.t(K.escalationScanNow),
              icon: const Icon(Icons.refresh),
              onPressed: () => _scanNow(context, ref),
            ),
            if (canManage)
              IconButton(
                tooltip: l10n.t(K.escalationRules),
                icon: const Icon(Icons.rule_folder_outlined),
                onPressed: () => EscalationRulesPage.open(context),
              ),
          ],
        ),
        body: TabBarView(
          children: <Widget>[
            _EscalationList(provider: openEscalationsProvider, open: true, canManage: canManage),
            _EscalationList(
              provider: resolvedEscalationsProvider,
              open: false,
              canManage: canManage,
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _scanNow(BuildContext context, WidgetRef ref) async {
    final AppLocalizations l10n = context.l10n;
    final Result<WorkflowRefreshResult> result =
        await ref.read(workflowServiceProvider).refresh();
    invalidateEscalations(ref);
    if (!context.mounted) return;
    result.fold(
      (_) => showAppSnack(context, l10n.t(K.errorGeneric), isError: true),
      (WorkflowRefreshResult value) => showAppSnack(
        context,
        l10n.t(K.escalationRaisedCount, <String, Object?>{'count': value.escalationsRaised}),
      ),
    );
  }
}

class _EscalationList extends ConsumerWidget {
  const _EscalationList({
    required this.provider,
    required this.open,
    required this.canManage,
  });

  final FutureProvider<List<EscalationView>> provider;
  final bool open;
  final bool canManage;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<EscalationView>> alerts = ref.watch(provider);

    return alerts.when(
      loading: () => const LoadingView(),
      error: (Object error, StackTrace stack) => ErrorView(message: error.toString()),
      data: (List<EscalationView> views) {
        if (views.isEmpty) {
          return EmptyState(
            icon: open ? Icons.verified_outlined : Icons.history,
            title: l10n.t(K.escalationNone),
            message: open ? l10n.t(K.escalationNoneHint) : null,
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(Dimens.gutter),
          itemCount: views.length + 1,
          itemBuilder: (BuildContext context, int index) {
            if (index == 0) {
              return Padding(
                padding: const EdgeInsets.only(bottom: Dimens.gapM),
                child: NoticeBanner(
                  icon: Icons.supervisor_account_outlined,
                  tone: open ? NoticeTone.warning : NoticeTone.info,
                  message: l10n.t(K.escalationSubtitle),
                ),
              );
            }
            return Padding(
              padding: const EdgeInsets.only(bottom: Dimens.gapS),
              child: _EscalationCard(view: views[index - 1], canManage: canManage),
            );
          },
        );
      },
    );
  }
}

class _EscalationCard extends ConsumerWidget {
  const _EscalationCard({required this.view, required this.canManage});

  final EscalationView view;
  final bool canManage;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final Escalation alert = view.escalation;
    final InventoryItemView? item = view.item;
    final bool critical = alert.severity == EscalationSeverity.critical;
    final Color tone = critical ? theme.colorScheme.error : theme.colorScheme.tertiary;

    return AppCard(
      borderColor: alert.isOpen ? tone : null,
      onTap: item == null ? null : () => RecordDetailPage.open(context, item.record.id),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(critical ? Icons.crisis_alert : Icons.warning_amber_outlined, color: tone),
              const SizedBox(width: Dimens.gapS),
              Expanded(
                child: Text(
                  item?.product.displayName ?? l10n.t(K.commonUnknown),
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              Chip(
                visualDensity: VisualDensity.compact,
                label: Text(
                  l10n.t(K.escalationLevel, <String, Object?>{'level': alert.level}),
                ),
              ),
            ],
          ),
          if (item != null && item.locationLabel.isNotEmpty)
            Text(item.locationLabel, style: theme.textTheme.bodySmall),
          const SizedBox(height: Dimens.gapXs),
          Text(
            '${l10n.t(K.escalationRaisedAt)}: ${l10n.dateTime(alert.raisedAt)}',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
          if (item != null)
            Text(
              l10n.t(K.escalationOverdueBy, <String, Object?>{
                'duration': l10n.duration(
                  ref.read(clockProvider).now().difference(item.record.destroyAt),
                ),
              }),
              style: theme.textTheme.bodySmall?.copyWith(color: tone),
            ),
          if (!alert.isOpen) ...<Widget>[
            const SizedBox(height: Dimens.gapXs),
            Text(
              l10n.t(_resolutionKey(alert.resolution)),
              style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            if ((alert.note ?? '').isNotEmpty)
              Text(alert.note!, style: theme.textTheme.bodySmall),
          ],
          if (alert.isOpen && canManage) ...<Widget>[
            const SizedBox(height: Dimens.gapS),
            Wrap(
              spacing: Dimens.gapS,
              children: <Widget>[
                OutlinedButton.icon(
                  onPressed: () => _acknowledge(context, ref, alert),
                  icon: const Icon(Icons.how_to_reg_outlined, size: 18),
                  label: Text(l10n.t(K.escalationAcknowledge)),
                ),
                TextButton.icon(
                  onPressed: () => _override(context, ref, alert),
                  icon: const Icon(Icons.gavel_outlined, size: 18),
                  label: Text(l10n.t(K.escalationManagerOverride)),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  static String _resolutionKey(EscalationResolution? resolution) => switch (resolution) {
        EscalationResolution.destroyed => K.escalationResolutionDestroyed,
        EscalationResolution.acknowledged => K.escalationResolutionAcknowledged,
        EscalationResolution.override => K.escalationResolutionOverride,
        EscalationResolution.cancelled => K.escalationResolutionCancelled,
        null => K.commonUnknown,
      };

  Future<void> _acknowledge(BuildContext context, WidgetRef ref, Escalation alert) async {
    final AppLocalizations l10n = context.l10n;
    final Result<Escalation> result =
        await ref.read(workflowServiceProvider).acknowledge(escalationId: alert.id);
    invalidateEscalations(ref);
    if (!context.mounted) return;
    result.fold(
      (_) => showAppSnack(context, describeFailure(context, result.failureOrNull!), isError: true),
      (_) => showAppSnack(context, l10n.t(K.escalationAcknowledged)),
    );
  }

  Future<void> _override(BuildContext context, WidgetRef ref, Escalation alert) async {
    final AppLocalizations l10n = context.l10n;
    final TextEditingController controller = TextEditingController();
    final String? reason = await showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.escalationManagerOverride)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(l10n.t(K.escalationOverrideHint)),
            const SizedBox(height: Dimens.gapM),
            TextField(
              controller: controller,
              autofocus: true,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: l10n.t(K.escalationOverrideReason),
                border: const OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(controller.text.trim()),
            child: Text(l10n.t(K.commonConfirm)),
          ),
        ],
      ),
    );
    controller.dispose();
    if (reason == null) return;
    if (reason.isEmpty) {
      // The reason is what makes an override auditable, so an empty one is
      // refused rather than quietly written as a blank.
      if (!context.mounted) return;
      showAppSnack(context, l10n.t(K.escalationOverrideHint), isError: true);
      return;
    }

    final Result<Escalation> result = await ref.read(workflowServiceProvider).managerOverride(
          escalationId: alert.id,
          reason: reason,
        );
    invalidateEscalations(ref);
    if (!context.mounted) return;
    result.fold(
      (_) => showAppSnack(context, describeFailure(context, result.failureOrNull!), isError: true),
      (_) => showAppSnack(context, l10n.t(K.escalationOverrideDone)),
    );
  }
}
