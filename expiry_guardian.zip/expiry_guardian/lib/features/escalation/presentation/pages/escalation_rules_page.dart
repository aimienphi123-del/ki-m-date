import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/presentation/viewmodels/manager_view_model.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/users_page.dart' show roleLabel;
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:expiry_guardian/shared/widgets/duration_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// "24 hours after the deadline, tell a manager" as an editable row.
///
/// The delay, the role told, the severity and the chase-up interval are all
/// configurable, and a store can add further levels - level 2 to the admin
/// after another day, say.
class EscalationRulesPage extends ConsumerWidget {
  const EscalationRulesPage({super.key});

  static Future<void> open(BuildContext context) => Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const EscalationRulesPage()),
      );

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<EscalationRule>> rules = ref.watch(escalationRulesProvider);
    ref.watch(settingsRevisionProvider);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    final bool enabled =
        settings.readBool(SettingKeys.escalationEnabled, SettingDefaults.escalationEnabled);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.escalationRules)),
        actions: <Widget>[
          PopupMenuButton<String>(
            onSelected: (String value) async {
              if (value != 'defaults') return;
              await ref.read(escalationRepositoryProvider).restoreDefaultRules();
              invalidateEscalations(ref);
              ref.invalidate(escalationRulesProvider);
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'defaults',
                child: Text(l10n.t(K.escalationRestoreDefaults)),
              ),
            ],
          ),
        ],
      ),
      body: rules.when(
        loading: () => const LoadingView(),
        error: (Object error, StackTrace stack) => ErrorView(message: error.toString()),
        data: (List<EscalationRule> value) => ListView(
          padding: const EdgeInsets.fromLTRB(
            Dimens.gutter,
            Dimens.gutter,
            Dimens.gutter,
            Dimens.gapXl * 4,
          ),
          children: <Widget>[
            NoticeBanner(
              icon: Icons.supervisor_account_outlined,
              message: l10n.t(K.escalationSubtitle),
            ),
            const SizedBox(height: Dimens.gapM),
            AppCard(
              child: SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l10n.t(K.escalationEnabled)),
                value: enabled,
                onChanged: (bool on) async {
                  await writeSettingFrom(ref, SettingKeys.escalationEnabled, on);
                  await ref.read(workflowServiceProvider).refresh();
                  invalidateEscalations(ref);
                },
              ),
            ),
            SectionHeader(title: l10n.t(K.escalationRules)),
            if (value.isEmpty)
              EmptyState(
                icon: Icons.rule_folder_outlined,
                title: l10n.t(K.escalationNewRule),
                message: l10n.t(K.escalationSubtitle),
              )
            else
              for (final EscalationRule rule in value)
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimens.gapS),
                  child: _RuleCard(rule: rule),
                ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => EscalationRuleEditorPage.open(context),
        icon: const Icon(Icons.add),
        label: Text(l10n.t(K.escalationNewRule)),
      ),
    );
  }
}

class _RuleCard extends ConsumerWidget {
  const _RuleCard({required this.rule});

  final EscalationRule rule;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    return AppCard(
      onTap: () => EscalationRuleEditorPage.open(context, rule: rule),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Icon(
            rule.severity == EscalationSeverity.critical
                ? Icons.crisis_alert
                : Icons.warning_amber_outlined,
            color: rule.severity == EscalationSeverity.critical
                ? theme.colorScheme.error
                : theme.colorScheme.tertiary,
          ),
          const SizedBox(width: Dimens.gapM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  escalationRuleName(l10n, rule),
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                ),
                Text(
                  '${l10n.t(K.escalationDelayAfterDestroy)}: '
                  '${l10n.duration(rule.delayAfterDestroy)}',
                  style: theme.textTheme.bodySmall,
                ),
                Text(
                  '${l10n.t(K.escalationNotifyRole)}: ${roleLabel(l10n, rule.notifyRole)}',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
                if (rule.repeatEvery != null)
                  Text(
                    '${l10n.t(K.escalationRepeatEvery)}: ${l10n.duration(rule.repeatEvery!)}'
                    ' · ${l10n.t(K.escalationMaxRepeats)}: ${rule.maxRepeats ?? 0}',
                    style: theme.textTheme.bodySmall,
                  ),
              ],
            ),
          ),
          Switch(
            value: rule.isActive,
            onChanged: (bool value) async {
              await ref.read(escalationRepositoryProvider).upsertRule(
                    rule.copyWith(isActive: value, updatedAt: ref.read(clockProvider).now()),
                  );
              ref.invalidate(escalationRulesProvider);
              invalidateEscalations(ref);
            },
          ),
        ],
      ),
    );
  }
}

String escalationRuleName(AppLocalizations l10n, EscalationRule rule) {
  final String name = l10n.locale.languageCode == 'en' ? rule.nameEn : rule.nameVi;
  return name.isEmpty
      ? l10n.t(K.escalationLevel, <String, Object?>{'level': rule.sortOrder})
      : name;
}

class EscalationRuleEditorPage extends ConsumerStatefulWidget {
  const EscalationRuleEditorPage({this.rule, super.key});

  final EscalationRule? rule;

  static Future<void> open(BuildContext context, {EscalationRule? rule}) =>
      Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => EscalationRuleEditorPage(rule: rule)),
      );

  @override
  ConsumerState<EscalationRuleEditorPage> createState() => _EscalationRuleEditorPageState();
}

class _EscalationRuleEditorPageState extends ConsumerState<EscalationRuleEditorPage> {
  late final TextEditingController _nameVi;
  late final TextEditingController _nameEn;
  late Duration _delay;
  late UserRole _role;
  late EscalationSeverity _severity;
  late bool _repeats;
  late Duration _repeatEvery;
  late int _maxRepeats;
  late bool _isActive;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final EscalationRule? rule = widget.rule;
    _nameVi = TextEditingController(text: rule?.nameVi ?? '');
    _nameEn = TextEditingController(text: rule?.nameEn ?? '');
    _delay = rule?.delayAfterDestroy ?? const Duration(hours: 24);
    _role = rule?.notifyRole ?? UserRole.manager;
    _severity = rule?.severity ?? EscalationSeverity.critical;
    _repeats = rule?.repeatEvery != null;
    _repeatEvery = rule?.repeatEvery ?? const Duration(hours: 12);
    _maxRepeats = rule?.maxRepeats ?? 4;
    _isActive = rule?.isActive ?? true;
  }

  @override
  void dispose() {
    _nameVi.dispose();
    _nameEn.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final bool isNew = widget.rule == null;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(isNew ? K.escalationNewRule : K.escalationEditRule)),
        actions: <Widget>[
          if (!isNew)
            IconButton(
              tooltip: l10n.t(K.commonDelete),
              icon: const Icon(Icons.delete_outline),
              onPressed: _saving ? null : _delete,
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(Dimens.gutter),
        children: <Widget>[
          AppCard(
            child: Column(
              children: <Widget>[
                TextField(
                  controller: _nameVi,
                  decoration: InputDecoration(
                    labelText: '${l10n.t(K.escalationRuleName)} (VI)',
                  ),
                ),
                const SizedBox(height: Dimens.gapS),
                TextField(
                  controller: _nameEn,
                  decoration: InputDecoration(
                    labelText: '${l10n.t(K.escalationRuleName)} (EN)',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: Dimens.gapM),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                DurationField(
                  label: l10n.t(K.escalationDelayAfterDestroy),
                  value: _delay,
                  onChanged: (Duration? value) =>
                      setState(() => _delay = value ?? const Duration(hours: 24)),
                ),
                const SizedBox(height: Dimens.gapM),
                DropdownButtonFormField<UserRole>(
                  initialValue: _role,
                  decoration: InputDecoration(labelText: l10n.t(K.escalationNotifyRole)),
                  items: <DropdownMenuItem<UserRole>>[
                    for (final UserRole role in UserRole.values)
                      DropdownMenuItem<UserRole>(
                        value: role,
                        child: Text(roleLabel(l10n, role)),
                      ),
                  ],
                  onChanged: (UserRole? value) => setState(() => _role = value ?? _role),
                ),
                const SizedBox(height: Dimens.gapM),
                SegmentedButton<EscalationSeverity>(
                  segments: <ButtonSegment<EscalationSeverity>>[
                    ButtonSegment<EscalationSeverity>(
                      value: EscalationSeverity.warning,
                      label: Text(l10n.t(K.escalationSeverityWarning)),
                    ),
                    ButtonSegment<EscalationSeverity>(
                      value: EscalationSeverity.critical,
                      label: Text(l10n.t(K.escalationSeverityCritical)),
                    ),
                  ],
                  selected: <EscalationSeverity>{_severity},
                  onSelectionChanged: (Set<EscalationSeverity> value) =>
                      setState(() => _severity = value.first),
                ),
              ],
            ),
          ),
          const SizedBox(height: Dimens.gapM),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l10n.t(K.escalationRepeatEvery)),
                  value: _repeats,
                  onChanged: (bool value) => setState(() => _repeats = value),
                ),
                if (_repeats) ...<Widget>[
                  DurationField(
                    label: l10n.t(K.escalationRepeatEvery),
                    value: _repeatEvery,
                    onChanged: (Duration? value) =>
                        setState(() => _repeatEvery = value ?? const Duration(hours: 12)),
                  ),
                  const SizedBox(height: Dimens.gapM),
                  TextFormField(
                    initialValue: '$_maxRepeats',
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: l10n.t(K.escalationMaxRepeats)),
                    onChanged: (String value) =>
                        _maxRepeats = int.tryParse(value.trim()) ?? _maxRepeats,
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: Dimens.gapM),
          AppCard(
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(l10n.t(K.escalationEnabled)),
              value: _isActive,
              onChanged: (bool value) => setState(() => _isActive = value),
            ),
          ),
          const SizedBox(height: Dimens.gapL),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: const Icon(Icons.check),
            label: Text(l10n.t(K.commonSave)),
          ),
        ],
      ),
    );
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final DateTime now = ref.read(clockProvider).now();
    final EscalationRule? existing = widget.rule;
    final EscalationRule rule = existing == null
        ? EscalationRule(
            id: '',
            sortOrder: _delay.inMinutes,
            nameVi: _nameVi.text.trim(),
            nameEn: _nameEn.text.trim(),
            delayAfterDestroy: _delay,
            notifyRole: _role,
            severity: _severity,
            repeatEvery: _repeats ? _repeatEvery : null,
            maxRepeats: _repeats ? _maxRepeats : null,
            isActive: _isActive,
            createdAt: now,
            updatedAt: now,
          )
        : existing.copyWith(
            nameVi: _nameVi.text.trim(),
            nameEn: _nameEn.text.trim(),
            delayAfterDestroy: _delay,
            notifyRole: _role,
            severity: _severity,
            repeatEvery: _repeats ? _repeatEvery : null,
            clearRepeatEvery: !_repeats,
            maxRepeats: _repeats ? _maxRepeats : null,
            clearMaxRepeats: !_repeats,
            isActive: _isActive,
            updatedAt: now,
          );

    final Result<EscalationRule> result =
        await ref.read(escalationRepositoryProvider).upsertRule(rule);
    ref.invalidate(escalationRulesProvider);
    invalidateEscalations(ref);
    if (!mounted) return;
    setState(() => _saving = false);
    if (result.isErr) {
      showAppSnack(context, describeFailure(context, result.failureOrNull!), isError: true);
      return;
    }
    Navigator.of(context).pop();
  }

  Future<void> _delete() async {
    final EscalationRule? rule = widget.rule;
    if (rule == null) return;
    final bool confirmed = await confirmDialog(
      context,
      title: context.l10n.t(K.commonDelete),
      message: escalationRuleName(context.l10n, rule),
      destructive: true,
    );
    if (!confirmed) return;
    await ref.read(escalationRepositoryProvider).deleteRule(rule.id);
    ref.invalidate(escalationRulesProvider);
    invalidateEscalations(ref);
    if (!mounted) return;
    Navigator.of(context).pop();
  }
}
