import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Alerts still waiting for a manager, worst first.
final FutureProvider<List<EscalationView>> openEscalationsProvider =
    FutureProvider<List<EscalationView>>((Ref ref) async {
  ref
    ..watch(escalationChangesProvider)
    ..watch(inventoryChangesProvider);
  final Result<List<EscalationView>> result =
      await ref.watch(escalationRepositoryProvider).listOpen();
  return result.valueOrNull ?? const <EscalationView>[];
});

/// What has already been dealt with, newest first - the manager's paper trail.
final FutureProvider<List<EscalationView>> resolvedEscalationsProvider =
    FutureProvider<List<EscalationView>>((Ref ref) async {
  ref.watch(escalationChangesProvider);
  final Result<List<EscalationView>> result =
      await ref.watch(escalationRepositoryProvider).listResolved();
  return result.valueOrNull ?? const <EscalationView>[];
});

/// The editable escalation rules.
final FutureProvider<List<EscalationRule>> escalationRulesProvider =
    FutureProvider<List<EscalationRule>>((Ref ref) async {
  ref.watch(escalationChangesProvider);
  final Result<List<EscalationRule>> result =
      await ref.watch(escalationRepositoryProvider).listRules();
  return result.valueOrNull ?? const <EscalationRule>[];
});

/// How many open alerts are critical, for the red badge.
final FutureProvider<int> criticalEscalationCountProvider = FutureProvider<int>((Ref ref) async {
  ref.watch(escalationChangesProvider);
  final Result<int> result = await ref
      .watch(escalationRepositoryProvider)
      .openCount(severity: EscalationSeverity.critical);
  return result.valueOrNull ?? 0;
});

/// Rebuilds every escalation-related provider after an action.
void invalidateEscalations(WidgetRef ref) {
  ref
    ..invalidate(openEscalationsProvider)
    ..invalidate(resolvedEscalationsProvider)
    ..invalidate(criticalEscalationCountProvider)
    ..invalidate(openEscalationCountProvider);
}
