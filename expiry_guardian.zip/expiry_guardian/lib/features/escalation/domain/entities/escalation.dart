import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';

enum EscalationSeverity {
  warning,
  critical;

  static EscalationSeverity fromName(String? value) =>
      value == 'critical' ? EscalationSeverity.critical : EscalationSeverity.warning;

  int get rank => this == EscalationSeverity.critical ? 0 : 1;
}

enum EscalationResolution {
  /// The stock was destroyed and confirmed.
  destroyed,

  /// A manager saw the alert and took ownership of it.
  acknowledged,

  /// A manager closed the alert without a destruction, with a written reason.
  override,

  /// The lot was closed some other way (sold out, removed).
  cancelled;

  static EscalationResolution fromName(String? value) =>
      EscalationResolution.values.firstWhere(
        (EscalationResolution r) => r.name == value,
        orElse: () => EscalationResolution.acknowledged,
      );
}

/// One configurable escalation step.
///
/// The shipped default is exactly the handbook rule - notify a manager 24
/// hours after the destroy deadline - but the delay, the role, the severity
/// and the chase-up interval are all rows a manager edits, and more levels can
/// be added.
class EscalationRule {
  const EscalationRule({
    required this.id,
    required this.sortOrder,
    required this.nameVi,
    required this.nameEn,
    required this.delayAfterDestroy,
    required this.notifyRole,
    required this.severity,
    required this.createdAt,
    required this.updatedAt,
    this.repeatEvery,
    this.maxRepeats,
    this.isActive = true,
  });

  final String id;

  /// Level order. The first rule is level 1, the next level 2, and so on.
  final int sortOrder;

  final String nameVi;
  final String nameEn;

  /// How long after the destroy instant this level fires.
  final Duration delayAfterDestroy;

  /// Who should be told. Only a signed-in user with at least this role gets
  /// the local alert on their handset.
  final UserRole notifyRole;

  final EscalationSeverity severity;

  /// Optional chase-ups for the manager while the alert stays open.
  final Duration? repeatEvery;
  final int? maxRepeats;

  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  /// The instants a manager should be alerted for a lot due at [destroyAt].
  List<DateTime> alertTimesFor(DateTime destroyAt) {
    final DateTime first = destroyAt.add(delayAfterDestroy);
    final Duration? every = repeatEvery;
    final int repeats = maxRepeats ?? 0;
    if (every == null || every <= Duration.zero || repeats <= 0) {
      return <DateTime>[first];
    }
    return List<DateTime>.generate(repeats + 1, (int i) => first.add(every * i));
  }

  EscalationRule copyWith({
    int? sortOrder,
    String? nameVi,
    String? nameEn,
    Duration? delayAfterDestroy,
    UserRole? notifyRole,
    EscalationSeverity? severity,
    Duration? repeatEvery,
    bool clearRepeatEvery = false,
    int? maxRepeats,
    bool clearMaxRepeats = false,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return EscalationRule(
      id: id,
      sortOrder: sortOrder ?? this.sortOrder,
      nameVi: nameVi ?? this.nameVi,
      nameEn: nameEn ?? this.nameEn,
      delayAfterDestroy: delayAfterDestroy ?? this.delayAfterDestroy,
      notifyRole: notifyRole ?? this.notifyRole,
      severity: severity ?? this.severity,
      repeatEvery: clearRepeatEvery ? null : (repeatEvery ?? this.repeatEvery),
      maxRepeats: clearMaxRepeats ? null : (maxRepeats ?? this.maxRepeats),
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() =>
      'EscalationRule(level $sortOrder, +$delayAfterDestroy, ${severity.name})';
}

/// A raised alert: one lot, one level, open until somebody deals with it.
class Escalation {
  const Escalation({
    required this.id,
    required this.recordId,
    required this.level,
    required this.severity,
    required this.notifyRole,
    required this.dueAt,
    required this.raisedAt,
    required this.createdAt,
    this.ruleId,
    this.resolvedAt,
    this.resolution,
    this.acknowledgedBy,
    this.note,
  });

  final String id;
  final String recordId;
  final String? ruleId;

  /// 1 for the first rule, 2 for the second, and so on.
  final int level;

  final EscalationSeverity severity;
  final UserRole notifyRole;

  /// The instant the rule said this lot should have been escalated.
  final DateTime dueAt;

  /// When the app actually noticed. Later than [dueAt] if the phone was off.
  final DateTime raisedAt;

  final DateTime? resolvedAt;
  final EscalationResolution? resolution;
  final String? acknowledgedBy;
  final String? note;
  final DateTime createdAt;

  bool get isOpen => resolvedAt == null;

  Escalation copyWith({
    DateTime? resolvedAt,
    EscalationResolution? resolution,
    String? acknowledgedBy,
    String? note,
  }) {
    return Escalation(
      id: id,
      recordId: recordId,
      ruleId: ruleId,
      level: level,
      severity: severity,
      notifyRole: notifyRole,
      dueAt: dueAt,
      raisedAt: raisedAt,
      resolvedAt: resolvedAt ?? this.resolvedAt,
      resolution: resolution ?? this.resolution,
      acknowledgedBy: acknowledgedBy ?? this.acknowledgedBy,
      note: note ?? this.note,
      createdAt: createdAt,
    );
  }

  @override
  String toString() => 'Escalation(level $level, ${severity.name}, open=$isOpen)';
}

/// The default handbook rule, written on first launch and editable after that.
abstract final class DefaultEscalationRules {
  static List<EscalationRule> build({
    required String Function() newId,
    required DateTime now,
  }) {
    return <EscalationRule>[
      EscalationRule(
        id: newId(),
        sortOrder: 1,
        nameVi: 'Báo quản lý sau 24 giờ',
        nameEn: 'Notify the manager after 24 hours',
        delayAfterDestroy: const Duration(hours: 24),
        notifyRole: UserRole.manager,
        severity: EscalationSeverity.critical,
        repeatEvery: const Duration(hours: 12),
        maxRepeats: 4,
        createdAt: now,
        updatedAt: now,
      ),
    ];
  }
}
