import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';

/// One alert the engine says should exist.
class EscalationCandidate {
  const EscalationCandidate({
    required this.item,
    required this.rule,
    required this.level,
    required this.dueAt,
  });

  final InventoryItemView item;
  final EscalationRule rule;
  final int level;

  /// The instant the rule became due for this lot.
  final DateTime dueAt;
}

/// Decides which lots have to be raised to a manager, and what the manager's
/// phone should be told and when.
///
/// Pure: it takes the open lots, the rules and the clock, and returns
/// decisions. Nothing here reads a database or a platform channel, so every
/// branch is covered by unit tests.
class EscalationEngine {
  const EscalationEngine();

  /// Lots whose destroy deadline passed longer ago than a rule allows and
  /// which nobody has confirmed. [alreadyRaised] holds the `recordId:level`
  /// pairs that exist already, so the same alert is never raised twice.
  List<EscalationCandidate> candidates({
    required List<InventoryItemView> openOverdueItems,
    required List<EscalationRule> rules,
    required Set<String> alreadyRaised,
    required DateTime now,
  }) {
    final List<EscalationRule> active = rules
        .where((EscalationRule r) => r.isActive)
        .toList()
      ..sort((EscalationRule a, EscalationRule b) => a.sortOrder.compareTo(b.sortOrder));
    if (active.isEmpty) return const <EscalationCandidate>[];

    final List<EscalationCandidate> out = <EscalationCandidate>[];
    for (final InventoryItemView item in openOverdueItems) {
      for (int index = 0; index < active.length; index++) {
        final EscalationRule rule = active[index];
        final int level = index + 1;
        final DateTime dueAt = item.record.destroyAt.add(rule.delayAfterDestroy);
        if (dueAt.isAfter(now)) continue;
        if (alreadyRaised.contains(key(item.record.id, level))) continue;
        out.add(EscalationCandidate(
          item: item,
          rule: rule,
          level: level,
          dueAt: dueAt,
        ),);
      }
    }

    out.sort((EscalationCandidate a, EscalationCandidate b) {
      final int bySeverity = a.rule.severity.rank.compareTo(b.rule.severity.rank);
      if (bySeverity != 0) return bySeverity;
      return a.dueAt.compareTo(b.dueAt);
    });
    return out;
  }

  static String key(String recordId, int level) => '$recordId:$level';

  /// Alerts to put on the manager's phone for the lots that are still open.
  ///
  /// Only produced when the signed-in user actually holds the role the rule
  /// names - a local notification can only reach the handset it is scheduled
  /// on, so alerting an employee's phone about a manager escalation would be
  /// noise, not oversight.
  List<AppNotification> notifications({
    required List<InventoryItemView> openOverdueItems,
    required List<EscalationRule> rules,
    required UserRole? viewerRole,
    required AppLocalizations strings,
    required DateTime now,
  }) {
    if (viewerRole == null) return const <AppNotification>[];

    final List<AppNotification> out = <AppNotification>[];
    for (final InventoryItemView item in openOverdueItems) {
      for (final EscalationRule rule in rules.where((EscalationRule r) => r.isActive)) {
        if (!viewerRole.atLeast(rule.notifyRole)) continue;
        final List<DateTime> times = rule.alertTimesFor(item.record.destroyAt);
        for (int index = 0; index < times.length; index++) {
          if (!times[index].isAfter(now)) continue;
          final String location = item.locationLabel;
          out.add(AppNotification(
            id: NotificationPlanner.notificationId(
              'escalation:${rule.id}',
              item.record.id,
              index,
            ),
            kind: NotificationKind.escalation,
            title: strings.t(K.notifEscalationTitle),
            body: strings.t(K.notifEscalationBody, <String, Object?>{
              'product': item.product.displayName,
              'location': location.isEmpty ? strings.t(K.todayNoShelf) : location,
              'duration': strings.duration(rule.delayAfterDestroy),
            }),
            scheduledFor: times[index],
            recordId: item.record.id,
            payload: 'record:${item.record.id}',
            severity: rule.severity == EscalationSeverity.critical
                ? NotificationSeverity.critical
                : NotificationSeverity.high,
          ),);
        }
      }
    }
    return out;
  }
}
