import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';

/// An open alert joined with the lot it is about - what the manager dashboard
/// actually renders.
class EscalationView {
  const EscalationView({required this.escalation, required this.item});

  final Escalation escalation;

  /// Null when the lot has since been deleted; the alert is still shown so the
  /// history stays complete.
  final InventoryItemView? item;
}

abstract interface class EscalationRepository {
  // --- rules -------------------------------------------------------------
  Future<Result<List<EscalationRule>>> listRules({bool includeInactive = true});
  Future<Result<EscalationRule>> upsertRule(EscalationRule rule);
  Future<Result<void>> deleteRule(String ruleId);
  Future<Result<void>> restoreDefaultRules();
  Future<Result<int>> countRules();

  // --- alerts ------------------------------------------------------------

  /// Raises every alert that is due and does not exist yet. Returns what it
  /// created. Safe to call as often as you like.
  Future<Result<List<Escalation>>> raiseDue();

  Future<Result<List<EscalationView>>> listOpen();

  Future<Result<List<EscalationView>>> listResolved({int limit = 100});

  Future<Result<int>> openCount({EscalationSeverity? severity});

  Future<Result<Escalation>> acknowledge({
    required String escalationId,
    String? note,
  });

  /// Closes the alert without a destruction. A written reason is required and
  /// the whole decision lands in the audit trail as a manager override.
  Future<Result<Escalation>> managerOverride({
    required String escalationId,
    required String reason,
  });

  /// Closes every open alert for a lot, used when it is finally destroyed or
  /// otherwise closed.
  Future<Result<int>> resolveForRecord({
    required String recordId,
    required EscalationResolution resolution,
    String? note,
  });

  Stream<void> watch();
}
