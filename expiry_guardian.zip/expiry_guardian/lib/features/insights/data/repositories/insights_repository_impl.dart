import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/insights/domain/entities/insight_models.dart';
import 'package:expiry_guardian/features/insights/domain/repositories/insights_repository.dart';
import 'package:expiry_guardian/features/insights/domain/services/prediction_engine.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';

class InsightsRepositoryImpl implements InsightsRepository {
  const InsightsRepositoryImpl({
    required AnalyticsRepository analytics,
    required InventoryRepository inventory,
    required PredictionEngine engine,
    required Clock clock,
  })  : _analytics = analytics,
        _inventory = inventory,
        _engine = engine,
        _clock = clock;

  final AnalyticsRepository _analytics;
  final InventoryRepository _inventory;
  final PredictionEngine _engine;
  final Clock _clock;

  PredictionConfig get _config => _engine.config;

  @override
  Future<Result<InsightsSnapshot>> snapshot() async {
    final DateTime now = _clock.now();
    final ReportPeriod lookback = ReportPeriod.lastDays(now, _config.lookbackDays);

    final Result<int> samplesResult = await _analytics.destructionSampleSize();
    if (samplesResult.isErr) return Result<InsightsSnapshot>.err(samplesResult.failureOrNull!);
    final int samples = samplesResult.unwrap();

    final Result<List<WasteStats>> shelfStats = await _analytics.wasteByShelf(lookback);
    if (shelfStats.isErr) return Result<InsightsSnapshot>.err(shelfStats.failureOrNull!);

    final Result<List<WasteStats>> categoryStats = await _analytics.wasteByCategory(lookback);
    if (categoryStats.isErr) return Result<InsightsSnapshot>.err(categoryStats.failureOrNull!);

    final Result<List<WasteStats>> productStats = await _analytics.wasteByProduct(lookback);
    if (productStats.isErr) return Result<InsightsSnapshot>.err(productStats.failureOrNull!);

    final Result<DestructionReport> history = await _analytics.destructionReport(lookback);
    if (history.isErr) return Result<InsightsSnapshot>.err(history.failureOrNull!);

    final RiskRanking shelfRisk =
        _engine.rank(shelfStats.unwrap(), totalDestructions: samples);
    final RiskRanking categoryRisk =
        _engine.rank(categoryStats.unwrap(), totalDestructions: samples);

    // "Frequently forgotten" is measured as destructions that happened after
    // the policy deadline, not as destructions in general.
    final RiskRanking forgotten = _engine.rank(
      productStats.unwrap(),
      totalDestructions: samples,
      rankByOverdue: true,
    );

    final Result<List<InventoryItemView>> due = await _inventory.destroyList(
      until: now.add(const Duration(days: 1)),
    );
    if (due.isErr) return Result<InsightsSnapshot>.err(due.failureOrNull!);

    final Result<List<InventoryItemView>> horizon = await _inventory.destroyList(
      until: now.add(Duration(days: _config.forecastDays)),
    );
    if (horizon.isErr) return Result<InsightsSnapshot>.err(horizon.failureOrNull!);

    return Result<InsightsSnapshot>.ok(InsightsSnapshot(
      shelfRisk: shelfRisk,
      categoryRisk: categoryRisk,
      forgottenProducts: forgotten,
      route: _engine.buildRoute(
        dueItems: due.unwrap(),
        shelfRisk: shelfRisk,
        generatedAt: now,
      ),
      forecast: _engine.forecast(
        scheduledItems: horizon.unwrap(),
        history: history.unwrap(),
        generatedAt: now,
      ),
      generatedAt: now,
    ),);
  }

  @override
  Future<Result<InspectionRoute>> route({Duration window = const Duration(days: 1)}) async {
    final DateTime now = _clock.now();
    final Result<List<InventoryItemView>> due =
        await _inventory.destroyList(until: now.add(window));
    if (due.isErr) return Result<InspectionRoute>.err(due.failureOrNull!);

    final ReportPeriod lookback = ReportPeriod.lastDays(now, _config.lookbackDays);
    final Result<int> samples = await _analytics.destructionSampleSize();
    final Result<List<WasteStats>> shelfStats = await _analytics.wasteByShelf(lookback);
    if (samples.isErr || shelfStats.isErr) {
      return Result<InspectionRoute>.err(
        samples.failureOrNull ?? shelfStats.failureOrNull ?? const Failure.unknown('insights'),
      );
    }

    return Result<InspectionRoute>.ok(_engine.buildRoute(
      dueItems: due.unwrap(),
      shelfRisk: _engine.rank(shelfStats.unwrap(), totalDestructions: samples.unwrap()),
      generatedAt: now,
    ),);
  }
}
