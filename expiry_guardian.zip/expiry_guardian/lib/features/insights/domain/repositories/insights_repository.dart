import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/insights/domain/entities/insight_models.dart';

abstract interface class InsightsRepository {
  Future<Result<InsightsSnapshot>> snapshot();
  Future<Result<InspectionRoute>> route({Duration window = const Duration(days: 1)});
}
