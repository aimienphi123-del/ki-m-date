import 'dart:math' as math;

import 'package:expiry_guardian/features/insights/domain/entities/insight_models.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_models.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';

/// Tunable analysis parameters, all editable in Settings.
class PredictionConfig {
  const PredictionConfig({
    this.minimumSamplesPerEntry = 5,
    this.minimumTotalSamples = 8,
    this.lookbackDays = 180,
    this.forecastDays = 30,
    this.confidenceZ = 1.96,
    this.secondsPerItem = 45,
    this.secondsPerStop = 60,
    this.maxEntries = 10,
  });

  /// A shelf needs at least this many intake lots before it can be ranked.
  final int minimumSamplesPerEntry;

  /// The store needs at least this many destructions before any ranking is
  /// shown at all.
  final int minimumTotalSamples;

  final int lookbackDays;
  final int forecastDays;

  /// 1.96 = 95% confidence.
  final double confidenceZ;

  final int secondsPerItem;
  final int secondsPerStop;
  final int maxEntries;
}

/// Turns real historical aggregates into the predictions shown on the
/// insights screen.
///
/// Two rules govern everything here:
///  * ranking uses the **lower bound** of the confidence interval, so a shelf
///    with one unlucky lot never outranks a shelf with a real problem;
///  * when there is not enough history the engine returns
///    [InsightAvailability.insufficientData] instead of a number.
class PredictionEngine {
  const PredictionEngine({this.config = const PredictionConfig()});

  final PredictionConfig config;

  /// Wilson score interval lower bound for `successes / trials`.
  static double wilsonLowerBound(int successes, int trials, {double z = 1.96}) {
    if (trials <= 0) return 0;
    final double n = trials.toDouble();
    final double phat = successes / n;
    final double z2 = z * z;
    final double denominator = 1 + z2 / n;
    final double centre = phat + z2 / (2 * n);
    final double margin = z * math.sqrt((phat * (1 - phat) + z2 / (4 * n)) / n);
    final double lower = (centre - margin) / denominator;
    return lower.clamp(0.0, 1.0);
  }

  RiskRanking rank(
    List<WasteStats> stats, {
    required int totalDestructions,
    bool rankByOverdue = false,
  }) {
    if (totalDestructions < config.minimumTotalSamples) {
      return RiskRanking.insufficient(
        sampleSize: totalDestructions,
        lookbackDays: config.lookbackDays,
        minimumSamples: config.minimumTotalSamples,
      );
    }

    final List<RiskEntry> entries = <RiskEntry>[];
    for (final WasteStats stat in stats) {
      final int trials = rankByOverdue ? stat.destroyedRecords : stat.intakeRecords;
      final int successes = rankByOverdue ? stat.overdueRecords : stat.destroyedRecords;
      final InsightAvailability availability = trials == 0
          ? InsightAvailability.noHistory
          : trials < config.minimumSamplesPerEntry
              ? InsightAvailability.insufficientData
              : InsightAvailability.ready;

      entries.add(RiskEntry(
        key: stat.key,
        label: stat.label,
        intakeRecords: stat.intakeRecords,
        destroyedRecords: stat.destroyedRecords,
        overdueRecords: stat.overdueRecords,
        loss: stat.loss,
        rate: trials == 0 ? 0 : successes / trials,
        rateLowerBound: wilsonLowerBound(successes, trials, z: config.confidenceZ),
        availability: availability,
      ),);
    }

    final List<RiskEntry> ready = entries.where((RiskEntry e) => e.isReady).toList()
      ..sort((RiskEntry a, RiskEntry b) {
        final int byBound = b.rateLowerBound.compareTo(a.rateLowerBound);
        if (byBound != 0) return byBound;
        return b.loss.compareTo(a.loss);
      });

    if (ready.isEmpty) {
      return RiskRanking.insufficient(
        sampleSize: totalDestructions,
        lookbackDays: config.lookbackDays,
        minimumSamples: config.minimumSamplesPerEntry,
      );
    }

    return RiskRanking(
      entries: ready.take(config.maxEntries).toList(growable: false),
      availability: InsightAvailability.ready,
      sampleSize: totalDestructions,
      lookbackDays: config.lookbackDays,
      minimumSamples: config.minimumSamplesPerEntry,
    );
  }

  /// Orders the shelves that need visiting into a single walk, following the
  /// store's own area and shelf ordering, urgent stops first.
  InspectionRoute buildRoute({
    required List<InventoryItemView> dueItems,
    required RiskRanking shelfRisk,
    required DateTime generatedAt,
  }) {
    if (dueItems.isEmpty) return InspectionRoute.empty(generatedAt);

    final Map<String, List<InventoryItemView>> byShelf = <String, List<InventoryItemView>>{};
    for (final InventoryItemView item in dueItems) {
      byShelf.putIfAbsent(item.shelf?.id ?? '', () => <InventoryItemView>[]).add(item);
    }

    final Map<String, RiskEntry> riskByShelf = <String, RiskEntry>{
      for (final RiskEntry entry in shelfRisk.entries) entry.key: entry,
    };

    final List<RouteStop> stops = <RouteStop>[];
    for (final MapEntry<String, List<InventoryItemView>> entry in byShelf.entries) {
      final List<InventoryItemView> items = entry.value;
      final InventoryItemView sample = items.first;
      final RiskEntry? risk = riskByShelf[entry.key];
      stops.add(RouteStop(
        areaId: sample.area?.id,
        shelfId: sample.shelf?.id,
        areaName: sample.area?.name ?? '',
        shelfName: sample.shelf?.name ?? '',
        dueItems: items.length,
        urgentItems:
            items.where((InventoryItemView i) => i.priority.level.isActionable).length,
        walkOrder: sample.walkOrder,
        riskRate: risk?.rateLowerBound ?? 0,
        riskIsReady: risk?.isReady ?? false,
      ),);
    }

    stops.sort((RouteStop a, RouteStop b) {
      // Anything already overdue is visited first, whatever the walk order.
      final bool aUrgent = a.urgentItems > 0;
      final bool bUrgent = b.urgentItems > 0;
      if (aUrgent != bUrgent) return aUrgent ? -1 : 1;
      final int byWalk = a.walkOrder.compareTo(b.walkOrder);
      if (byWalk != 0) return byWalk;
      return b.riskRate.compareTo(a.riskRate);
    });

    final int totalItems = stops.fold(0, (int sum, RouteStop s) => sum + s.dueItems);
    final int seconds =
        totalItems * config.secondsPerItem + stops.length * config.secondsPerStop;

    return InspectionRoute(
      stops: stops,
      totalItems: totalItems,
      estimatedMinutes: (seconds / 60).ceil(),
      generatedAt: generatedAt,
    );
  }

  /// Combines what is certain (lots already scheduled for destruction) with a
  /// run-rate estimate derived from real history.
  WasteForecast forecast({
    required List<InventoryItemView> scheduledItems,
    required DestructionReport history,
    required DateTime generatedAt,
  }) {
    double scheduledUnits = 0;
    double scheduledLoss = 0;
    int priced = 0;
    for (final InventoryItemView item in scheduledItems) {
      scheduledUnits += item.record.quantityRemaining;
      final double loss = item.lossValue;
      if (loss > 0) {
        scheduledLoss += loss;
        priced++;
      }
    }

    if (history.totalRecords < config.minimumTotalSamples) {
      return WasteForecast.insufficient(
        horizonDays: config.forecastDays,
        lookbackDays: config.lookbackDays,
        scheduledRecords: scheduledItems.length,
        scheduledUnits: scheduledUnits,
        scheduledLoss: scheduledLoss,
        scheduledPricedRecords: priced,
        historicalRecords: history.totalRecords,
        generatedAt: generatedAt,
      );
    }

    final int lookbackDays = math.max(history.period.dayCount, 1);
    final double horizon = config.forecastDays.toDouble();

    return WasteForecast(
      horizonDays: config.forecastDays,
      lookbackDays: lookbackDays,
      scheduledRecords: scheduledItems.length,
      scheduledUnits: scheduledUnits,
      scheduledLoss: scheduledLoss,
      scheduledPricedRecords: priced,
      historicalRecords: history.totalRecords,
      projectedRecords: history.totalRecords / lookbackDays * horizon,
      projectedUnits: history.totalUnits / lookbackDays * horizon,
      projectedLoss: history.totalLoss / lookbackDays * horizon,
      availability: InsightAvailability.ready,
      generatedAt: generatedAt,
    );
  }
}
