/// Why a prediction cannot be shown yet.
enum InsightAvailability {
  /// Enough records exist for the figure to mean something.
  ready,

  /// The store has not destroyed enough stock yet for a rate to be meaningful.
  insufficientData,

  /// No stock has ever been booked in for this shelf / category.
  noHistory,
}

/// One ranked row: a shelf, a category or a product.
class RiskEntry {
  const RiskEntry({
    required this.key,
    required this.label,
    required this.intakeRecords,
    required this.destroyedRecords,
    required this.overdueRecords,
    required this.loss,
    required this.rate,
    required this.rateLowerBound,
    required this.availability,
  });

  final String key;
  final String label;

  /// Denominator: how many lots were booked in during the window.
  final int intakeRecords;
  final int destroyedRecords;
  final int overdueRecords;
  final double loss;

  /// destroyedRecords / intakeRecords
  final double rate;

  /// Wilson 95% lower bound of [rate]. Ranking on this instead of the raw rate
  /// stops a shelf with "1 of 1 destroyed" from topping the list.
  final double rateLowerBound;

  final InsightAvailability availability;

  bool get isReady => availability == InsightAvailability.ready;
}

class RiskRanking {
  const RiskRanking({
    required this.entries,
    required this.availability,
    required this.sampleSize,
    required this.lookbackDays,
    required this.minimumSamples,
  });

  const RiskRanking.insufficient({
    required this.sampleSize,
    required this.lookbackDays,
    required this.minimumSamples,
  })  : entries = const <RiskEntry>[],
        availability = InsightAvailability.insufficientData;

  final List<RiskEntry> entries;
  final InsightAvailability availability;
  final int sampleSize;
  final int lookbackDays;
  final int minimumSamples;

  bool get isReady => availability == InsightAvailability.ready && entries.isNotEmpty;
}

/// One stop on the suggested inspection walk.
class RouteStop {
  const RouteStop({
    required this.areaName,
    required this.shelfName,
    required this.dueItems,
    required this.urgentItems,
    required this.walkOrder,
    required this.riskRate,
    required this.riskIsReady,
    this.shelfId,
    this.areaId,
  });

  final String? areaId;
  final String? shelfId;
  final String areaName;
  final String shelfName;

  /// Items whose destroy instant falls inside the planning window.
  final int dueItems;

  /// Items already overdue or expired.
  final int urgentItems;

  final int walkOrder;

  /// Historical destruction rate for this shelf; 0 when [riskIsReady] is false.
  final double riskRate;
  final bool riskIsReady;

  String get label => areaName.isEmpty ? shelfName : '$areaName · $shelfName';
}

class InspectionRoute {
  const InspectionRoute({
    required this.stops,
    required this.totalItems,
    required this.estimatedMinutes,
    required this.generatedAt,
  });

  const InspectionRoute.empty(this.generatedAt)
      : stops = const <RouteStop>[],
        totalItems = 0,
        estimatedMinutes = 0;

  final List<RouteStop> stops;
  final int totalItems;

  /// Derived from a configurable seconds-per-item plus a per-stop walk cost.
  final int estimatedMinutes;
  final DateTime generatedAt;

  bool get isEmpty => stops.isEmpty;
}

/// The forecast is deliberately split into a part that is certain and a part
/// that is an estimate, so nobody reads a projection as a fact.
class WasteForecast {
  const WasteForecast({
    required this.horizonDays,
    required this.lookbackDays,
    required this.scheduledRecords,
    required this.scheduledUnits,
    required this.scheduledLoss,
    required this.scheduledPricedRecords,
    required this.historicalRecords,
    required this.projectedRecords,
    required this.projectedUnits,
    required this.projectedLoss,
    required this.availability,
    required this.generatedAt,
  });

  const WasteForecast.insufficient({
    required this.horizonDays,
    required this.lookbackDays,
    required this.scheduledRecords,
    required this.scheduledUnits,
    required this.scheduledLoss,
    required this.scheduledPricedRecords,
    required this.historicalRecords,
    required this.generatedAt,
  })  : projectedRecords = 0,
        projectedUnits = 0,
        projectedLoss = 0,
        availability = InsightAvailability.insufficientData;

  final int horizonDays;
  final int lookbackDays;

  /// Certain: lots already on the shelves whose destroy instant falls inside
  /// the horizon. Straight out of the inventory table.
  final int scheduledRecords;
  final double scheduledUnits;
  final double scheduledLoss;
  final int scheduledPricedRecords;

  /// How many destructions the run-rate was computed from.
  final int historicalRecords;

  /// Estimate: the historical destruction run rate extended over the horizon.
  final double projectedRecords;
  final double projectedUnits;
  final double projectedLoss;

  final InsightAvailability availability;
  final DateTime generatedAt;

  bool get isReady => availability == InsightAvailability.ready;
  bool get scheduledLossIsPartial => scheduledPricedRecords < scheduledRecords;
}

/// Everything the insights screen shows in one immutable snapshot.
class InsightsSnapshot {
  const InsightsSnapshot({
    required this.shelfRisk,
    required this.categoryRisk,
    required this.forgottenProducts,
    required this.route,
    required this.forecast,
    required this.generatedAt,
  });

  final RiskRanking shelfRisk;
  final RiskRanking categoryRisk;
  final RiskRanking forgottenProducts;
  final InspectionRoute route;
  final WasteForecast forecast;
  final DateTime generatedAt;
}
