import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/insights/domain/entities/insight_models.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final FutureProvider<InsightsSnapshot> insightsProvider =
    FutureProvider<InsightsSnapshot>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  final Result<InsightsSnapshot> result =
      await ref.watch(insightsRepositoryProvider).snapshot();
  return result.fold((Failure f) => throw f, (InsightsSnapshot v) => v);
});

/// Predictions computed from the store's own history. Every panel either shows
/// a figure backed by enough records or says plainly that it cannot yet.
class InsightsPage extends ConsumerWidget {
  const InsightsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<InsightsSnapshot> snapshot = ref.watch(insightsProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.insightsTitle))),
      body: snapshot.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(
          message: e.toString(),
          onRetry: () => ref.invalidate(insightsProvider),
        ),
        data: (InsightsSnapshot value) => RefreshIndicator(
          onRefresh: () async => ref.invalidate(insightsProvider),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gapXl * 3,
            ),
            children: <Widget>[
              NoticeBanner(
                icon: Icons.science_outlined,
                message: l10n.t(K.insightsSubtitle),
              ),
              SectionHeader(title: l10n.t(K.insightsRoute)),
              _RouteCard(route: value.route),
              SectionHeader(title: l10n.t(K.insightsForecast)),
              _ForecastCard(forecast: value.forecast),
              SectionHeader(
                title: l10n.t(K.insightsShelfRisk),
                subtitle: l10n.t(K.insightsBasedOn,
                    <String, Object?>{'days': value.shelfRisk.lookbackDays},),
              ),
              _RankingCard(ranking: value.shelfRisk),
              SectionHeader(title: l10n.t(K.insightsCategoryRisk)),
              _RankingCard(ranking: value.categoryRisk),
              SectionHeader(title: l10n.t(K.insightsForgotten)),
              _RankingCard(ranking: value.forgottenProducts, showOverdue: true),
            ],
          ),
        ),
      ),
    );
  }
}

class _RouteCard extends StatelessWidget {
  const _RouteCard({required this.route});

  final InspectionRoute route;

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);

    if (route.isEmpty) {
      return AppCard(
        child: Row(
          children: <Widget>[
            const Icon(Icons.check_circle_outline),
            const SizedBox(width: Dimens.gapS),
            Expanded(child: Text(l10n.t(K.insightsRouteEmpty))),
          ],
        ),
      );
    }

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            l10n.t(K.insightsRouteStops, <String, Object?>{
              'stops': route.stops.length,
              'items': route.totalItems,
              'minutes': route.estimatedMinutes,
            }),
            style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: Dimens.gapS),
          for (int i = 0; i < route.stops.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: CircleAvatar(
                radius: 14,
                backgroundColor: route.stops[i].urgentItems > 0
                    ? theme.colorScheme.errorContainer
                    : theme.colorScheme.primaryContainer,
                child: Text(
                  '${i + 1}',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: route.stops[i].urgentItems > 0
                        ? theme.colorScheme.onErrorContainer
                        : theme.colorScheme.onPrimaryContainer,
                  ),
                ),
              ),
              title: Text(route.stops[i].label.isEmpty
                  ? l10n.t(K.todayNoShelf)
                  : route.stops[i].label,),
              subtitle: Text(
                <String>[
                  l10n.t(K.todayItemsToDestroy,
                      <String, Object?>{'count': route.stops[i].dueItems},),
                  if (route.stops[i].urgentItems > 0)
                    l10n.t(K.todayUrgentCount,
                        <String, Object?>{'count': route.stops[i].urgentItems},),
                  if (route.stops[i].riskIsReady)
                    l10n.t(K.insightsWasteRate, <String, Object?>{
                      'rate': l10n.percent(route.stops[i].riskRate),
                    }),
                ].join(' · '),
              ),
            ),
        ],
      ),
    );
  }
}

class _ForecastCard extends ConsumerWidget {
  const _ForecastCard({required this.forecast});

  final WasteForecast forecast;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final String currency = ref.watch(currencySymbolProvider);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            l10n.t(K.insightsForecastScheduled,
                <String, Object?>{'days': forecast.horizonDays},),
            style: Theme.of(context).textTheme.titleSmall
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: Dimens.gapS),
          DetailRow(
            label: l10n.t(K.reportsDestroyedRecords),
            value: l10n.number(forecast.scheduledRecords),
          ),
          DetailRow(
            label: l10n.t(K.reportsDestroyedQuantity),
            value: l10n.number(forecast.scheduledUnits, decimals: 0),
          ),
          DetailRow(
            label: l10n.t(K.reportsFinancialLoss),
            value: l10n.money(forecast.scheduledLoss, symbol: currency),
            caption: forecast.scheduledLossIsPartial
                ? l10n.t(K.reportsPartialLoss, <String, Object?>{
                    'priced': forecast.scheduledPricedRecords,
                    'total': forecast.scheduledRecords,
                  })
                : null,
          ),
          const Divider(height: Dimens.gapL),
          if (!forecast.isReady)
            NoticeBanner(
              icon: Icons.hourglass_empty,
              message: '${l10n.t(K.insightsInsufficient)} · '
                  '${l10n.t(K.insightsInsufficientHint, <String, Object?>{
                    'required': 8,
                    'actual': forecast.historicalRecords,
                  })}',
            )
          else ...<Widget>[
            Text(
              l10n.t(K.insightsForecastProjected),
              style: Theme.of(context).textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: Dimens.gapS),
            DetailRow(
              label: l10n.t(K.reportsDestroyedRecords),
              value: l10n.number(forecast.projectedRecords, decimals: 1),
            ),
            DetailRow(
              label: l10n.t(K.reportsFinancialLoss),
              value: l10n.money(forecast.projectedLoss, symbol: currency),
            ),
            const SizedBox(height: Dimens.gapS),
            Text(
              l10n.t(K.insightsForecastNote),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ],
      ),
    );
  }
}

class _RankingCard extends ConsumerWidget {
  const _RankingCard({required this.ranking, this.showOverdue = false});

  final RiskRanking ranking;
  final bool showOverdue;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final String currency = ref.watch(currencySymbolProvider);

    if (!ranking.isReady) {
      return AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Icon(Icons.hourglass_empty),
                const SizedBox(width: Dimens.gapS),
                Expanded(
                  child: Text(
                    l10n.t(K.insightsInsufficient),
                    style: Theme.of(context).textTheme.titleSmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: Dimens.gapXs),
            Text(
              l10n.t(K.insightsInsufficientHint, <String, Object?>{
                'required': ranking.minimumSamples,
                'actual': ranking.sampleSize,
              }),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ),
      );
    }

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          for (final RiskEntry entry in ranking.entries)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          entry.label.isEmpty ? l10n.t(K.commonUnknown) : entry.label,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                      Text(
                        l10n.percent(entry.rate),
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: entry.rateLowerBound.clamp(0.0, 1.0),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    <String>[
                      l10n.t(K.insightsSampleSize,
                          <String, Object?>{'count': entry.intakeRecords},),
                      if (showOverdue)
                        l10n.t(K.insightsOverdueShare, <String, Object?>{
                          'rate': l10n.percent(
                            entry.destroyedRecords == 0
                                ? 0
                                : entry.overdueRecords / entry.destroyedRecords,
                          ),
                        }),
                      if (entry.loss > 0) l10n.money(entry.loss, symbol: currency),
                    ].join(' · '),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: Dimens.gapS),
          Text(
            l10n.t(K.insightsConfidenceNote),
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
        ],
      ),
    );
  }
}
