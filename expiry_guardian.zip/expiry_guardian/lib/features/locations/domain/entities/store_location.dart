/// A physical zone of the store ("Quầy lạnh", "Kho khô", "Aisle 3").
class StoreArea {
  const StoreArea({
    required this.id,
    required this.name,
    required this.sortOrder,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
    this.code,
  });

  final String id;
  final String name;
  final String? code;

  /// Walking order used by the inspection-route suggestion.
  final int sortOrder;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  StoreArea copyWith({
    String? name,
    String? code,
    int? sortOrder,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return StoreArea(
      id: id,
      name: name ?? this.name,
      code: code ?? this.code,
      sortOrder: sortOrder ?? this.sortOrder,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() => 'StoreArea($name)';
}

/// A shelf, rack, chiller or bin inside an area.
class Shelf {
  const Shelf({
    required this.id,
    required this.areaId,
    required this.name,
    required this.sortOrder,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
    this.code,
  });

  final String id;
  final String areaId;
  final String name;
  final String? code;
  final int sortOrder;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  Shelf copyWith({
    String? areaId,
    String? name,
    String? code,
    int? sortOrder,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return Shelf(
      id: id,
      areaId: areaId ?? this.areaId,
      name: name ?? this.name,
      code: code ?? this.code,
      sortOrder: sortOrder ?? this.sortOrder,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() => 'Shelf($name)';
}

/// A shelf together with the area it belongs to - what the UI actually shows.
class ShelfLocation {
  const ShelfLocation({required this.area, required this.shelf});

  final StoreArea area;
  final Shelf shelf;

  String get label => '${area.name} · ${shelf.name}';
  String get shortLabel => shelf.code ?? shelf.name;
  int get walkOrder => area.sortOrder * 1000 + shelf.sortOrder;
}

/// The shelf id a dropdown can safely be given, or `null` when [shelfId] is not
/// among [shelves].
///
/// A Flutter dropdown asserts that its value matches exactly one item, and
/// throws otherwise - so a shelf that is missing from the list crashes the
/// screen instead of merely showing nothing. That happens in two ordinary
/// situations: the shelf list is still loading (the provider hands back an
/// empty list for the first frames) while the product already carries a
/// default shelf, and a shelf that has since been deactivated is still
/// referenced by a product or a stock record. Falling back to "no shelf"
/// shows the field empty for a moment - or until the employee picks again -
/// which is the right outcome either way.
String? selectableShelfId(String? shelfId, List<ShelfLocation> shelves) {
  if (shelfId == null) return null;
  final bool present =
      shelves.any((ShelfLocation location) => location.shelf.id == shelfId);
  return present ? shelfId : null;
}
