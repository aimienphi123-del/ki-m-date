import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';

abstract interface class LocationRepository {
  Future<Result<List<StoreArea>>> listAreas({bool includeInactive = false});
  Future<Result<List<Shelf>>> listShelves({String? areaId, bool includeInactive = false});
  Future<Result<List<ShelfLocation>>> listShelfLocations({bool includeInactive = false});
  Future<Result<StoreArea?>> findArea(String id);
  Future<Result<Shelf?>> findShelf(String id);

  Future<Result<StoreArea>> createArea({required String name, String? code, int? sortOrder});
  Future<Result<StoreArea>> updateArea(StoreArea area);
  Future<Result<void>> deleteArea(String id);

  Future<Result<Shelf>> createShelf({
    required String areaId,
    required String name,
    String? code,
    int? sortOrder,
  });
  Future<Result<Shelf>> updateShelf(Shelf shelf);
  Future<Result<void>> deleteShelf(String id);

  Stream<void> watchLocations();
}
