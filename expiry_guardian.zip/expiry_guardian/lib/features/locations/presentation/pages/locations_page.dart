import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_list_view_model.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Areas and shelves. Their order is the walking order used by the destroy
/// list and by the suggested inspection route.
class LocationsPage extends ConsumerWidget {
  const LocationsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<StoreArea>> areas = ref.watch(storeAreasProvider);
    final AsyncValue<List<ShelfLocation>> shelves = ref.watch(shelfLocationsProvider);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.locationsTitle))),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editArea(context, ref),
        icon: const Icon(Icons.add),
        label: Text(l10n.t(K.locationsNewArea)),
      ),
      body: areas.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
        data: (List<StoreArea> value) {
          if (value.isEmpty) {
            return EmptyState(
              icon: Icons.store_mall_directory_outlined,
              title: l10n.t(K.locationsEmpty),
              message: l10n.t(K.locationsEmptyHint),
            );
          }
          final List<ShelfLocation> allShelves =
              shelves.valueOrNull ?? const <ShelfLocation>[];
          return ListView(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gutter,
              Dimens.gapXl * 3,
            ),
            children: <Widget>[
              NoticeBanner(
                icon: Icons.route_outlined,
                message: l10n.t(K.locationsSortOrderHint),
              ),
              for (final StoreArea area in value) ...<Widget>[
                SectionHeader(
                  title: area.name,
                  subtitle: '#${area.sortOrder}${area.code == null ? '' : ' · ${area.code}'}',
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      IconButton(
                        onPressed: () => _editArea(context, ref, area: area),
                        icon: const Icon(Icons.edit_outlined),
                      ),
                      IconButton(
                        onPressed: () => _confirmDeleteArea(context, ref, area),
                        icon: const Icon(Icons.delete_outline),
                      ),
                    ],
                  ),
                ),
                AppCard(
                  child: Column(
                    children: <Widget>[
                      for (final ShelfLocation location
                          in allShelves.where((ShelfLocation l) => l.area.id == area.id))
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: const Icon(Icons.shelves),
                          title: Text(location.shelf.name),
                          subtitle: Text('#${location.shelf.sortOrder}'),
                          trailing: IconButton(
                            onPressed: () =>
                                _editShelf(context, ref, area: area, shelf: location.shelf),
                            icon: const Icon(Icons.edit_outlined),
                          ),
                        ),
                      TextButton.icon(
                        onPressed: () => _editShelf(context, ref, area: area),
                        icon: const Icon(Icons.add),
                        label: Text(l10n.t(K.locationsNewShelf)),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Future<void> _editArea(BuildContext context, WidgetRef ref, {StoreArea? area}) async {
    final AppLocalizations l10n = context.l10n;
    final _NameAndOrder? entered = await _askNameAndOrder(
      context,
      title: area == null ? l10n.t(K.locationsNewArea) : l10n.t(K.commonEdit),
      initialName: area?.name ?? '',
      initialOrder: area?.sortOrder.toString() ?? '',
      orderHelperText: l10n.t(K.locationsSortOrderHint),
    );
    if (entered == null || !context.mounted) return;

    final Result<StoreArea> result = area == null
        ? await ref.read(locationRepositoryProvider).createArea(
              name: entered.name,
              sortOrder: entered.sortOrder,
            )
        : await ref.read(locationRepositoryProvider).updateArea(
              area.copyWith(
                name: entered.name,
                sortOrder: entered.sortOrder ?? area.sortOrder,
              ),
            );
    if (!context.mounted) return;
    // Saying nothing on failure is how "it just does nothing" bugs are born:
    // the row never appears and the employee has no idea why.
    result.fold(
      (Failure failure) =>
          showAppSnack(context, describeFailure(context, failure), isError: true),
      (StoreArea _) => showAppSnack(context, l10n.t(K.locationsAreaSaved)),
    );
  }

  Future<void> _editShelf(
    BuildContext context,
    WidgetRef ref, {
    required StoreArea area,
    Shelf? shelf,
  }) async {
    final AppLocalizations l10n = context.l10n;
    final _NameAndOrder? entered = await _askNameAndOrder(
      context,
      title: shelf == null ? l10n.t(K.locationsNewShelf) : l10n.t(K.commonEdit),
      initialName: shelf?.name ?? '',
      initialOrder: shelf?.sortOrder.toString() ?? '',
    );
    if (entered == null || !context.mounted) return;

    final Result<Shelf> result = shelf == null
        ? await ref.read(locationRepositoryProvider).createShelf(
              areaId: area.id,
              name: entered.name,
              sortOrder: entered.sortOrder,
            )
        : await ref.read(locationRepositoryProvider).updateShelf(
              shelf.copyWith(
                name: entered.name,
                sortOrder: entered.sortOrder ?? shelf.sortOrder,
              ),
            );
    if (!context.mounted) return;
    result.fold(
      (Failure failure) =>
          showAppSnack(context, describeFailure(context, failure), isError: true),
      (Shelf _) => showAppSnack(context, l10n.t(K.locationsShelfSaved)),
    );
  }

  Future<void> _confirmDeleteArea(
    BuildContext context,
    WidgetRef ref,
    StoreArea area,
  ) async {
    final AppLocalizations l10n = context.l10n;
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.commonDelete)),
        content: Text(l10n.t(K.locationsDeleteAreaWarning)),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(l10n.t(K.commonDelete)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await ref.read(locationRepositoryProvider).deleteArea(area.id);
  }
}

/// What the name + order dialog returned.
class _NameAndOrder {
  const _NameAndOrder(this.name, this.sortOrder);
  final String name;
  final int? sortOrder;
}

/// The one dialog used to add or rename an area and a shelf.
///
/// Written once rather than twice because the two were byte-for-byte the same
/// apart from a label, and the hardening below has to apply to both:
///
///  * the content scrolls and is width-bounded, so the soft keyboard cannot
///    squeeze the Save button off a small screen;
///  * the keyboard's own "done" key submits, so the employee is never stuck
///    looking for a button the keyboard is covering;
///  * an empty name is refused in the dialog instead of being dropped in
///    silence after it closes.
Future<_NameAndOrder?> _askNameAndOrder(
  BuildContext context, {
  required String title,
  required String initialName,
  required String initialOrder,
  String? orderHelperText,
}) async {
  final AppLocalizations l10n = context.l10n;
  final TextEditingController name = TextEditingController(text: initialName);
  final TextEditingController order = TextEditingController(text: initialOrder);
  final GlobalKey<FormState> form = GlobalKey<FormState>();

  try {
    return await showDialog<_NameAndOrder>(
      context: context,
      builder: (BuildContext context) {
        void submit() {
          if (!(form.currentState?.validate() ?? false)) return;
          Navigator.of(context).pop(
            _NameAndOrder(name.text.trim(), int.tryParse(order.text.trim())),
          );
        }

        return AlertDialog(
          title: Text(title),
          content: SizedBox(
            width: 360,
            child: SingleChildScrollView(
              child: Form(
                key: form,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    TextFormField(
                      controller: name,
                      autofocus: true,
                      textInputAction: TextInputAction.done,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(labelText: l10n.t(K.commonName)),
                      validator: (String? value) => (value ?? '').trim().isEmpty
                          ? l10n.t(K.locationsNameRequired)
                          : null,
                      onFieldSubmitted: (_) => submit(),
                    ),
                    const SizedBox(height: Dimens.gapM),
                    TextFormField(
                      controller: order,
                      keyboardType: TextInputType.number,
                      textInputAction: TextInputAction.done,
                      decoration: InputDecoration(
                        labelText: l10n.t(K.inventorySort),
                        helperText: orderHelperText,
                        helperMaxLines: 2,
                      ),
                      onFieldSubmitted: (_) => submit(),
                    ),
                  ],
                ),
              ),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(l10n.t(K.commonCancel)),
            ),
            FilledButton(
              onPressed: submit,
              child: Text(l10n.t(K.commonSave)),
            ),
          ],
        );
      },
    );
  } finally {
    name.dispose();
    order.dispose();
  }
}
