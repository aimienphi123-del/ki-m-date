import 'dart:async';

import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/locations/data/models/location_mapper.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/locations/domain/repositories/location_repository.dart';
import 'package:sqflite/sqflite.dart';

class LocationRepositoryImpl implements LocationRepository {
  LocationRepositoryImpl({
    required AppDatabase database,
    required Clock clock,
    required IdGenerator ids,
    required SyncQueue syncQueue,
    required AppLogger logger,
  })  : _database = database,
        _clock = clock,
        _ids = ids,
        _syncQueue = syncQueue,
        _logger = logger;

  final AppDatabase _database;
  final Clock _clock;
  final IdGenerator _ids;
  final SyncQueue _syncQueue;
  final AppLogger _logger;

  static const String _tag = 'LocationRepository';

  @override
  Future<Result<List<StoreArea>>> listAreas({bool includeInactive = false}) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.areas,
        where: includeInactive ? null : 'is_active = 1',
        orderBy: 'sort_order ASC, name COLLATE NOCASE',
      );
      return rows.map(LocationMapper.areaFromRow).toList();
    });
  }

  @override
  Future<Result<List<Shelf>>> listShelves({String? areaId, bool includeInactive = false}) async {
    return _guard(() async {
      final List<String> clauses = <String>[];
      final List<Object?> args = <Object?>[];
      if (!includeInactive) clauses.add('is_active = 1');
      if (areaId != null) {
        clauses.add('area_id = ?');
        args.add(areaId);
      }
      final List<Map<String, Object?>> rows = await _database.db.query(
        Tables.shelves,
        where: clauses.isEmpty ? null : clauses.join(' AND '),
        whereArgs: args.isEmpty ? null : args,
        orderBy: 'sort_order ASC, name COLLATE NOCASE',
      );
      return rows.map(LocationMapper.shelfFromRow).toList();
    });
  }

  @override
  Future<Result<List<ShelfLocation>>> listShelfLocations({bool includeInactive = false}) async {
    return _guard(() async {
      final String activeFilter = includeInactive ? '' : 'WHERE s.is_active = 1 AND a.is_active = 1';
      final List<Map<String, Object?>> rows = await _database.db.rawQuery('''
        SELECT
          s.id AS s_id, s.area_id AS s_area_id, s.name AS s_name, s.code AS s_code,
          s.sort_order AS s_sort_order, s.is_active AS s_is_active,
          s.created_at AS s_created_at, s.updated_at AS s_updated_at,
          a.id AS a_id, a.name AS a_name, a.code AS a_code, a.sort_order AS a_sort_order,
          a.is_active AS a_is_active, a.created_at AS a_created_at, a.updated_at AS a_updated_at
        FROM ${Tables.shelves} s
        JOIN ${Tables.areas} a ON a.id = s.area_id
        $activeFilter
        ORDER BY a.sort_order ASC, a.name COLLATE NOCASE, s.sort_order ASC, s.name COLLATE NOCASE
      ''');
      return rows.map((Map<String, Object?> row) {
        return ShelfLocation(
          area: LocationMapper.areaFromRow(_prefixed(row, 'a_')),
          shelf: LocationMapper.shelfFromRow(_prefixed(row, 's_')),
        );
      }).toList();
    });
  }

  Map<String, Object?> _prefixed(Map<String, Object?> row, String prefix) {
    final Map<String, Object?> out = <String, Object?>{};
    for (final MapEntry<String, Object?> entry in row.entries) {
      if (entry.key.startsWith(prefix)) {
        out[entry.key.substring(prefix.length)] = entry.value;
      }
    }
    return out;
  }

  @override
  Future<Result<StoreArea?>> findArea(String id) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db
          .query(Tables.areas, where: 'id = ?', whereArgs: <Object?>[id], limit: 1);
      return rows.isEmpty ? null : LocationMapper.areaFromRow(rows.first);
    });
  }

  @override
  Future<Result<Shelf?>> findShelf(String id) async {
    return _guard(() async {
      final List<Map<String, Object?>> rows = await _database.db
          .query(Tables.shelves, where: 'id = ?', whereArgs: <Object?>[id], limit: 1);
      return rows.isEmpty ? null : LocationMapper.shelfFromRow(rows.first);
    });
  }

  @override
  Future<Result<StoreArea>> createArea({
    required String name,
    String? code,
    int? sortOrder,
  }) async {
    final String cleanName = name.trim();
    if (cleanName.isEmpty) {
      return const Result<StoreArea>.err(Failure.validation('name_required'));
    }
    return _guard(() async {
      final DateTime now = _clock.now();
      final int order = sortOrder ?? await _nextSortOrder(Tables.areas);
      final StoreArea area = StoreArea(
        id: _ids.newId(),
        name: cleanName,
        code: code?.trim().isEmpty ?? true ? null : code!.trim(),
        sortOrder: order,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      );
      await _database.write(<String>{Tables.areas}, (Transaction txn) async {
        await txn.insert(Tables.areas, LocationMapper.areaToRow(area));
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.areas,
        entityId: area.id,
        payload: LocationMapper.areaToRow(area),
      );
      return area;
    });
  }

  @override
  Future<Result<StoreArea>> updateArea(StoreArea area) async {
    return _guard(() async {
      final StoreArea updated = area.copyWith(updatedAt: _clock.now());
      await _database.write(<String>{Tables.areas}, (Transaction txn) async {
        await txn.update(
          Tables.areas,
          LocationMapper.areaToRow(updated),
          where: 'id = ?',
          whereArgs: <Object?>[updated.id],
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.areas,
        entityId: updated.id,
        payload: LocationMapper.areaToRow(updated),
      );
      return updated;
    });
  }

  @override
  Future<Result<void>> deleteArea(String id) async {
    return _guard(() async {
      // Shelves cascade away with the area, and every stock record that sat on
      // one has its shelf and area set to null by the foreign keys. The record
      // tables have to be named here too, or the stock list goes on showing a
      // shelf that no longer exists until the app is restarted.
      await _database.write(
        <String>{Tables.areas, Tables.shelves, Tables.inventoryRecords},
        (Transaction txn) async {
          await txn.delete(Tables.areas, where: 'id = ?', whereArgs: <Object?>[id]);
        },
      );
      await _syncQueue.enqueueDelete(entity: Tables.areas, entityId: id);
      _logger.i(_tag, 'Deleted area $id');
    });
  }

  @override
  Future<Result<Shelf>> createShelf({
    required String areaId,
    required String name,
    String? code,
    int? sortOrder,
  }) async {
    final String cleanName = name.trim();
    if (cleanName.isEmpty) {
      return const Result<Shelf>.err(Failure.validation('name_required'));
    }
    return _guard(() async {
      final DateTime now = _clock.now();
      final int order = sortOrder ?? await _nextSortOrder(Tables.shelves, 'area_id = ?', <Object?>[areaId]);
      final Shelf shelf = Shelf(
        id: _ids.newId(),
        areaId: areaId,
        name: cleanName,
        code: code?.trim().isEmpty ?? true ? null : code!.trim(),
        sortOrder: order,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      );
      await _database.write(<String>{Tables.shelves}, (Transaction txn) async {
        await txn.insert(Tables.shelves, LocationMapper.shelfToRow(shelf));
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.shelves,
        entityId: shelf.id,
        payload: LocationMapper.shelfToRow(shelf),
      );
      return shelf;
    });
  }

  @override
  Future<Result<Shelf>> updateShelf(Shelf shelf) async {
    return _guard(() async {
      final Shelf updated = shelf.copyWith(updatedAt: _clock.now());
      await _database.write(<String>{Tables.shelves}, (Transaction txn) async {
        await txn.update(
          Tables.shelves,
          LocationMapper.shelfToRow(updated),
          where: 'id = ?',
          whereArgs: <Object?>[updated.id],
        );
      });
      await _syncQueue.enqueueUpsert(
        entity: Tables.shelves,
        entityId: updated.id,
        payload: LocationMapper.shelfToRow(updated),
      );
      return updated;
    });
  }

  @override
  Future<Result<void>> deleteShelf(String id) async {
    return _guard(() async {
      // As in [deleteArea]: the stock that sat on this shelf is updated by the
      // foreign key, so the inventory views have to be told as well.
      await _database.write(
        <String>{Tables.shelves, Tables.inventoryRecords},
        (Transaction txn) async {
          await txn.delete(Tables.shelves, where: 'id = ?', whereArgs: <Object?>[id]);
        },
      );
      await _syncQueue.enqueueDelete(entity: Tables.shelves, entityId: id);
    });
  }

  @override
  Stream<void> watchLocations() {
    return _database.changes
        .where((String table) => table == Tables.areas || table == Tables.shelves);
  }

  Future<int> _nextSortOrder(String table, [String? where, List<Object?>? args]) async {
    final List<Map<String, Object?>> rows = await _database.db.rawQuery(
      'SELECT COALESCE(MAX(sort_order), 0) AS m FROM $table${where == null ? '' : ' WHERE $where'}',
      args,
    );
    final Object? value = rows.first['m'];
    final int current = value is int ? value : (value as num?)?.toInt() ?? 0;
    return current + 10;
  }

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Location operation failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('Location operation failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
