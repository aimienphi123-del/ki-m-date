import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';

abstract final class LocationMapper {
  static StoreArea areaFromRow(Map<String, Object?> row) => StoreArea(
        id: row.str('id'),
        name: row.str('name'),
        code: row.strOrNull('code'),
        sortOrder: row.integer('sort_order'),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
      );

  static Map<String, Object?> areaToRow(StoreArea area) => <String, Object?>{
        'id': area.id,
        'name': area.name,
        'code': area.code,
        'sort_order': area.sortOrder,
        'is_active': boolToInt(area.isActive),
        'created_at': area.createdAt.millisecondsSinceEpoch,
        'updated_at': area.updatedAt.millisecondsSinceEpoch,
      };

  static Shelf shelfFromRow(Map<String, Object?> row) => Shelf(
        id: row.str('id'),
        areaId: row.str('area_id'),
        name: row.str('name'),
        code: row.strOrNull('code'),
        sortOrder: row.integer('sort_order'),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
      );

  static Map<String, Object?> shelfToRow(Shelf shelf) => <String, Object?>{
        'id': shelf.id,
        'area_id': shelf.areaId,
        'name': shelf.name,
        'code': shelf.code,
        'sort_order': shelf.sortOrder,
        'is_active': boolToInt(shelf.isActive),
        'created_at': shelf.createdAt.millisecondsSinceEpoch,
        'updated_at': shelf.updatedAt.millisecondsSinceEpoch,
      };
}
