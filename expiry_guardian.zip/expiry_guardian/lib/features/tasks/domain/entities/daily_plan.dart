import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';

/// Items to destroy on one shelf.
class ShelfTaskGroup {
  const ShelfTaskGroup({required this.items, this.shelf});

  final Shelf? shelf;
  final List<InventoryItemView> items;

  String get title => shelf?.name ?? '';
  int get count => items.length;
  double get units => items.fold(0, (double sum, InventoryItemView i) => sum + i.record.quantityRemaining);
  double get loss => items.fold(0, (double sum, InventoryItemView i) => sum + i.lossValue);

  PriorityLevel get topPriority => items.isEmpty
      ? PriorityLevel.safe
      : items
          .map((InventoryItemView i) => i.priority.level)
          .reduce((PriorityLevel a, PriorityLevel b) => a.rank <= b.rank ? a : b);
}

/// Items to destroy in one store area, grouped by shelf.
class AreaTaskGroup {
  const AreaTaskGroup({required this.shelves, this.area});

  final StoreArea? area;
  final List<ShelfTaskGroup> shelves;

  String get title => area?.name ?? '';
  int get count => shelves.fold(0, (int sum, ShelfTaskGroup s) => sum + s.count);
  double get loss => shelves.fold(0, (double sum, ShelfTaskGroup s) => sum + s.loss);

  PriorityLevel get topPriority => shelves.isEmpty
      ? PriorityLevel.safe
      : shelves
          .map((ShelfTaskGroup s) => s.topPriority)
          .reduce((PriorityLevel a, PriorityLevel b) => a.rank <= b.rank ? a : b);
}

/// The morning list: everything that must leave the shelves today, ordered by
/// priority, then store area, then shelf, then product.
class DailyDestroyPlan {
  const DailyDestroyPlan({
    required this.day,
    required this.generatedAt,
    required this.items,
    required this.areas,
    required this.countsByPriority,
    required this.totalUnits,
    required this.estimatedLoss,
    required this.pricedItemCount,
  });

  const DailyDestroyPlan.empty(this.day, this.generatedAt)
      : items = const <InventoryItemView>[],
        areas = const <AreaTaskGroup>[],
        countsByPriority = const <PriorityLevel, int>{},
        totalUnits = 0,
        estimatedLoss = 0,
        pricedItemCount = 0;

  final DateTime day;
  final DateTime generatedAt;
  final List<InventoryItemView> items;
  final List<AreaTaskGroup> areas;
  final Map<PriorityLevel, int> countsByPriority;
  final double totalUnits;

  /// Sum of unit cost x remaining quantity for the items that have a price.
  final double estimatedLoss;

  /// How many of [items] have a price. The UI shows this so a partial loss
  /// figure is never mistaken for the full one.
  final int pricedItemCount;

  int get count => items.length;
  bool get isEmpty => items.isEmpty;

  int countOf(PriorityLevel level) => countsByPriority[level] ?? 0;

  int get urgentCount =>
      countOf(PriorityLevel.destroyNow) +
      countOf(PriorityLevel.expired) +
      countOf(PriorityLevel.destroySoon);

  bool get lossIsPartial => pricedItemCount < items.length;
}
