import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/tasks/domain/entities/daily_plan.dart';

/// Turns a flat list of due items into the grouped, sorted morning plan.
///
/// Pure function of its inputs, so the ordering rule
/// (priority -> area -> shelf -> product) is covered by unit tests.
class DailyPlanBuilder {
  const DailyPlanBuilder();

  DailyDestroyPlan build({
    required List<InventoryItemView> items,
    required DateTime day,
    required DateTime generatedAt,
  }) {
    if (items.isEmpty) return DailyDestroyPlan.empty(day, generatedAt);

    final List<InventoryItemView> sorted = List<InventoryItemView>.of(items)
      ..sort(compareForDestroyList);

    final Map<PriorityLevel, int> counts = <PriorityLevel, int>{};
    double units = 0;
    double loss = 0;
    int priced = 0;
    for (final InventoryItemView item in sorted) {
      counts.update(item.priority.level, (int v) => v + 1, ifAbsent: () => 1);
      units += item.record.quantityRemaining;
      final double itemLoss = item.lossValue;
      if (itemLoss > 0) {
        loss += itemLoss;
        priced++;
      }
    }

    return DailyDestroyPlan(
      day: day,
      generatedAt: generatedAt,
      items: sorted,
      areas: _group(sorted),
      countsByPriority: counts,
      totalUnits: units,
      estimatedLoss: loss,
      pricedItemCount: priced,
    );
  }

  List<AreaTaskGroup> _group(List<InventoryItemView> sorted) {
    final List<AreaTaskGroup> areas = <AreaTaskGroup>[];
    final Map<String, List<InventoryItemView>> byArea = <String, List<InventoryItemView>>{};
    final Map<String, StoreArea?> areaById = <String, StoreArea?>{};

    for (final InventoryItemView item in sorted) {
      final String key = item.area?.id ?? '';
      byArea.putIfAbsent(key, () => <InventoryItemView>[]).add(item);
      areaById[key] = item.area;
    }

    final List<String> areaKeys = byArea.keys.toList()
      ..sort((String a, String b) {
        final StoreArea? left = areaById[a];
        final StoreArea? right = areaById[b];
        if (left == null && right == null) return 0;
        if (left == null) return 1;
        if (right == null) return -1;
        final int bySort = left.sortOrder.compareTo(right.sortOrder);
        return bySort != 0 ? bySort : left.name.toLowerCase().compareTo(right.name.toLowerCase());
      });

    for (final String areaKey in areaKeys) {
      final List<InventoryItemView> inArea = byArea[areaKey]!;
      final Map<String, List<InventoryItemView>> byShelf = <String, List<InventoryItemView>>{};
      final Map<String, Shelf?> shelfById = <String, Shelf?>{};
      for (final InventoryItemView item in inArea) {
        final String key = item.shelf?.id ?? '';
        byShelf.putIfAbsent(key, () => <InventoryItemView>[]).add(item);
        shelfById[key] = item.shelf;
      }

      final List<String> shelfKeys = byShelf.keys.toList()
        ..sort((String a, String b) {
          final Shelf? left = shelfById[a];
          final Shelf? right = shelfById[b];
          if (left == null && right == null) return 0;
          if (left == null) return 1;
          if (right == null) return -1;
          final int bySort = left.sortOrder.compareTo(right.sortOrder);
          return bySort != 0
              ? bySort
              : left.name.toLowerCase().compareTo(right.name.toLowerCase());
        });

      areas.add(AreaTaskGroup(
        area: areaById[areaKey],
        shelves: shelfKeys
            .map((String key) =>
                ShelfTaskGroup(shelf: shelfById[key], items: byShelf[key]!),)
            .toList(growable: false),
      ),);
    }
    return areas;
  }
}
