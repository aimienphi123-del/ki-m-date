import 'dart:async';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/theme/priority_palette.dart';
import 'package:expiry_guardian/features/escalation/presentation/viewmodels/manager_view_model.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/presentation/pages/record_detail_page.dart';
import 'package:expiry_guardian/features/inventory/presentation/widgets/destroy_sheet.dart';
import 'package:expiry_guardian/features/inventory/presentation/widgets/inventory_item_tile.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/tasks/domain/entities/daily_plan.dart';
import 'package:expiry_guardian/features/tasks/presentation/viewmodels/daily_plan_view_model.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The screen an employee opens first every morning.
class TodayPage extends ConsumerWidget {
  const TodayPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<DailyDestroyPlan> plan = ref.watch(dailyPlanProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.todayTitle)),
        actions: <Widget>[
          IconButton(
            tooltip: l10n.t(K.commonRefresh),
            onPressed: () => ref.invalidate(dailyPlanProvider),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: plan.when(
        loading: () => const LoadingView(),
        error: (Object error, StackTrace stack) => ErrorView(
          message: error.toString(),
          onRetry: () => ref.invalidate(dailyPlanProvider),
        ),
        data: (DailyDestroyPlan value) => _PlanBody(plan: value),
      ),
    );
  }
}

class _PlanBody extends ConsumerWidget {
  const _PlanBody({required this.plan});

  final DailyDestroyPlan plan;

  Future<void> _destroy(BuildContext context, WidgetRef ref, InventoryItemView item) async {
    final DestroyConfirmationResult? result = await showDestroySheet(context, item: item);
    if (result == null || !context.mounted) return;
    final AppLocalizations l10n = context.l10n;
    final double quantity = result.destruction.quantity;
    // Say what actually happened, including that the chase-ups have stopped -
    // that is the thing an employee wants to be sure of.
    final String message = <String>[
      l10n.t(K.destroyDone, <String, Object?>{
        'quantity': l10n.number(quantity, decimals: quantity % 1 == 0 ? 0 : 2),
        'unit': item.record.unit,
      }),
      if (result.remindersCancelled > 0)
        l10n.t(K.destroyRemindersCancelled, <String, Object?>{
          'count': result.remindersCancelled,
        }),
    ].join(' ');
    showAppSnack(context, message);
    ref.invalidate(dailyPlanProvider);
    invalidateEscalations(ref);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final String currency = ref.watch(currencySymbolProvider);

    if (plan.isEmpty) {
      return RefreshIndicator(
        onRefresh: () async => ref.invalidate(dailyPlanProvider),
        child: ListView(
          children: <Widget>[
            SizedBox(height: MediaQuery.of(context).size.height * 0.15),
            EmptyState(
              icon: Icons.task_alt,
              title: l10n.t(K.todayEmpty),
              message: l10n.t(K.todayEmptyHint),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async => ref.invalidate(dailyPlanProvider),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gutter,
          Dimens.gapXl * 3,
        ),
        children: <Widget>[
          // A reminder nobody is allowed to show is the worst kind of silent
          // failure: the schedule is perfect and the phone says nothing. This
          // is the first screen of every shift, so the block is stated here
          // rather than buried in Settings where nobody would look for it.
          const _NotificationsBlockedBanner(),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  l10n.t(K.todayItemsToDestroy, <String, Object?>{'count': plan.count}),
                  style: theme.textTheme.headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                if (plan.urgentCount > 0)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      l10n.t(K.todayUrgentCount, <String, Object?>{'count': plan.urgentCount}),
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: PriorityPalette.of(context, PriorityLevel.destroyNow).foreground,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                const SizedBox(height: Dimens.gapM),
                Wrap(
                  spacing: Dimens.gapS,
                  runSpacing: Dimens.gapS,
                  children: PriorityLevel.values
                      .where((PriorityLevel level) => plan.countOf(level) > 0)
                      .map((PriorityLevel level) => _CountChip(
                            level: level,
                            count: plan.countOf(level),
                          ),)
                      .toList(growable: false),
                ),
                const SizedBox(height: Dimens.gapM),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: DetailRow(
                        icon: Icons.payments_outlined,
                        label: l10n.t(K.todayEstimatedLoss),
                        value: l10n.money(plan.estimatedLoss, symbol: currency),
                        caption: plan.lossIsPartial
                            ? l10n.t(K.reportsPartialLoss, <String, Object?>{
                                'priced': plan.pricedItemCount,
                                'total': plan.count,
                              })
                            : null,
                      ),
                    ),
                  ],
                ),
                Text(
                  l10n.t(K.todayGeneratedAt,
                      <String, Object?>{'time': l10n.time(plan.generatedAt)},),
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          const SizedBox(height: Dimens.gapM),
          const PriorityLegend(),
          for (final AreaTaskGroup area in plan.areas) ...<Widget>[
            SectionHeader(
              title: area.title.isEmpty ? l10n.t(K.todayNoArea) : area.title,
              subtitle: l10n.t(K.todayItemsToDestroy, <String, Object?>{'count': area.count}),
              trailing: PriorityBadge(level: area.topPriority, compact: true),
            ),
            for (final ShelfTaskGroup shelf in area.shelves) ...<Widget>[
              Padding(
                padding: const EdgeInsets.only(top: Dimens.gapS, bottom: Dimens.gapXs),
                child: Row(
                  children: <Widget>[
                    Icon(Icons.shelves, size: 16, color: theme.colorScheme.onSurfaceVariant),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        shelf.title.isEmpty ? l10n.t(K.todayNoShelf) : shelf.title,
                        style: theme.textTheme.titleSmall
                            ?.copyWith(fontWeight: FontWeight.w700),
                      ),
                    ),
                    Text(
                      '${shelf.count}',
                      style: theme.textTheme.labelLarge
                          ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              for (final InventoryItemView item in shelf.items)
                Padding(
                  padding: const EdgeInsets.only(bottom: Dimens.gapS),
                  child: InventoryItemTile(
                    item: item,
                    showLocation: false,
                    onTap: () => RecordDetailPage.open(context, item.record.id),
                    onDestroy: () => _destroy(context, ref, item),
                  ),
                ),
            ],
          ],
        ],
      ),
    );
  }
}

class _CountChip extends StatelessWidget {
  const _CountChip({required this.level, required this.count});

  final PriorityLevel level;
  final int count;

  @override
  Widget build(BuildContext context) {
    final PriorityColors colors = PriorityPalette.of(context, level);
    final String label = context.l10n.t(switch (level) {
      PriorityLevel.safe => K.prioritySafe,
      PriorityLevel.approaching => K.priorityApproaching,
      PriorityLevel.destroySoon => K.priorityDestroySoon,
      PriorityLevel.destroyNow => K.priorityDestroyNow,
      PriorityLevel.expired => K.priorityExpired,
    },);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: colors.background,
        border: Border.all(color: colors.border),
        borderRadius: BorderRadius.circular(Dimens.radiusSmall),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(PriorityPalette.iconOf(level), size: 16, color: colors.foreground),
          const SizedBox(width: 6),
          Text(
            '$count',
            style: TextStyle(
              color: colors.foreground,
              fontWeight: FontWeight.w800,
              fontSize: 16,
            ),
          ),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: colors.foreground, fontSize: 12)),
        ],
      ),
    );
  }
}


/// Shown when Android is blocking the app's notifications.
///
/// Reads the state recorded at start-up rather than asking the platform on
/// every rebuild, and re-checks when tapped so it disappears the moment the
/// permission is granted.
class _NotificationsBlockedBanner extends ConsumerStatefulWidget {
  const _NotificationsBlockedBanner();

  @override
  ConsumerState<_NotificationsBlockedBanner> createState() =>
      _NotificationsBlockedBannerState();
}

class _NotificationsBlockedBannerState
    extends ConsumerState<_NotificationsBlockedBanner> {
  bool? _blocked;

  @override
  void initState() {
    super.initState();
    unawaited(_check());
  }

  Future<void> _check() async {
    final bool granted =
        await ref.read(dependenciesProvider).notificationGateway.hasPermission();
    if (!mounted) return;
    setState(() => _blocked = !granted);
  }

  @override
  Widget build(BuildContext context) {
    if (_blocked != true) return const SizedBox.shrink();
    final AppLocalizations l10n = context.l10n;
    return Padding(
      padding: const EdgeInsets.only(bottom: Dimens.gapM),
      child: NoticeBanner(
        tone: NoticeTone.warning,
        icon: Icons.notifications_off_outlined,
        message: '${l10n.t(K.notifBlockedTitle)}\n${l10n.t(K.notifBlockedBody)}',
        action: TextButton(
          onPressed: () async {
            await ref
                .read(dependenciesProvider)
                .notificationGateway
                .requestPermission();
            await _check();
          },
          child: Text(l10n.t(K.notifAllow)),
        ),
      ),
    );
  }
}
