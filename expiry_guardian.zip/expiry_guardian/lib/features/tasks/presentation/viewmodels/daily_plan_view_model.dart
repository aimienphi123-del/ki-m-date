import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/tasks/domain/entities/daily_plan.dart';
import 'package:expiry_guardian/features/tasks/domain/services/daily_plan_builder.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// How far ahead the "today" list looks. One day by default; a manager can
/// widen it to plan a whole shift or a weekend.
final StateProvider<int> planHorizonDaysProvider = StateProvider<int>((Ref ref) => 1);

/// The morning destroy list. Rebuilds automatically whenever inventory or the
/// active policy changes, so a destroyed item disappears from the list
/// immediately.
final FutureProvider<DailyDestroyPlan> dailyPlanProvider =
    FutureProvider<DailyDestroyPlan>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  ref.watch(activePolicyProvider);

  final Clock clock = ref.watch(clockProvider);
  final int horizon = ref.watch(planHorizonDaysProvider);
  final DateTime now = clock.now();
  final DateTime day = DateTime(now.year, now.month, now.day);
  final DateTime until = day.add(Duration(days: horizon));

  final Result<List<InventoryItemView>> items =
      await ref.watch(inventoryRepositoryProvider).destroyList(until: until);

  return items.fold(
    (Failure failure) => throw failure,
    (List<InventoryItemView> due) => const DailyPlanBuilder().build(
      items: due,
      day: day,
      generatedAt: now,
    ),
  );
});

/// Everything that is already past its destroy instant, whatever day it was
/// due - the list a manager checks first.
final FutureProvider<List<InventoryItemView>> overdueItemsProvider =
    FutureProvider<List<InventoryItemView>>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  final Clock clock = ref.watch(clockProvider);
  final Result<List<InventoryItemView>> result =
      await ref.watch(inventoryRepositoryProvider).search(
            InventoryQuery(
              statuses: const <InventoryStatus>{InventoryStatus.active},
              destroyBefore: clock.now(),
              sort: InventorySort.priority,
              limit: 500,
            ),
          );
  return result.fold((Failure failure) => throw failure, (List<InventoryItemView> v) => v);
});
