import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/features/catalog/data/models/catalog_mapper.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/data/models/inventory_mapper.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/data/models/location_mapper.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';

/// A joined row: record + product + optional location + category name.
class InventoryJoinedRow {
  const InventoryJoinedRow({
    required this.record,
    required this.product,
    this.area,
    this.shelf,
    this.categoryName,
  });

  final InventoryRecord record;
  final Product product;
  final StoreArea? area;
  final Shelf? shelf;
  final String? categoryName;
}

abstract interface class InventoryLocalDataSource {
  Future<List<InventoryJoinedRow>> query(InventoryQuery query);
  Future<InventoryJoinedRow?> findJoined(String recordId);
  Future<InventoryRecord?> findRecord(String recordId);
  Future<int> countMatching(InventoryQuery query);
  Future<int> sequenceForDay(DateTime day);
  Future<List<InventoryRecord>> openRecords();
  Future<List<Destruction>> destructionsBetween(DateTime from, DateTime to);
  Future<List<Destruction>> destructionsFor(String recordId);
  Future<List<RecordEvent>> history(String recordId);
}

class SqfliteInventoryDataSource implements InventoryLocalDataSource {
  const SqfliteInventoryDataSource(this._database);

  final AppDatabase _database;

  static const String _selectJoined = '''
    SELECT
      r.id AS r_id, r.code AS r_code, r.product_id AS r_product_id, r.batch_code AS r_batch_code,
      r.manufactured_at AS r_manufactured_at, r.expiry_at AS r_expiry_at,
      r.expiry_precision AS r_expiry_precision, r.expiry_instant AS r_expiry_instant,
      r.destroy_at AS r_destroy_at, r.lead_time_minutes AS r_lead_time_minutes,
      r.shelf_life_minutes AS r_shelf_life_minutes, r.policy_id AS r_policy_id,
      r.policy_version AS r_policy_version, r.policy_rule_id AS r_policy_rule_id,
      r.area_id AS r_area_id, r.shelf_id AS r_shelf_id, r.quantity AS r_quantity,
      r.quantity_remaining AS r_quantity_remaining, r.unit AS r_unit, r.unit_cost AS r_unit_cost,
      r.received_at AS r_received_at, r.status AS r_status, r.photo_path AS r_photo_path,
      r.source AS r_source, r.note AS r_note, r.created_by AS r_created_by,
      r.created_at AS r_created_at, r.updated_at AS r_updated_at, r.closed_at AS r_closed_at,
      p.id AS p_id, p.barcode AS p_barcode, p.name AS p_name, p.brand AS p_brand,
      p.category_id AS p_category_id, p.unit AS p_unit, p.default_shelf_id AS p_default_shelf_id,
      p.expiry_precision AS p_expiry_precision,
      p.default_shelf_life_minutes AS p_default_shelf_life_minutes,
      p.unit_cost AS p_unit_cost, p.photo_path AS p_photo_path,
      p.barcode_photo_path AS p_barcode_photo_path, p.notes AS p_notes,
      p.is_active AS p_is_active, p.created_at AS p_created_at, p.updated_at AS p_updated_at,
      a.id AS a_id, a.name AS a_name, a.code AS a_code, a.sort_order AS a_sort_order,
      a.is_active AS a_is_active, a.created_at AS a_created_at, a.updated_at AS a_updated_at,
      s.id AS s_id, s.area_id AS s_area_id, s.name AS s_name, s.code AS s_code,
      s.sort_order AS s_sort_order, s.is_active AS s_is_active,
      s.created_at AS s_created_at, s.updated_at AS s_updated_at,
      c.name AS c_name
    FROM ${Tables.inventoryRecords} r
    JOIN ${Tables.products} p ON p.id = r.product_id
    LEFT JOIN ${Tables.shelves} s ON s.id = r.shelf_id
    LEFT JOIN ${Tables.areas} a ON a.id = COALESCE(s.area_id, r.area_id)
    LEFT JOIN ${Tables.categories} c ON c.id = p.category_id
  ''';

  ({String where, List<Object?> args}) _buildWhere(InventoryQuery q) {
    final List<String> clauses = <String>[];
    final List<Object?> args = <Object?>[];

    if (q.statuses.isNotEmpty) {
      final ({List<Object?> args, String clause}) statusIn = inClause(
        'r.status',
        q.statuses.map((InventoryStatus s) => s.name).toList(),
      );
      clauses.add(statusIn.clause);
      args.addAll(statusIn.args);
    }
    if (q.productId != null) {
      clauses.add('r.product_id = ?');
      args.add(q.productId);
    }
    if (q.categoryId != null) {
      clauses.add('p.category_id = ?');
      args.add(q.categoryId);
    }
    if (q.shelfId != null) {
      clauses.add('r.shelf_id = ?');
      args.add(q.shelfId);
    }
    if (q.areaId != null) {
      clauses.add('COALESCE(s.area_id, r.area_id) = ?');
      args.add(q.areaId);
    }
    if (q.batchCode != null && q.batchCode!.trim().isNotEmpty) {
      clauses.add(r"r.batch_code LIKE ? ESCAPE '\'");
      args.add(likeArgument(q.batchCode!.trim()));
    }
    if (q.barcode != null && q.barcode!.trim().isNotEmpty) {
      clauses.add(
        'p.id IN (SELECT id FROM ${Tables.products} WHERE barcode = ?'
        ' UNION SELECT product_id FROM ${Tables.productBarcodes} WHERE barcode = ?)',
      );
      args.addAll(<Object?>[q.barcode!.trim(), q.barcode!.trim()]);
    }
    final String? text = q.text?.trim();
    if (text != null && text.isNotEmpty) {
      clauses.add(
        r"(p.name LIKE ? ESCAPE '\' OR p.brand LIKE ? ESCAPE '\'"
        r" OR r.batch_code LIKE ? ESCAPE '\' OR r.code LIKE ? ESCAPE '\'"
        r" OR p.barcode LIKE ? ESCAPE '\')",
      );
      final String like = likeArgument(text);
      args.addAll(<Object?>[like, like, like, like, like]);
    }
    void range(String column, DateTime? after, DateTime? before) {
      if (after != null) {
        clauses.add('$column >= ?');
        args.add(after.millisecondsSinceEpoch);
      }
      if (before != null) {
        clauses.add('$column <= ?');
        args.add(before.millisecondsSinceEpoch);
      }
    }

    range('r.destroy_at', q.destroyAfter, q.destroyBefore);
    range('r.expiry_instant', q.expiryAfter, q.expiryBefore);
    range('r.received_at', q.receivedAfter, q.receivedBefore);

    return (
      where: clauses.isEmpty ? '' : 'WHERE ${clauses.join(' AND ')}',
      args: args,
    );
  }

  String _orderBy(InventoryQuery q) {
    final String direction = q.descending ? 'DESC' : 'ASC';
    return switch (q.sort) {
      InventorySort.destroyDate || InventorySort.priority => 'ORDER BY r.destroy_at $direction',
      InventorySort.expiryDate => 'ORDER BY r.expiry_instant $direction',
      InventorySort.receivedDate => 'ORDER BY r.received_at $direction',
      InventorySort.productName => 'ORDER BY p.name COLLATE NOCASE $direction',
      InventorySort.location =>
        'ORDER BY a.sort_order $direction, s.sort_order $direction, p.name COLLATE NOCASE',
    };
  }

  @override
  Future<List<InventoryJoinedRow>> query(InventoryQuery q) async {
    final ({List<Object?> args, String where}) filter = _buildWhere(q);
    final List<Map<String, Object?>> rows = await _database.db.rawQuery(
      '$_selectJoined ${filter.where} ${_orderBy(q)} LIMIT ? OFFSET ?',
      <Object?>[...filter.args, q.limit, q.offset],
    );
    return rows.map(_fromJoined).toList();
  }

  @override
  Future<int> countMatching(InventoryQuery q) async {
    final ({List<Object?> args, String where}) filter = _buildWhere(q);
    return countOf(
      _database.db,
      '''
      SELECT COUNT(*) FROM ${Tables.inventoryRecords} r
      JOIN ${Tables.products} p ON p.id = r.product_id
      LEFT JOIN ${Tables.shelves} s ON s.id = r.shelf_id
      ${filter.where}
      ''',
      filter.args,
    );
  }

  @override
  Future<InventoryJoinedRow?> findJoined(String recordId) async {
    final List<Map<String, Object?>> rows =
        await _database.db.rawQuery('$_selectJoined WHERE r.id = ? LIMIT 1', <Object?>[recordId]);
    return rows.isEmpty ? null : _fromJoined(rows.first);
  }

  @override
  Future<InventoryRecord?> findRecord(String recordId) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.inventoryRecords,
      where: 'id = ?',
      whereArgs: <Object?>[recordId],
      limit: 1,
    );
    return rows.isEmpty ? null : InventoryMapper.recordFromRow(rows.first);
  }

  @override
  Future<int> sequenceForDay(DateTime day) async {
    final DateTime start = DateTime(day.year, day.month, day.day);
    final DateTime end = start.add(const Duration(days: 1));
    final int used = await countOf(
      _database.db,
      'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE created_at >= ? AND created_at < ?',
      <Object?>[start.millisecondsSinceEpoch, end.millisecondsSinceEpoch],
    );
    return used + 1;
  }

  @override
  Future<List<InventoryRecord>> openRecords() async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.inventoryRecords,
      where: 'status = ?',
      whereArgs: <Object?>[InventoryStatus.active.name],
    );
    return rows.map(InventoryMapper.recordFromRow).toList();
  }

  @override
  Future<List<Destruction>> destructionsBetween(DateTime from, DateTime to) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.destructions,
      where: 'destroyed_at >= ? AND destroyed_at < ?',
      whereArgs: <Object?>[from.millisecondsSinceEpoch, to.millisecondsSinceEpoch],
      orderBy: 'destroyed_at DESC',
    );
    return rows.map(InventoryMapper.destructionFromRow).toList();
  }

  @override
  Future<List<Destruction>> destructionsFor(String recordId) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.destructions,
      where: 'record_id = ?',
      whereArgs: <Object?>[recordId],
      orderBy: 'destroyed_at DESC',
    );
    return rows.map(InventoryMapper.destructionFromRow).toList();
  }

  @override
  Future<List<RecordEvent>> history(String recordId) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.recordEvents,
      where: 'record_id = ?',
      whereArgs: <Object?>[recordId],
      orderBy: 'occurred_at DESC',
    );
    return rows.map(InventoryMapper.eventFromRow).toList();
  }

  InventoryJoinedRow _fromJoined(Map<String, Object?> row) {
    final Map<String, Object?> recordRow = _slice(row, 'r_');
    final Map<String, Object?> productRow = _slice(row, 'p_');
    final Map<String, Object?> areaRow = _slice(row, 'a_');
    final Map<String, Object?> shelfRow = _slice(row, 's_');
    return InventoryJoinedRow(
      record: InventoryMapper.recordFromRow(recordRow),
      product: CatalogMapper.productFromRow(productRow),
      area: areaRow['id'] == null ? null : LocationMapper.areaFromRow(areaRow),
      shelf: shelfRow['id'] == null ? null : LocationMapper.shelfFromRow(shelfRow),
      categoryName: row['c_name'] as String?,
    );
  }

  Map<String, Object?> _slice(Map<String, Object?> row, String prefix) {
    final Map<String, Object?> out = <String, Object?>{};
    for (final MapEntry<String, Object?> entry in row.entries) {
      if (entry.key.startsWith(prefix)) {
        out[entry.key.substring(prefix.length)] = entry.value;
      }
    }
    return out;
  }
}
