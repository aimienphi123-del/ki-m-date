import 'dart:async';

import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/inventory/data/datasources/inventory_local_datasource.dart';
import 'package:expiry_guardian/features/inventory/data/models/inventory_mapper.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/inventory/domain/services/inventory_code_generator.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/repositories/policy_repository.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:sqflite/sqflite.dart';

class InventoryRepositoryImpl implements InventoryRepository {
  InventoryRepositoryImpl({
    required AppDatabase database,
    required InventoryLocalDataSource local,
    required CatalogRepository catalog,
    required PolicyRepository policies,
    required ExpiryPolicyEngine engine,
    required InventoryCodeGenerator codes,
    required Clock clock,
    required IdGenerator ids,
    required SyncQueue syncQueue,
    required AppLogger logger,
  })  : _database = database,
        _local = local,
        _catalog = catalog,
        _policies = policies,
        _engine = engine,
        _codes = codes,
        _clock = clock,
        _ids = ids,
        _syncQueue = syncQueue,
        _logger = logger;

  final AppDatabase _database;
  final InventoryLocalDataSource _local;
  final CatalogRepository _catalog;
  final PolicyRepository _policies;
  final ExpiryPolicyEngine _engine;
  final InventoryCodeGenerator _codes;
  final Clock _clock;
  final IdGenerator _ids;
  final SyncQueue _syncQueue;
  final AppLogger _logger;

  static const String _tag = 'InventoryRepository';

  // ---------------------------------------------------------------- intake

  @override
  Future<Result<InventoryRecord>> intake(IntakeDraft draft, {String? actorId}) async {
    if (draft.quantity <= 0) {
      return const Result<InventoryRecord>.err(Failure.validation('quantity_must_be_positive'));
    }
    final Result<DestroyPolicy> policyResult = await _policies.getActivePolicy();
    if (policyResult.isErr) {
      return Result<InventoryRecord>.err(policyResult.failureOrNull!);
    }
    final Result<Product?> productResult = await _catalog.findById(draft.productId);
    if (productResult.isErr) return Result<InventoryRecord>.err(productResult.failureOrNull!);
    final Product? product = productResult.unwrap();
    if (product == null) {
      return Result<InventoryRecord>.err(Failure.notFound('product ${draft.productId}'));
    }

    return _guard(() async {
      final DestroyPolicy policy = policyResult.unwrap();
      final DateTime now = _clock.now();
      final DateTime receivedAt = draft.receivedAt ?? now;

      final PolicyDecision decision = _engine.evaluate(
        policy,
        PolicyInput(
          expiry: draft.expiryAt,
          receivedAt: receivedAt,
          precision: draft.expiryPrecision,
          manufacturedAt: draft.manufacturedAt,
        ),
      );

      final String? shelfId = draft.shelfId ?? product.defaultShelfId;
      final String? areaId = shelfId == null ? null : await _areaOfShelf(shelfId);

      final InventoryRecord record = InventoryRecord(
        id: _ids.newId(),
        code: await _allocateCode(now),
        productId: product.id,
        batchCode: draft.batchCode?.trim().isEmpty ?? true ? null : draft.batchCode!.trim(),
        manufacturedAt: draft.manufacturedAt,
        expiryAt: draft.expiryAt,
        expiryPrecision: draft.expiryPrecision,
        expiryInstant: decision.expiryInstant,
        destroyAt: decision.destroyAt,
        leadTime: decision.leadTime,
        shelfLife: decision.shelfLife,
        policyId: decision.policyId,
        policyVersion: decision.policyVersion,
        policyRuleId: decision.matchedRule?.id,
        areaId: areaId,
        shelfId: shelfId,
        quantity: draft.quantity,
        quantityRemaining: draft.quantity,
        unit: draft.unit ?? product.unit,
        unitCost: draft.unitCost ?? product.unitCost,
        receivedAt: receivedAt,
        status: InventoryStatus.active,
        photoPath: draft.photoPath,
        source: draft.source,
        note: draft.note,
        createdBy: actorId,
        createdAt: now,
        updatedAt: now,
      );

      await _database.write(<String>{Tables.inventoryRecords, Tables.recordEvents},
          (Transaction txn) async {
        await txn.insert(Tables.inventoryRecords, InventoryMapper.recordToRow(record));
        await txn.insert(
          Tables.recordEvents,
          InventoryMapper.eventToRow(RecordEvent(
            id: _ids.newId(),
            recordId: record.id,
            type: RecordEventType.created,
            occurredAt: now,
            actorId: actorId,
            quantityDelta: record.quantity,
            payload: <String, Object?>{
              'policyId': decision.policyId,
              'policyVersion': decision.policyVersion,
              'ruleId': decision.matchedRule?.id,
              'ruleName': decision.matchedRule?.nameEn,
              'leadMinutes': decision.leadTime.inMinutes,
              'shelfLifeMinutes': decision.shelfLife.inMinutes,
              'basis': decision.basisUsed.name,
              'usedFallback': decision.usedFallbackLeadTime,
            },
          ),),
        );
      });

      await _syncQueue.enqueueUpsert(
        entity: Tables.inventoryRecords,
        entityId: record.id,
        payload: InventoryMapper.recordToRow(record),
      );
      _logger.i(_tag, 'Intake ${record.code} destroyAt=${record.destroyAt}');
      return record;
    });
  }

  Future<String> _allocateCode(DateTime now) async {
    final int sequence = await _local.sequenceForDay(now);
    for (int attempt = 0; attempt < 50; attempt++) {
      final String candidate = _codes.next(date: now, sequenceForDay: sequence + attempt);
      final int existing = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE code = ?',
        <Object?>[candidate],
      );
      if (existing == 0) return candidate;
    }
    // Extremely unlikely; fall back to the opaque id so intake never blocks.
    return _ids.newId();
  }

  Future<String?> _areaOfShelf(String shelfId) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.shelves,
      columns: <String>['area_id'],
      where: 'id = ?',
      whereArgs: <Object?>[shelfId],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first['area_id'] as String?;
  }

  // ----------------------------------------------------------------- reads

  @override
  Future<Result<InventoryRecord?>> findRecord(String recordId) =>
      _guard(() => _local.findRecord(recordId));

  @override
  Future<Result<InventoryItemView?>> findView(String recordId) async {
    final Result<DestroyPolicy> policyResult = await _policies.getActivePolicy();
    if (policyResult.isErr) return Result<InventoryItemView?>.err(policyResult.failureOrNull!);
    return _guard(() async {
      final InventoryJoinedRow? row = await _local.findJoined(recordId);
      if (row == null) return null;
      return _toView(row, policyResult.unwrap(), _clock.now());
    });
  }

  @override
  Future<Result<List<InventoryItemView>>> search(InventoryQuery query) async {
    final Result<DestroyPolicy> policyResult = await _policies.getActivePolicy();
    if (policyResult.isErr) {
      return Result<List<InventoryItemView>>.err(policyResult.failureOrNull!);
    }
    return _guard(() async {
      final DestroyPolicy policy = policyResult.unwrap();
      final DateTime now = _clock.now();
      final List<InventoryJoinedRow> rows = await _local.query(query);
      List<InventoryItemView> views = rows
          .map((InventoryJoinedRow row) => _toView(row, policy, now))
          .toList(growable: false);
      if (query.priorities.isNotEmpty) {
        views = views
            .where((InventoryItemView v) => query.priorities.contains(v.priority.level))
            .toList(growable: false);
      }
      if (query.sort == InventorySort.priority) {
        views = List<InventoryItemView>.of(views)..sort(compareForDestroyList);
      }
      return views;
    });
  }

  @override
  Future<Result<int>> count(InventoryQuery query) => _guard(() => _local.countMatching(query));

  @override
  Future<Result<List<InventoryItemView>>> destroyList({required DateTime until}) {
    return search(InventoryQuery(
      statuses: const <InventoryStatus>{InventoryStatus.active},
      destroyBefore: until,
      sort: InventorySort.priority,
      limit: 1000,
    ),);
  }

  @override
  Future<Result<List<InventoryItemView>>> dueBetween(DateTime from, DateTime to) {
    return search(InventoryQuery(
      statuses: const <InventoryStatus>{InventoryStatus.active},
      destroyAfter: from,
      destroyBefore: to,
      sort: InventorySort.destroyDate,
      limit: 2000,
    ),);
  }

  InventoryItemView _toView(InventoryJoinedRow row, DestroyPolicy policy, DateTime now) {
    final PriorityAssessment assessment = _engine.assess(
      policy: policy,
      now: now,
      destroyAt: row.record.destroyAt,
      expiryInstant: row.record.expiryInstant,
    );
    return InventoryItemView(
      record: row.record,
      product: row.product,
      priority: assessment,
      area: row.area,
      shelf: row.shelf,
      categoryName: row.categoryName,
    );
  }

  @override
  Future<Result<InventorySummary>> summary({
    required DateTime dayStart,
    required DateTime dayEnd,
  }) async {
    final Result<DestroyPolicy> policyResult = await _policies.getActivePolicy();
    if (policyResult.isErr) return Result<InventorySummary>.err(policyResult.failureOrNull!);
    return _guard(() async {
      final DestroyPolicy policy = policyResult.unwrap();
      final DateTime now = _clock.now();
      final int nowMs = now.millisecondsSinceEpoch;
      final String active = InventoryStatus.active.name;

      final int activeRecords = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE status = ?',
        <Object?>[active],
      );
      final double activeUnits = await sumOf(
        _database.db,
        'SELECT COALESCE(SUM(quantity_remaining), 0) FROM ${Tables.inventoryRecords} WHERE status = ?',
        <Object?>[active],
      );
      final double activeValue = await sumOf(
        _database.db,
        '''
        SELECT COALESCE(SUM(quantity_remaining * COALESCE(r.unit_cost, p.unit_cost, 0)), 0)
        FROM ${Tables.inventoryRecords} r
        JOIN ${Tables.products} p ON p.id = r.product_id
        WHERE r.status = ?
        ''',
        <Object?>[active],
      );
      final int pricedRecords = await countOf(
        _database.db,
        '''
        SELECT COUNT(*) FROM ${Tables.inventoryRecords} r
        JOIN ${Tables.products} p ON p.id = r.product_id
        WHERE r.status = ? AND COALESCE(r.unit_cost, p.unit_cost) IS NOT NULL
        ''',
        <Object?>[active],
      );
      final int overdue = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE status = ? AND destroy_at <= ? AND expiry_instant >= ?',
        <Object?>[active, nowMs, nowMs],
      );
      final int expired = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE status = ? AND expiry_instant < ?',
        <Object?>[active, nowMs],
      );
      final int dueToday = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE status = ? AND destroy_at >= ? AND destroy_at < ?',
        <Object?>[active, dayStart.millisecondsSinceEpoch, dayEnd.millisecondsSinceEpoch],
      );
      final int approaching = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.inventoryRecords} WHERE status = ? AND destroy_at > ? AND destroy_at <= ?',
        <Object?>[
          active,
          nowMs,
          now.add(policy.thresholds.approachingWindow).millisecondsSinceEpoch,
        ],
      );
      final int destroyedTodayRecords = await countOf(
        _database.db,
        'SELECT COUNT(*) FROM ${Tables.destructions} WHERE destroyed_at >= ? AND destroyed_at < ?',
        <Object?>[dayStart.millisecondsSinceEpoch, dayEnd.millisecondsSinceEpoch],
      );
      final double destroyedTodayUnits = await sumOf(
        _database.db,
        'SELECT COALESCE(SUM(quantity), 0) FROM ${Tables.destructions} WHERE destroyed_at >= ? AND destroyed_at < ?',
        <Object?>[dayStart.millisecondsSinceEpoch, dayEnd.millisecondsSinceEpoch],
      );
      final double destroyedTodayLoss = await sumOf(
        _database.db,
        'SELECT COALESCE(SUM(loss_amount), 0) FROM ${Tables.destructions} WHERE destroyed_at >= ? AND destroyed_at < ?',
        <Object?>[dayStart.millisecondsSinceEpoch, dayEnd.millisecondsSinceEpoch],
      );

      return InventorySummary(
        activeRecords: activeRecords,
        activeUnits: activeUnits,
        approachingRecords: approaching,
        dueTodayRecords: dueToday,
        overdueRecords: overdue,
        expiredRecords: expired,
        destroyedTodayRecords: destroyedTodayRecords,
        destroyedTodayUnits: destroyedTodayUnits,
        destroyedTodayLoss: destroyedTodayLoss,
        activeStockValue: activeValue,
        pricedProductsRatio: activeRecords == 0 ? 0 : pricedRecords / activeRecords,
      );
    });
  }

  @override
  Future<Result<List<RecordEvent>>> history(String recordId) =>
      _guard(() => _local.history(recordId));

  @override
  Future<Result<List<Destruction>>> destructionsBetween(DateTime from, DateTime to) =>
      _guard(() => _local.destructionsBetween(from, to));

  @override
  Future<Result<List<Destruction>>> destructionsFor(String recordId) =>
      _guard(() => _local.destructionsFor(recordId));

  // ---------------------------------------------------------------- writes

  @override
  Future<Result<Destruction>> destroy(DestroyCommand command, {String? actorId}) async {
    return _guard(() async {
      final InventoryJoinedRow? row = await _local.findJoined(command.recordId);
      if (row == null) throw StateError('record_not_found');
      final InventoryRecord record = row.record;
      if (record.status != InventoryStatus.active) {
        throw StateError('record_not_active');
      }

      final double quantity = command.quantity ?? record.quantityRemaining;
      if (quantity <= 0 || quantity > record.quantityRemaining + 1e-9) {
        throw StateError('invalid_quantity');
      }

      final DateTime at = command.at ?? _clock.now();
      final double? unitCost = record.unitCost ?? row.product.unitCost;
      final double remaining = _round(record.quantityRemaining - quantity);
      final bool fullyClosed = remaining <= 1e-9;
      final bool overdue = at.isAfter(record.destroyAt);
      final int minutesLate = overdue ? at.difference(record.destroyAt).inMinutes : 0;

      final Destruction destruction = Destruction(
        id: _ids.newId(),
        recordId: record.id,
        productId: record.productId,
        categoryId: row.product.categoryId,
        areaId: record.areaId,
        shelfId: record.shelfId,
        quantity: quantity,
        unitCost: unitCost,
        lossAmount: (unitCost ?? 0) * quantity,
        reason: command.reason,
        wasOverdue: overdue,
        minutesLate: minutesLate,
        destroyedAt: at,
        confirmedAt: command.confirmedAt ?? at,
        deviceId: command.deviceId,
        actorId: actorId,
        photoPath: command.photoPath,
        note: command.note,
        createdAt: _clock.now(),
      );

      await _database.write(
        <String>{Tables.destructions, Tables.inventoryRecords, Tables.recordEvents},
        (Transaction txn) async {
          await txn.insert(Tables.destructions, InventoryMapper.destructionToRow(destruction));
          await txn.update(
            Tables.inventoryRecords,
            <String, Object?>{
              'quantity_remaining': remaining,
              'status':
                  fullyClosed ? InventoryStatus.destroyed.name : InventoryStatus.active.name,
              'closed_at': fullyClosed ? at.millisecondsSinceEpoch : null,
              'updated_at': _clock.now().millisecondsSinceEpoch,
            },
            where: 'id = ?',
            whereArgs: <Object?>[record.id],
          );
          await txn.insert(
            Tables.recordEvents,
            InventoryMapper.eventToRow(RecordEvent(
              id: _ids.newId(),
              recordId: record.id,
              type: RecordEventType.destroyed,
              occurredAt: at,
              actorId: actorId,
              quantityDelta: -quantity,
              note: command.note,
              payload: <String, Object?>{
                'reason': command.reason.name,
                'wasOverdue': overdue,
                'minutesLate': minutesLate,
                'lossAmount': destruction.lossAmount,
                'deviceId': command.deviceId,
                'confirmedAt': destruction.confirmedAt.toIso8601String(),
              },
            ),),
          );
        },
      );

      await _syncQueue.enqueueUpsert(
        entity: Tables.destructions,
        entityId: destruction.id,
        payload: InventoryMapper.destructionToRow(destruction),
      );
      _logger.i(_tag, 'Destroyed $quantity of ${record.code} (overdue=$overdue)');
      return destruction;
    });
  }

  @override
  Future<Result<InventoryRecord>> adjustQuantity({
    required String recordId,
    required double newQuantityRemaining,
    String? note,
    String? actorId,
  }) async {
    if (newQuantityRemaining < 0) {
      return const Result<InventoryRecord>.err(Failure.validation('quantity_must_be_positive'));
    }
    return _guard(() async {
      final InventoryRecord? record = await _local.findRecord(recordId);
      if (record == null) throw StateError('record_not_found');
      // A closed lot is not adjustable. Without this a destroyed lot could be
      // silently set back to active and destroyed a second time, which would
      // write a second destruction row and count the same stock twice in the
      // loss report. Reopening is a deliberate act that goes through
      // [closeRecord], where it is audited as a `reopened` event.
      if (!record.status.isOpen) throw StateError('record_not_active');
      final DateTime now = _clock.now();
      final double delta = _round(newQuantityRemaining - record.quantityRemaining);
      final InventoryRecord updated = record.copyWith(
        quantityRemaining: _round(newQuantityRemaining),
        status: newQuantityRemaining <= 1e-9 ? InventoryStatus.soldOut : InventoryStatus.active,
        closedAt: newQuantityRemaining <= 1e-9 ? now : null,
        clearClosedAt: newQuantityRemaining > 1e-9,
        updatedAt: now,
      );
      await _persist(updated, RecordEventType.quantityAdjusted,
          actorId: actorId, quantityDelta: delta, note: note,);
      return updated;
    });
  }

  @override
  Future<Result<InventoryRecord>> moveToShelf({
    required String recordId,
    required String? shelfId,
    String? actorId,
  }) async {
    return _guard(() async {
      final InventoryRecord? record = await _local.findRecord(recordId);
      if (record == null) throw StateError('record_not_found');
      final String? areaId = shelfId == null ? null : await _areaOfShelf(shelfId);
      final InventoryRecord updated = record.copyWith(
        shelfId: shelfId,
        clearShelf: shelfId == null,
        areaId: areaId,
        clearArea: areaId == null,
        updatedAt: _clock.now(),
      );
      await _persist(updated, RecordEventType.moved, actorId: actorId, payload: <String, Object?>{
        'fromShelfId': record.shelfId,
        'toShelfId': shelfId,
      },);
      return updated;
    });
  }

  @override
  Future<Result<InventoryRecord>> updateRecord(InventoryRecord record, {String? actorId}) async {
    final Result<DestroyPolicy> policyResult = await _policies.getActivePolicy();
    if (policyResult.isErr) return Result<InventoryRecord>.err(policyResult.failureOrNull!);
    return _guard(() async {
      final DestroyPolicy policy = policyResult.unwrap();
      final PolicyDecision decision = _engine.evaluate(
        policy,
        PolicyInput(
          expiry: record.expiryAt,
          receivedAt: record.receivedAt,
          precision: record.expiryPrecision,
          manufacturedAt: record.manufacturedAt,
        ),
      );
      final InventoryRecord updated = record.copyWith(
        expiryInstant: decision.expiryInstant,
        destroyAt: decision.destroyAt,
        leadTime: decision.leadTime,
        shelfLife: decision.shelfLife,
        policyId: decision.policyId,
        policyVersion: decision.policyVersion,
        policyRuleId: decision.matchedRule?.id,
        clearPolicyRule: decision.matchedRule == null,
        updatedAt: _clock.now(),
      );
      await _persist(updated, RecordEventType.updated, actorId: actorId);
      return updated;
    });
  }

  @override
  Future<Result<void>> closeRecord({
    required String recordId,
    required InventoryStatus status,
    String? note,
    String? actorId,
  }) async {
    return _guard(() async {
      final InventoryRecord? record = await _local.findRecord(recordId);
      if (record == null) throw StateError('record_not_found');
      final DateTime now = _clock.now();
      final InventoryRecord updated = record.copyWith(
        status: status,
        closedAt: status.isOpen ? null : now,
        clearClosedAt: status.isOpen,
        updatedAt: now,
      );
      final RecordEventType type = switch (status) {
        InventoryStatus.soldOut => RecordEventType.soldOut,
        InventoryStatus.removed => RecordEventType.removed,
        InventoryStatus.destroyed => RecordEventType.destroyed,
        InventoryStatus.active => RecordEventType.reopened,
      };
      await _persist(updated, type, actorId: actorId, note: note);
    });
  }

  @override
  Future<Result<int>> recalculateOpenRecords({String? actorId}) async {
    final Result<DestroyPolicy> policyResult = await _policies.getActivePolicy();
    if (policyResult.isErr) return Result<int>.err(policyResult.failureOrNull!);
    return _guard(() async {
      final DestroyPolicy policy = policyResult.unwrap();
      final List<InventoryRecord> open = await _local.openRecords();
      final DateTime now = _clock.now();
      int changed = 0;

      await _database.write(<String>{Tables.inventoryRecords, Tables.recordEvents},
          (Transaction txn) async {
        for (final InventoryRecord record in open) {
          final PolicyDecision decision = _engine.evaluate(
            policy,
            PolicyInput(
              expiry: record.expiryAt,
              receivedAt: record.receivedAt,
              precision: record.expiryPrecision,
              manufacturedAt: record.manufacturedAt,
            ),
          );
          final bool unchanged = decision.destroyAt == record.destroyAt &&
              decision.policyVersion == record.policyVersion &&
              decision.matchedRule?.id == record.policyRuleId;
          if (unchanged) continue;

          changed++;
          await txn.update(
            Tables.inventoryRecords,
            <String, Object?>{
              'expiry_instant': decision.expiryInstant.millisecondsSinceEpoch,
              'destroy_at': decision.destroyAt.millisecondsSinceEpoch,
              'lead_time_minutes': decision.leadTime.inMinutes,
              'shelf_life_minutes': decision.shelfLife.inMinutes,
              'policy_id': decision.policyId,
              'policy_version': decision.policyVersion,
              'policy_rule_id': decision.matchedRule?.id,
              'updated_at': now.millisecondsSinceEpoch,
            },
            where: 'id = ?',
            whereArgs: <Object?>[record.id],
          );
          await txn.insert(
            Tables.recordEvents,
            InventoryMapper.eventToRow(RecordEvent(
              id: _ids.newId(),
              recordId: record.id,
              type: RecordEventType.policyRecalculated,
              occurredAt: now,
              actorId: actorId,
              payload: <String, Object?>{
                'previousDestroyAt': record.destroyAt.toIso8601String(),
                'newDestroyAt': decision.destroyAt.toIso8601String(),
                'policyVersion': decision.policyVersion,
                'ruleId': decision.matchedRule?.id,
              },
            ),),
          );
        }
      });
      _logger.i(_tag, 'Recalculated $changed of ${open.length} open records');
      return changed;
    });
  }

  Future<void> _persist(
    InventoryRecord record,
    RecordEventType type, {
    String? actorId,
    double? quantityDelta,
    String? note,
    Map<String, Object?> payload = const <String, Object?>{},
  }) async {
    await _database.write(<String>{Tables.inventoryRecords, Tables.recordEvents},
        (Transaction txn) async {
      await txn.update(
        Tables.inventoryRecords,
        InventoryMapper.recordToRow(record),
        where: 'id = ?',
        whereArgs: <Object?>[record.id],
      );
      await txn.insert(
        Tables.recordEvents,
        InventoryMapper.eventToRow(RecordEvent(
          id: _ids.newId(),
          recordId: record.id,
          type: type,
          occurredAt: _clock.now(),
          actorId: actorId,
          quantityDelta: quantityDelta,
          note: note,
          payload: payload,
        ),),
      );
    });
    await _syncQueue.enqueueUpsert(
      entity: Tables.inventoryRecords,
      entityId: record.id,
      payload: InventoryMapper.recordToRow(record),
    );
  }

  double _round(double value) => (value * 1000).roundToDouble() / 1000;

  @override
  Stream<void> watchInventory() {
    return _database.changes.where((String table) =>
        table == Tables.inventoryRecords ||
        table == Tables.destructions ||
        table == Tables.recordEvents,);
  }

  Future<Result<T>> _guard<T>(Future<T> Function() action) async {
    try {
      return Result<T>.ok(await action());
    } on StateError catch (error) {
      return Result<T>.err(Failure.validation(error.message));
    } catch (error, stackTrace) {
      _logger.e(_tag, 'Inventory operation failed', error: error, stackTrace: stackTrace);
      return Result<T>.err(
        Failure.database('Inventory operation failed', cause: error, stackTrace: stackTrace),
      );
    }
  }
}
