import 'dart:convert';

import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';

abstract final class InventoryMapper {
  static InventoryRecord recordFromRow(Map<String, Object?> row) => InventoryRecord(
        id: row.str('id'),
        code: row.str('code'),
        productId: row.str('product_id'),
        batchCode: row.strOrNull('batch_code'),
        manufacturedAt: row.dateTimeOrNull('manufactured_at'),
        expiryAt: row.dateTime('expiry_at'),
        expiryPrecision: ExpiryPrecision.fromName(row.strOrNull('expiry_precision')),
        expiryInstant: row.dateTime('expiry_instant'),
        destroyAt: row.dateTime('destroy_at'),
        leadTime: row.duration('lead_time_minutes'),
        shelfLife: row.duration('shelf_life_minutes'),
        policyId: row.str('policy_id'),
        policyVersion: row.integer('policy_version'),
        policyRuleId: row.strOrNull('policy_rule_id'),
        areaId: row.strOrNull('area_id'),
        shelfId: row.strOrNull('shelf_id'),
        quantity: row.number('quantity'),
        quantityRemaining: row.number('quantity_remaining'),
        unit: row.strOrNull('unit') ?? 'pcs',
        unitCost: row.numberOrNull('unit_cost'),
        receivedAt: row.dateTime('received_at'),
        status: InventoryStatus.fromName(row.strOrNull('status')),
        photoPath: row.strOrNull('photo_path'),
        source: IntakeSource.fromName(row.strOrNull('source')),
        note: row.strOrNull('note'),
        createdBy: row.strOrNull('created_by'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
        closedAt: row.dateTimeOrNull('closed_at'),
      );

  static Map<String, Object?> recordToRow(InventoryRecord record) => <String, Object?>{
        'id': record.id,
        'code': record.code,
        'product_id': record.productId,
        'batch_code': record.batchCode,
        'manufactured_at': dateToMillis(record.manufacturedAt),
        'expiry_at': record.expiryAt.millisecondsSinceEpoch,
        'expiry_precision': record.expiryPrecision.name,
        'expiry_instant': record.expiryInstant.millisecondsSinceEpoch,
        'destroy_at': record.destroyAt.millisecondsSinceEpoch,
        'lead_time_minutes': record.leadTime.inMinutes,
        'shelf_life_minutes': record.shelfLife.inMinutes,
        'policy_id': record.policyId,
        'policy_version': record.policyVersion,
        'policy_rule_id': record.policyRuleId,
        'area_id': record.areaId,
        'shelf_id': record.shelfId,
        'quantity': record.quantity,
        'quantity_remaining': record.quantityRemaining,
        'unit': record.unit,
        'unit_cost': record.unitCost,
        'received_at': record.receivedAt.millisecondsSinceEpoch,
        'status': record.status.name,
        'photo_path': record.photoPath,
        'source': record.source.name,
        'note': record.note,
        'created_by': record.createdBy,
        'created_at': record.createdAt.millisecondsSinceEpoch,
        'updated_at': record.updatedAt.millisecondsSinceEpoch,
        'closed_at': dateToMillis(record.closedAt),
      };

  static RecordEvent eventFromRow(Map<String, Object?> row) {
    final String? raw = row.strOrNull('payload');
    Map<String, Object?> payload = const <String, Object?>{};
    if (raw != null && raw.isNotEmpty) {
      final Object? decoded = jsonDecode(raw);
      if (decoded is Map<String, Object?>) payload = decoded;
    }
    return RecordEvent(
      id: row.str('id'),
      recordId: row.str('record_id'),
      type: RecordEventType.fromName(row.strOrNull('type')),
      occurredAt: row.dateTime('occurred_at'),
      actorId: row.strOrNull('actor_id'),
      quantityDelta: row.numberOrNull('quantity_delta'),
      note: row.strOrNull('note'),
      payload: payload,
    );
  }

  static Map<String, Object?> eventToRow(RecordEvent event) => <String, Object?>{
        'id': event.id,
        'record_id': event.recordId,
        'type': event.type.name,
        'occurred_at': event.occurredAt.millisecondsSinceEpoch,
        'actor_id': event.actorId,
        'quantity_delta': event.quantityDelta,
        'note': event.note,
        'payload': event.payload.isEmpty ? null : jsonEncode(event.payload),
      };

  static Destruction destructionFromRow(Map<String, Object?> row) => Destruction(
        id: row.str('id'),
        recordId: row.str('record_id'),
        productId: row.str('product_id'),
        categoryId: row.strOrNull('category_id'),
        areaId: row.strOrNull('area_id'),
        shelfId: row.strOrNull('shelf_id'),
        quantity: row.number('quantity'),
        unitCost: row.numberOrNull('unit_cost'),
        lossAmount: row.number('loss_amount'),
        reason: DestructionReason.fromName(row.strOrNull('reason')),
        wasOverdue: row.boolean('was_overdue'),
        minutesLate: row.integer('minutes_late'),
        destroyedAt: row.dateTime('destroyed_at'),
        confirmedAt: row.dateTimeOrNull('confirmed_at') ?? row.dateTime('destroyed_at'),
        deviceId: row.strOrNull('device_id'),
        actorId: row.strOrNull('actor_id'),
        photoPath: row.strOrNull('photo_path'),
        note: row.strOrNull('note'),
        createdAt: row.dateTime('created_at'),
      );

  static Map<String, Object?> destructionToRow(Destruction destruction) => <String, Object?>{
        'id': destruction.id,
        'record_id': destruction.recordId,
        'product_id': destruction.productId,
        'category_id': destruction.categoryId,
        'area_id': destruction.areaId,
        'shelf_id': destruction.shelfId,
        'quantity': destruction.quantity,
        'unit_cost': destruction.unitCost,
        'loss_amount': destruction.lossAmount,
        'reason': destruction.reason.name,
        'was_overdue': boolToInt(destruction.wasOverdue),
        'minutes_late': destruction.minutesLate,
        'destroyed_at': destruction.destroyedAt.millisecondsSinceEpoch,
        'confirmed_at': destruction.confirmedAt.millisecondsSinceEpoch,
        'device_id': destruction.deviceId,
        'actor_id': destruction.actorId,
        'photo_path': destruction.photoPath,
        'note': destruction.note,
        'created_at': destruction.createdAt.millisecondsSinceEpoch,
      };
}
