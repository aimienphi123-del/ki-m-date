/// Builds the short code printed on the shelf label, e.g. `EG-260906-0007`.
///
/// The uniqueness guarantee comes from the unique index on
/// `inventory_records.code`; this generator only proposes candidates and the
/// repository retries on collision.
abstract interface class InventoryCodeGenerator {
  String next({required DateTime date, required int sequenceForDay});
}

class DatedSequenceCodeGenerator implements InventoryCodeGenerator {
  const DatedSequenceCodeGenerator({this.prefix = 'EG', this.sequenceWidth = 4});

  final String prefix;
  final int sequenceWidth;

  @override
  String next({required DateTime date, required int sequenceForDay}) {
    final String yy = (date.year % 100).toString().padLeft(2, '0');
    final String mm = date.month.toString().padLeft(2, '0');
    final String dd = date.day.toString().padLeft(2, '0');
    final String seq = sequenceForDay.toString().padLeft(sequenceWidth, '0');
    return '$prefix-$yy$mm$dd-$seq';
  }
}
