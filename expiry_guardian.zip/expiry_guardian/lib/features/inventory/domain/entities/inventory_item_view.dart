import 'package:expiry_guardian/features/catalog/domain/entities/product.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';

/// A record joined with everything a list row needs, plus the live priority
/// computed by the policy engine at query time.
class InventoryItemView {
  const InventoryItemView({
    required this.record,
    required this.product,
    required this.priority,
    this.area,
    this.shelf,
    this.categoryName,
  });

  final InventoryRecord record;
  final Product product;
  final PriorityAssessment priority;
  final StoreArea? area;
  final Shelf? shelf;
  final String? categoryName;

  String get locationLabel {
    final StoreArea? a = area;
    final Shelf? s = shelf;
    if (a == null && s == null) return '';
    if (a == null) return s!.name;
    if (s == null) return a.name;
    return '${a.name} · ${s.name}';
  }

  int get walkOrder => (area?.sortOrder ?? 9999) * 1000 + (shelf?.sortOrder ?? 999);

  double get lossValue => (record.unitCost ?? product.unitCost ?? 0) * record.quantityRemaining;
}

/// Sorting used by the daily destroy list:
/// priority -> store area -> shelf -> product name.
int compareForDestroyList(InventoryItemView a, InventoryItemView b) {
  final int byPriority = a.priority.level.rank.compareTo(b.priority.level.rank);
  if (byPriority != 0) return byPriority;

  final int byArea = (a.area?.sortOrder ?? 9999).compareTo(b.area?.sortOrder ?? 9999);
  if (byArea != 0) return byArea;

  final int byAreaName =
      (a.area?.name ?? '').toLowerCase().compareTo((b.area?.name ?? '').toLowerCase());
  if (byAreaName != 0) return byAreaName;

  final int byShelf = (a.shelf?.sortOrder ?? 999).compareTo(b.shelf?.sortOrder ?? 999);
  if (byShelf != 0) return byShelf;

  final int byShelfName =
      (a.shelf?.name ?? '').toLowerCase().compareTo((b.shelf?.name ?? '').toLowerCase());
  if (byShelfName != 0) return byShelfName;

  final int byDestroy = a.record.destroyAt.compareTo(b.record.destroyAt);
  if (byDestroy != 0) return byDestroy;

  return a.product.name.toLowerCase().compareTo(b.product.name.toLowerCase());
}
