/// Lifecycle of one inventory record.
///
/// Note that "expired" is deliberately **not** a status: whether goods are past
/// their expiry instant is a function of the clock, not a stored flag, so the
/// app never needs a background job to mutate rows and can never show a stale
/// state after the phone has been off overnight.
enum InventoryStatus {
  /// On the shelf, counting down.
  active,

  /// Pulled and destroyed under the policy.
  destroyed,

  /// Sold or consumed before the destroy date.
  soldOut,

  /// Returned to supplier, transferred out, or entered by mistake.
  removed;

  bool get isOpen => this == InventoryStatus.active;

  static InventoryStatus fromName(String? value) => switch (value) {
        'destroyed' => InventoryStatus.destroyed,
        'soldOut' => InventoryStatus.soldOut,
        'removed' => InventoryStatus.removed,
        _ => InventoryStatus.active,
      };
}

/// How a record entered the system.
enum IntakeSource {
  scan,
  manual,
  csvImport;

  static IntakeSource fromName(String? value) => switch (value) {
        'manual' => IntakeSource.manual,
        'csvImport' => IntakeSource.csvImport,
        _ => IntakeSource.scan,
      };
}

enum DestructionReason {
  policy,
  damaged,
  recalled,
  contaminated,
  other;

  static DestructionReason fromName(String? value) => switch (value) {
        'damaged' => DestructionReason.damaged,
        'recalled' => DestructionReason.recalled,
        'contaminated' => DestructionReason.contaminated,
        'other' => DestructionReason.other,
        _ => DestructionReason.policy,
      };
}

enum RecordEventType {
  created,
  updated,
  quantityAdjusted,
  moved,
  destroyed,
  soldOut,
  removed,
  reopened,
  policyRecalculated,
  photoAttached,
  noteAdded;

  static RecordEventType fromName(String? value) => RecordEventType.values.firstWhere(
        (RecordEventType t) => t.name == value,
        orElse: () => RecordEventType.updated,
      );
}
