import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';

/// One tracked lot of one product on one shelf.
///
/// Every field that the policy engine produced is stored alongside the raw
/// dates, so a destroy date can always be explained: which policy, which
/// version, which rule, what lead time, what shelf life.
class InventoryRecord {
  const InventoryRecord({
    required this.id,
    required this.code,
    required this.productId,
    required this.expiryAt,
    required this.expiryPrecision,
    required this.expiryInstant,
    required this.destroyAt,
    required this.leadTime,
    required this.shelfLife,
    required this.policyId,
    required this.policyVersion,
    required this.quantity,
    required this.quantityRemaining,
    required this.unit,
    required this.receivedAt,
    required this.status,
    required this.source,
    required this.createdAt,
    required this.updatedAt,
    this.batchCode,
    this.manufacturedAt,
    this.policyRuleId,
    this.areaId,
    this.shelfId,
    this.unitCost,
    this.photoPath,
    this.note,
    this.createdBy,
    this.closedAt,
  });

  final String id;

  /// Short human-readable identifier printed on the shelf label.
  final String code;

  final String productId;
  final String? batchCode;

  final DateTime? manufacturedAt;

  /// Exactly what the label said.
  final DateTime expiryAt;
  final ExpiryPrecision expiryPrecision;

  /// The engine's resolved expiry instant (end of day for date labels).
  final DateTime expiryInstant;

  /// The engine's destroy instant.
  final DateTime destroyAt;

  final Duration leadTime;
  final Duration shelfLife;

  final String policyId;
  final int policyVersion;
  final String? policyRuleId;

  final String? areaId;
  final String? shelfId;

  final double quantity;
  final double quantityRemaining;
  final String unit;
  final double? unitCost;

  final DateTime receivedAt;
  final InventoryStatus status;
  final String? photoPath;
  final IntakeSource source;
  final String? note;
  final String? createdBy;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? closedAt;

  double get remainingValue => (unitCost ?? 0) * quantityRemaining;

  bool isExpiredAt(DateTime now) => now.isAfter(expiryInstant);

  bool isDueAt(DateTime now) => !now.isBefore(destroyAt);

  InventoryRecord copyWith({
    String? batchCode,
    bool clearBatchCode = false,
    DateTime? manufacturedAt,
    bool clearManufacturedAt = false,
    DateTime? expiryAt,
    ExpiryPrecision? expiryPrecision,
    DateTime? expiryInstant,
    DateTime? destroyAt,
    Duration? leadTime,
    Duration? shelfLife,
    String? policyId,
    int? policyVersion,
    String? policyRuleId,
    bool clearPolicyRule = false,
    String? areaId,
    bool clearArea = false,
    String? shelfId,
    bool clearShelf = false,
    double? quantity,
    double? quantityRemaining,
    String? unit,
    double? unitCost,
    bool clearUnitCost = false,
    DateTime? receivedAt,
    InventoryStatus? status,
    String? photoPath,
    String? note,
    DateTime? updatedAt,
    DateTime? closedAt,
    bool clearClosedAt = false,
  }) {
    return InventoryRecord(
      id: id,
      code: code,
      productId: productId,
      batchCode: clearBatchCode ? null : (batchCode ?? this.batchCode),
      manufacturedAt: clearManufacturedAt ? null : (manufacturedAt ?? this.manufacturedAt),
      expiryAt: expiryAt ?? this.expiryAt,
      expiryPrecision: expiryPrecision ?? this.expiryPrecision,
      expiryInstant: expiryInstant ?? this.expiryInstant,
      destroyAt: destroyAt ?? this.destroyAt,
      leadTime: leadTime ?? this.leadTime,
      shelfLife: shelfLife ?? this.shelfLife,
      policyId: policyId ?? this.policyId,
      policyVersion: policyVersion ?? this.policyVersion,
      policyRuleId: clearPolicyRule ? null : (policyRuleId ?? this.policyRuleId),
      areaId: clearArea ? null : (areaId ?? this.areaId),
      shelfId: clearShelf ? null : (shelfId ?? this.shelfId),
      quantity: quantity ?? this.quantity,
      quantityRemaining: quantityRemaining ?? this.quantityRemaining,
      unit: unit ?? this.unit,
      unitCost: clearUnitCost ? null : (unitCost ?? this.unitCost),
      receivedAt: receivedAt ?? this.receivedAt,
      status: status ?? this.status,
      photoPath: photoPath ?? this.photoPath,
      source: source,
      note: note ?? this.note,
      createdBy: createdBy,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      closedAt: clearClosedAt ? null : (closedAt ?? this.closedAt),
    );
  }

  @override
  String toString() => 'InventoryRecord($code, destroyAt=$destroyAt, $status)';
}

/// An audit-trail entry. Records are never silently mutated.
class RecordEvent {
  const RecordEvent({
    required this.id,
    required this.recordId,
    required this.type,
    required this.occurredAt,
    this.actorId,
    this.quantityDelta,
    this.note,
    this.payload = const <String, Object?>{},
  });

  final String id;
  final String recordId;
  final RecordEventType type;
  final DateTime occurredAt;
  final String? actorId;
  final double? quantityDelta;
  final String? note;
  final Map<String, Object?> payload;
}

/// A completed destruction - the row that reports and financial loss read.
class Destruction {
  const Destruction({
    required this.id,
    required this.recordId,
    required this.productId,
    required this.quantity,
    required this.lossAmount,
    required this.reason,
    required this.wasOverdue,
    required this.minutesLate,
    required this.destroyedAt,
    required this.confirmedAt,
    required this.createdAt,
    this.deviceId,
    this.categoryId,
    this.areaId,
    this.shelfId,
    this.unitCost,
    this.actorId,
    this.photoPath,
    this.note,
  });

  final String id;
  final String recordId;
  final String productId;
  final String? categoryId;
  final String? areaId;
  final String? shelfId;
  final double quantity;
  final double? unitCost;

  /// quantity * unitCost. Zero when no cost has been entered for the product -
  /// the app never guesses a price.
  final double lossAmount;

  final DestructionReason reason;

  /// True when the destruction happened after the policy destroy instant.
  final bool wasOverdue;
  final int minutesLate;

  final DateTime destroyedAt;

  /// When the employee pressed "confirm". Usually the same instant as
  /// [destroyedAt]; different when a destruction is entered after the fact.
  final DateTime confirmedAt;

  /// Which handset the confirmation was made on. Part of the signature the
  /// workflow requires: employee, date and time, quantity, device.
  final String? deviceId;

  final String? actorId;
  final String? photoPath;
  final String? note;
  final DateTime createdAt;

  /// A destruction is only a valid confirmation when it names both the
  /// employee and the device it was made on.
  bool get isConfirmed => actorId != null && deviceId != null;
}
