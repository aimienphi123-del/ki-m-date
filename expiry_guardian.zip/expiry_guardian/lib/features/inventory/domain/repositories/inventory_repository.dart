import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';

enum InventorySort { destroyDate, expiryDate, receivedDate, productName, location, priority }

/// Search / filter criteria shared by the inventory screen, the daily task list
/// and the reports.
class InventoryQuery {
  const InventoryQuery({
    this.text,
    this.barcode,
    this.batchCode,
    this.productId,
    this.categoryId,
    this.areaId,
    this.shelfId,
    this.statuses = const <InventoryStatus>{InventoryStatus.active},
    this.priorities = const <PriorityLevel>{},
    this.destroyBefore,
    this.destroyAfter,
    this.expiryBefore,
    this.expiryAfter,
    this.receivedBefore,
    this.receivedAfter,
    this.sort = InventorySort.priority,
    this.descending = false,
    this.limit = 200,
    this.offset = 0,
  });

  /// Free text: matched against product name, brand, batch code and record code.
  final String? text;
  final String? barcode;
  final String? batchCode;
  final String? productId;
  final String? categoryId;
  final String? areaId;
  final String? shelfId;
  final Set<InventoryStatus> statuses;

  /// Applied after the priority assessment, in memory.
  final Set<PriorityLevel> priorities;

  final DateTime? destroyBefore;
  final DateTime? destroyAfter;
  final DateTime? expiryBefore;
  final DateTime? expiryAfter;
  final DateTime? receivedBefore;
  final DateTime? receivedAfter;

  final InventorySort sort;
  final bool descending;
  final int limit;
  final int offset;

  InventoryQuery copyWith({
    String? text,
    bool clearText = false,
    String? barcode,
    String? batchCode,
    String? productId,
    String? categoryId,
    bool clearCategory = false,
    String? areaId,
    bool clearArea = false,
    String? shelfId,
    bool clearShelf = false,
    Set<InventoryStatus>? statuses,
    Set<PriorityLevel>? priorities,
    DateTime? destroyBefore,
    bool clearDestroyBefore = false,
    DateTime? destroyAfter,
    bool clearDestroyAfter = false,
    InventorySort? sort,
    bool? descending,
    int? limit,
    int? offset,
  }) {
    return InventoryQuery(
      text: clearText ? null : (text ?? this.text),
      barcode: barcode ?? this.barcode,
      batchCode: batchCode ?? this.batchCode,
      productId: productId ?? this.productId,
      categoryId: clearCategory ? null : (categoryId ?? this.categoryId),
      areaId: clearArea ? null : (areaId ?? this.areaId),
      shelfId: clearShelf ? null : (shelfId ?? this.shelfId),
      statuses: statuses ?? this.statuses,
      priorities: priorities ?? this.priorities,
      destroyBefore: clearDestroyBefore ? null : (destroyBefore ?? this.destroyBefore),
      destroyAfter: clearDestroyAfter ? null : (destroyAfter ?? this.destroyAfter),
      expiryBefore: expiryBefore,
      expiryAfter: expiryAfter,
      receivedBefore: receivedBefore,
      receivedAfter: receivedAfter,
      sort: sort ?? this.sort,
      descending: descending ?? this.descending,
      limit: limit ?? this.limit,
      offset: offset ?? this.offset,
    );
  }
}

/// Everything captured at goods-in for a single lot.
class IntakeDraft {
  const IntakeDraft({
    required this.productId,
    required this.expiryAt,
    required this.expiryPrecision,
    required this.quantity,
    this.batchCode,
    this.manufacturedAt,
    this.shelfId,
    this.unit,
    this.unitCost,
    this.photoPath,
    this.note,
    this.receivedAt,
    this.source = IntakeSource.scan,
  });

  final String productId;
  final DateTime expiryAt;
  final ExpiryPrecision expiryPrecision;
  final DateTime? manufacturedAt;
  final String? batchCode;
  final double quantity;
  final String? unit;
  final double? unitCost;
  final String? shelfId;
  final String? photoPath;
  final String? note;
  final DateTime? receivedAt;
  final IntakeSource source;
}

class DestroyCommand {
  const DestroyCommand({
    required this.recordId,
    this.quantity,
    this.reason = DestructionReason.policy,
    this.note,
    this.photoPath,
    this.at,
    this.deviceId,
    this.confirmedAt,
  });

  final String recordId;

  /// `null` destroys everything that is left.
  final double? quantity;
  final DestructionReason reason;
  final String? note;
  final String? photoPath;
  final DateTime? at;

  /// Which handset confirmed it. Filled in by the workflow service.
  final String? deviceId;

  /// When the employee confirmed, if different from [at].
  final DateTime? confirmedAt;
}

/// Aggregated counters for the dashboard, computed with SQL - never estimated.
class InventorySummary {
  const InventorySummary({
    required this.activeRecords,
    required this.activeUnits,
    required this.approachingRecords,
    required this.dueTodayRecords,
    required this.overdueRecords,
    required this.expiredRecords,
    required this.destroyedTodayRecords,
    required this.destroyedTodayUnits,
    required this.destroyedTodayLoss,
    required this.activeStockValue,
    required this.pricedProductsRatio,
  });

  final int activeRecords;
  final double activeUnits;
  final int approachingRecords;
  final int dueTodayRecords;
  final int overdueRecords;
  final int expiredRecords;
  final int destroyedTodayRecords;
  final double destroyedTodayUnits;
  final double destroyedTodayLoss;
  final double activeStockValue;

  /// Share of active records that have a unit cost. The dashboard shows this so
  /// nobody mistakes a partial loss figure for the full one.
  final double pricedProductsRatio;
}

abstract interface class InventoryRepository {
  Future<Result<InventoryRecord>> intake(IntakeDraft draft, {String? actorId});

  Future<Result<InventoryItemView?>> findView(String recordId);

  Future<Result<InventoryRecord?>> findRecord(String recordId);

  Future<Result<List<InventoryItemView>>> search(InventoryQuery query);

  Future<Result<int>> count(InventoryQuery query);

  /// The morning destroy list: everything due up to [until], plus anything
  /// already overdue or expired.
  Future<Result<List<InventoryItemView>>> destroyList({required DateTime until});

  Future<Result<InventorySummary>> summary({required DateTime dayStart, required DateTime dayEnd});

  Future<Result<Destruction>> destroy(DestroyCommand command, {String? actorId});

  Future<Result<InventoryRecord>> adjustQuantity({
    required String recordId,
    required double newQuantityRemaining,
    String? note,
    String? actorId,
  });

  Future<Result<InventoryRecord>> moveToShelf({
    required String recordId,
    required String? shelfId,
    String? actorId,
  });

  Future<Result<InventoryRecord>> updateRecord(InventoryRecord record, {String? actorId});

  Future<Result<void>> closeRecord({
    required String recordId,
    required InventoryStatus status,
    String? note,
    String? actorId,
  });

  Future<Result<List<RecordEvent>>> history(String recordId);

  /// Re-runs the policy engine over every open record. Called after a manager
  /// edits the handbook so existing stock immediately follows the new rules.
  Future<Result<int>> recalculateOpenRecords({String? actorId});

  /// Records whose destroy instant falls inside the window - used to schedule
  /// notifications.
  Future<Result<List<InventoryItemView>>> dueBetween(DateTime from, DateTime to);

  Future<Result<List<Destruction>>> destructionsBetween(DateTime from, DateTime to);

  /// Every confirmed destruction of one lot - who confirmed it, when, on which
  /// device, and how much. What the record screen shows under "confirmed".
  Future<Result<List<Destruction>>> destructionsFor(String recordId);

  Stream<void> watchInventory();
}
