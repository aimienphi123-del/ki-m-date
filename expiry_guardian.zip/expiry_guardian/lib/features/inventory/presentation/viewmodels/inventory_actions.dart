import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Write-side operations on stock, shared by the task list, the stock list and
/// the record detail screen.
///
/// Every operation reschedules the reminders afterwards, because destroying,
/// moving or adjusting a lot changes what the phone should remind about.
class InventoryActions {
  const InventoryActions(this._ref);

  final Ref _ref;

  InventoryRepository get _repository => _ref.read(inventoryRepositoryProvider);
  OperationWorkflowService get _workflow => _ref.read(workflowServiceProvider);
  AppUser? get _actor => _ref.read(sessionProvider).valueOrNull?.user;

  /// Feature 2: a destruction is never written directly. It goes through the
  /// workflow service, which requires a signed-in employee and a device id,
  /// stops the remaining reminders, resolves any manager escalation and writes
  /// the audit entry - all of it, or none of it.
  Future<Result<DestroyConfirmationResult>> confirmDestruction(
    DestroyConfirmation confirmation,
  ) =>
      _workflow.confirmDestruction(confirmation);

  Future<Result<InventoryRecord>> adjustQuantity({
    required String recordId,
    required double newQuantity,
    String? note,
  }) async {
    final Result<InventoryRecord> result = await _repository.adjustQuantity(
      recordId: recordId,
      newQuantityRemaining: newQuantity,
      note: note,
      actorId: _actor?.id,
    );
    if (result.isOk) await _refreshReminders();
    return result;
  }

  Future<Result<InventoryRecord>> moveToShelf({
    required String recordId,
    required String? shelfId,
  }) async {
    final Result<InventoryRecord> result = await _repository.moveToShelf(
      recordId: recordId,
      shelfId: shelfId,
      actorId: _actor?.id,
    );
    if (result.isOk) await _refreshReminders();
    return result;
  }

  /// Closing a lot any other way also clears its alerts and reminders, so it
  /// goes through the same owner.
  Future<Result<void>> close({
    required String recordId,
    required InventoryStatus status,
    String? note,
  }) =>
      _workflow.closeRecord(recordId: recordId, status: status, note: note);

  Future<Result<InventoryRecord>> update(InventoryRecord record) async {
    final Result<InventoryRecord> result =
        await _repository.updateRecord(record, actorId: _actor?.id);
    if (result.isOk) await _refreshReminders();
    return result;
  }

  Future<Result<int>> recalculateAfterPolicyChange() async {
    final Result<int> result =
        await _repository.recalculateOpenRecords(actorId: _actor?.id);
    if (result.isOk) await _refreshReminders();
    return result;
  }

  Future<void> _refreshReminders() async {
    final NotificationPlanner planner = _ref.read(dependenciesProvider).notificationPlanner;
    final Result<NotificationPlan> result = await planner.reschedule(
      preferences: _ref.read(notificationPreferencesProvider),
      strings: _ref.read(stringsProvider),
    );
    if (result.isErr) {
      _ref.read(dependenciesProvider).logger.w(
            'InventoryActions',
            'Reminder refresh failed: ${result.failureOrNull?.message}',
          );
    }
  }
}

final Provider<InventoryActions> inventoryActionsProvider =
    Provider<InventoryActions>(InventoryActions.new);

/// Localised label for a record status.
String statusLabel(AppLocalizations l10n, InventoryStatus status) => l10n.t(switch (status) {
      InventoryStatus.active => 'record.status.active',
      InventoryStatus.destroyed => 'record.status.destroyed',
      InventoryStatus.soldOut => 'record.status.soldOut',
      InventoryStatus.removed => 'record.status.removed',
    },);

/// Localised label for a destruction reason.
String reasonLabel(AppLocalizations l10n, DestructionReason reason) => l10n.t(switch (reason) {
      DestructionReason.policy => 'destroy.reason.policy',
      DestructionReason.damaged => 'destroy.reason.damaged',
      DestructionReason.recalled => 'destroy.reason.recalled',
      DestructionReason.contaminated => 'destroy.reason.contaminated',
      DestructionReason.other => 'destroy.reason.other',
    },);

/// Localised label for a history event.
String eventLabel(AppLocalizations l10n, RecordEventType type) => l10n.t(switch (type) {
      RecordEventType.created => 'event.created',
      RecordEventType.updated => 'event.updated',
      RecordEventType.quantityAdjusted => 'event.quantityAdjusted',
      RecordEventType.moved => 'event.moved',
      RecordEventType.destroyed => 'event.destroyed',
      RecordEventType.soldOut => 'event.soldOut',
      RecordEventType.removed => 'event.removed',
      RecordEventType.reopened => 'event.reopened',
      RecordEventType.policyRecalculated => 'event.policyRecalculated',
      RecordEventType.photoAttached => 'event.photoAttached',
      RecordEventType.noteAdded => 'event.noteAdded',
    },);

Failure? failureOf(Result<Object?> result) => result.failureOrNull;
