import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// The live filter set of the stock screen.
final NotifierProvider<InventoryQueryController, InventoryQuery> inventoryQueryProvider =
    NotifierProvider<InventoryQueryController, InventoryQuery>(InventoryQueryController.new);

class InventoryQueryController extends Notifier<InventoryQuery> {
  @override
  InventoryQuery build() => const InventoryQuery();

  void setText(String? text) =>
      state = state.copyWith(text: text, clearText: text == null || text.isEmpty);

  void setArea(String? areaId) =>
      state = state.copyWith(areaId: areaId, clearArea: areaId == null, clearShelf: true);

  void setShelf(String? shelfId) =>
      state = state.copyWith(shelfId: shelfId, clearShelf: shelfId == null);

  void setCategory(String? categoryId) =>
      state = state.copyWith(categoryId: categoryId, clearCategory: categoryId == null);

  void setStatuses(Set<InventoryStatus> statuses) => state = state.copyWith(statuses: statuses);

  void togglePriority(PriorityLevel level) {
    final Set<PriorityLevel> next = <PriorityLevel>{...state.priorities};
    if (!next.remove(level)) next.add(level);
    state = state.copyWith(priorities: next);
  }

  void setSort(InventorySort sort, {bool? descending}) =>
      state = state.copyWith(sort: sort, descending: descending ?? state.descending);

  void reset() => state = const InventoryQuery();
}

/// The result list. Re-runs whenever the filters or the underlying rows change.
final FutureProvider<List<InventoryItemView>> inventoryListProvider =
    FutureProvider<List<InventoryItemView>>((Ref ref) async {
  ref.watch(inventoryChangesProvider);
  ref.watch(activePolicyProvider);
  final InventoryQuery query = ref.watch(inventoryQueryProvider);
  final Result<List<InventoryItemView>> result =
      await ref.watch(inventoryRepositoryProvider).search(query);
  return result.fold((Failure f) => throw f, (List<InventoryItemView> v) => v);
});

/// A single record with its product and location, for the detail screen.
final FutureProviderFamily<InventoryItemView?, String> recordViewProvider =
    FutureProvider.family<InventoryItemView?, String>((Ref ref, String recordId) async {
  ref.watch(inventoryChangesProvider);
  final Result<InventoryItemView?> result =
      await ref.watch(inventoryRepositoryProvider).findView(recordId);
  return result.fold((Failure f) => throw f, (InventoryItemView? v) => v);
});

final FutureProviderFamily<List<RecordEvent>, String> recordHistoryProvider =
    FutureProvider.family<List<RecordEvent>, String>((Ref ref, String recordId) async {
  ref.watch(inventoryChangesProvider);
  final Result<List<RecordEvent>> result =
      await ref.watch(inventoryRepositoryProvider).history(recordId);
  return result.fold((Failure f) => throw f, (List<RecordEvent> v) => v);
});

/// Every confirmed destruction of one lot - the employee, the moment, the
/// device and the quantity that Feature 2 requires be recorded.
final FutureProviderFamily<List<Destruction>, String> recordDestructionsProvider =
    FutureProvider.family<List<Destruction>, String>((Ref ref, String recordId) async {
  ref.watch(inventoryChangesProvider);
  final Result<List<Destruction>> result =
      await ref.watch(inventoryRepositoryProvider).destructionsFor(recordId);
  return result.valueOrNull ?? const <Destruction>[];
});

/// Areas and shelves for the filter and the "move" dialog.
final FutureProvider<List<ShelfLocation>> shelfLocationsProvider =
    FutureProvider<List<ShelfLocation>>((Ref ref) async {
  ref.watch(locationChangesProvider);
  final Result<List<ShelfLocation>> result =
      await ref.watch(locationRepositoryProvider).listShelfLocations();
  return result.fold((Failure f) => throw f, (List<ShelfLocation> v) => v);
});

final FutureProvider<List<StoreArea>> storeAreasProvider =
    FutureProvider<List<StoreArea>>((Ref ref) async {
  ref.watch(locationChangesProvider);
  final Result<List<StoreArea>> result =
      await ref.watch(locationRepositoryProvider).listAreas();
  return result.fold((Failure f) => throw f, (List<StoreArea> v) => v);
});
