import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/core/theme/priority_palette.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// One row of stock. Designed for a thumb: the whole row opens the detail
/// screen and the destroy button is a full-height target on the trailing edge.
class InventoryItemTile extends ConsumerWidget {
  const InventoryItemTile({
    required this.item,
    this.onTap,
    this.onDestroy,
    this.showLocation = true,
    super.key,
  });

  final InventoryItemView item;
  final VoidCallback? onTap;
  final VoidCallback? onDestroy;
  final bool showLocation;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final PriorityColors colors = PriorityPalette.of(context, item.priority.level);
    final String currency = ref.watch(currencySymbolProvider);

    final String countdown = item.priority.isOverdue
        ? l10n.t(K.recordOverdueBy,
            <String, Object?>{'duration': l10n.duration(item.priority.timeUntilDestroy)},)
        : l10n.t(K.recordTimeLeft,
            <String, Object?>{'duration': l10n.duration(item.priority.timeUntilDestroy)},);

    return AppCard(
      onTap: onTap,
      padding: EdgeInsets.zero,
      borderColor: colors.border,
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(width: 6, color: colors.foreground),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 0, 12),
              child: _ProductAvatar(
                path: item.product.photoPath,
                label: item.product.displayName,
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 8, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            item.product.displayName,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                        ),
                        const SizedBox(width: Dimens.gapS),
                        PriorityBadge(level: item.priority.level, compact: true),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: Dimens.gapM,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: <Widget>[
                        _Meta(
                          icon: Icons.schedule,
                          text: countdown,
                          color: colors.foreground,
                          emphasise: true,
                        ),
                        if (showLocation && item.locationLabel.isNotEmpty)
                          _Meta(icon: Icons.place_outlined, text: item.locationLabel),
                        _Meta(
                          icon: Icons.inventory_2_outlined,
                          text: '${l10n.number(item.record.quantityRemaining,
                              decimals: item.record.quantityRemaining % 1 == 0 ? 0 : 1,)}'
                              ' ${item.record.unit}',
                        ),
                        if (item.record.batchCode != null)
                          _Meta(icon: Icons.tag, text: item.record.batchCode!),
                        _Meta(
                          icon: Icons.qr_code_2,
                          text: item.product.barcode ?? l10n.t(K.catalogNoBarcode),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${l10n.t(K.recordDestroyAt)}: ${item.record.expiryPrecision.isHourly ? l10n.dateTime(item.record.destroyAt) : l10n.date(item.record.destroyAt)}'
                      '${item.lossValue > 0 ? ' · ${l10n.money(item.lossValue, symbol: currency)}' : ''}',
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            ),
            if (onDestroy != null)
              Semantics(
                button: true,
                label: l10n.t(K.todayMarkDestroyed),
                child: InkWell(
                  onTap: onDestroy,
                  child: Container(
                    width: 72,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: colors.background,
                      border: Border(left: BorderSide(color: colors.border)),
                      borderRadius: const BorderRadius.horizontal(
                        right: Radius.circular(Dimens.radius),
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(Icons.delete_forever_outlined, color: colors.foreground),
                        const SizedBox(height: 2),
                        Text(
                          l10n.t(K.todayMarkDestroyed),
                          textAlign: TextAlign.center,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: colors.foreground,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta({
    required this.icon,
    required this.text,
    this.color,
    this.emphasise = false,
  });

  final IconData icon;
  final String text;
  final Color? color;
  final bool emphasise;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final Color effective = color ?? theme.colorScheme.onSurfaceVariant;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, size: 15, color: effective),
        const SizedBox(width: 4),
        Text(
          text,
          style: theme.textTheme.bodySmall?.copyWith(
            color: effective,
            fontWeight: emphasise ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

/// Colour key shown at the top of the task list.
class PriorityLegend extends StatelessWidget {
  const PriorityLegend({super.key});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: Dimens.gapS,
      runSpacing: Dimens.gapS,
      children: PriorityLevel.values
          .map((PriorityLevel level) => PriorityBadge(level: level))
          .toList(growable: false),
    );
  }
}

/// The product's picture in the stock list, or its initials when there is none.
///
/// Matching a lot on a shelf by sight is faster than reading a name off a
/// phone, which is the whole reason the photo is offered on the catalog form.
class _ProductAvatar extends StatelessWidget {
  const _ProductAvatar({required this.path, required this.label});

  final String? path;
  final String label;

  static const double _size = 52;

  @override
  Widget build(BuildContext context) {
    final String? current = path;
    final bool hasPhoto = current != null && current.isNotEmpty;

    return ClipRRect(
      borderRadius: BorderRadius.circular(Dimens.radiusSmall),
      child: SizedBox(
        width: _size,
        height: _size,
        child: hasPhoto
            ? Image.file(
                File(current),
                fit: BoxFit.cover,
                // A photo the OS cleaned up must not blank the row.
                errorBuilder: (BuildContext context, Object _, StackTrace? __) =>
                    _Initials(label: label),
              )
            : _Initials(label: label),
      ),
    );
  }
}

class _Initials extends StatelessWidget {
  const _Initials({required this.label});

  final String label;

  String get _initials {
    final List<String> words = label
        .trim()
        .split(RegExp(r'\s+'))
        .where((String w) => w.isNotEmpty)
        .toList();
    if (words.isEmpty) return '?';
    if (words.length == 1) return words.first.characters.first.toUpperCase();
    return (words.first.characters.first + words[1].characters.first).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return ColoredBox(
      color: theme.colorScheme.surfaceContainerHighest,
      child: Center(
        child: Text(
          _initials,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w800,
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}
