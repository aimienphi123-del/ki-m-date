import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_actions.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/camera_capture_page.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Two-tap destruction: open the sheet, confirm. Everything else on the sheet
/// has a sensible default already filled in.
///
/// Returns what the workflow did - the destruction row, how many pending
/// reminders were cancelled and how many manager alerts it closed - so the
/// caller can tell the employee, not just that it saved.
Future<DestroyConfirmationResult?> showDestroySheet(
  BuildContext context, {
  required InventoryItemView item,
}) {
  return showModalBottomSheet<DestroyConfirmationResult>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (BuildContext context) => _DestroySheet(item: item),
  );
}

class _DestroySheet extends ConsumerStatefulWidget {
  const _DestroySheet({required this.item});

  final InventoryItemView item;

  @override
  ConsumerState<_DestroySheet> createState() => _DestroySheetState();
}

class _DestroySheetState extends ConsumerState<_DestroySheet> {
  late double _quantity = widget.item.record.quantityRemaining;
  DestructionReason _reason = DestructionReason.policy;
  final TextEditingController _note = TextEditingController();
  String? _photoPath;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _error = null;
    });

    // The spinner is cleared in `finally`, not on the success and failure
    // branches. Clearing it only where things went as expected is what turns
    // any unforeseen throw into a sheet that spins for ever and can only be
    // escaped with the back button.
    DestroyConfirmationResult? confirmed;
    String? message;
    try {
      final Result<DestroyConfirmationResult> result =
          await ref.read(inventoryActionsProvider).confirmDestruction(
                DestroyConfirmation(
                  recordId: widget.item.record.id,
                  quantity: _quantity,
                  reason: _reason,
                  note: _note.text.trim().isEmpty ? null : _note.text.trim(),
                  photoPath: _photoPath,
                ),
              );
      if (!mounted) return;
      result.fold(
        (Failure failure) => message = describeFailure(context, failure),
        (DestroyConfirmationResult value) => confirmed = value,
      );
    } on Object catch (error) {
      if (!mounted) return;
      message = '${context.l10n.t(K.errorGeneric)} ($error)';
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = message;
        });
      }
    }

    final DestroyConfirmationResult? done = confirmed;
    if (done != null && mounted) Navigator.of(context).pop(done);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final SettingsStore settings = ref.watch(settingsStoreProvider);
    final String currency = ref.watch(currencySymbolProvider);
    final InventoryItemView item = widget.item;
    final bool requirePhoto =
        settings.readBool(SettingKeys.requirePhotoOnDestroy, SettingDefaults.requirePhotoOnDestroy);
    final double unitCost = item.record.unitCost ?? item.product.unitCost ?? 0;
    final bool canSubmit = !_busy &&
        _quantity > 0 &&
        _quantity <= item.record.quantityRemaining &&
        (!requirePhoto || _photoPath != null);

    return Padding(
      padding: EdgeInsets.only(
        left: Dimens.gutter,
        right: Dimens.gutter,
        top: Dimens.gutter,
        bottom: MediaQuery.of(context).viewInsets.bottom + Dimens.gutter,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Center(
              child: Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                  color: theme.colorScheme.outlineVariant,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: Dimens.gapM),
            Text(
              l10n.t(K.destroyTitle),
              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: Dimens.gapXs),
            Text(
              item.product.displayName,
              style: theme.textTheme.bodyLarge,
            ),
            if (item.locationLabel.isNotEmpty)
              Text(
                item.locationLabel,
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
            if (item.priority.isOverdue) ...<Widget>[
              const SizedBox(height: Dimens.gapM),
              NoticeBanner(
                tone: NoticeTone.danger,
                icon: Icons.report_gmailerrorred_outlined,
                message: l10n.t(K.destroyOverdueNotice, <String, Object?>{
                  'duration': l10n.duration(item.priority.timeUntilDestroy),
                }),
              ),
            ],
            const SizedBox(height: Dimens.gapL),
            Text(l10n.t(K.destroyQuantityToDestroy), style: theme.textTheme.labelLarge),
            const SizedBox(height: Dimens.gapS),
            Row(
              children: <Widget>[
                IconButton.filledTonal(
                  iconSize: 28,
                  onPressed: _quantity <= 1
                      ? null
                      : () => setState(() => _quantity = (_quantity - 1).clamp(
                            0,
                            item.record.quantityRemaining,
                          ),),
                  icon: const Icon(Icons.remove),
                ),
                Expanded(
                  child: Text(
                    '${l10n.number(_quantity, decimals: _quantity % 1 == 0 ? 0 : 2)} ${item.record.unit}',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
                IconButton.filledTonal(
                  iconSize: 28,
                  onPressed: _quantity >= item.record.quantityRemaining
                      ? null
                      : () => setState(() => _quantity = (_quantity + 1)
                          .clamp(0, item.record.quantityRemaining),),
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            Center(
              child: TextButton(
                onPressed: _quantity == item.record.quantityRemaining
                    ? null
                    : () => setState(() => _quantity = item.record.quantityRemaining),
                child: Text(l10n.t(K.destroyAll)),
              ),
            ),
            const SizedBox(height: Dimens.gapM),
            Text(l10n.t(K.commonReason), style: theme.textTheme.labelLarge),
            const SizedBox(height: Dimens.gapS),
            Wrap(
              spacing: Dimens.gapS,
              runSpacing: Dimens.gapS,
              children: DestructionReason.values
                  .map((DestructionReason reason) => ChoiceChip(
                        label: Text(reasonLabel(l10n, reason)),
                        selected: _reason == reason,
                        onSelected: (_) => setState(() => _reason = reason),
                      ),)
                  .toList(growable: false),
            ),
            const SizedBox(height: Dimens.gapM),
            TextField(
              controller: _note,
              maxLines: 2,
              decoration: InputDecoration(
                labelText: '${l10n.t(K.commonNotes)} (${l10n.t(K.commonOptional)})',
              ),
            ),
            const SizedBox(height: Dimens.gapM),
            OutlinedButton.icon(
              onPressed: () async {
                final CaptureResult? shot = await CameraCapturePage.open(
                  context,
                  title: l10n.t(K.destroyTakePhoto),
                  hint: l10n.t(K.destroyTakePhoto),
                );
                if (shot != null && shot.path.isNotEmpty && mounted) {
                  setState(() => _photoPath = shot.path);
                }
              },
              icon: Icon(_photoPath == null ? Icons.photo_camera_outlined : Icons.check),
              label: Text(
                _photoPath == null
                    ? '${l10n.t(K.destroyTakePhoto)}${requirePhoto ? ' *' : ''}'
                    : l10n.t(K.commonPhoto),
              ),
            ),
            if (_photoPath != null) ...<Widget>[
              const SizedBox(height: Dimens.gapS),
              ClipRRect(
                borderRadius: BorderRadius.circular(Dimens.radiusSmall),
                child: Image.file(
                  File(_photoPath!),
                  height: 120,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ],
            const SizedBox(height: Dimens.gapM),
            NoticeBanner(
              icon: unitCost > 0 ? Icons.payments_outlined : Icons.info_outline,
              message: unitCost > 0
                  ? l10n.t(K.destroyLossRecorded, <String, Object?>{
                      'amount': l10n.money(unitCost * _quantity, symbol: currency),
                    })
                  : l10n.t(K.destroyNoCost),
            ),
            if (_error != null) ...<Widget>[
              const SizedBox(height: Dimens.gapM),
              NoticeBanner(
                tone: NoticeTone.danger,
                icon: Icons.error_outline,
                message: _error!,
              ),
            ],
            const SizedBox(height: Dimens.gapL),
            FilledButton.icon(
              onPressed: canSubmit ? _submit : null,
              icon: _busy
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2.5),
                    )
                  : const Icon(Icons.delete_forever),
              label: Text(l10n.t(K.destroyConfirm)),
            ),
            const SizedBox(height: Dimens.gapS),
            TextButton(
              onPressed: _busy ? null : () => Navigator.of(context).pop(),
              child: Text(l10n.t(K.commonCancel)),
            ),
          ],
        ),
      ),
    );
  }
}

/// Quick close actions available from the record screen.
Future<InventoryStatus?> showCloseRecordDialog(BuildContext context) {
  final AppLocalizations l10n = context.l10n;
  return showDialog<InventoryStatus>(
    context: context,
    builder: (BuildContext context) => SimpleDialog(
      title: Text(l10n.t(K.commonActions)),
      children: <Widget>[
        SimpleDialogOption(
          onPressed: () => Navigator.of(context).pop(InventoryStatus.soldOut),
          child: ListTile(
            leading: const Icon(Icons.sell_outlined),
            title: Text(l10n.t(K.inventoryMarkSoldOut)),
          ),
        ),
        SimpleDialogOption(
          onPressed: () => Navigator.of(context).pop(InventoryStatus.removed),
          child: ListTile(
            leading: const Icon(Icons.remove_circle_outline),
            title: Text(l10n.t(K.inventoryRemove)),
          ),
        ),
      ],
    ),
  );
}
