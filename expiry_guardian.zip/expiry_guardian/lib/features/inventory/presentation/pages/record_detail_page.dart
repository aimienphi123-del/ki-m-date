import 'dart:io';

import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_actions.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_list_view_model.dart';
import 'package:expiry_guardian/features/inventory/presentation/widgets/destroy_sheet.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/users_page.dart' show usersProvider;
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Full record: what was scanned, what the policy decided, and every change
/// anyone has ever made to it.
class RecordDetailPage extends ConsumerWidget {
  const RecordDetailPage({required this.recordId, super.key});

  final String recordId;

  static Future<void> open(BuildContext context, String recordId) {
    return Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => RecordDetailPage(recordId: recordId)),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<InventoryItemView?> item = ref.watch(recordViewProvider(recordId));

    return Scaffold(
      appBar: AppBar(title: Text(l10n.t(K.recordProduct))),
      body: item.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(
          message: e.toString(),
          onRetry: () => ref.invalidate(recordViewProvider(recordId)),
        ),
        data: (InventoryItemView? value) => value == null
            ? EmptyState(title: l10n.t(K.errorRecordNotFound))
            : _Body(item: value),
      ),
    );
  }
}

class _Body extends ConsumerWidget {
  const _Body({required this.item});

  final InventoryItemView item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final ThemeData theme = Theme.of(context);
    final String currency = ref.watch(currencySymbolProvider);
    final Set<Permission> permissions = ref.watch(permissionsProvider);
    final InventoryRecord record = item.record;
    final AsyncValue<DestroyPolicy> policy = ref.watch(activePolicyProvider);

    final String? ruleName = policy.valueOrNull?.rules
        .where((PolicyRule r) => r.id == record.policyRuleId)
        .map((PolicyRule r) => l10n.isVietnamese ? r.nameVi : r.nameEn)
        .firstOrNull;

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gutter,
        Dimens.gapXl * 2,
      ),
      children: <Widget>[
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Text(
                      item.product.displayName,
                      style: theme.textTheme.titleLarge
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ),
                  PriorityBadge(level: item.priority.level),
                ],
              ),
              const SizedBox(height: Dimens.gapXs),
              Text(
                '${l10n.t(K.recordCode)}: ${record.code}',
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: Dimens.gapM),
              Text(
                item.priority.isOverdue
                    ? l10n.t(K.recordOverdueBy, <String, Object?>{
                        'duration': l10n.duration(item.priority.timeUntilDestroy),
                      })
                    : l10n.t(K.recordTimeLeft, <String, Object?>{
                        'duration': l10n.duration(item.priority.timeUntilDestroy),
                      }),
                style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
              ),
              if (record.photoPath != null && File(record.photoPath!).existsSync()) ...<Widget>[
                const SizedBox(height: Dimens.gapM),
                ClipRRect(
                  borderRadius: BorderRadius.circular(Dimens.radiusSmall),
                  child: Image.file(
                    File(record.photoPath!),
                    height: 160,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  ),
                ),
              ],
            ],
          ),
        ),
        SectionHeader(title: l10n.t(K.recordProduct)),
        AppCard(
          child: Column(
            children: <Widget>[
              DetailRow(
                label: l10n.t(K.recordBarcode),
                value: item.product.barcode ?? l10n.t(K.commonNone),
              ),
              if (item.product.brand != null && item.product.brand!.isNotEmpty)
                DetailRow(label: l10n.t(K.recordBrand), value: item.product.brand!),
              if (item.categoryName != null && item.categoryName!.isNotEmpty)
                DetailRow(label: l10n.t(K.recordCategory), value: item.categoryName!),
              DetailRow(
                label: l10n.t(K.recordBatch),
                value: record.batchCode ?? l10n.t(K.commonNone),
              ),
              DetailRow(
                label: l10n.t(K.recordShelf),
                value: item.locationLabel.isEmpty ? l10n.t(K.todayNoShelf) : item.locationLabel,
              ),
              DetailRow(
                label: l10n.t(K.recordRemaining),
                value:
                    '${l10n.number(record.quantityRemaining, decimals: record.quantityRemaining % 1 == 0 ? 0 : 2)}'
                    ' / ${l10n.number(record.quantity, decimals: record.quantity % 1 == 0 ? 0 : 2)} ${record.unit}',
              ),
              DetailRow(
                label: l10n.t(K.commonStatus),
                value: statusLabel(l10n, record.status),
              ),
              if (record.unitCost != null)
                DetailRow(
                  label: l10n.t(K.recordUnitCost),
                  value: l10n.money(record.unitCost!, symbol: currency),
                ),
            ],
          ),
        ),
        SectionHeader(
          title: l10n.t(K.policyTitle),
          subtitle: l10n.t(K.policyVersion, <String, Object?>{'version': record.policyVersion}),
        ),
        AppCard(
          child: Column(
            children: <Widget>[
              DetailRow(
                label: l10n.t(K.recordManufacturedAt),
                value: record.manufacturedAt == null
                    ? l10n.t(K.commonUnknown)
                    : l10n.date(record.manufacturedAt!),
              ),
              DetailRow(
                label: l10n.t(K.recordExpiryAt),
                value: record.expiryPrecision.isHourly
                    ? l10n.dateTime(record.expiryAt)
                    : l10n.date(record.expiryAt),
                caption: record.expiryPrecision.isHourly
                    ? l10n.t(K.recordHourly)
                    : l10n.t(K.recordDaily),
              ),
              DetailRow(
                label: l10n.t(K.recordShelfLife),
                value: l10n.shelfLife(record.shelfLife),
              ),
              DetailRow(
                label: l10n.t(K.recordLeadTime),
                value: l10n.duration(record.leadTime),
              ),
              DetailRow(
                label: l10n.t(K.recordDestroyAt),
                value: l10n.dateTime(record.destroyAt),
                valueColor: theme.colorScheme.primary,
              ),
              DetailRow(
                label: l10n.t(K.recordAppliedRule),
                value: ruleName ?? l10n.t(K.recordFallbackRule),
              ),
            ],
          ),
        ),
        _Confirmations(recordId: record.id),
        SectionHeader(title: l10n.t(K.recordHistory)),
        _History(recordId: record.id),
        const SizedBox(height: Dimens.gapL),
        if (record.status.isOpen) ...<Widget>[
          if (permissions.contains(Permission.destroyStock))
            FilledButton.icon(
              onPressed: () async {
                final DestroyConfirmationResult? result =
                    await showDestroySheet(context, item: item);
                if (result != null && context.mounted) Navigator.of(context).pop();
              },
              icon: const Icon(Icons.delete_forever),
              label: Text(l10n.t(K.destroyConfirm)),
            ),
          const SizedBox(height: Dimens.gapS),
          if (permissions.contains(Permission.adjustQuantity))
            OutlinedButton.icon(
              onPressed: () => _adjust(context, ref),
              icon: const Icon(Icons.tune),
              label: Text(l10n.t(K.inventoryAdjustQuantity)),
            ),
          const SizedBox(height: Dimens.gapS),
          if (permissions.contains(Permission.editInventoryRecord))
            OutlinedButton.icon(
              onPressed: () => _move(context, ref),
              icon: const Icon(Icons.swap_horiz),
              label: Text(l10n.t(K.inventoryMoveShelf)),
            ),
          const SizedBox(height: Dimens.gapS),
          if (permissions.contains(Permission.editInventoryRecord))
            TextButton(
              onPressed: () async {
                final InventoryStatus? status = await showCloseRecordDialog(context);
                if (status == null || !context.mounted) return;
                await ref
                    .read(inventoryActionsProvider)
                    .close(recordId: record.id, status: status);
                if (context.mounted) Navigator.of(context).pop();
              },
              child: Text(l10n.t(K.commonActions)),
            ),
        ],
      ],
    );
  }

  Future<void> _adjust(BuildContext context, WidgetRef ref) async {
    final AppLocalizations l10n = context.l10n;
    final TextEditingController controller = TextEditingController(
      text: item.record.quantityRemaining.toString(),
    );
    final double? value = await showDialog<double>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text(l10n.t(K.inventoryAdjustQuantity)),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          autofocus: true,
          decoration: InputDecoration(labelText: l10n.t(K.recordRemaining)),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(l10n.t(K.commonCancel)),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.of(context).pop(double.tryParse(controller.text.replaceAll(',', '.'))),
            child: Text(l10n.t(K.commonSave)),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null || !context.mounted) return;
    await ref
        .read(inventoryActionsProvider)
        .adjustQuantity(recordId: item.record.id, newQuantity: value);
  }

  Future<void> _move(BuildContext context, WidgetRef ref) async {
    final AppLocalizations l10n = context.l10n;
    final List<ShelfLocation> shelves =
        ref.read(shelfLocationsProvider).valueOrNull ?? const <ShelfLocation>[];
    if (shelves.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l10n.t(K.locationsEmptyHint))),
      );
      return;
    }
    final String? shelfId = await showModalBottomSheet<String>(
      context: context,
      useSafeArea: true,
      builder: (BuildContext context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: <Widget>[
            for (final ShelfLocation location in shelves)
              ListTile(
                leading: const Icon(Icons.shelves),
                title: Text(location.label),
                selected: location.shelf.id == item.record.shelfId,
                onTap: () => Navigator.of(context).pop(location.shelf.id),
              ),
          ],
        ),
      ),
    );
    if (shelfId == null || !context.mounted) return;
    await ref
        .read(inventoryActionsProvider)
        .moveToShelf(recordId: item.record.id, shelfId: shelfId);
  }
}

/// What Feature 2 requires be recorded for every destroyed lot, shown back to
/// the person who is looking at the record: who confirmed it, when, on which
/// handset, how much, with what note and photo.
class _Confirmations extends ConsumerWidget {
  const _Confirmations({required this.recordId});

  final String recordId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final List<Destruction> destructions =
        ref.watch(recordDestructionsProvider(recordId)).valueOrNull ?? const <Destruction>[];
    if (destructions.isEmpty) return const SizedBox.shrink();

    final List<AppUser> users =
        ref.watch(usersProvider).valueOrNull ?? const <AppUser>[];
    String nameOf(String? id) {
      if (id == null) return l10n.t(K.commonUnknown);
      for (final AppUser user in users) {
        if (user.id == id) return user.displayName;
      }
      return l10n.t(K.commonUnknown);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SectionHeader(title: l10n.t(K.destroyConfirmation)),
        for (final Destruction destruction in destructions)
          Padding(
            padding: const EdgeInsets.only(bottom: Dimens.gapS),
            child: AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  DetailRow(
                    label: l10n.t(K.destroyConfirmedBy),
                    value: nameOf(destruction.actorId),
                  ),
                  DetailRow(
                    label: l10n.t(K.destroyConfirmedAt),
                    value: l10n.dateTime(destruction.confirmedAt),
                  ),
                  DetailRow(
                    label: l10n.t(K.commonQuantity),
                    value: l10n.number(
                      destruction.quantity,
                      decimals: destruction.quantity % 1 == 0 ? 0 : 2,
                    ),
                  ),
                  DetailRow(
                    label: l10n.t(K.destroyDevice),
                    value: destruction.deviceId == null
                        ? l10n.t(K.commonUnknown)
                        : _shortDevice(destruction.deviceId!),
                  ),
                  DetailRow(
                    label: l10n.t(K.commonReason),
                    value: reasonLabel(l10n, destruction.reason),
                  ),
                  if ((destruction.note ?? '').isNotEmpty)
                    DetailRow(label: l10n.t(K.commonNotes), value: destruction.note!),
                  if (destruction.photoPath != null &&
                      File(destruction.photoPath!).existsSync())
                    Padding(
                      padding: const EdgeInsets.only(top: Dimens.gapS),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(Dimens.radiusSmall),
                        child: Image.file(
                          File(destruction.photoPath!),
                          height: 160,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  static String _shortDevice(String id) => id.length <= 8 ? id : id.substring(0, 8);
}

class _History extends ConsumerWidget {
  const _History({required this.recordId});

  final String recordId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<RecordEvent>> events = ref.watch(recordHistoryProvider(recordId));

    return events.when(
      loading: () => const LoadingView(),
      error: (Object e, StackTrace s) => ErrorView(message: e.toString()),
      data: (List<RecordEvent> value) => AppCard(
        child: Column(
          children: <Widget>[
            for (final RecordEvent event in value)
              ListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                leading: Icon(_iconFor(event.type), size: 20),
                title: Text(eventLabel(l10n, event.type)),
                subtitle: Text(
                  <String>[
                    l10n.dateTime(event.occurredAt),
                    if (event.quantityDelta != null)
                      '${event.quantityDelta! > 0 ? '+' : ''}${l10n.number(event.quantityDelta!, decimals: event.quantityDelta! % 1 == 0 ? 0 : 2)}',
                    if (event.note != null && event.note!.isNotEmpty) event.note!,
                  ].join(' · '),
                ),
              ),
          ],
        ),
      ),
    );
  }

  IconData _iconFor(RecordEventType type) => switch (type) {
        RecordEventType.created => Icons.add_circle_outline,
        RecordEventType.destroyed => Icons.delete_forever_outlined,
        RecordEventType.moved => Icons.swap_horiz,
        RecordEventType.quantityAdjusted => Icons.tune,
        RecordEventType.policyRecalculated => Icons.rule_folder_outlined,
        RecordEventType.soldOut => Icons.sell_outlined,
        RecordEventType.removed => Icons.remove_circle_outline,
        RecordEventType.reopened => Icons.restore,
        RecordEventType.photoAttached => Icons.photo_outlined,
        RecordEventType.noteAdded => Icons.sticky_note_2_outlined,
        RecordEventType.updated => Icons.edit_outlined,
      };
}
