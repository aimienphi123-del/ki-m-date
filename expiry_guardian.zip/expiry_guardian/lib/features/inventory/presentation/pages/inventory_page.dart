import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/catalog/domain/entities/product_category.dart';
import 'package:expiry_guardian/features/catalog/presentation/viewmodels/catalog_view_model.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/inventory/presentation/pages/record_detail_page.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_actions.dart';
import 'package:expiry_guardian/features/inventory/presentation/viewmodels/inventory_list_view_model.dart';
import 'package:expiry_guardian/features/inventory/presentation/widgets/destroy_sheet.dart';
import 'package:expiry_guardian/features/inventory/presentation/widgets/inventory_item_tile.dart';
import 'package:expiry_guardian/features/locations/domain/entities/store_location.dart';
import 'package:expiry_guardian/features/policy/domain/entities/priority_level.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Search and filter every lot the store has ever booked in.
class InventoryPage extends ConsumerStatefulWidget {
  const InventoryPage({super.key});

  @override
  ConsumerState<InventoryPage> createState() => _InventoryPageState();
}

class _InventoryPageState extends ConsumerState<InventoryPage> {
  final TextEditingController _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final AsyncValue<List<InventoryItemView>> items = ref.watch(inventoryListProvider);
    final InventoryQuery query = ref.watch(inventoryQueryProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.t(K.inventoryTitle)),
        actions: <Widget>[
          IconButton(
            tooltip: l10n.t(K.commonFilter),
            onPressed: () => _openFilters(context),
            icon: Badge(
              isLabelVisible: _activeFilterCount(query) > 0,
              label: Text('${_activeFilterCount(query)}'),
              child: const Icon(Icons.tune),
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(68),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(
              Dimens.gutter,
              0,
              Dimens.gutter,
              Dimens.gapM,
            ),
            child: TextField(
              controller: _search,
              textInputAction: TextInputAction.search,
              onChanged: (String value) =>
                  ref.read(inventoryQueryProvider.notifier).setText(value),
              decoration: InputDecoration(
                hintText: l10n.t(K.inventorySearchHint),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _search.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _search.clear();
                          ref.read(inventoryQueryProvider.notifier).setText(null);
                        },
                      ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              ),
            ),
          ),
        ),
      ),
      body: items.when(
        loading: () => const LoadingView(),
        error: (Object e, StackTrace s) => ErrorView(
          message: e.toString(),
          onRetry: () => ref.invalidate(inventoryListProvider),
        ),
        data: (List<InventoryItemView> value) {
          if (value.isEmpty) {
            return EmptyState(
              icon: Icons.inventory_2_outlined,
              title: l10n.t(K.inventoryEmpty),
              message: l10n.t(K.inventoryEmptyHint),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(inventoryListProvider),
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(
                Dimens.gutter,
                Dimens.gapS,
                Dimens.gutter,
                Dimens.gapXl * 3,
              ),
              itemCount: value.length + 1,
              separatorBuilder: (_, __) => const SizedBox(height: Dimens.gapS),
              itemBuilder: (BuildContext context, int index) {
                if (index == 0) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: Dimens.gapXs),
                    child: Text(
                      l10n.t(K.inventoryResultCount, <String, Object?>{'count': value.length}),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    ),
                  );
                }
                final InventoryItemView item = value[index - 1];
                return InventoryItemTile(
                  item: item,
                  onTap: () => RecordDetailPage.open(context, item.record.id),
                  onDestroy: item.record.status.isOpen
                      ? () async {
                          final DestroyConfirmationResult? result =
                              await showDestroySheet(context, item: item);
                          if (result != null) ref.invalidate(inventoryListProvider);
                        }
                      : null,
                );
              },
            ),
          );
        },
      ),
    );
  }

  int _activeFilterCount(InventoryQuery query) {
    int count = 0;
    if (query.areaId != null) count++;
    if (query.shelfId != null) count++;
    if (query.categoryId != null) count++;
    if (query.priorities.isNotEmpty) count++;
    if (query.statuses.length != 1 ||
        !query.statuses.contains(InventoryStatus.active)) {
      count++;
    }
    return count;
  }

  Future<void> _openFilters(BuildContext context) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (BuildContext context) => const _FilterSheet(),
    );
  }
}

class _FilterSheet extends ConsumerWidget {
  const _FilterSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppLocalizations l10n = context.l10n;
    final InventoryQuery query = ref.watch(inventoryQueryProvider);
    final InventoryQueryController controller = ref.read(inventoryQueryProvider.notifier);
    final List<ShelfLocation> shelves =
        ref.watch(shelfLocationsProvider).valueOrNull ?? const <ShelfLocation>[];
    final List<ProductCategory> categories =
        ref.watch(categoriesProvider).valueOrNull ?? const <ProductCategory>[];

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(Dimens.gutter),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SectionHeader(title: l10n.t(K.inventoryFilterPriority)),
            Wrap(
              spacing: Dimens.gapS,
              runSpacing: Dimens.gapS,
              children: PriorityLevel.values
                  .map((PriorityLevel level) => FilterChip(
                        label: Text(l10n.t(switch (level) {
                          PriorityLevel.safe => K.prioritySafe,
                          PriorityLevel.approaching => K.priorityApproaching,
                          PriorityLevel.destroySoon => K.priorityDestroySoon,
                          PriorityLevel.destroyNow => K.priorityDestroyNow,
                          PriorityLevel.expired => K.priorityExpired,
                        },),),
                        selected: query.priorities.contains(level),
                        onSelected: (_) => controller.togglePriority(level),
                      ),)
                  .toList(growable: false),
            ),
            SectionHeader(title: l10n.t(K.inventoryFilterStatus)),
            Wrap(
              spacing: Dimens.gapS,
              runSpacing: Dimens.gapS,
              children: InventoryStatus.values
                  .map((InventoryStatus status) => FilterChip(
                        label: Text(statusLabel(l10n, status)),
                        selected: query.statuses.contains(status),
                        onSelected: (bool selected) {
                          final Set<InventoryStatus> next = <InventoryStatus>{...query.statuses};
                          if (selected) {
                            next.add(status);
                          } else {
                            next.remove(status);
                          }
                          controller.setStatuses(
                            next.isEmpty
                                ? <InventoryStatus>{InventoryStatus.active}
                                : next,
                          );
                        },
                      ),)
                  .toList(growable: false),
            ),
            if (shelves.isNotEmpty) ...<Widget>[
              SectionHeader(title: l10n.t(K.inventoryFilterShelf)),
              DropdownButtonFormField<String?>(
                initialValue: selectableShelfId(query.shelfId, shelves),
                isExpanded: true,
                decoration: InputDecoration(labelText: l10n.t(K.recordShelf)),
                items: <DropdownMenuItem<String?>>[
                  DropdownMenuItem<String?>(child: Text(l10n.t(K.commonAll))),
                  for (final ShelfLocation location in shelves)
                    DropdownMenuItem<String?>(
                      value: location.shelf.id,
                      child: Text(location.label, overflow: TextOverflow.ellipsis),
                    ),
                ],
                onChanged: controller.setShelf,
              ),
            ],
            if (categories.isNotEmpty) ...<Widget>[
              SectionHeader(title: l10n.t(K.inventoryFilterCategory)),
              DropdownButtonFormField<String?>(
                initialValue: query.categoryId,
                isExpanded: true,
                decoration: InputDecoration(labelText: l10n.t(K.recordCategory)),
                items: <DropdownMenuItem<String?>>[
                  DropdownMenuItem<String?>(child: Text(l10n.t(K.commonAll))),
                  for (final ProductCategory category in categories)
                    DropdownMenuItem<String?>(
                      value: category.id,
                      child: Text(category.name, overflow: TextOverflow.ellipsis),
                    ),
                ],
                onChanged: controller.setCategory,
              ),
            ],
            SectionHeader(title: l10n.t(K.inventorySort)),
            Wrap(
              spacing: Dimens.gapS,
              runSpacing: Dimens.gapS,
              children: InventorySort.values
                  .map((InventorySort sort) => ChoiceChip(
                        label: Text(l10n.t(switch (sort) {
                          InventorySort.priority => K.inventorySortPriority,
                          InventorySort.destroyDate => K.inventorySortDestroyDate,
                          InventorySort.expiryDate => K.inventorySortExpiryDate,
                          InventorySort.receivedDate => K.inventorySortReceivedDate,
                          InventorySort.productName => K.inventorySortProductName,
                          InventorySort.location => K.inventorySortLocation,
                        },),),
                        selected: query.sort == sort,
                        onSelected: (_) => controller.setSort(sort),
                      ),)
                  .toList(growable: false),
            ),
            const SizedBox(height: Dimens.gapL),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      controller.reset();
                      Navigator.of(context).pop();
                    },
                    child: Text(l10n.t(K.commonClear)),
                  ),
                ),
                const SizedBox(width: Dimens.gapM),
                Expanded(
                  child: FilledButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text(l10n.t(K.commonApply)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
