import 'package:expiry_guardian/core/audit/audit_entry.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/services/escalation_engine.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_item_view.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_record.dart';
import 'package:expiry_guardian/features/inventory/domain/entities/inventory_status.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';

/// What an employee fills in when they confirm a destruction.
///
/// The workflow refuses anything that would leave the record unattributable:
/// there must be a signed-in employee, a positive quantity and a device.
class DestroyConfirmation {
  const DestroyConfirmation({
    required this.recordId,
    this.quantity,
    this.reason = DestructionReason.policy,
    this.note,
    this.photoPath,
    this.at,
  });

  final String recordId;

  /// `null` confirms everything that is left of the lot.
  final double? quantity;
  final DestructionReason reason;
  final String? note;
  final String? photoPath;
  final DateTime? at;
}

/// Everything that happened as a result of one confirmation.
class DestroyConfirmationResult {
  const DestroyConfirmationResult({
    required this.destruction,
    required this.remindersCancelled,
    required this.escalationsResolved,
    required this.lotFullyClosed,
  });

  final Destruction destruction;
  final int remindersCancelled;
  final int escalationsResolved;
  final bool lotFullyClosed;
}

class WorkflowRefreshResult {
  const WorkflowRefreshResult({
    required this.escalationsRaised,
    required this.notificationsScheduled,
    required this.openEscalations,
  });

  final int escalationsRaised;
  final int notificationsScheduled;
  final int openEscalations;
}

/// The single owner of the operation workflow.
///
/// Confirming a destruction, raising escalations and rebuilding the reminder
/// schedule are one connected process, and doing them from three different
/// screens is how a workflow rots. Every screen calls this service instead.
class OperationWorkflowService {
  OperationWorkflowService({
    required InventoryRepository inventory,
    required EscalationRepository escalations,
    required EscalationEngine escalationEngine,
    required NotificationPlanner planner,
    required AuditRepository audit,
    required DeviceIdentityProvider device,
    required SettingsStore settings,
    required Clock clock,
    required AppLogger logger,
    required AppUser? Function() currentUser,
    required AppLocalizations Function() strings,
    required NotificationPreferences Function() preferences,
  })  : _inventory = inventory,
        _escalations = escalations,
        _escalationEngine = escalationEngine,
        _planner = planner,
        _audit = audit,
        _device = device,
        _settings = settings,
        _clock = clock,
        _logger = logger,
        _currentUser = currentUser,
        _strings = strings,
        _preferences = preferences;

  final InventoryRepository _inventory;
  final EscalationRepository _escalations;
  final EscalationEngine _escalationEngine;
  final NotificationPlanner _planner;
  final AuditRepository _audit;
  final DeviceIdentityProvider _device;
  final SettingsStore _settings;
  final Clock _clock;
  final AppLogger _logger;
  final AppUser? Function() _currentUser;
  final AppLocalizations Function() _strings;
  final NotificationPreferences Function() _preferences;

  static const String _tag = 'OperationWorkflow';

  Future<void>? _refreshInFlight;
  bool _refreshAgain = false;

  // ------------------------------------------------- deferred rescheduling

  /// Rebuilds the reminder schedule *without making the employee wait for it*.
  ///
  /// A reschedule registers one OS alarm per reminder, and each registration
  /// is a platform call. For a store with several overdue lots that is over a
  /// hundred round trips - seconds of dead time on a cheap handset. Doing that
  /// inside the confirm-destruction tap is what made the sheet look frozen.
  ///
  /// Nothing is lost by deferring it: the reminders that had to stop have
  /// already been cancelled synchronously by [confirmDestruction], and the
  /// schedule is re-derived from scratch every time, so a rebuild that lands a
  /// moment later lands with exactly the same content. Overlapping requests
  /// collapse into one trailing rebuild rather than queueing up.
  void requestRefresh() {
    if (_refreshInFlight != null) {
      _refreshAgain = true;
      return;
    }
    _refreshInFlight = _drainRefresh();
  }

  Future<void> _drainRefresh() async {
    try {
      do {
        _refreshAgain = false;
        final Result<WorkflowRefreshResult> result = await refresh();
        if (result.isErr) {
          _logger.w(
            _tag,
            'Deferred reschedule failed: ${result.failureOrNull?.message}',
          );
        }
      } while (_refreshAgain);
    } finally {
      _refreshInFlight = null;
    }
  }

  /// Awaits whatever [requestRefresh] has queued.
  ///
  /// The UI never needs this - that is the whole point - but startup and the
  /// tests do, because they assert on the finished schedule.
  Future<void> settleRefresh() async {
    while (_refreshInFlight != null) {
      await _refreshInFlight;
    }
  }

  // ------------------------------------------------------- confirmation

  /// Feature 2: every destroyed product is confirmed by a named employee, on a
  /// named device, at a recorded time, with a quantity.
  Future<Result<DestroyConfirmationResult>> confirmDestruction(
    DestroyConfirmation confirmation,
  ) async {
    // Every step below reports failure as a `Result`, but a thrown exception
    // would escape as a rejected future - and the sheet that calls this only
    // clears its spinner on the two outcomes it expects, so an escaping throw
    // showed up as a spinner that never stopped. One catch here turns any
    // surprise into a failure the UI already knows how to render.
    try {
      return await _confirmDestruction(confirmation);
    } on Object catch (error, stackTrace) {
      _logger.e(
        _tag,
        'Destruction confirmation threw',
        error: error,
        stackTrace: stackTrace,
      );
      return Result<DestroyConfirmationResult>.err(
        Failure.unknown('destroy_failed', cause: error, stackTrace: stackTrace),
      );
    }
  }

  Future<Result<DestroyConfirmationResult>> _confirmDestruction(
    DestroyConfirmation confirmation,
  ) async {
    final AppUser? user = _currentUser();
    if (user == null) {
      return const Result<DestroyConfirmationResult>.err(
        Failure.unauthenticated('destroy_needs_signed_in_employee'),
      );
    }
    if (_settings.readBool(
          SettingKeys.requirePhotoOnDestroy,
          SettingDefaults.requirePhotoOnDestroy,
        ) &&
        (confirmation.photoPath == null || confirmation.photoPath!.isEmpty)) {
      return const Result<DestroyConfirmationResult>.err(
        Failure.validation('photo_required'),
      );
    }

    final DateTime now = _clock.now();
    final Result<InventoryItemView?> before =
        await _inventory.findView(confirmation.recordId);
    final InventoryItemView? item = before.valueOrNull;

    final Result<Destruction> destroyed = await _inventory.destroy(
      DestroyCommand(
        recordId: confirmation.recordId,
        quantity: confirmation.quantity,
        reason: confirmation.reason,
        note: confirmation.note,
        photoPath: confirmation.photoPath,
        at: confirmation.at ?? now,
        confirmedAt: now,
        deviceId: _device.current.id,
      ),
      actorId: user.id,
    );
    if (destroyed.isErr) {
      return Result<DestroyConfirmationResult>.err(destroyed.failureOrNull!);
    }
    final Destruction destruction = destroyed.unwrap();

    // The lot is closed only when nothing is left; a partial destruction must
    // keep chasing the remainder.
    final Result<InventoryRecord?> after = await _inventory.findRecord(confirmation.recordId);
    final bool fullyClosed = after.valueOrNull?.status != InventoryStatus.active;

    int cancelled = 0;
    int resolved = 0;
    if (fullyClosed) {
      cancelled = (await _planner.cancelForRecord(confirmation.recordId)).valueOrNull ?? 0;
      resolved = (await _escalations.resolveForRecord(
            recordId: confirmation.recordId,
            resolution: EscalationResolution.destroyed,
            note: confirmation.note,
          ))
              .valueOrNull ??
          0;
    }

    await _audit.append(AuditDraft(
      action: AuditAction.destroyConfirmed,
      entity: Tables.destructions,
      entityId: destruction.id,
      entityLabel: item?.product.displayName,
      imagePath: confirmation.photoPath,
      note: confirmation.note,
      previousValue: item == null
          ? null
          : <String, Object?>{
              'recordCode': item.record.code,
              'quantityRemaining': item.record.quantityRemaining,
              'status': item.record.status.name,
            },
      newValue: <String, Object?>{
        'recordId': destruction.recordId,
        'recordCode': item?.record.code,
        'quantity': destruction.quantity,
        'unit': item?.record.unit,
        'reason': destruction.reason.name,
        'lossAmount': destruction.lossAmount,
        'wasOverdue': destruction.wasOverdue,
        'minutesLate': destruction.minutesLate,
        'confirmedAt': destruction.confirmedAt.toIso8601String(),
        'deviceId': destruction.deviceId,
        'deviceLabel': _device.current.label,
        'employee': user.displayName,
        'remindersCancelled': cancelled,
        'escalationsResolved': resolved,
      },
    ),);

    _logger.i(
      _tag,
      'Destruction confirmed for ${item?.record.code ?? confirmation.recordId} '
      'by ${user.username} on ${_device.current.shortId}; '
      'cancelled $cancelled reminder(s), resolved $resolved escalation(s)',
    );

    // The remaining schedule changed, so rebuild it - but off this tap. The
    // reminders for *this* lot were already cancelled above, which is the part
    // that has to be immediate; re-deriving everyone else's alarms can happen
    // while the employee is already looking at the confirmation.
    requestRefresh();

    return Result<DestroyConfirmationResult>.ok(DestroyConfirmationResult(
      destruction: destruction,
      remindersCancelled: cancelled,
      escalationsResolved: resolved,
      lotFullyClosed: fullyClosed,
    ),);
  }

  // -------------------------------------------------------- escalation

  /// Feature 3: raise anything that is overdue beyond the configured delay,
  /// then rebuild the whole notification schedule including the manager
  /// alerts. Safe and cheap to call after any change and on app start.
  Future<Result<WorkflowRefreshResult>> refresh() async {
    int raised = 0;
    if (_settings.readBool(SettingKeys.escalationEnabled, SettingDefaults.escalationEnabled)) {
      final Result<List<Escalation>> result = await _escalations.raiseDue();
      raised = result.valueOrNull?.length ?? 0;
      if (result.isErr) {
        _logger.w(_tag, 'Escalation scan failed: ${result.failureOrNull?.message}');
      }
    }

    final List<AppNotification> managerAlerts = await _managerAlerts();

    final Result<NotificationPlan> plan = await _planner.reschedule(
      preferences: _preferences(),
      strings: _strings(),
      extraNotifications: managerAlerts,
    );
    if (plan.isErr) {
      return Result<WorkflowRefreshResult>.err(plan.failureOrNull!);
    }

    final int open = (await _escalations.openCount()).valueOrNull ?? 0;

    if (plan.unwrap().total > 0) {
      await _audit.append(AuditDraft(
        action: AuditAction.destroyReminderScheduled,
        entity: Tables.scheduledNotifications,
        newValue: <String, Object?>{
          'total': plan.unwrap().total,
          'digests': plan.unwrap().digestCount,
          'stageAlerts': plan.unwrap().stageCount,
          'escalationAlerts': plan.unwrap().extraCount,
        },
        actorName: 'system',
        actorRole: 'system',
      ),);
    }

    return Result<WorkflowRefreshResult>.ok(WorkflowRefreshResult(
      escalationsRaised: raised,
      notificationsScheduled: plan.unwrap().total,
      openEscalations: open,
    ),);
  }

  Future<List<AppNotification>> _managerAlerts() async {
    final AppUser? user = _currentUser();
    if (user == null) return const <AppNotification>[];
    if (!_settings.readBool(
      SettingKeys.escalationEnabled,
      SettingDefaults.escalationEnabled,
    )) {
      return const <AppNotification>[];
    }

    final Result<List<EscalationRule>> rules =
        await _escalations.listRules(includeInactive: false);
    if (rules.isErr || rules.unwrap().isEmpty) return const <AppNotification>[];

    final DateTime now = _clock.now();
    final Result<List<InventoryItemView>> overdue = await _inventory.search(
      InventoryQuery(
        statuses: const <InventoryStatus>{InventoryStatus.active},
        destroyBefore: now,
        sort: InventorySort.destroyDate,
        limit: 500,
      ),
    );
    if (overdue.isErr) return const <AppNotification>[];

    return _escalationEngine.notifications(
      openOverdueItems: overdue.unwrap(),
      rules: rules.unwrap(),
      viewerRole: user.role,
      strings: _strings(),
      now: now,
    );
  }

  /// A manager closing an alert without destroying the stock. The reason is
  /// mandatory and the whole decision is written to the audit trail.
  Future<Result<Escalation>> managerOverride({
    required String escalationId,
    required String reason,
  }) async {
    final AppUser? user = _currentUser();
    if (user == null) {
      return const Result<Escalation>.err(
        Failure.unauthenticated('override_needs_signed_in_manager'),
      );
    }
    final Result<Escalation> result = await _escalations.managerOverride(
      escalationId: escalationId,
      reason: reason,
    );
    if (result.isOk) await refresh();
    return result;
  }

  Future<Result<Escalation>> acknowledge({
    required String escalationId,
    String? note,
  }) async {
    final Result<Escalation> result =
        await _escalations.acknowledge(escalationId: escalationId, note: note);
    if (result.isOk) await refresh();
    return result;
  }

  /// Closing a lot for any other reason also clears its alerts and reminders.
  Future<Result<void>> closeRecord({
    required String recordId,
    required InventoryStatus status,
    String? note,
  }) async {
    final AppUser? user = _currentUser();
    final Result<void> result = await _inventory.closeRecord(
      recordId: recordId,
      status: status,
      note: note,
      actorId: user?.id,
    );
    if (result.isErr) return result;

    await _planner.cancelForRecord(recordId);
    await _escalations.resolveForRecord(
      recordId: recordId,
      resolution: EscalationResolution.cancelled,
      note: note,
    );
    await _audit.append(AuditDraft(
      action: AuditAction.recordClosed,
      entity: Tables.inventoryRecords,
      entityId: recordId,
      newValue: <String, Object?>{'status': status.name},
      note: note,
    ),);
    await refresh();
    return result;
  }
}
