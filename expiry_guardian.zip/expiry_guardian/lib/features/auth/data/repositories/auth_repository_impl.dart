import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/session/current_user_holder.dart';
import 'package:expiry_guardian/core/storage/session_store.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/auth/data/datasources/user_local_datasource.dart';
import 'package:expiry_guardian/features/auth/data/models/user_mapper.dart';
import 'package:expiry_guardian/features/auth/data/security/password_hasher.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  AuthRepositoryImpl({
    required UserLocalDataSource local,
    required PasswordHasher hasher,
    required SessionStore session,
    required CurrentUserHolder currentUser,
    required Clock clock,
    required IdGenerator ids,
    required SyncQueue syncQueue,
    required AppLogger logger,
  })  : _local = local,
        _hasher = hasher,
        _session = session,
        _currentUser = currentUser,
        _clock = clock,
        _ids = ids,
        _syncQueue = syncQueue,
        _logger = logger;

  final UserLocalDataSource _local;
  final PasswordHasher _hasher;
  final SessionStore _session;

  /// Kept in step with the durable session so the audit trail, the escalation
  /// repository and the workflow service can name the actor without reaching
  /// into the widget tree.
  final CurrentUserHolder _currentUser;
  final Clock _clock;
  final IdGenerator _ids;
  final SyncQueue _syncQueue;
  final AppLogger _logger;

  static const String _tag = 'AuthRepository';
  static const int minPasswordLength = 4;

  @override
  Future<Result<bool>> needsInitialSetup() async {
    try {
      return Result<bool>.ok(await _local.count() == 0);
    } catch (error, st) {
      return Result<bool>.err(Failure.database('Cannot read users', cause: error, stackTrace: st));
    }
  }

  @override
  Future<Result<AppUser>> createInitialAdmin({
    required String username,
    required String displayName,
    required String password,
  }) async {
    final Result<bool> setup = await needsInitialSetup();
    if (setup.isErr) return Result<AppUser>.err(setup.failureOrNull!);
    if (setup.unwrap() == false) {
      return const Result<AppUser>.err(
        Failure(code: FailureCode.validation, message: 'Users already exist'),
      );
    }
    final Result<AppUser> created = await _create(
      username: username,
      displayName: displayName,
      password: password,
      role: UserRole.admin,
    );
    // Setting up the store signs that admin in for real, durable session and
    // all - otherwise the first destroy confirmation would find nobody signed
    // in after the next restart.
    final AppUser? admin = created.valueOrNull;
    if (admin != null) {
      await _session.writeUserId(admin.id);
      _currentUser.user = admin;
    }
    return created;
  }

  @override
  Future<Result<AppUser>> createUser({
    required String username,
    required String displayName,
    required String password,
    required UserRole role,
  }) =>
      _create(username: username, displayName: displayName, password: password, role: role);

  Future<Result<AppUser>> _create({
    required String username,
    required String displayName,
    required String password,
    required UserRole role,
  }) async {
    final String cleanUsername = username.trim();
    final String cleanName = displayName.trim();
    if (cleanUsername.isEmpty) {
      return const Result<AppUser>.err(Failure.validation('username_required'));
    }
    if (cleanName.isEmpty) {
      return const Result<AppUser>.err(Failure.validation('display_name_required'));
    }
    if (password.length < minPasswordLength) {
      return const Result<AppUser>.err(Failure.validation('password_too_short'));
    }
    try {
      if (await _local.findByUsername(cleanUsername) != null) {
        return const Result<AppUser>.err(Failure.duplicate('username_taken'));
      }
      final DateTime now = _clock.now();
      final AppUser user = AppUser(
        id: _ids.newId(),
        username: cleanUsername,
        displayName: cleanName,
        role: role,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      );
      final StoredUser stored = StoredUser(user: user, credentials: _hasher.hash(password));
      await _local.insert(stored);
      await _syncQueue.enqueueUpsert(
        entity: Tables.users,
        entityId: user.id,
        payload: UserMapper.toRow(stored),
      );
      _logger.i(_tag, 'Created ${role.name} account "$cleanUsername"');
      return Result<AppUser>.ok(user);
    } catch (error, st) {
      return Result<AppUser>.err(
        Failure.database('Cannot create user', cause: error, stackTrace: st),
      );
    }
  }

  @override
  Future<Result<AppUser>> signIn({required String username, required String password}) async {
    try {
      final StoredUser? stored = await _local.findByUsername(username.trim());
      if (stored == null || !_hasher.verify(password, stored.credentials)) {
        return const Result<AppUser>.err(Failure.unauthenticated('invalid_credentials'));
      }
      if (!stored.user.isActive) {
        return const Result<AppUser>.err(Failure.unauthenticated('account_disabled'));
      }
      final DateTime now = _clock.now();
      await _local.touchLogin(stored.user.id, now);
      await _session.writeUserId(stored.user.id);
      final AppUser signedIn = stored.user.copyWith(lastLoginAt: now);
      _currentUser.user = signedIn;
      return Result<AppUser>.ok(signedIn);
    } catch (error, st) {
      return Result<AppUser>.err(Failure.database('Sign-in failed', cause: error, stackTrace: st));
    }
  }

  @override
  Future<Result<void>> signOut() async {
    await _session.clear();
    _currentUser.clear();
    return const Result<void>.ok(null);
  }

  @override
  Future<Result<AppUser?>> restoreSession() async {
    try {
      final String? userId = await _session.readUserId();
      if (userId == null) {
        _currentUser.clear();
        return const Result<AppUser?>.ok(null);
      }
      final StoredUser? stored = await _local.findById(userId);
      if (stored == null || !stored.user.isActive) {
        await _session.clear();
        _currentUser.clear();
        return const Result<AppUser?>.ok(null);
      }
      _currentUser.user = stored.user;
      return Result<AppUser?>.ok(stored.user);
    } catch (error, st) {
      return Result<AppUser?>.err(
        Failure.database('Cannot restore session', cause: error, stackTrace: st),
      );
    }
  }

  @override
  Future<Result<List<AppUser>>> listUsers({bool includeInactive = false}) async {
    try {
      final List<StoredUser> stored = await _local.findAll(includeInactive: includeInactive);
      return Result<List<AppUser>>.ok(
        stored.map((StoredUser s) => s.user).toList(growable: false),
      );
    } catch (error, st) {
      return Result<List<AppUser>>.err(
        Failure.database('Cannot list users', cause: error, stackTrace: st),
      );
    }
  }

  @override
  Future<Result<AppUser>> updateUser(AppUser user) async {
    try {
      final StoredUser? existing = await _local.findById(user.id);
      if (existing == null) {
        return Result<AppUser>.err(Failure.notFound('user ${user.id}'));
      }
      final AppUser updated = user.copyWith(updatedAt: _clock.now());
      final StoredUser stored = StoredUser(user: updated, credentials: existing.credentials);
      await _local.update(stored);
      await _syncQueue.enqueueUpsert(
        entity: Tables.users,
        entityId: updated.id,
        payload: UserMapper.toRow(stored),
      );
      return Result<AppUser>.ok(updated);
    } catch (error, st) {
      return Result<AppUser>.err(
        Failure.database('Cannot update user', cause: error, stackTrace: st),
      );
    }
  }

  @override
  Future<Result<void>> changePassword({
    required String userId,
    required String newPassword,
    String? currentPassword,
  }) async {
    if (newPassword.length < minPasswordLength) {
      return const Result<void>.err(Failure.validation('password_too_short'));
    }
    try {
      final StoredUser? existing = await _local.findById(userId);
      if (existing == null) return Result<void>.err(Failure.notFound('user $userId'));
      if (currentPassword != null && !_hasher.verify(currentPassword, existing.credentials)) {
        return const Result<void>.err(Failure.unauthenticated('invalid_credentials'));
      }
      final StoredUser stored = StoredUser(
        user: existing.user.copyWith(updatedAt: _clock.now()),
        credentials: _hasher.hash(newPassword),
      );
      await _local.update(stored);
      await _syncQueue.enqueueUpsert(
        entity: Tables.users,
        entityId: userId,
        payload: UserMapper.toRow(stored),
      );
      return const Result<void>.ok(null);
    } catch (error, st) {
      return Result<void>.err(
        Failure.database('Cannot change password', cause: error, stackTrace: st),
      );
    }
  }

  @override
  Future<Result<void>> setActive({required String userId, required bool isActive}) async {
    try {
      await _local.setActive(userId, isActive, _clock.now());
      await _syncQueue.enqueueUpsert(
        entity: Tables.users,
        entityId: userId,
        payload: <String, Object?>{'id': userId, 'is_active': isActive ? 1 : 0},
      );
      return const Result<void>.ok(null);
    } catch (error, st) {
      return Result<void>.err(
        Failure.database('Cannot change account state', cause: error, stackTrace: st),
      );
    }
  }
}
