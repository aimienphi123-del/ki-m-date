import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

class PasswordHash {
  const PasswordHash({required this.hash, required this.salt, required this.iterations});
  final String hash;
  final String salt;
  final int iterations;
}

/// PBKDF2-HMAC-SHA256 password hashing.
///
/// Implemented directly on `package:crypto` so the app has no native
/// dependency and works identically on every device the store owns.
abstract interface class PasswordHasher {
  PasswordHash hash(String password, {String? salt, int? iterations});
  bool verify(String password, PasswordHash stored);
}

class Pbkdf2PasswordHasher implements PasswordHasher {
  Pbkdf2PasswordHasher({
    this.defaultIterations = 120000,
    this.keyLengthBytes = 32,
    Random? random,
  }) : _random = random ?? Random.secure();

  final int defaultIterations;
  final int keyLengthBytes;
  final Random _random;

  @override
  PasswordHash hash(String password, {String? salt, int? iterations}) {
    final String effectiveSalt = salt ?? _newSalt();
    final int rounds = iterations ?? defaultIterations;
    final Uint8List derived = _pbkdf2(
      utf8.encode(password),
      base64Decode(effectiveSalt),
      rounds,
      keyLengthBytes,
    );
    return PasswordHash(
      hash: base64Encode(derived),
      salt: effectiveSalt,
      iterations: rounds,
    );
  }

  @override
  bool verify(String password, PasswordHash stored) {
    final PasswordHash candidate =
        hash(password, salt: stored.salt, iterations: stored.iterations);
    return _constantTimeEquals(candidate.hash, stored.hash);
  }

  String _newSalt({int bytes = 16}) {
    final Uint8List salt = Uint8List(bytes);
    for (int i = 0; i < bytes; i++) {
      salt[i] = _random.nextInt(256);
    }
    return base64Encode(salt);
  }

  Uint8List _pbkdf2(List<int> password, List<int> salt, int iterations, int keyLength) {
    final Hmac hmac = Hmac(sha256, password);
    final int blockCount = (keyLength / 32).ceil();
    final BytesBuilder output = BytesBuilder();

    for (int block = 1; block <= blockCount; block++) {
      final Uint8List blockIndex = Uint8List(4)
        ..[0] = (block >> 24) & 0xff
        ..[1] = (block >> 16) & 0xff
        ..[2] = (block >> 8) & 0xff
        ..[3] = block & 0xff;

      Uint8List u = Uint8List.fromList(hmac.convert(<int>[...salt, ...blockIndex]).bytes);
      final Uint8List accumulator = Uint8List.fromList(u);

      for (int i = 1; i < iterations; i++) {
        u = Uint8List.fromList(hmac.convert(u).bytes);
        for (int j = 0; j < accumulator.length; j++) {
          accumulator[j] ^= u[j];
        }
      }
      output.add(accumulator);
    }
    return Uint8List.fromList(output.toBytes().sublist(0, keyLength));
  }

  bool _constantTimeEquals(String a, String b) {
    if (a.length != b.length) return false;
    int diff = 0;
    for (int i = 0; i < a.length; i++) {
      diff |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return diff == 0;
  }
}
