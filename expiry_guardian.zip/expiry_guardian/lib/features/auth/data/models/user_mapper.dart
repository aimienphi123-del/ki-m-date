import 'package:expiry_guardian/core/database/sql_helpers.dart';
import 'package:expiry_guardian/features/auth/data/security/password_hasher.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';

class StoredUser {
  const StoredUser({required this.user, required this.credentials});
  final AppUser user;
  final PasswordHash credentials;
}

abstract final class UserMapper {
  static StoredUser fromRow(Map<String, Object?> row) {
    return StoredUser(
      user: AppUser(
        id: row.str('id'),
        username: row.str('username'),
        displayName: row.str('display_name'),
        role: UserRole.fromName(row.strOrNull('role')),
        isActive: row.boolean('is_active'),
        createdAt: row.dateTime('created_at'),
        updatedAt: row.dateTime('updated_at'),
        lastLoginAt: row.dateTimeOrNull('last_login_at'),
      ),
      credentials: PasswordHash(
        hash: row.str('password_hash'),
        salt: row.str('password_salt'),
        iterations: row.integer('password_iterations'),
      ),
    );
  }

  static Map<String, Object?> toRow(StoredUser stored) {
    return <String, Object?>{
      'id': stored.user.id,
      'username': stored.user.username,
      'display_name': stored.user.displayName,
      'role': stored.user.role.name,
      'password_hash': stored.credentials.hash,
      'password_salt': stored.credentials.salt,
      'password_iterations': stored.credentials.iterations,
      'is_active': boolToInt(stored.user.isActive),
      'created_at': stored.user.createdAt.millisecondsSinceEpoch,
      'updated_at': stored.user.updatedAt.millisecondsSinceEpoch,
      'last_login_at': dateToMillis(stored.user.lastLoginAt),
    };
  }
}
