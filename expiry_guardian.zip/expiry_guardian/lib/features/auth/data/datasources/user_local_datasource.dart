import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/database/tables.dart';
import 'package:expiry_guardian/features/auth/data/models/user_mapper.dart';
import 'package:sqflite/sqflite.dart';

abstract interface class UserLocalDataSource {
  Future<int> count();
  Future<StoredUser?> findByUsername(String username);
  Future<StoredUser?> findById(String id);
  Future<List<StoredUser>> findAll({bool includeInactive = false});
  Future<void> insert(StoredUser user);
  Future<void> update(StoredUser user);
  Future<void> touchLogin(String id, DateTime at);
  Future<void> setActive(String id, bool isActive, DateTime updatedAt);
}

class SqfliteUserDataSource implements UserLocalDataSource {
  const SqfliteUserDataSource(this._database);
  final AppDatabase _database;

  @override
  Future<int> count() async {
    final List<Map<String, Object?>> rows =
        await _database.db.rawQuery('SELECT COUNT(*) AS c FROM ${Tables.users}');
    return (rows.first['c'] as int?) ?? 0;
  }

  @override
  Future<StoredUser?> findByUsername(String username) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.users,
      where: 'username = ? COLLATE NOCASE',
      whereArgs: <Object?>[username.trim()],
      limit: 1,
    );
    return rows.isEmpty ? null : UserMapper.fromRow(rows.first);
  }

  @override
  Future<StoredUser?> findById(String id) async {
    final List<Map<String, Object?>> rows = await _database.db
        .query(Tables.users, where: 'id = ?', whereArgs: <Object?>[id], limit: 1);
    return rows.isEmpty ? null : UserMapper.fromRow(rows.first);
  }

  @override
  Future<List<StoredUser>> findAll({bool includeInactive = false}) async {
    final List<Map<String, Object?>> rows = await _database.db.query(
      Tables.users,
      where: includeInactive ? null : 'is_active = 1',
      orderBy: 'display_name COLLATE NOCASE',
    );
    return rows.map(UserMapper.fromRow).toList();
  }

  @override
  Future<void> insert(StoredUser user) async {
    await _database.write(<String>{Tables.users}, (Transaction txn) async {
      await txn.insert(Tables.users, UserMapper.toRow(user));
    });
  }

  @override
  Future<void> update(StoredUser user) async {
    await _database.write(<String>{Tables.users}, (Transaction txn) async {
      await txn.update(
        Tables.users,
        UserMapper.toRow(user),
        where: 'id = ?',
        whereArgs: <Object?>[user.user.id],
      );
    });
  }

  @override
  Future<void> touchLogin(String id, DateTime at) async {
    await _database.db.update(
      Tables.users,
      <String, Object?>{'last_login_at': at.millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
    _database.notifyChanged(<String>[Tables.users]);
  }

  @override
  Future<void> setActive(String id, bool isActive, DateTime updatedAt) async {
    await _database.db.update(
      Tables.users,
      <String, Object?>{
        'is_active': isActive ? 1 : 0,
        'updated_at': updatedAt.millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: <Object?>[id],
    );
    _database.notifyChanged(<String>[Tables.users]);
  }
}
