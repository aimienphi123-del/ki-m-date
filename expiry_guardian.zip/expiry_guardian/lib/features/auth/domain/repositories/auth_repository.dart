import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';

abstract interface class AuthRepository {
  /// True when no user exists yet - the app shows the "create the first
  /// administrator" screen instead of the sign-in screen.
  Future<Result<bool>> needsInitialSetup();

  Future<Result<AppUser>> createInitialAdmin({
    required String username,
    required String displayName,
    required String password,
  });

  Future<Result<AppUser>> signIn({required String username, required String password});

  Future<Result<void>> signOut();

  /// The user restored from the last session, if any.
  Future<Result<AppUser?>> restoreSession();

  Future<Result<List<AppUser>>> listUsers({bool includeInactive = false});

  Future<Result<AppUser>> createUser({
    required String username,
    required String displayName,
    required String password,
    required UserRole role,
  });

  Future<Result<AppUser>> updateUser(AppUser user);

  Future<Result<void>> changePassword({
    required String userId,
    required String newPassword,
    String? currentPassword,
  });

  Future<Result<void>> setActive({required String userId, required bool isActive});
}
