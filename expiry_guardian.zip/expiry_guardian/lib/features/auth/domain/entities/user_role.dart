/// Role-based access control.
///
/// Permissions are derived from the role rather than stored per user so that a
/// manager can never accidentally grant a partial, inconsistent permission set.
enum UserRole {
  employee,
  manager,
  admin;

  static UserRole fromName(String? value) => switch (value) {
        'manager' => UserRole.manager,
        'admin' => UserRole.admin,
        _ => UserRole.employee,
      };

  int get level => switch (this) {
        UserRole.employee => 1,
        UserRole.manager => 2,
        UserRole.admin => 3,
      };

  bool atLeast(UserRole other) => level >= other.level;
}

/// Every guarded action in the app.
enum Permission {
  scanGoods,
  viewInventory,
  destroyStock,
  adjustQuantity,
  editInventoryRecord,
  deleteInventoryRecord,
  manageCatalog,
  manageLocations,
  editPolicy,
  viewReports,
  exportReports,

  /// Seeing the manager dashboard, acknowledging an alert and overriding one.
  manageEscalations,

  /// Reading the append-only log and verifying its integrity.
  viewAuditTrail,

  manageUsers,
  manageSettings,
  resetData,
}

abstract final class RolePermissions {
  static const Map<UserRole, Set<Permission>> _map = <UserRole, Set<Permission>>{
    UserRole.employee: <Permission>{
      Permission.scanGoods,
      Permission.viewInventory,
      Permission.destroyStock,
    },
    UserRole.manager: <Permission>{
      Permission.scanGoods,
      Permission.viewInventory,
      Permission.destroyStock,
      Permission.adjustQuantity,
      Permission.editInventoryRecord,
      Permission.manageCatalog,
      Permission.manageLocations,
      Permission.editPolicy,
      Permission.viewReports,
      Permission.exportReports,
      Permission.manageEscalations,
      Permission.viewAuditTrail,
    },
    UserRole.admin: <Permission>{...Permission.values},
  };

  static Set<Permission> of(UserRole role) => _map[role] ?? const <Permission>{};

  static bool allows(UserRole role, Permission permission) => of(role).contains(permission);
}
