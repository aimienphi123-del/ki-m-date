import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Shared scaffold for the two pre-login screens.
class _AuthScaffold extends StatelessWidget {
  const _AuthScaffold({required this.title, required this.subtitle, required this.children});

  final String title;
  final String subtitle;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(Dimens.gapXl),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Icon(Icons.shield_moon_outlined, size: 56, color: theme.colorScheme.primary),
                  const SizedBox(height: Dimens.gapM),
                  Text(
                    context.l10n.t(K.appName),
                    textAlign: TextAlign.center,
                    style: theme.textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: Dimens.gapXs),
                  Text(
                    context.l10n.t(K.appTagline),
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium
                        ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: Dimens.gapXl),
                  Text(title, style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w800),),
                  const SizedBox(height: Dimens.gapXs),
                  Text(
                    subtitle,
                    style: theme.textTheme.bodyMedium
                        ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: Dimens.gapL),
                  ...children,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class InitialSetupPage extends ConsumerStatefulWidget {
  const InitialSetupPage({super.key});

  @override
  ConsumerState<InitialSetupPage> createState() => _InitialSetupPageState();
}

class _InitialSetupPageState extends ConsumerState<InitialSetupPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _username = TextEditingController();
  final TextEditingController _displayName = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirm = TextEditingController();

  @override
  void dispose() {
    _username.dispose();
    _displayName.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    await ref.read(sessionProvider.notifier).createInitialAdmin(
          username: _username.text,
          displayName: _displayName.text,
          password: _password.text,
        );
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final SessionState? session = ref.watch(sessionProvider).valueOrNull;

    return _AuthScaffold(
      title: l10n.t(K.authSetupTitle),
      subtitle: l10n.t(K.authSetupSubtitle),
      children: <Widget>[
        Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _displayName,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(labelText: l10n.t(K.authDisplayName)),
                validator: (String? v) =>
                    (v ?? '').trim().isEmpty ? l10n.t(K.errorDisplayNameRequired) : null,
              ),
              const SizedBox(height: Dimens.gapM),
              TextFormField(
                controller: _username,
                textInputAction: TextInputAction.next,
                autocorrect: false,
                decoration: InputDecoration(labelText: l10n.t(K.authUsername)),
                validator: (String? v) =>
                    (v ?? '').trim().isEmpty ? l10n.t(K.errorUsernameRequired) : null,
              ),
              const SizedBox(height: Dimens.gapM),
              TextFormField(
                controller: _password,
                obscureText: true,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(labelText: l10n.t(K.authPassword)),
                validator: (String? v) =>
                    (v ?? '').length < 4 ? l10n.t(K.errorPasswordTooShort) : null,
              ),
              const SizedBox(height: Dimens.gapM),
              TextFormField(
                controller: _confirm,
                obscureText: true,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(labelText: l10n.t(K.authConfirmPassword)),
                onFieldSubmitted: (_) => _submit(),
                validator: (String? v) =>
                    v != _password.text ? l10n.t(K.authPasswordsDoNotMatch) : null,
              ),
            ],
          ),
        ),
        if (session?.failure != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.error_outline,
            message: describeFailure(context, session!.failure!),
          ),
        ],
        const SizedBox(height: Dimens.gapL),
        FilledButton(
          onPressed: (session?.busy ?? false) ? null : _submit,
          child: (session?.busy ?? false)
              ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.5),
                )
              : Text(l10n.t(K.authCreateAccount)),
        ),
      ],
    );
  }
}

class SignInPage extends ConsumerStatefulWidget {
  const SignInPage({super.key});

  @override
  ConsumerState<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends ConsumerState<SignInPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _username = TextEditingController();
  final TextEditingController _password = TextEditingController();

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    await ref
        .read(sessionProvider.notifier)
        .signIn(username: _username.text, password: _password.text);
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final SessionState? session = ref.watch(sessionProvider).valueOrNull;

    return _AuthScaffold(
      title: l10n.t(K.authSignInTitle),
      subtitle: l10n.t(K.appTagline),
      children: <Widget>[
        Form(
          key: _formKey,
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _username,
                autocorrect: false,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                  labelText: l10n.t(K.authUsername),
                  prefixIcon: const Icon(Icons.person_outline),
                ),
                validator: (String? v) =>
                    (v ?? '').trim().isEmpty ? l10n.t(K.errorUsernameRequired) : null,
              ),
              const SizedBox(height: Dimens.gapM),
              TextFormField(
                controller: _password,
                obscureText: true,
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _submit(),
                decoration: InputDecoration(
                  labelText: l10n.t(K.authPassword),
                  prefixIcon: const Icon(Icons.lock_outline),
                ),
              ),
            ],
          ),
        ),
        if (session?.failure != null) ...<Widget>[
          const SizedBox(height: Dimens.gapM),
          NoticeBanner(
            tone: NoticeTone.danger,
            icon: Icons.error_outline,
            message: describeFailure(context, session!.failure!),
          ),
        ],
        const SizedBox(height: Dimens.gapL),
        FilledButton(
          onPressed: (session?.busy ?? false) ? null : _submit,
          child: (session?.busy ?? false)
              ? const SizedBox(
                  height: 22,
                  width: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.5),
                )
              : Text(l10n.t(K.authSignIn)),
        ),
      ],
    );
  }
}
