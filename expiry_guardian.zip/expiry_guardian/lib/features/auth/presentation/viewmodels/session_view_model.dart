import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/features/auth/domain/entities/app_user.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/domain/repositories/auth_repository.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

enum SessionStage { loading, needsSetup, signedOut, signedIn }

class SessionState {
  const SessionState({required this.stage, this.user, this.failure, this.busy = false});

  final SessionStage stage;
  final AppUser? user;
  final Failure? failure;
  final bool busy;

  bool can(Permission permission) => user?.can(permission) ?? false;

  SessionState copyWith({
    SessionStage? stage,
    AppUser? user,
    bool clearUser = false,
    Failure? failure,
    bool clearFailure = false,
    bool? busy,
  }) {
    return SessionState(
      stage: stage ?? this.stage,
      user: clearUser ? null : (user ?? this.user),
      failure: clearFailure ? null : (failure ?? this.failure),
      busy: busy ?? this.busy,
    );
  }
}

/// Owns who is signed in and what they may do.
class SessionViewModel extends AsyncNotifier<SessionState> {
  AuthRepository get _auth => ref.read(authRepositoryProvider);

  @override
  Future<SessionState> build() async {
    final Result<bool> setup = await _auth.needsInitialSetup();
    if (setup.isOk && setup.unwrap()) {
      return const SessionState(stage: SessionStage.needsSetup);
    }
    final Result<AppUser?> restored = await _auth.restoreSession();
    final AppUser? user = restored.valueOrNull;
    return user == null
        ? const SessionState(stage: SessionStage.signedOut)
        : SessionState(stage: SessionStage.signedIn, user: user);
  }

  Future<bool> createInitialAdmin({
    required String username,
    required String displayName,
    required String password,
  }) async {
    return _run(() => _auth.createInitialAdmin(
          username: username,
          displayName: displayName,
          password: password,
        ),);
  }

  Future<bool> signIn({required String username, required String password}) async {
    return _run(() => _auth.signIn(username: username, password: password));
  }

  Future<bool> _run(Future<Result<AppUser>> Function() action) async {
    final SessionState current = state.valueOrNull ??
        const SessionState(stage: SessionStage.loading);
    state = AsyncValue<SessionState>.data(current.copyWith(busy: true, clearFailure: true));

    final Result<AppUser> result = await action();
    return result.fold(
      (Failure failure) {
        state = AsyncValue<SessionState>.data(
          current.copyWith(busy: false, failure: failure),
        );
        return false;
      },
      (AppUser user) {
        state = AsyncValue<SessionState>.data(
          SessionState(stage: SessionStage.signedIn, user: user),
        );
        return true;
      },
    );
  }

  Future<void> signOut() async {
    await _auth.signOut();
    state = const AsyncValue<SessionState>.data(SessionState(stage: SessionStage.signedOut));
  }

  void clearFailure() {
    final SessionState? current = state.valueOrNull;
    if (current == null) return;
    state = AsyncValue<SessionState>.data(current.copyWith(clearFailure: true));
  }
}

final AsyncNotifierProvider<SessionViewModel, SessionState> sessionProvider =
    AsyncNotifierProvider<SessionViewModel, SessionState>(SessionViewModel.new);

/// Convenience for widgets that only need "may I do X".
final Provider<Set<Permission>> permissionsProvider = Provider<Set<Permission>>((Ref ref) {
  final AppUser? user = ref.watch(sessionProvider).valueOrNull?.user;
  if (user == null || !user.isActive) return const <Permission>{};
  return RolePermissions.of(user.role);
});

/// The signed-in user's id, or null. Used by write operations for the audit
/// trail without dragging the whole session object around.
final Provider<String?> sessionUserIdProvider =
    Provider<String?>((Ref ref) => ref.watch(sessionProvider).valueOrNull?.user?.id);
