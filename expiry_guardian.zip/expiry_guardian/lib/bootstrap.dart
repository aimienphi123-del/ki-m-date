import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:expiry_guardian/core/audit/audit_repository.dart';
import 'package:expiry_guardian/core/audit/audit_repository_impl.dart';
import 'package:expiry_guardian/core/database/app_database.dart';
import 'package:expiry_guardian/core/device/device_identity.dart';
import 'package:expiry_guardian/core/di/dependencies.dart';
import 'package:expiry_guardian/core/error/failure.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/logging/app_logger.dart';
import 'package:expiry_guardian/core/notifications/local_notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_gateway.dart';
import 'package:expiry_guardian/core/notifications/notification_planner.dart';
import 'package:expiry_guardian/core/notifications/notification_preferences.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/notifications/notification_workflow_repository.dart';
import 'package:expiry_guardian/core/result/result.dart';
import 'package:expiry_guardian/core/session/current_user_holder.dart';
import 'package:expiry_guardian/core/storage/session_store.dart';
import 'package:expiry_guardian/core/storage/settings_store.dart';
import 'package:expiry_guardian/core/sync/remote_sync_gateway.dart';
import 'package:expiry_guardian/core/sync/sync_engine.dart';
import 'package:expiry_guardian/core/sync/sync_queue.dart';
import 'package:expiry_guardian/core/sync/unconfigured_remote_gateway.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/auth/data/datasources/user_local_datasource.dart';
import 'package:expiry_guardian/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:expiry_guardian/features/auth/data/security/password_hasher.dart';
import 'package:expiry_guardian/features/auth/domain/repositories/auth_repository.dart';
import 'package:expiry_guardian/features/backup/data/repositories/backup_repository_impl.dart';
import 'package:expiry_guardian/features/backup/domain/repositories/backup_repository.dart';
import 'package:expiry_guardian/features/catalog/data/repositories/catalog_repository_impl.dart';
import 'package:expiry_guardian/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:expiry_guardian/features/escalation/data/repositories/escalation_repository_impl.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/escalation/domain/repositories/escalation_repository.dart';
import 'package:expiry_guardian/features/escalation/domain/services/escalation_engine.dart';
import 'package:expiry_guardian/features/insights/data/repositories/insights_repository_impl.dart';
import 'package:expiry_guardian/features/insights/domain/repositories/insights_repository.dart';
import 'package:expiry_guardian/features/insights/domain/services/prediction_engine.dart';
import 'package:expiry_guardian/features/inventory/data/datasources/inventory_local_datasource.dart';
import 'package:expiry_guardian/features/inventory/data/repositories/inventory_repository_impl.dart';
import 'package:expiry_guardian/features/inventory/domain/repositories/inventory_repository.dart';
import 'package:expiry_guardian/features/inventory/domain/services/inventory_code_generator.dart';
import 'package:expiry_guardian/features/locations/data/repositories/location_repository_impl.dart';
import 'package:expiry_guardian/features/locations/domain/repositories/location_repository.dart';
import 'package:expiry_guardian/features/policy/data/datasources/policy_local_datasource.dart';
import 'package:expiry_guardian/features/policy/data/repositories/policy_repository_impl.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/repositories/policy_repository.dart';
import 'package:expiry_guardian/features/policy/domain/services/default_policy_factory.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:expiry_guardian/features/reports/data/datasources/export_local_datasource.dart';
import 'package:expiry_guardian/features/reports/data/export/csv_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/html_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/local_file_export_gateway.dart';
import 'package:expiry_guardian/features/reports/data/export/pdf_document_renderer.dart';
import 'package:expiry_guardian/features/reports/data/export/unconfigured_google_docs_gateway.dart';
import 'package:expiry_guardian/features/reports/data/repositories/analytics_repository_impl.dart';
import 'package:expiry_guardian/features/reports/data/repositories/document_export_repository_impl.dart';
import 'package:expiry_guardian/features/reports/domain/entities/report_document.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/analytics_repository.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_gateway.dart';
import 'package:expiry_guardian/features/reports/domain/repositories/document_export_repository.dart';
import 'package:expiry_guardian/features/scan/data/sources/mlkit_barcode_reader.dart';
import 'package:expiry_guardian/features/scan/data/sources/mlkit_text_reader.dart';
import 'package:expiry_guardian/features/scan/domain/repositories/vision_gateways.dart';
import 'package:expiry_guardian/features/scan/domain/services/scan_pipeline.dart';
import 'package:expiry_guardian/features/workflow/domain/services/operation_workflow_service.dart';
import 'package:flutter/services.dart' show ByteData, rootBundle;
import 'package:flutter/widgets.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';


/// Builds the whole object graph, in one place, in a readable order.
///
/// Any of these collaborators can be swapped for a test double simply by
/// calling [buildDependencies] with a different argument - there is no service
/// locator and no global state.
Future<Dependencies> buildDependencies({
  AppLogger? logger,
  Clock clock = const SystemClock(),
  DatabaseFactory? databaseFactory,
  String? databasePath,
  NotificationGateway? notificationGateway,
  RemoteSyncGateway remoteGateway = const UnconfiguredRemoteGateway(),
}) async {
  WidgetsFlutterBinding.ensureInitialized();

  final AppLogger log = logger ?? const DeveloperLogLogger();
  final IdGenerator ids = UuidGenerator.create();

  final Directory documents = await getApplicationDocumentsDirectory();
  final String path = databasePath ?? await AppDatabase.defaultPath(documents.path);

  final AppDatabase database = AppDatabase(
    factory: databaseFactory ?? databaseFactorySqflitePlugin,
    databasePath: path,
    logger: log,
  );
  await database.open();

  final SettingsStore settings = SettingsStore(database, clock);
  await settings.load();

  final SharedPreferences preferences = await SharedPreferences.getInstance();
  final SessionStore session = PreferencesSessionStore(preferences);
  final CurrentUserHolder currentUser = CurrentUserHolder();

  // Identifies this handset in every confirmation and audit row. Generated on
  // first launch; no hardware identifier is read.
  final DeviceIdentityProvider deviceIdentity =
      await SettingsDeviceIdentityProvider.resolve(settings, ids);

  final SyncQueue syncQueue = SqfliteSyncQueue(database, clock);
  final SyncEngine syncEngine = SyncEngine(
    queue: syncQueue,
    gateway: remoteGateway,
    connectivity: Connectivity(),
    clock: clock,
    logger: log,
  );

  // The append-only log. Everything that writes takes this, so no feature can
  // change the database without leaving a trace.
  final AuditRepository auditRepository = AuditRepositoryImpl(
    database: database,
    clock: clock,
    ids: ids,
    device: deviceIdentity,
    actor: () => AuditActor(
      id: currentUser.id,
      name: currentUser.displayName,
      role: currentUser.user?.role.name,
    ),
    logger: log,
  );

  const ExpiryPolicyEngine policyEngine = DefaultExpiryPolicyEngine();

  final PolicyLocalDataSource policyLocal = SqflitePolicyDataSource(database);
  final PolicyRepository policyRepository = PolicyRepositoryImpl(
    local: policyLocal,
    database: database,
    clock: clock,
    syncQueue: syncQueue,
    logger: log,
  );
  await _seedPolicyIfMissing(policyLocal, policyRepository, ids, clock, log);

  final AuthRepository authRepository = AuthRepositoryImpl(
    local: SqfliteUserDataSource(database),
    hasher: Pbkdf2PasswordHasher(),
    session: session,
    currentUser: currentUser,
    clock: clock,
    ids: ids,
    syncQueue: syncQueue,
    logger: log,
  );

  final LocationRepository locationRepository = LocationRepositoryImpl(
    database: database,
    clock: clock,
    ids: ids,
    syncQueue: syncQueue,
    logger: log,
  );

  final CatalogRepository catalogRepository = CatalogRepositoryImpl(
    database: database,
    clock: clock,
    ids: ids,
    syncQueue: syncQueue,
    logger: log,
  );

  final InventoryRepository inventoryRepository = InventoryRepositoryImpl(
    database: database,
    local: SqfliteInventoryDataSource(database),
    catalog: catalogRepository,
    policies: policyRepository,
    engine: policyEngine,
    codes: const DatedSequenceCodeGenerator(),
    clock: clock,
    ids: ids,
    syncQueue: syncQueue,
    logger: log,
  );

  final AnalyticsRepository analyticsRepository =
      AnalyticsRepositoryImpl(database: database, logger: log);

  final InsightsRepository insightsRepository = InsightsRepositoryImpl(
    analytics: analyticsRepository,
    inventory: inventoryRepository,
    engine: PredictionEngine(
      config: PredictionConfig(
        minimumTotalSamples: settings.readInt(
          SettingKeys.insightsMinimumSamples,
          SettingDefaults.insightsMinimumSamples,
        ),
        lookbackDays: settings.readInt(
          SettingKeys.insightsLookbackDays,
          SettingDefaults.insightsLookbackDays,
        ),
        forecastDays: settings.readInt(
          SettingKeys.insightsForecastDays,
          SettingDefaults.insightsForecastDays,
        ),
      ),
    ),
    clock: clock,
  );

  final NotificationGateway notifications =
      notificationGateway ?? LocalNotificationGateway(logger: log);
  await notifications.initialize();

  // Feature 1: the reminder timeline is data, not code. Seeded once with the
  // -2d / -1d / on-time / hourly-repeat stages, editable from that moment on.
  final NotificationWorkflowRepository notificationWorkflow =
      NotificationWorkflowRepositoryImpl(
    database: database,
    clock: clock,
    newId: ids.newId,
    syncQueue: syncQueue,
    audit: auditRepository,
    logger: log,
  );
  await _seedNotificationStagesIfMissing(notificationWorkflow, ids, clock, log);

  final NotificationPlanner planner = NotificationPlanner(
    inventory: inventoryRepository,
    workflow: notificationWorkflow,
    gateway: notifications,
    database: database,
    clock: clock,
    logger: log,
  );

  // Feature 3: escalation rules are data too - "24 hours after the destroy
  // deadline, tell a manager" is a row a manager can change.
  const EscalationEngine escalationEngine = EscalationEngine();
  final EscalationRepository escalationRepository = EscalationRepositoryImpl(
    database: database,
    inventory: inventoryRepository,
    engine: escalationEngine,
    clock: clock,
    ids: ids,
    syncQueue: syncQueue,
    audit: auditRepository,
    logger: log,
    currentUserId: () => currentUser.id,
  );
  await _seedEscalationRulesIfMissing(escalationRepository, ids, clock, log);

  // Feature 2 + 3 orchestration: one owner for confirm -> cancel reminders ->
  // resolve escalation -> write the audit entry, so no screen can do half of it.
  final OperationWorkflowService workflowService = OperationWorkflowService(
    inventory: inventoryRepository,
    escalations: escalationRepository,
    escalationEngine: escalationEngine,
    planner: planner,
    audit: auditRepository,
    device: deviceIdentity,
    settings: settings,
    clock: clock,
    logger: log,
    currentUser: () => currentUser.user,
    strings: () => AppLocalizations(
      Locale(settings.readString(SettingKeys.locale, SettingDefaults.locale)),
    ),
    preferences: () => NotificationPreferences.fromSettings(settings),
  );

  // Feature 5: offline export first. The three file destinations work with no
  // account and no network; Google Docs is present but honestly unavailable.
  final Map<ExportDestination, DocumentExportGateway> exportGateways =
      await _buildExportGateways(
    documentsPath: documents.path,
    clock: clock,
    logger: log,
  );

  final DocumentExportRepository documentExportRepository = DocumentExportRepositoryImpl(
    dataSource: SqfliteExportDataSource(database),
    analytics: analyticsRepository,
    inventory: inventoryRepository,
    audit: auditRepository,
    database: database,
    settings: settings,
    clock: clock,
    ids: ids,
    device: deviceIdentity,
    actor: () => AuditActor(
      id: currentUser.id,
      name: currentUser.displayName,
      role: currentUser.user?.role.name,
    ),
    strings: () => AppLocalizations(
      Locale(settings.readString(SettingKeys.locale, SettingDefaults.locale)),
    ),
    gateways: exportGateways,
    logger: log,
  );

  // One reader, shared: the viewfinder reads the live stream through it and
  // the pipeline reads the still through it, so there is a single ML Kit
  // scanner to keep warm and a single one to close.
  final BarcodeReader barcodeReader = MlKitBarcodeReader(logger: log);

  final TextReader textReader = MlKitTextReader(logger: log);

  final ScanPipeline scanPipeline = ScanPipeline(
    barcodeReader: barcodeReader,
    textReader: textReader,
    catalog: catalogRepository,
    clock: clock,
    logger: log,
  );

  final PackageInfo packageInfo = await PackageInfo.fromPlatform();

  final BackupRepository backupRepository = BackupRepositoryImpl(
    database: database,
    clock: clock,
    logger: log,
    documentsDirectory: () async => documents,
    appVersion: '${packageInfo.version}+${packageInfo.buildNumber}',
  );

  return Dependencies(
    logger: log,
    clock: clock,
    ids: ids,
    database: database,
    settings: settings,
    session: session,
    syncQueue: syncQueue,
    remoteGateway: remoteGateway,
    syncEngine: syncEngine,
    currentUser: currentUser,
    notificationGateway: notifications,
    notificationPlanner: planner,
    notificationWorkflowRepository: notificationWorkflow,
    deviceIdentity: deviceIdentity,
    auditRepository: auditRepository,
    policyEngine: policyEngine,
    authRepository: authRepository,
    policyRepository: policyRepository,
    locationRepository: locationRepository,
    catalogRepository: catalogRepository,
    inventoryRepository: inventoryRepository,
    analyticsRepository: analyticsRepository,
    insightsRepository: insightsRepository,
    escalationRepository: escalationRepository,
    documentExportRepository: documentExportRepository,
    backupRepository: backupRepository,
    workflowService: workflowService,
    scanPipeline: scanPipeline,
    barcodeReader: barcodeReader,
    textReader: textReader,
    appVersion: packageInfo.version,
    appBuild: packageInfo.buildNumber,
  );
}

/// Writes the starting handbook on first launch. These are ordinary editable
/// rows from that moment on.
Future<void> _seedPolicyIfMissing(
  PolicyLocalDataSource local,
  PolicyRepository repository,
  IdGenerator ids,
  Clock clock,
  AppLogger logger,
) async {
  if (await local.countPolicies() > 0) return;
  final DestroyPolicy policy = DefaultPolicyFactory(ids, clock).build();
  await local.insertPolicy(policy);
  await local.setActive(policy.id);
  logger.i('Bootstrap', 'Seeded the default destruction policy (${policy.rules.length} rules)');
}

/// Writes the starting reminder timeline on first launch: two days before,
/// one day before, on the destroy instant, then hourly until somebody
/// confirms. Ordinary editable rows from that moment on.
Future<void> _seedNotificationStagesIfMissing(
  NotificationWorkflowRepository repository,
  IdGenerator ids,
  Clock clock,
  AppLogger logger,
) async {
  final Result<int> existing = await repository.count();
  if (existing.valueOrNull != 0) return;
  final List<NotificationStage> stages =
      DefaultNotificationStages.build(newId: ids.newId, now: clock.now());
  for (final NotificationStage stage in stages) {
    await repository.upsert(stage);
  }
  logger.i('Bootstrap', 'Seeded ${stages.length} notification stages');
}

/// Writes the starting escalation rule on first launch: 24 hours after the
/// destroy deadline, tell a manager, and keep telling them every 12 hours up
/// to four times.
Future<void> _seedEscalationRulesIfMissing(
  EscalationRepository repository,
  IdGenerator ids,
  Clock clock,
  AppLogger logger,
) async {
  final Result<int> existing = await repository.countRules();
  if (existing.valueOrNull != 0) return;
  final List<EscalationRule> rules =
      DefaultEscalationRules.build(newId: ids.newId, now: clock.now());
  for (final EscalationRule rule in rules) {
    await repository.upsertRule(rule);
  }
  logger.i('Bootstrap', 'Seeded ${rules.length} escalation rules');
}

/// Builds the four export destinations.
///
/// The PDF writer needs real font bytes - the built-in PDF fonts have no
/// Vietnamese diacritics, so a report would print "Sa ti" for "Sữa tươi". If
/// the bundled faces cannot be read the PDF option reports itself unavailable
/// rather than producing a document with the accents stripped out.
Future<Map<ExportDestination, DocumentExportGateway>> _buildExportGateways({
  required String documentsPath,
  required Clock clock,
  required AppLogger logger,
}) async {
  Future<Directory> exportDirectory() async =>
      Directory(p.join(documentsPath, 'expiry_guardian', 'reports'));

  PdfDocumentRenderer? pdfRenderer;
  try {
    final ByteData regular = await rootBundle.load('assets/fonts/Roboto-Regular.ttf');
    final ByteData bold = await rootBundle.load('assets/fonts/Roboto-Bold.ttf');
    pdfRenderer = PdfDocumentRenderer(
      ReportFonts(
        regular: regular.buffer.asUint8List(),
        bold: bold.buffer.asUint8List(),
      ),
    );
  } on Object catch (error) {
    logger.w('Bootstrap', 'Report fonts unavailable, PDF export disabled', error: error);
  }

  return <ExportDestination, DocumentExportGateway>{
    ExportDestination.localPdf: pdfRenderer == null
        ? const UnavailableExportGateway(
            destination: ExportDestination.localPdf,
            reasonKey: 'export.fontsMissing',
          )
        : LocalFileExportGateway(
            destination: ExportDestination.localPdf,
            directory: exportDirectory,
            clock: clock,
            pdfRenderer: pdfRenderer,
          ),
    ExportDestination.localHtml: LocalFileExportGateway(
      destination: ExportDestination.localHtml,
      directory: exportDirectory,
      clock: clock,
      html: const HtmlDocumentRenderer(),
    ),
    ExportDestination.localCsv: LocalFileExportGateway(
      destination: ExportDestination.localCsv,
      directory: exportDirectory,
      clock: clock,
      csv: const CsvDocumentRenderer(),
    ),
    ExportDestination.googleDocs: const UnconfiguredGoogleDocsGateway(),
  };
}

/// Runs after the first frame.
///
/// One call does the whole Phase X start-up sequence: raise any escalation
/// whose delay elapsed while the phone was off, build the manager alerts, and
/// re-derive the complete reminder schedule from the stages and the open
/// stock. Everything is deterministic, so this is also what makes the workflow
/// survive a reboot with no background service running.
Future<void> scheduleRemindersAfterStartup(
  Dependencies dependencies,
  AppLocalizations strings,
) async {
  // Ask for permission to notify *before* building a schedule, otherwise the
  // whole timeline is registered against a permission the app does not have
  // and every reminder is silently discarded by Android. On 13+ this is a
  // runtime permission that starts denied, so a build that never asks never
  // notifies - and the employee has no way to tell the difference between
  // "nothing is due" and "the app cannot speak".
  await ensureNotificationPermission(dependencies);

  final Result<WorkflowRefreshResult> result = await dependencies.workflowService.refresh();
  result.fold(
    (Failure failure) => dependencies.logger
        .w('Bootstrap', 'Could not schedule reminders: ${failure.message}'),
    (WorkflowRefreshResult value) => dependencies.logger.i(
      'Bootstrap',
      'Workflow ready: ${value.notificationsScheduled} reminders, '
      '${value.escalationsRaised} new escalations, '
      '${value.openEscalations} open',
    ),
  );
}

/// Makes sure the app is actually allowed to put a reminder on screen.
///
/// Three separate gates have to be open on a modern Android phone, and every
/// one of them fails *silently*:
///
///  1. `POST_NOTIFICATIONS` (API 33+) is a runtime permission that starts
///     denied. `zonedSchedule` still succeeds without it; the notification is
///     simply never shown.
///  2. Exact alarms (API 31+). The app declares `USE_EXACT_ALARM`, which is
///     granted on install, but a phone that only honours `SCHEDULE_EXACT_ALARM`
///     needs the user to allow it. Without it reminders still arrive, just
///     batched by the system - acceptable, so this is asked for but never
///     insisted on.
///  3. The notification channels, created by `initialize()`.
///
/// The answer is recorded so the employee is asked once rather than on every
/// launch, and so Settings can show the real state instead of guessing.
Future<bool> ensureNotificationPermission(Dependencies dependencies) async {
  final NotificationGateway gateway = dependencies.notificationGateway;
  final SettingsStore settings = dependencies.settings;
  final AppLogger logger = dependencies.logger;

  await gateway.initialize();

  bool granted = await gateway.hasPermission();
  if (!granted && !settings.readBool(SettingKeys.notificationPermissionAsked, false)) {
    granted = await gateway.requestPermission();
    await settings.write(SettingKeys.notificationPermissionAsked, true);
    logger.i('Bootstrap', 'Asked for notification permission: granted=$granted');
  }
  await settings.write(SettingKeys.notificationPermissionGranted, granted);

  if (!granted) {
    logger.w(
      'Bootstrap',
      'Notifications are blocked; reminders will be scheduled but not shown',
    );
    return false;
  }

  if (!await gateway.canScheduleExactAlarms() &&
      !settings.readBool(SettingKeys.exactAlarmPermissionAsked, false)) {
    final bool exact = await gateway.requestExactAlarmPermission();
    await settings.write(SettingKeys.exactAlarmPermissionAsked, true);
    logger.i('Bootstrap', 'Asked for exact alarms: granted=$exact');
  }
  return true;
}
