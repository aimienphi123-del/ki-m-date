import 'package:expiry_guardian/core/di/providers.dart';
import 'package:expiry_guardian/core/l10n/app_localizations.dart';
import 'package:expiry_guardian/core/l10n/app_strings.dart';
import 'package:expiry_guardian/core/theme/app_theme.dart';
import 'package:expiry_guardian/features/auth/domain/entities/user_role.dart';
import 'package:expiry_guardian/features/auth/presentation/pages/auth_pages.dart';
import 'package:expiry_guardian/features/auth/presentation/viewmodels/session_view_model.dart';
import 'package:expiry_guardian/features/inventory/presentation/pages/inventory_page.dart';
import 'package:expiry_guardian/features/inventory/presentation/pages/record_detail_page.dart';
import 'package:expiry_guardian/features/reports/presentation/pages/reports_page.dart';
import 'package:expiry_guardian/features/scan/presentation/pages/scan_page.dart';
import 'package:expiry_guardian/features/settings/presentation/pages/more_page.dart';
import 'package:expiry_guardian/features/tasks/presentation/pages/today_page.dart';
import 'package:expiry_guardian/shared/widgets/common_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ExpiryGuardianApp extends ConsumerWidget {
  const ExpiryGuardianApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final Locale locale = ref.watch(localeProvider);
    final ThemeMode themeMode = ref.watch(themeModeProvider);

    return MaterialApp(
      title: 'Expiry Guardian',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
      locale: locale,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const <LocalizationsDelegate<Object>>[
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const _RootGate(),
    );
  }
}

/// Chooses between first-run setup, sign-in and the app shell.
class _RootGate extends ConsumerWidget {
  const _RootGate();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<SessionState> session = ref.watch(sessionProvider);

    return session.when(
      loading: () => const Scaffold(body: LoadingView()),
      error: (Object error, StackTrace stack) => Scaffold(
        body: ErrorView(
          message: error.toString(),
          onRetry: () => ref.invalidate(sessionProvider),
        ),
      ),
      data: (SessionState state) => switch (state.stage) {
        SessionStage.loading => const Scaffold(body: LoadingView()),
        SessionStage.needsSetup => const InitialSetupPage(),
        SessionStage.signedOut => const SignInPage(),
        SessionStage.signedIn => const AppShell(),
      },
    );
  }
}

final StateProvider<int> shellTabProvider = StateProvider<int>((Ref ref) => 0);

/// Five destinations, thumb-reachable, with Scan as the centre action so the
/// most frequent task is always one tap away.
class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});

  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

/// The More icon with the open-escalation badge.
class _MoreIcon extends StatelessWidget {
  const _MoreIcon({required this.openAlerts});

  final int openAlerts;

  @override
  Widget build(BuildContext context) {
    const Icon icon = Icon(Icons.more_horiz);
    if (openAlerts <= 0) return icon;
    return Badge.count(count: openAlerts, child: icon);
  }
}

class _AppShellState extends ConsumerState<AppShell> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _listenForTaps());
  }

  /// Tapping a reminder opens the lot it is about.
  void _listenForTaps() {
    ref.read(dependenciesProvider).notificationGateway.selections.listen((String? payload) {
      if (!mounted || payload == null) return;
      if (payload == 'today') {
        ref.read(shellTabProvider.notifier).state = 0;
        return;
      }
      if (payload.startsWith('record:')) {
        RecordDetailPage.open(context, payload.substring('record:'.length));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppLocalizations l10n = context.l10n;
    final int index = ref.watch(shellTabProvider);
    final Set<Permission> permissions = ref.watch(permissionsProvider);
    final bool canScan = permissions.contains(Permission.scanGoods);
    final bool canReport = permissions.contains(Permission.viewReports);
    final int openAlerts = permissions.contains(Permission.manageEscalations)
        ? (ref.watch(openEscalationCountProvider).valueOrNull ?? 0)
        : 0;

    final List<Widget> pages = <Widget>[
      const TodayPage(),
      if (canScan) const ScanPage(),
      const InventoryPage(),
      if (canReport) const ReportsPage(),
      const MorePage(),
    ];

    final List<NavigationDestination> destinations = <NavigationDestination>[
      NavigationDestination(
        icon: const Icon(Icons.today_outlined),
        selectedIcon: const Icon(Icons.today),
        label: l10n.t(K.navToday),
      ),
      if (canScan)
        NavigationDestination(
          icon: const Icon(Icons.qr_code_scanner),
          selectedIcon: const Icon(Icons.qr_code_scanner),
          label: l10n.t(K.navScan),
        ),
      NavigationDestination(
        icon: const Icon(Icons.inventory_2_outlined),
        selectedIcon: const Icon(Icons.inventory_2),
        label: l10n.t(K.navInventory),
      ),
      if (canReport)
        NavigationDestination(
          icon: const Icon(Icons.insert_chart_outlined),
          selectedIcon: const Icon(Icons.insert_chart),
          label: l10n.t(K.navReports),
        ),
      NavigationDestination(
        // A manager should see that something is waiting without opening the
        // tab, so the open-escalation count rides on the More icon.
        icon: _MoreIcon(openAlerts: openAlerts),
        selectedIcon: _MoreIcon(openAlerts: openAlerts),
        label: l10n.t(K.navMore),
      ),
    ];

    final int safeIndex = index.clamp(0, pages.length - 1);

    return Scaffold(
      body: IndexedStack(index: safeIndex, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: safeIndex,
        destinations: destinations,
        onDestinationSelected: (int value) =>
            ref.read(shellTabProvider.notifier).state = value,
      ),
    );
  }
}
