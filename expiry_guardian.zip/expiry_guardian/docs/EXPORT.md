# Xuất báo cáo / Report export

Phase X, Feature 5. Bản này **xuất offline trước**: PDF, HTML và CSV ghi thẳng
ra file trên máy, không cần tài khoản, không cần mạng. Google Docs đã có sẵn
giao diện (`DocumentExportGateway`) nhưng chưa nối — và nó **báo thẳng là chưa
cấu hình** chứ không giả vờ chạy.

---

## 1. Sáu mẫu báo cáo

| Mẫu | `ReportTemplate` | Nội dung |
| --- | --- | --- |
| Báo cáo huỷ hàng ngày | `dailyDestroy` | Thống kê + từng lô đã huỷ trong ngày |
| Báo cáo tuần | `weekly` | Như trên, kỳ 7 ngày |
| Báo cáo tháng | `monthly` | Như trên, kỳ 1 tháng |
| Báo cáo kiểm toán | `audit` | Nhật ký thao tác + kết quả kiểm tra chuỗi băm |
| Báo cáo tồn kho | `inventory` | Hàng đang trên kệ, sắp theo hạn huỷ |
| Báo cáo hàng quá hạn | `expired` | Hàng đã quá hạn mà chưa huỷ |

Mọi mẫu đều mang: Công ty · Cửa hàng (+ mã) · Kỳ báo cáo · Thời điểm lập ·
Người lập · Thiết bị. Thống kê, ảnh và ô ký tên bật/tắt được trong màn hình
Xuất báo cáo.

**Không có dữ liệu giả.** Kỳ nào không có gì thì báo cáo ghi rõ "Không có dữ
liệu trong kỳ này" — không độn dòng mẫu.

---

## 2. Kiến trúc

```
ReportInputs  ──►  ReportDocumentBuilder  ──►  ReportDocument
   (dữ liệu thật)        (thuần, test được)      (không phụ thuộc định dạng)
                                                        │
                        ┌───────────────────────────────┼───────────────────┐
                        ▼                   ▼           ▼                   ▼
              PdfDocumentRenderer  HtmlDocumentRenderer  CsvDocumentRenderer  (Google Docs)
                        └───────────────────┬───────────────────────────────┘
                                            ▼
                                  DocumentExportGateway
                                            ▼
                              DocumentExportRepository
                       (ghi lịch sử `document_exports` + 1 dòng nhật ký kiểm toán)
```

`ReportDocument` là một cây `sealed class DocumentSection`:

- `TextSection` — đoạn văn
- `StatSection` — ô số liệu
- `TableSection` — bảng, có `numericColumns` (căn phải) và `totals`
- `ImageSection` — ảnh bằng chứng

Thêm một định dạng mới = viết thêm một renderer đọc cùng cây này. Sáu mẫu chỉ
được định nghĩa **một lần**.

---

## 3. Ba đích xuất offline

`LocalFileExportGateway` ghi vào `<documents>/expiry_guardian/reports/` với tên
`<mẫu>-<YYYYMMDD-HHMMSS>.<ext>`, tự thêm hậu tố `-2`, `-3`… nếu trùng.

| Đích | Ghi chú |
| --- | --- |
| `localPdf` | Dùng font Roboto đóng kèm trong `assets/fonts/`. **Không dùng font mặc định của thư viện PDF** vì font đó không có dấu tiếng Việt — "Sữa tươi" sẽ in ra "Sa ti". Nếu không đọc được font, đích PDF tự báo không dùng được thay vì in mất dấu. |
| `localHtml` | Một file HTML tự chứa, có CSS in ấn — mở bằng trình duyệt rồi "In → Lưu thành PDF" cũng được. |
| `localCsv` | Có BOM UTF-8 để Excel bản tiếng Việt mở đúng chữ. |

Chia sẻ: nút Chia sẻ gọi hệ thống (Zalo, Drive, Gmail, cáp USB…).

---

## 4. Hợp đồng cho Google Docs

Khi cửa hàng muốn nối Google Docs, **chỉ cần viết một lớp mới** cài đặt đúng
`DocumentExportGateway` rồi thay vào map trong `bootstrap.dart`. Không màn hình
nào, không repository nào, không test nào phải sửa.

```dart
abstract interface class DocumentExportGateway {
  ExportDestination get destination;      // ExportDestination.googleDocs
  bool get isConfigured;                  // đã có OAuth client + thư mục chưa
  String? get unavailableReasonKey;       // khoá i18n giải thích vì sao chưa dùng được

  Future<ExportOutcome> create(ReportDocument document);
  Future<ExportOutcome> update(String documentId, ReportDocument document);
  Future<String?> shareLink(String documentId);
  Future<String?> exportPdf(String documentId, ReportDocument document);
}
```

Yêu cầu với một cài đặt thật:

1. **`create`** — `documents.create` rồi `documents.batchUpdate` để đổ nội dung.
   Trả về `ExportOutcome(documentId:, url:)`.
2. **`update`** — `batchUpdate` xoá sạch body cũ rồi ghi lại, **giữ nguyên
   `documentId`** để link đã chia sẻ không chết. Đích nào không sửa tại chỗ
   được thì tạo file mới và nói rõ qua `ExportOutcome`.
3. **`shareLink`** — `drive.permissions.create` (reader, anyoneWithLink) rồi trả
   `webViewLink`.
4. **`exportPdf`** — `drive.files.export` với `mimeType: application/pdf`, lưu
   xuống máy, trả đường dẫn.
5. **Thất bại phải ném `ExportUnavailableException(messageKey)`** với khoá i18n —
   không nuốt lỗi, không trả id giả.

Cấu hình cần lưu (đã có sẵn khoá trong `SettingsStore`):

| Khoá | Ý nghĩa |
| --- | --- |
| `google.docs.clientId` | OAuth client ID |
| `google.docs.folderId` | Thư mục Drive chứa báo cáo |

Ánh xạ `DocumentSection` → Google Docs API:

| Phần | Request |
| --- | --- |
| `DocumentHeader` | `insertText` + `updateParagraphStyle` (HEADING_1 / SUBTITLE) |
| `TextSection` | `insertText` + `updateParagraphStyle` (HEADING_2 + NORMAL_TEXT) |
| `StatSection` | `insertTable` 2 cột hoặc danh sách `insertText` in đậm |
| `TableSection` | `insertTable` (rows+1, cols) rồi `insertText` từng ô; cột số căn phải bằng `updateParagraphStyle(alignment: END)` |
| `ImageSection` | tải ảnh lên Drive rồi `insertInlineImage` theo URI |
| `SignatureBlock` | bảng 1 hàng, gạch chân bằng `updateTableCellStyle` |

---

## 5. Lịch sử và nhật ký

Mỗi lần xuất ghi một dòng `document_exports`:

| Cột | Ý nghĩa |
| --- | --- |
| `template`, `destination` | Mẫu và đích |
| `status` | `pending` → `ready` hoặc `failed` |
| `file_path` / `document_id` / `url` | Kết quả |
| `period_from`, `period_to` | Kỳ báo cáo |
| `created_by`, `device_id` | Ai, trên máy nào |
| `error` | Lý do thất bại, nếu có |

Và một dòng nhật ký kiểm toán `reportExported` — không sửa, không xoá được.
`regenerate(id)` dựng lại đúng file cũ với dữ liệu mới, giữ nguyên `id` và
đường dẫn.

---

## 6. Kiểm thử

`test/report_export_test.dart` phủ: ba renderer (kể cả escape HTML và trích dẫn
CSV), gateway chưa cấu hình ném lỗi thật, sáu mẫu dựng được từ dữ liệu rỗng mà
không bịa dòng nào, và toàn bộ đường đi từ một lần huỷ hàng thật đến file PDF /
HTML / CSV trên đĩa.
