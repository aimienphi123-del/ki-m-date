# Scanning

## Why the viewfinder reads the code, not the photograph

The first release photographed the barcode and then looked for a code in the
JPEG. On a shop floor that fails often enough to be useless, for reasons that
have nothing to do with the decoder:

* A printed EAN-13 gives about two millimetres of bar per digit. At 720p, held
  at a natural arm's length, a single bar lands on roughly one pixel and no
  decoder can recover it.
* A still gets exactly one attempt. It has to be sharp, square-on, evenly lit
  and not motion-blurred, all at the instant a thumb hits the button.
* Autofocus had not necessarily settled when the shutter fired.

A real scanner does not take photographs. It looks at a stream and needs only
one good frame out of dozens. That is the change:

```
CameraCapturePage(liveBarcode: true)
  startImageStream
    → CameraFrame (NV21 on Android, BGRA on iOS)
      → MlKitBarcodeReader.readFrame  → InputImage.fromBytes
        → a code? → stop the stream, buzz, keep a still, return
```

`CaptureResult` carries both the still and the codes the stream decoded.
`ScanPipeline.process(..., alreadyRead:)` trusts those codes and does not
re-read the photograph, so a still too poor to decode no longer costs the scan.

Three supporting fixes matter as much as the stream:

| Change | Why |
| --- | --- |
| `ResolutionPreset.veryHigh`, stepping down only if the hardware refuses | 720p cannot resolve small retail bars |
| Tap the preview to focus and meter there | Small printed dates are exactly what centre-weighted autofocus misses |
| The frame turns green while scanning | Otherwise nobody knows the button is unnecessary |

The shutter button stays. A damaged, missing or hand-written barcode still
needs a photograph, and the manual-entry route stays for when there is no
barcode at all.

### Rotation is not cosmetic

`CameraFrame.rotationDegrees` carries the sensor orientation through to ML Kit.
A barcode read out of a sideways buffer decodes as nothing whatsoever, so
getting this wrong looks exactly like "the scanner does not work".

### An undecodable frame is not an error

`readFrame` returns an empty list rather than throwing. At streaming rates most
frames carry no readable code, and a blurred or half-exposed buffer is the
ordinary case. Throwing would abort the scan on the first bad frame - which is
every scan. `readFile` still throws, because there a failure is a real failure.

## The optional photograph of the product front

Offered on the goods-in review step, never demanded. The barcode and the
printed dates are what the policy engine actually needs; the picture is for the
human who later has to find this exact lot on a shelf, and a picture of the
front is faster to match than a code. Making it mandatory would slow every
intake for a benefit that only sometimes applies, so it is a card with a
"take / retake / remove" row and no validation attached.

It travels as `IntakeDraft.photoPath` and is stored on the inventory record, so
it also shows up wherever that record is displayed later.

## Native dependencies

`google_mlkit_barcode_scanning` pulls in `com.google.mlkit:barcode-scanning`,
the **bundled** variant: the model ships inside the APK as
`lib/<abi>/libbarhopper_v3.so` and needs no Google Play download and no
network. `tool/patch_android.py` also writes the
`com.google.mlkit.vision.DEPENDENCIES` manifest tag with `barcode,ocr`.

Check a built APK with:

```bash
unzip -l build/app/outputs/flutter-apk/app-arm64-v8a-release.apk | grep barhopper
```

No `libbarhopper_v3.so` means barcode scanning cannot work on a phone no matter
what the Dart code says.

## Text is read from the stream too

The same argument applies to printed dates, only more strongly. A date is
small, low contrast, frequently on a curved or shiny surface, and often under
shop lighting that makes it worse. Photographing it hands the recogniser one
attempt at exactly the kind of image it is worst at.

So the date step streams as well, with one extra rule: it stops on the first
frame that yields a **usable date**, not on the first frame that yields any
text. A label is covered in text that is not a date, and returning on that
would be worse than returning nothing. The live pass uses the store's own
`LabelTextParser` configuration, so it agrees with the pipeline about what
counts as a date rather than applying a second, looser rule.

### The Chinese pass can no longer lose the Latin one

`MlKitTextReader` tries Latin first and adds a Chinese pass when the Latin pass
found nothing date-like. That second pass used to share the outer `try`, so any
failure inside it discarded the Latin lines that had already been read
successfully - an extra chance at an imported label was able to destroy a
perfectly good Vietnamese reading. The Chinese pass is now best effort in its
own right and keeps whatever Latin produced.

### A lost photograph no longer loses the scan

`ScanPipeline.process` accepts an empty capture path as long as the live pass
read something. The code and the date are the valuable output; the still is a
souvenir for the record. Losing the file must not throw away the reading. With
neither, the pipeline still reports `capture_missing` - it never invents a
value it did not read.

## Remembering a product

A barcode the store has seen before comes back from `products` with its name,
unit, cost and **shelf**, and the flow then walks straight to the date step
(`scan.autoAdvance`, default on) because the dates are the only thing left.

The shelf is the half that was missing. `Product.defaultShelfId` was read but
never written, so every scan of a known barcode still arrived with an empty
shelf. After a successful intake the flow now records the chosen shelf on the
product - but only when the product has none yet, and only a shelf the employee
actually chose. A product with a usual home keeps it, and a one-off placement
never silently overwrites it. Nothing is guessed.
