# Notifications

## Three gates, all of which fail silently

A reminder that nobody is allowed to show is the worst kind of bug: the
schedule is perfect, the database is right, the logs say "scheduled 27
reminders", and the phone says nothing at all. On a modern Android handset
three separate gates have to be open, and none of them reports an error when
it is shut.

| Gate | Since | What happens when closed |
| --- | --- | --- |
| `POST_NOTIFICATIONS` runtime permission | Android 13 | `zonedSchedule` succeeds; the notification is never shown |
| Exact alarms | Android 12 | Reminders still arrive, but batched by the system |
| Notification channels | Android 8 | The post is dropped |

The first one is what broke this app. It is a **runtime** permission and it
starts **denied**, and the only code that asked for it lived behind a button in
Settings → Notifications. Nobody goes looking in Settings for a feature they
believe is already working, so the app scheduled a full timeline against a
permission it did not have and stayed quiet for ever.

## What the app does now

`ensureNotificationPermission` runs at start-up, *before* the first schedule is
built:

1. `initialize()` - creates the three channels (`Importance.max` for item and
   escalation alerts) and resolves the device time zone.
2. Asks for `POST_NOTIFICATIONS` **once**. The answer is stored, so the
   employee is asked on first launch rather than on every launch.
3. Records whether it was granted, which is what lets the UI state the truth
   instead of guessing.
4. Asks for exact alarms, once, and does not insist - inexact reminders are
   worse but not useless, so a refusal is not treated as a failure.

Reminders are still scheduled on a blocked phone, deliberately: the moment the
employee allows notifications the whole timeline is already in place.

And the block is stated on the **Today** screen - the first thing seen every
shift - not only in Settings. A warning nobody will find is the same as no
warning.

## Manifest

`tool/patch_android.py` declares `POST_NOTIFICATIONS`, `SCHEDULE_EXACT_ALARM`,
`USE_EXACT_ALARM`, `VIBRATE` and `RECEIVE_BOOT_COMPLETED`, plus the two
`flutter_local_notifications` receivers so the schedule survives a reboot.

`USE_EXACT_ALARM` is granted on install and needs no prompt. Google Play
restricts it to alarm and calendar apps; this app is sideloaded inside one
company, so it is the right choice here and would need revisiting before any
Play Store release.
