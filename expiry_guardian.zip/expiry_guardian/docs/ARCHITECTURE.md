# Architecture

## Shape

Clean Architecture, one folder per feature, three layers per feature.

```
lib/
├── main.dart                      composition root entry point
├── bootstrap.dart                 builds the whole object graph, once
├── app.dart                       MaterialApp + the five-tab shell
├── core/                          cross-cutting infrastructure
│   ├── audit/                     append-only, hash-chained operation log
│   ├── database/                  SQLite connection, migrations, SQL helpers
│   ├── device/                    this handset's identity (random, not hardware)
│   ├── di/                        Dependencies container + Riverpod providers
│   ├── domain/                    shared kernel value objects
│   ├── error/                     Failure, exceptions
│   ├── l10n/                      the two string tables + lookup
│   ├── logging/                   AppLogger seam
│   ├── notifications/             gateway, preferences, the stage timeline, planner
│   ├── session/                    who is signed in, readable outside the tree
│   ├── result/                    Result<T> (Ok | Err)
│   ├── storage/                   settings + session
│   ├── sync/                      outbox queue, remote gateway seam, engine
│   ├── theme/                     tokens, palette, ThemeData
│   └── utils/                     Clock, IdGenerator, CSV
├── features/<feature>/
│   ├── domain/                    entities, repository interfaces, pure services
│   ├── data/                      models (row mappers), data sources, repository impls
│   └── presentation/              view models, pages, widgets
└── shared/widgets/                widgets used by more than one feature
```

Dependency rule: `presentation → domain ← data`. The domain layer imports
nothing from Flutter, from sqflite, or from ML Kit, which is why the policy
engine, the label parser, the GS1 parser, the plan builder and the prediction
engine are all covered by fast unit tests.

## Patterns

| Requirement | How it is met |
|---|---|
| Modular | One folder per feature; `core/` holds only what two features share. |
| Clean Architecture | Three layers per feature, dependencies point inwards. |
| SOLID | Repositories and gateways are `abstract interface class`; the engines are single-purpose and injected; the sync gateway is the open/closed seam for adding a backend. |
| Repository pattern | Every feature exposes an interface in `domain/repositories/`, implemented in `data/repositories/`. |
| Dependency injection | `buildDependencies()` in `bootstrap.dart` is the only place concrete classes are constructed. Riverpod hosts the graph and the view models; there is no service locator and no global mutable state. |
| MVVM | Pages are dumb; each screen has a view model (`Notifier` / `AsyncNotifier` / `FutureProvider`) exposing immutable state. |
| Documentation | Every public class carries a doc comment explaining *why*, not just *what*. |

### One owner per workflow

`OperationWorkflowService` (`features/workflow/`) owns the confirm → cancel
reminders → resolve escalation → write audit sequence. No screen calls
`InventoryRepository.destroy` directly, because half of that sequence running is
worse than none of it. `InventoryActions` — the view-model seam every screen
already used — delegates to it. See `OPERATION_WORKFLOW.md`.

## Error handling

Data sources may throw. Repositories catch, map onto a `Failure`, and return
`Result<T>`. `Failure.code` is a machine-readable enum; the UI maps it to a
localized message in `describeFailure`. Nothing shows an English exception
string to a shop-floor employee.

## Data flow of one destruction

```
DestroySheet                employee, quantity, reason, optional note + photo
        │
InventoryActions            the view-model seam
        │
OperationWorkflowService    refuses without a signed-in employee or a required photo
        ├── InventoryRepository.destroy      writes the row + device id + confirmed_at
        ├── NotificationPlanner.cancelForRecord   stops the hourly chase-ups now
        ├── EscalationRepository.resolveForRecord closes the manager alert
        ├── AuditRepository.append           one immutable, hash-chained row
        └── refresh()                        rebuilds the whole schedule
```

## Data flow of one scan

```
CameraCapturePage        takes a still, returns a file path
        │
ScanPipeline             quality check → enhance → barcode → GS1 → OCR → parse
        │                   ↳ auto-crop retry when the first OCR pass finds no date
ScanFlowController       merges sources, records where each field came from
        │
InventoryRepository      resolves product, asks the policy engine, writes the row
        │
ExpiryPolicyEngine       shelf life → matching rule → lead time → destroy instant
        │
SQLite                   inventory_records + record_events + sync_outbox
        │
NotificationPlanner      recomputes the whole reminder schedule
```

## Reactivity

`AppDatabase.write` emits the names of the tables it touched on a broadcast
stream. `inventoryChangesProvider`, `catalogChangesProvider`,
`locationChangesProvider` and `activePolicyProvider` listen to it, and the
screens watch those. Destroying a lot therefore removes it from the task list,
updates the dashboard and reschedules the reminders without any manual refresh.

## Offline-first

Every write lands in SQLite first and is appended to `sync_outbox` in the same
transaction. `SyncEngine` drains that queue whenever a `RemoteSyncGateway`
reports itself reachable. This build ships `UnconfiguredRemoteGateway`, which
accepts nothing and says so; see `SYNC_CONTRACT.md` for adding a real backend.

## Time

Nothing calls `DateTime.now()` outside `SystemClock`. Every service takes a
`Clock`, so the policy engine, the planner and the reports are deterministic
under test.

## Testing

| Suite | What it pins down |
|---|---|
| `expiry_policy_engine_test.dart` | Each default band, both inclusive and exclusive boundaries, a sweep proving the shelf-life axis has no gap or overlap, the priority colours, and the safety rails. |
| `label_text_parser_test.dart` | Vietnamese, English and CJK label formats, day/month ambiguity, compact digits, month-only dates, batch codes, and every warning. |
| `gs1_parser_test.dart` | Fixed and variable-length application identifiers, FNC1 separators, the century rule, and malformed input. |
| `image_quality_test.dart` | Laplacian focus measure, exposure detection, contrast stretch, unsharp mask, cropping, and corrupt bytes. |
| `inventory_repository_test.dart` | The real SQLite stack: intake, partial and full destruction, overdue detection, loss pricing, the daily list, summaries, policy recalculation, and search. |
| `daily_plan_and_insights_test.dart` | Task ordering and grouping, the Wilson lower bound, ranking, routing, and the two halves of the forecast. |
| `notifications_and_auth_test.dart` | Quiet hours, notification ids, digest wording in both languages, lead times, the schedule cap, PBKDF2, and role permissions. |
| `localization_test.dart` | Key parity and placeholder parity between the two languages, plus every formatter. |
| `app_smoke_test.dart` | The whole widget tree: first-run setup, sign-in, the shell, and the empty states. |
| `operation_workflow_test.dart` | The escalation engine's every branch, `raiseDue` idempotency, destroy confirmation (refusals, device stamping, partial confirmation, reminder cancellation, escalation closure, the audit row), manager decisions, and repeat-safe `refresh()`. |
| `audit_trail_test.dart` | The hash chain, `verifyChain` locating a forged row, and the SQLite triggers actually refusing a real UPDATE and DELETE. |
| `migration_test.dart` | A real v1 database file with real rows, reopened at the current version: the Phase X tables and triggers arrive, the old rows survive, and an upgraded schema is byte-for-byte the same set of tables, indexes and triggers as a fresh install. |
| `workflow_screens_test.dart` | Each Phase X screen mounted against the real stack, so a screen that would crash or render blank on a phone fails here first. |
| `report_export_test.dart` | All three renderers (HTML escaping, CSV quoting, real PDF bytes), the unconfigured Google Docs gateway failing honestly, all six templates built from empty input without inventing a row, and the full path from a real destruction to a file on disk. |

Run everything with `flutter test`. The suite uses `sqflite_common_ffi`, so it
exercises the real database engine rather than a mock.
