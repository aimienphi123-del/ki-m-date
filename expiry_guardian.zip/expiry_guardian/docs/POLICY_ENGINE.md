# The expiry policy engine

The engine answers one question: **given a lot of stock, when must it leave the
shelf?** Nothing about the answer is compiled into the app.

## The data model

```
policies
  basis                            manufacturingToExpiry | intakeToExpiry
  fallback_to_intake_basis         use the receipt date when no MFG is printed
  date_expiry_at_end_of_day        "20/12" means good through 20 December
  normalize_destroy_time_minutes   optional: snap to a fixed time of day
  fallback_lead_minutes            used when no rule matches
  destroy_soon_window_minutes      the orange band (default 24 h)
  approaching_window_minutes       the yellow band (default 72 h)
  version                          bumped on every edit

policy_rules
  sort_order                       evaluation order, first match wins
  min_minutes / min_inclusive      lower bound of the shelf-life band
  max_minutes / max_inclusive      upper bound
  matches_hourly                   also capture every hourly-expiry product
  lead_minutes                     destroy this long before expiry
  is_active
```

Both bounds carry their own inclusivity flag. That is what lets the shipped
handbook be expressed exactly, without rounding:

| # | Band | Bounds | Lead |
|---|---|---|---|
| 1 | Hourly goods **or** shelf life ≤ 7 days | `[0 min, 7 d]` + hourly flag | 2 hours |
| 2 | Over 7 days, under 1 month | `(7 d, 30 d)` | 1 day |
| 3 | 1 month to under 6 months | `[30 d, 180 d)` | 3 days |
| 4 | 6 months to under 1 year | `[180 d, 365 d)` | 5 days |
| 5 | 1 year to under 3 years | `[365 d, 1095 d)` | 7 days |
| 6 | 3 years or more | `[1095 d, ∞)` | 1 month |

These rows are written to the database on first launch by
`DefaultPolicyFactory` and are ordinary editable rows from that moment on. The
factory is never read again.

## Evaluation

```
expiryInstant = precision == hour
                  ? the printed date-time
                  : dateExpiryAtEndOfDay ? end of the printed day
                                         : start of the printed day

shelfLife     = expiryInstant − (basis == manufacturingToExpiry
                                   ? manufacturingDate ?? receiptDate
                                   : receiptDate)          // clamped at zero

rule          = first active rule, by sort_order, where
                  (matchesHourly && precision == hour) || bounds contain shelfLife

destroyAt     = expiryInstant − (rule?.leadTime ?? policy.fallbackLeadTime)
                then optionally snapped to normalize_destroy_time_minutes
                then clamped so destroyAt ≤ expiryInstant
```

Two rails are unconditional:

- **A destroy instant is never after the expiry instant.** A misconfigured
  negative lead time cannot put goods on the shelf past their expiry.
- **Snapping never moves a destroy instant later.** If the fixed time of day
  would push it past the computed deadline, the previous day is used instead.

## Why shelf life, not remaining days

The handbook says "products with a three-year shelf life are destroyed one
month early". That is a statement about the product's *designed* life, not
about how much time happens to be left on the day it is scanned. Measuring
`expiry − manufacturing` is what makes a nearly-expired three-year product
still fall in the three-year band.

When the label carries no manufacturing date — common on imports — the engine
falls back to `expiry − goods receipt`, and records in `basis_used` which one
it applied. A manager can switch the fallback off.

## Priority

Computed live at query time, never stored, so the phone can be off for a week
and the colours are still right:

```
expired      now > expiryInstant
destroyNow   now ≥ destroyAt
destroySoon  destroyAt − now ≤ destroySoonWindow      (default 24 h)
approaching  destroyAt − now ≤ approachingWindow      (default 72 h)
safe         otherwise
```

Sort weight puts `destroyNow` before `expired`: an expired lot is a breach to
record, but a lot that is due right now is the one an employee must walk to.

## Auditability

Every inventory record stores the decision that produced it — `policy_id`,
`policy_version`, `policy_rule_id`, `lead_time_minutes`, `shelf_life_minutes`,
`expiry_instant`, `destroy_at` — and the `created` event stores the rule name
and whether the fallback was used. Months later the app can still explain why
a given carton had to go on a given morning.

## Editing the handbook

`PolicyValidator` runs on every edit and reports:

- no active rules;
- a negative lead time;
- an inverted band (`min > max`);
- a **coverage gap** — a shelf-life value no rule claims;
- **overlapping rules** — two rules claiming the same value;
- no catch-all for very long shelf lives;
- a lead time longer than the band it belongs to.

It finds these by probing every boundary ±1 minute, so a gap of a single
minute between two bands is caught before it can silently route stock to the
fallback lead time.

Saving bumps `policies.version`. **Apply to stock already on the shelves**
re-runs the engine over every open lot, writes a `policyRecalculated` event on
each one that moved, and reschedules the reminders.

## The destruction calculator

Employees were already doing this arithmetic several times a shift - on paper,
in their heads, or on a separate web calculator kept on a phone - and getting
it wrong in either direction costs money: too early bins saleable stock, too
late leaves expired stock on the shelf. `DisposalCalculatorPage` brings it
inside the app.

It answers three shapes of question:

| What the employee knows | What it works out |
| --- | --- |
| The production date and the printed expiry | The span, the band, the destroy deadline |
| The printed expiry and the stated shelf life | The production date, then the deadline |
| The production date and the stated shelf life | The expiry, then the deadline |

### It is not a second copy of the handbook

`ShelfLifeCalculator` reads every threshold and every lead time out of the
active `DestroyPolicy` rows and classifies with `PolicyRule.containsShelfLife`
- the same predicate the live engine uses - under the same end-of-day
convention for date-only labels. Halve the lead times in the policy and the
calculator halves with them; there is a test that does exactly that. Two sets
of numbers that could drift apart is the one thing this must never become, and
a test also asserts the calculator and `DefaultExpiryPolicyEngine` agree on the
destroy instant across seven different shelf lives.

It departs from the live engine in exactly two deliberate ways:

* **A typed clock time does not make goods hourly.** Only the SOP switch does.
  Otherwise entering "22:00" on a two-year tin would quietly pull it from the
  seven-day band into the two-hour one.
* **`normalizeDestroyTimeMinutes` is not applied.** That setting stabilises the
  real morning worklist; a what-if answer should show the raw handbook instant.

### Stated months are nominal, derived dates are calendar-correct

A packet that says "1 month" belongs in the one-month band whether it was made
in February or in July. February supplies 28 real days, which is short of the
30-day threshold, so classifying by elapsed days would apply the
under-a-month rule to a product whose label is perfectly clear. The band is
therefore chosen by the *nominal* span (30.4167 days to the month, matching the
shop's own calculator), while the derived date uses real calendar arithmetic.

`ShelfLifeCalculator.addCalendarMonths` clamps to the end of the target month:
one month after 31 January is 28 February, because `DateTime(2027, 2, 31)`
silently becomes 3 March in Dart and a destroy date in the wrong month is not
something an employee can explain to an auditor. Years clamp the same way, so a
year after 29 February is 28 February rather than 1 March.

### Where it refuses to answer

Given an expiry and nothing else, the calculator reports the expiry and says it
cannot work out a destroy time. The web calculator this replaces treats an
unknown shelf life as zero days and confidently answers "two hours" - a wrong
number on a safety-critical field. Saying so and pointing at the shelf-life
mode is the honest behaviour; the app never invents a figure it did not derive.
