# Hướng dẫn chạy Expiry Guardian trên điện thoại

> **Nếu bạn đã có sẵn file `.apk` tôi gửi:** bỏ qua Phần A và B, nhảy thẳng
> xuống **Phần C — Cài lên điện thoại**. Toàn bộ phần build đã làm xong.
>
> Phần A và B dành cho lúc bạn muốn **tự dựng lại** sau khi sửa mã nguồn.

Từ file `expiry_guardian.zip` đến app chạy được trên điện thoại Android.
**Không cần cài phần mềm gì lên máy tính.** Toàn bộ phần "build" chạy trên máy
chủ của GitHub, miễn phí.

Làm một lần mất khoảng **30–40 phút**, trong đó **20 phút là ngồi chờ máy chủ
build**. Những lần sau chỉ mất 15 phút.

---

## Trước khi bắt đầu

**Cần có:**

- Một máy tính có trình duyệt (quán net là đủ — không cài gì cả)
- Một email để đăng ký GitHub
- Điện thoại Android **7.0 trở lên**, có camera sau
- Hai file tôi gửi:
  - `expiry_guardian.zip` — toàn bộ mã nguồn
  - `build-apk.yml` — file hướng dẫn máy chủ GitHub cách build

**Chưa cần:** tài khoản Google Play, thẻ tín dụng, máy Mac, Android Studio.

> **Đọc kỹ chỗ này trước:** bản này chạy **hoàn toàn offline**. Dữ liệu nằm
> trong từng máy điện thoại và **hai máy không chia sẻ dữ liệu với nhau**. Nếu
> cửa hàng có 3 nhân viên cùng cài, sẽ có 3 kho dữ liệu riêng biệt.
>
> Cách dùng đúng cho lúc này: **dùng một máy chung của cửa hàng** (máy ở quầy),
> mọi người đăng nhập bằng tài khoản riêng trên cùng máy đó. Như vậy nhật ký
> kiểm toán mới ghi đúng ai làm gì, và cảnh báo quản lý mới đến đúng chỗ.

---

# PHẦN A — Đưa mã nguồn lên GitHub (làm ở quán net)

## A1. Tải hai file về máy tính

Mở Google Drive → tải `expiry_guardian.zip` và `build-apk.yml` về.

**Không cần giải nén file zip.** Cứ để nguyên.

## A2. Tạo tài khoản GitHub

1. Mở **github.com** → bấm **Sign up**
2. Nhập email, đặt mật khẩu, đặt tên tài khoản (chữ không dấu, ví dụ
   `cuahang-nguyentrai`)
3. Xác nhận mã gửi về email

Nếu đã có tài khoản thì bấm **Sign in**.

> Quán net hay bị đóng băng, khởi động lại là mất hết. **Ghi lại email, tên tài
> khoản và mật khẩu GitHub ra giấy hoặc ghi chú trong điện thoại** trước khi
> làm tiếp. Lần sau muốn build lại chỉ cần đăng nhập, không phải làm lại từ đầu.

## A3. Tạo kho chứa (repository)

1. Góc trên bên phải → bấm dấu **+** → **New repository**
2. **Repository name**: gõ `expiry-guardian`
3. Chọn **Private** (kho riêng tư — chỉ mình bạn thấy)
4. Tick vào ô **Add a README file**
5. Bấm **Create repository**

> Vì sao chọn Private: kho riêng tư được **2.000 phút build miễn phí mỗi tháng**
> — mỗi lần build tốn khoảng 15 phút, tức là hơn 100 lần build/tháng, dư sức
> dùng. Chọn Public thì build không giới hạn nhưng ai cũng xem được mã nguồn và
> **khoá ký app** nằm trong đó (xem phần *Câu hỏi thường gặp*).

## A4. Tải file zip lên

1. Ở trang kho vừa tạo, bấm nút **Add file** → **Upload files**
2. Kéo file `expiry_guardian.zip` từ máy tính thả vào khung
3. Chờ thanh chạy xong, kéo xuống dưới bấm **Commit changes**

> **Vì sao tải nguyên file zip mà không giải nén ra?** Trang web GitHub chỉ cho
> tải lên **tối đa 100 file một lần** ("Yowza, that's a lot of files"), mà dự án
> này có hơn 200 file. Máy chủ build đã được viết để tự giải nén giúp bạn, nên
> chỉ cần kéo đúng **một** file zip.

## A5. Dán file build

1. Bấm tab **Actions** (ở hàng trên cùng: Code · Issues · Pull requests ·
   **Actions** · …)
2. Bấm dòng chữ nhỏ **"set up a workflow yourself"**
3. Màn hình soạn thảo hiện ra với sẵn một đoạn mẫu — **xoá sạch nó đi**
   (bấm vào vùng soạn thảo, `Ctrl + A`, rồi `Delete`)
4. Mở file `build-apk.yml` bằng **Notepad** (chuột phải vào file →
   Open with → Notepad) → `Ctrl + A` → `Ctrl + C`
5. Quay lại trình duyệt, bấm vào vùng soạn thảo → `Ctrl + V`
6. Bấm nút xanh **Commit changes…** → **Commit changes**

**Xong phần máy tính.** Máy chủ GitHub bắt đầu build ngay lập tức.

> Thứ tự quan trọng: phải tải zip lên **trước**, dán file build **sau**. Nếu lỡ
> làm ngược lại, lần build đầu sẽ báo đỏ — không sao, xem mục *Chạy lại* ở
> phần Sự cố.

## A6. Chờ build

Tab **Actions** → bạn thấy một dòng đang chạy (vòng tròn vàng quay).

| Dấu hiệu | Nghĩa là |
|---|---|
| 🟡 Vòng tròn vàng | Đang chạy — chờ tiếp |
| ✅ Dấu tick xanh | Xong, có file APK |
| ❌ Dấu X đỏ | Lỗi — xem phần *Sự cố* |

Máy chủ làm hai việc: **kiểm tra mã nguồn** (phân tích + chạy 236 bài kiểm thử,
~5 phút), rồi **build APK** (~10–15 phút). Tổng khoảng 15–20 phút.

Có thể tắt trình duyệt, đi làm việc khác. Build vẫn chạy trên máy chủ.

---

# PHẦN B — Lấy file APK về điện thoại

Có hai cách. **Cách 1 dễ hơn nhiều nếu bạn dùng điện thoại.**

## Cách 1 — Tạo bản phát hành (khuyên dùng)

Cách này cho ra một **đường tải thẳng file APK**, không phải giải nén gì cả.
Làm được cả trên điện thoại.

1. Vào trang chính của kho (tab **Code**)
2. Cột bên phải, tìm mục **Releases** → bấm **Create a new release**
   *(Trên điện thoại: cuộn xuống dưới cùng mới thấy)*
3. Ô **Choose a tag** → gõ `v1.0.0` → bấm dòng **+ Create new tag: v1.0.0 on publish**
4. Ô **Release title** → gõ `Phiên bản 1.0`
5. Bấm **Publish release**

Việc này chạy build thêm một lần nữa (~15–20 phút). Khi xong, quay lại trang
release đó và **tải lại trang** — sẽ thấy file `app-release.apk` ở mục **Assets**.

6. Trên điện thoại: mở **github.com** bằng Chrome → đăng nhập → vào kho →
   **Releases** → `v1.0.0` → chạm vào **app-release.apk** → **Tải xuống**

## Cách 2 — Tải từ tab Actions

1. Tab **Actions** → bấm vào lần chạy mới nhất có ✅
2. Cuộn xuống dưới cùng, mục **Artifacts** → bấm **expiry-guardian-apk**
3. File tải về là một **file .zip**, phải giải nén mới lấy được APK
   - Trên máy tính: chuột phải → **Extract All**
   - Trên điện thoại: mở app **Files** (Google) → tìm file zip → chạm →
     **Extract**

Bên trong có:

| File | Dùng khi nào |
|---|---|
| **`app-arm64-v8a-release.apk`** | **Dùng cái này** — 43 MB, chạy trên hầu hết máy từ 2018 trở lại đây |
| `app-release.apk` | 113 MB, chạy được trên **mọi** máy. Dùng khi bản arm64 báo lỗi |
| `app-armeabi-v7a-release.apk` | Cho máy cũ 32-bit |
| `app-x86_64-release.apk` | Cho máy ảo, không dùng cho điện thoại thật |

Không chắc thì cứ dùng `app-release.apk` (bản chạy trên mọi máy).

> **Chọn một loại rồi dùng mãi loại đó.** Bản arm64 mang số hiệu phiên bản cao
> hơn bản universal, nên nếu đã cài arm64 thì sau này cài đè bản universal sẽ bị
> Android từ chối ("không cài đặt được"). Muốn đổi loại thì phải gỡ app —
> mất dữ liệu. Cứ giữ nguyên một loại là không bao giờ gặp chuyện này.

---

# PHẦN C — Cài lên điện thoại

## C1. Cho phép cài app ngoài Play Store

Chạm vào file APK vừa tải. Android sẽ chặn lần đầu:

> *"Vì lý do bảo mật, điện thoại của bạn không được phép cài đặt ứng dụng không
> xác định từ nguồn này."*

Đây là chuyện bình thường với app tự build. Làm như sau:

1. Bấm **Cài đặt** trong hộp thoại đó
2. Bật **Cho phép từ nguồn này** (cho Chrome, hoặc cho Files — tuỳ bạn mở file
   từ app nào)
3. Bấm nút **Quay lại**
4. Bấm **Cài đặt**

## C2. Nếu Play Protect cảnh báo

Có thể hiện: *"Ứng dụng không an toàn"* hoặc *"Google Play Protect không nhận
ra nhà phát triển này"*.

Bấm **Vẫn cài đặt** (hoặc **Cài đặt dù sao**). Google chỉ đang nói rằng app này
không tải từ Play Store — đúng vậy, vì đây là app riêng của cửa hàng bạn.

## C3. Xong

Biểu tượng **Expiry Guardian** xuất hiện trong danh sách app.

---

# PHẦN D — Lần chạy đầu tiên

## D1. Tạo tài khoản quản trị

Mở app → màn hình **"Tạo tài khoản quản trị"**:

| Ô | Điền gì |
|---|---|
| Tên hiển thị | Tên thật, ví dụ `Chị Lan` — tên này in trên báo cáo và nhật ký |
| Tên đăng nhập | Chữ không dấu, không cách, ví dụ `chilan` |
| Mật khẩu | Ít nhất 4 ký tự |
| Nhập lại mật khẩu | Gõ lại y hệt |

Bấm **Tạo tài khoản**. Bạn vào thẳng màn hình **Hôm nay** — đang trống vì chưa
có hàng nào.

> Ghi lại tên đăng nhập và mật khẩu. **Không có chức năng quên mật khẩu** —
> app chạy offline, không có máy chủ nào để gửi mail khôi phục.

## D2. Cấp quyền (quan trọng — không làm thì không nhắc được)

### Quyền thông báo

Android 13 trở lên sẽ tự hỏi ngay lần đầu mở app → bấm **Cho phép**.

Nếu lỡ bấm từ chối: **Cài đặt điện thoại → Ứng dụng → Expiry Guardian →
Thông báo → Bật**.

### Quyền báo thức chính xác (Android 12 trở lên)

Không có quyền này, thông báo sẽ đến trễ vài chục phút — với hàng huỷ theo giờ
là quá muộn.

Trong app: **Khác → Cài đặt → Thông báo** → có sẵn nút cấp quyền ở đầu màn
hình → bấm → bật **Cho phép đặt chuông báo và lời nhắc**.

### Quyền camera

App hỏi lần đầu bạn bấm quét → **Cho phép**.

### ⚠️ Tắt tối ưu pin (bước hay bị bỏ sót nhất)

Điện thoại Android hay tự "ngủ đông" app để tiết kiệm pin — và như vậy là **mất
thông báo nhắc huỷ hàng**. Bắt buộc phải tắt cho app này:

| Hãng máy | Đường đi |
|---|---|
| **Xiaomi / Redmi / POCO** | Cài đặt → Ứng dụng → Quản lý ứng dụng → Expiry Guardian → **Tiết kiệm pin → Không giới hạn**. Rồi vào phần **Tự khởi chạy → Bật**. |
| **Oppo / Realme / OnePlus** | Cài đặt → Pin → Tối ưu hoá pin → Expiry Guardian → **Không tối ưu hoá**. Thêm: Cài đặt → Ứng dụng → Expiry Guardian → **Cho phép chạy nền**. |
| **Vivo** | Cài đặt → Pin → Mức tiêu thụ nền cao → bật cho Expiry Guardian. |
| **Samsung** | Cài đặt → Pin → Giới hạn sử dụng nền → **Ứng dụng không bao giờ ngủ** → thêm Expiry Guardian. |
| **Huawei / Honor** | Cài đặt → Pin → Khởi chạy ứng dụng → Expiry Guardian → chuyển sang **Quản lý thủ công**, bật cả 3 mục. |
| **Android gốc (Pixel, Nokia, Motorola)** | Cài đặt → Ứng dụng → Expiry Guardian → Pin → **Không hạn chế**. |

## D3. Khai báo cửa hàng

**Khác → Cài đặt → Chung:**

| Mục | Ví dụ | Dùng để làm gì |
|---|---|---|
| Tên cửa hàng | `Cửa hàng Nguyễn Trãi` | In trên đầu mọi báo cáo |
| Tên công ty | `Công ty TNHH ABC` | In trên đầu mọi báo cáo |
| Mã cửa hàng | `NT-01` | In trên đầu mọi báo cáo |
| Ký hiệu tiền | `₫` | Hiển thị số tiền thiệt hại |

**Khác → Cài đặt → Thiết bị này:** đặt tên máy, ví dụ `Máy quầy 1`. Tên này
xuất hiện trong nhật ký kiểm toán để phân biệt các máy.

## D4. Tạo khu vực và kệ

**Khác → Khu vực & kệ** → thêm khu vực (`Quầy lạnh`, `Kệ khô`, `Quầy bánh`),
rồi thêm kệ trong từng khu vực (`A1`, `A2`, `B1`…).

Danh sách huỷ mỗi sáng sắp theo thứ tự khu vực → kệ, nên đặt đúng thứ tự đi
trong cửa hàng thì nhân viên đi một vòng là xong.

## D5. Quét thử một sản phẩm

1. Tab **Quét** → chĩa camera vào mã vạch
2. Mã lạ chưa có trong danh mục → app hỏi tên sản phẩm → nhập một lần, lần sau
   nó tự nhớ
3. Chụp chỗ in hạn sử dụng → app tự đọc ngày
4. Chọn kệ, nhập số lượng → **Lưu**

Sang tab **Tồn kho** sẽ thấy lô hàng vừa nhập, kèm ngày phải huỷ mà app tự tính
theo chính sách.

---

# PHẦN E — Kiểm tra app chạy đúng (5 phút)

Làm nhanh 5 việc này để chắc chắn mọi thứ ổn trước khi giao cho nhân viên:

| # | Làm gì | Phải thấy gì |
|---|---|---|
| 1 | Quét một sản phẩm, đặt hạn sử dụng là **ngày mai** | Tab **Hôm nay** hiện sản phẩm đó, ô màu **đỏ** hoặc **cam** |
| 2 | Bấm **Đã huỷ** trên sản phẩm đó → **Xác nhận đã huỷ** | Hiện dòng *"Đã huỷ … Đã huỷ N lượt nhắc còn lại"* |
| 3 | Khác → **Nhật ký kiểm toán** | Có dòng **"Xác nhận đã huỷ"** ghi tên bạn và tên máy |
| 4 | Ở màn hình đó bấm biểu tượng **khiên** (góc trên phải) | *"Nhật ký nguyên vẹn: đã kiểm tra N bản ghi"* |
| 5 | Khác → **Xuất báo cáo** → mẫu *Báo cáo huỷ hàng ngày* → **File PDF** → **Tạo báo cáo** | Bảng chia sẻ hiện ra; mở file thấy tiếng Việt **có dấu đầy đủ** |

Nếu cả 5 việc đều đúng thì app đã chạy hoàn chỉnh.

---

# PHẦN F — Cài cho máy khác

Gửi thẳng file `app-release.apk` cho máy kia — qua **Zalo**, email, Bluetooth
hoặc cáp USB. Không cần build lại.

Máy nhận cũng phải làm **Phần C** (cho phép cài từ nguồn không xác định) và
**Phần D2** (cấp quyền + tắt tối ưu pin).

> Nhắc lại điều quan trọng nhất: **mỗi máy có kho dữ liệu riêng, không nối với
> nhau.** Hàng nhập trên máy A không hiện trên máy B. Muốn cả cửa hàng dùng
> chung một kho dữ liệu thì phải nối máy chủ đồng bộ — phần đó đã để sẵn đường
> ráp, xem `docs/SYNC_CONTRACT.md`.

---

# PHẦN G — Cập nhật app về sau

Khi có bản mã nguồn mới:

1. Lên GitHub, vào kho → chạm vào file `expiry_guardian.zip` cũ → biểu tượng
   **thùng rác** → **Commit changes** (xoá file cũ)
2. **Add file → Upload files** → kéo file zip mới vào → **Commit changes**
3. Build tự chạy lại → lấy APK theo Phần B
4. Cài đè lên app cũ — **không cần gỡ, không mất dữ liệu**

> Cài đè được là nhờ mọi bản build đều ký bằng **cùng một khoá** nằm sẵn trong
> mã nguồn. Nếu khoá đổi, Android sẽ báo *"Không cài đặt được ứng dụng"* và
> cách duy nhất là gỡ app — **mất sạch dữ liệu cửa hàng**. Vì vậy đừng xoá
> thư mục `android/keystore/` trong mã nguồn.

---

# PHẦN H — Sự cố thường gặp

## Lúc build trên GitHub

| Triệu chứng | Nguyên nhân | Cách xử lý |
|---|---|---|
| ❌ đỏ, log ghi *"No pubspec.yaml and no .zip"* | Dán file build trước khi tải zip lên | Tải zip lên rồi **chạy lại**: Actions → lần chạy đỏ → **Re-run all jobs** |
| ❌ đỏ ngay bước *Static analysis* hoặc *tests* | File zip tải lên bị hỏng hoặc thiếu | Xoá file zip trên GitHub, tải lại từ Drive rồi upload lại |
| Tab Actions trống, không có gì chạy | Chưa dán file build, hoặc dán sai chỗ | Làm lại bước **A5** |
| *"Yowza, that's a lot of files"* | Đang cố tải cả thư mục đã giải nén | Chỉ tải lên **một file zip**, đừng giải nén |
| Build chạy mãi không xong (>40 phút) | Máy chủ GitHub đang kẹt | Bấm **Cancel workflow** rồi **Re-run all jobs** |

**Chạy lại một lần build:** tab Actions → bấm vào lần chạy đó → góc phải trên
bấm **Re-run all jobs**.

## Lúc cài trên điện thoại

| Triệu chứng | Nguyên nhân | Cách xử lý |
|---|---|---|
| *"Không cài đặt được ứng dụng"* (máy chưa từng có app) | Android quá cũ | Cần Android 7.0 trở lên |
| *"Không cài đặt được ứng dụng"* (máy đang có app cũ) | Bản cũ ký bằng khoá khác | Gỡ app cũ rồi cài lại — **sẽ mất dữ liệu**, nên xuất báo cáo ra file trước |
| *"Gói bị lỗi"* / *"There was a problem parsing the package"* | Tải chưa xong, hoặc chọn nhầm file `x86_64` | Tải lại; dùng `app-release.apk` |
| Không mở được file APK | Chưa giải nén file artifact | Xem Phần B cách 2 |

## Lúc dùng app

| Triệu chứng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Không nhận được thông báo nào | Chưa tắt tối ưu pin | Làm lại **D2** — đây là nguyên nhân số 1 |
| Thông báo đến trễ 15–30 phút | Thiếu quyền báo thức chính xác | Khác → Cài đặt → Thông báo → cấp quyền |
| Camera không đọc được hạn sử dụng | Thiếu sáng, chữ mờ, hoặc nhãn in kiểu lạ | Bật đèn flash trong màn hình quét; nếu vẫn không được thì **nhập tay** — app không đoán bừa ngày tháng |
| Bấm "Đã huỷ" báo lỗi phải đăng nhập | Đã đăng xuất | Đăng nhập lại; mọi lần huỷ đều phải có người đứng tên |
| Không thấy mục **Bảng quản lý** | Đang đăng nhập bằng tài khoản Nhân viên | Đăng nhập bằng tài khoản Quản lý hoặc Quản trị |
| Xuất PDF bị mờ chữ / mất dấu | Không xảy ra — app nhúng sẵn font tiếng Việt | Nếu vẫn gặp, báo lại kèm ảnh chụp |
| Quên mật khẩu quản trị | Không có khôi phục (app chạy offline) | Nếu còn tài khoản Quản trị khác thì dùng nó đổi mật khẩu; nếu không, phải gỡ và cài lại — mất dữ liệu |

---

# PHẦN I — Câu hỏi thường gặp

**App có cần mạng không?**
Không. Quét, tính hạn, nhắc nhở, huỷ hàng, báo cáo, xuất file — tất cả chạy khi
máy để chế độ máy bay. Mạng chỉ cần lúc tải file APK về.

**Tốn tiền không?**
Không. Tài khoản GitHub miễn phí, 2.000 phút build/tháng cho kho riêng tư. Mỗi
lần build khoảng 15 phút.

**App có gửi dữ liệu đi đâu không?**
Không. Không có máy chủ nào để gửi. Danh mục sản phẩm cũng không gọi ra ngoài —
mã vạch lạ thì nhân viên nhập tên một lần rồi máy tự nhớ.

**Mã thiết bị trong nhật ký có phải số IMEI không?**
Không. Đó là một chuỗi ngẫu nhiên app tự sinh lần chạy đầu, chỉ để phân biệt
hai máy với nhau. App không đọc số máy, không nhận dạng được người dùng.

**Vì sao mật khẩu khoá ký app lại nằm ngay trong mã nguồn?**
Vì giấu nó cạnh chính cái khoá mà nó mở thì chỉ là hình thức. Đây là đánh đổi
đúng cho một app cài tay trong nội bộ: giữ kho ở chế độ **Private** thì không
ai ngoài bạn build được bản cập nhật mà điện thoại chịu nhận.

**Gỡ app có mất dữ liệu không?**
Có, mất sạch. Trước khi gỡ hãy vào **Khác → Xuất báo cáo** xuất *Báo cáo tồn
kho* và *Báo cáo kiểm toán* ra file rồi lưu sang Zalo/Drive.

**Muốn nhiều máy dùng chung dữ liệu thì sao?**
Phải nối một máy chủ đồng bộ. Bản này chưa có, nhưng mọi thay đổi đã được xếp
sẵn vào hàng đợi đồng bộ (xem **Cài đặt → Đồng bộ**), nên khi nối máy chủ thì
toàn bộ lịch sử ghi offline sẽ được đẩy lên đúng thứ tự, không mất gì. Chi tiết
kỹ thuật ở `docs/SYNC_CONTRACT.md`.

**Máy iPhone dùng được không?**
Chưa. Bản này chỉ build cho Android. Mã nguồn viết bằng Flutter nên chạy được
trên iOS, nhưng build file cài cho iPhone bắt buộc phải có tài khoản Apple
Developer trả phí và một máy Mac.

---

## Đọc tiếp

| Muốn biết | Đọc file |
|---|---|
| Cách dùng hằng ngày cho nhân viên và quản lý | [`HUONG_DAN_SU_DUNG.md`](HUONG_DAN_SU_DUNG.md) |
| Quy trình nhắc, xác nhận huỷ, báo lên quản lý, nhật ký | [`OPERATION_WORKFLOW.md`](OPERATION_WORKFLOW.md) |
| Cách sửa chính sách huỷ hàng | [`POLICY_ENGINE.md`](POLICY_ENGINE.md) |
| Xuất báo cáo và nối Google Docs sau này | [`EXPORT.md`](EXPORT.md) |
