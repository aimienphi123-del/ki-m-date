# Quy trình vận hành / Operation workflow

Phase X. Bốn tính năng gắn liền nhau: nhắc nhiều mốc → nhân viên xác nhận →
quản lý được báo lên nếu không ai xác nhận → mọi bước đều nằm trong nhật ký
không sửa được.

Tất cả chạy **offline**. Không dịch vụ nền, không máy chủ, không FCM.

---

## 1. Nhắc nhiều mốc (Feature 1)

### Dòng thời gian mặc định

| Mốc | Lệch so với hạn huỷ | `NotificationStageKind` |
| --- | --- | --- |
| Cảnh báo sớm | −2 ngày | `earlyWarning` |
| Nhắc lần cuối | −1 ngày | `finalReminder` |
| Bắt buộc huỷ | đúng lúc tới hạn | `mandatory` |
| Nhắc lại tới khi xác nhận | +1 giờ, lặp mỗi 1 giờ, tối đa 24 lần | `repeatUntilConfirmed` |

**Không mốc nào được viết cứng.** Cả bốn là các dòng trong bảng
`notification_stages`, sửa trong *Cài đặt → Quy trình vận hành → Quy trình nhắc
nhở*: đổi độ lệch, đổi chiều (trước/sau), đổi chu kỳ lặp, đổi số lần tối đa,
tắt từng mốc, thêm mốc mới, hoặc khôi phục mặc định.

### Vì sao chạy được offline

Hạn huỷ của mỗi lô đã được tính sẵn và lưu trong `inventory_records.destroy_at`
ngay lúc nhập hàng. Vì vậy **toàn bộ lịch nhắc là hàm thuần của dữ liệu đã có**:

```dart
NotificationStage.occurrencesFor(destroyAt)
// earlyWarning  → [destroyAt - 2d]
// repeat        → [destroyAt + 1h, +2h, … +24h]
```

`NotificationPlanner.buildPlan` dựng cả lịch rồi giao thẳng cho hệ điều hành
(`flutter_local_notifications` + `AlarmManager`). App có thể bị tắt hẳn, máy có
thể khởi động lại — báo thức vẫn nổ. Mỗi lần khởi động, `refresh()` dựng lại
toàn bộ lịch từ đầu, nên không có trạng thái nào để lệch.

Mã thông báo (`notificationId`) là FNV-1a 31-bit của `giai đoạn|lô|lần lặp`, ổn
định giữa các lần dựng lại — dựng lại thay thế báo thức cũ chứ không nhân đôi.

Giờ yên lặng: nhắc **trước** hạn bị kéo sớm lên trước khung giờ yên lặng (không
bao giờ đẩy qua hạn); nhắc **sau** hạn và tóm tắt buổi sáng bị đẩy lùi sau
khung giờ.

---

## 2. Xác nhận huỷ hàng (Feature 2)

`OperationWorkflowService.confirmDestruction` là **nơi duy nhất** ghi một lần
huỷ. Màn hình không gọi thẳng repository.

Bắt buộc có:

| Trường | Nguồn |
| --- | --- |
| Nhân viên | Người đang đăng nhập — không có thì từ chối (`destroy_needs_signed_in_employee`) |
| Thời điểm | `Clock` tiêm vào, lưu ở `destructions.confirmed_at` |
| Số lượng | Mặc định là toàn bộ phần còn lại; nhập ít hơn thì lô vẫn mở |
| Mã thiết bị | `DeviceIdentity` — id ngẫu nhiên sinh lần chạy đầu, **không đọc số máy** |

Tuỳ chọn: ghi chú, ảnh (quản lý bật "bắt buộc chụp ảnh" thì thành bắt buộc).

Khi lô đóng hẳn, và **chỉ khi đó**, service làm liền một mạch:

1. `NotificationPlanner.cancelForRecord` — huỷ ngay mọi báo thức còn treo của lô
2. `EscalationRepository.resolveForRecord` — đóng cảnh báo quản lý với lý do
   `destroyed`
3. Ghi một dòng nhật ký `destroyConfirmed` (ai, máy nào, bao nhiêu, ghi chú)
4. `refresh()` — dựng lại lịch cho phần còn lại của cửa hàng

Xác nhận một phần thì lô vẫn mở và nhắc vẫn chạy — đúng như thực tế trên kệ.

---

## 3. Báo lên quản lý (Feature 3)

Quy tắc mặc định: **quá hạn huỷ 24 giờ mà chưa ai xác nhận → báo quản lý, mức
nghiêm trọng, nhắc lại mỗi 12 giờ tối đa 4 lần.** Sửa trong *Bảng quản lý →
Quy tắc báo lên*: độ trễ, vai trò được báo, mức nghiêm trọng, chu kỳ và số lần
nhắc lại; thêm cấp 2, cấp 3 tuỳ ý; tắt hẳn bằng một công tắc.

`EscalationEngine` là hàm thuần — không đọc cơ sở dữ liệu, không gọi hệ điều
hành — nên mọi nhánh đều được test.

**Idempotent:** `raiseDue()` chạy bao nhiêu lần cũng chỉ tạo một cảnh báo cho
mỗi `(lô, cấp)`, nhờ chỉ mục duy nhất trên `escalations(record_id, level)`. Vì
vậy cảnh báo được **suy ra từ dữ liệu**, không phải từ một hàng đợi có thể mất:
máy tắt ba ngày, bật lên là ba ngày cảnh báo hiện đủ.

**Một điểm thành thật quan trọng:** thông báo cục bộ chỉ tới được chính máy đặt
lịch. Nên `EscalationEngine.notifications` chỉ sinh cảnh báo khi **người đang
đăng nhập trên máy này thực sự giữ vai trò** mà quy tắc nêu. Máy của nhân viên
không kêu vì cảnh báo dành cho quản lý — nó sẽ chỉ là tiếng ồn, không phải sự
giám sát. Còn bản thân cảnh báo thì vẫn được tạo và vẫn nằm trong Bảng quản lý,
nên khi quản lý mở app là thấy.

Quản lý có hai cách đóng:

- **Tiếp nhận** (`acknowledged`) — tôi đã biết và đang xử lý
- **Xử lý thay** (`managerOverride`) — đóng mà không huỷ hàng; **bắt buộc ghi
  lý do**, và cả quyết định lẫn lý do vào thẳng nhật ký kiểm toán

---

## 4. Nhật ký kiểm toán (Feature 4)

31 loại thao tác (`AuditAction`), mỗi dòng lưu: thời điểm, người thực hiện, vai
trò, thiết bị, đối tượng, nhãn đối tượng, **giá trị cũ**, **giá trị mới**, ảnh
và ghi chú tuỳ chọn.

### Không sửa được — bằng hai lớp

**Lớp 1 — chuỗi băm.** Mỗi dòng mang `previous_hash` (băm của dòng trước) và
`hash` = `SHA-256(previous_hash + nội dung dòng này)`. Dòng đầu tiên bắt đầu từ
64 số 0. Sửa một ký tự ở giữa là mọi băm từ đó về sau sai — `verifyChain()`
duyệt lại toàn bộ và chỉ ra **đúng vị trí** đầu tiên bị gãy.

**Lớp 2 — trigger SQLite.**

```sql
CREATE TRIGGER audit_log_is_append_only_update
BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
```

Cùng một trigger cho `DELETE`. Kể cả mở file `.db` bằng công cụ ngoài và chạy
SQL tay thì cũng bị chặn.

**Lớp 3 — kiểu dữ liệu.** `AuditRepository` **không có** phương thức nào để sửa
hay xoá. Không phải "không nên"; là không tồn tại để mà gọi.

Nhân viên và quản lý mở nhật ký trong *Cài đặt → Nhật ký kiểm toán*, lọc theo
thao tác, và bấm nút khiên để kiểm tra tính toàn vẹn ngay tại chỗ.

---

## 5. Ai gọi ai

```
Màn hình  ──►  InventoryActions  ──►  OperationWorkflowService
                                            │
              ┌─────────────────────────────┼──────────────────────────┐
              ▼                 ▼           ▼                          ▼
    InventoryRepository  NotificationPlanner  EscalationRepository  AuditRepository
              │                 │                    │                  │
              └─────────────────┴────────────────────┴──────────────────┘
                                     SQLite
```

Không màn hình nào được gọi thẳng `InventoryRepository.destroy`. Nếu có, thì
một lần huỷ có thể được ghi mà báo thức vẫn kêu và cảnh báo vẫn treo — đúng
kiểu lỗi mà một quy trình chỉ có một chủ sở hữu sẽ không bao giờ mắc.

---

## 6. Bảng dữ liệu (migration v2)

| Bảng | Vai trò |
| --- | --- |
| `notification_stages` | Bốn mốc nhắc, sửa được |
| `escalation_rules` | Quy tắc báo lên, sửa được |
| `escalations` | Cảnh báo đã tạo; UNIQUE(`record_id`, `level`) |
| `audit_log` | Nhật ký chỉ ghi thêm, có trigger chặn UPDATE/DELETE |
| `document_exports` | Lịch sử xuất báo cáo |
| `destructions.device_id`, `.confirmed_at` | Cột thêm cho Feature 2 |

Mọi bảng đều ghi kèm vào `sync_outbox`, nên khi nối máy chủ sau này thì lịch sử
đầy đủ đã có sẵn để đẩy lên.

---

## 7. Kiểm thử

- `test/operation_workflow_test.dart` — `EscalationEngine` (mọi nhánh),
  `raiseDue` idempotent, xác nhận huỷ (từ chối khi chưa đăng nhập, ghi đủ nhân
  viên/máy/thời điểm, xác nhận một phần, dừng nhắc, đóng cảnh báo, ghi nhật ký),
  quyết định của quản lý, `refresh()` chạy lại an toàn.
- `test/audit_trail_test.dart` — chuỗi băm, `verifyChain` phát hiện sửa trộm,
  trigger chặn UPDATE và DELETE thật.
- `test/notifications_and_auth_test.dart` — bốn mốc nổ đúng thời điểm, chu kỳ
  lặp dừng đúng số lần cấu hình.

## Rescheduling is off the employee's tap

Confirming a destruction used to rebuild the whole reminder schedule inside the
tap. Rebuilding registers one operating-system alarm per reminder, and every
registration is a platform call, so a store with several overdue lots turned
one tap into hundreds of round trips - the confirmation sheet sat with a
spinner for many seconds on a cheap handset and looked frozen.

The split now is:

* **Synchronous, inside the tap.** Write the destruction, work out whether the
  lot is fully closed, cancel *this lot's* pending reminders, resolve its
  manager escalations, append the audit row. None of this can be deferred: an
  alarm that fires for stock already destroyed is a real fault, not a delay.
* **Deferred, after the tap.** Re-derive everyone else's alarms. The schedule
  is rebuilt from scratch every time, so a rebuild that lands a moment later
  lands with identical content. `requestRefresh()` queues it and collapses
  overlapping requests into one trailing rebuild; `settleRefresh()` awaits it,
  which startup and the tests use and the UI never needs.

The ceiling on pending alarms is `notifications.maxScheduled`, default 180,
editable in Settings and clamped to 20-450. Android keeps only about 500 exact
alarms per app, and the number is also the worst case length of a rebuild. The
plan is sorted by time before it is truncated, so the alarms that survive are
always the soonest; anything dropped is picked up by the next rebuild long
before it would have fired.
