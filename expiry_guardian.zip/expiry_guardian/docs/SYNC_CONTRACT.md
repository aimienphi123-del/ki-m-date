# Adding a backend later

This build runs fully offline. Nothing about that decision leaks into the
repositories or the UI, so connecting a server later is a matter of
implementing one interface.

## What already happens

Every repository write does two things in the same SQLite transaction:

1. writes the row;
2. appends an entry to `sync_outbox` (`entity`, `entity_id`, `operation`,
   `payload` as JSON, `created_at`, `attempts`, `last_error`, `next_attempt_at`).

`SyncEngine` drains that queue in id order whenever the gateway reports itself
reachable, with exponential back-off per entry. Because the queue is durable
and ordered, months of offline work replay correctly the first time a server
appears.

`Settings → Sync` shows the honest state: which gateway is configured, how many
changes are waiting, when the last successful sync was.

## The one interface to implement

```dart
abstract interface class RemoteSyncGateway {
  String get displayName;
  bool get isConfigured;
  Future<bool> isReachable();
  Future<SyncPushResult> push(List<OutboxEntry> batch);
  Future<List<RemoteChange>> pull({DateTime? since});
}
```

`push` returns which outbox ids the server accepted; anything it rejects stays
queued with a reason and a retry time. `pull` returns what changed elsewhere.

Wire the implementation in one line:

```dart
final Dependencies dependencies = await buildDependencies(
  remoteGateway: SupabaseSyncGateway(client),   // or Firebase, or your own API
);
```

No repository, view model or screen changes.

## Table shapes for a server

The outbox payloads are the row maps produced by the mappers, so a server
schema mirroring these tables can accept them directly:

| Table | Notes |
|---|---|
| `users` | `password_hash` / `password_salt` / `password_iterations` are PBKDF2-HMAC-SHA256. Do not sync these to a shared server unless you intend the same credentials everywhere; prefer server-side auth and treat the local rows as a cache. |
| `store_areas`, `shelves` | `sort_order` is the walking order. |
| `categories`, `products`, `product_barcodes` | The store's own catalog. |
| `inventory_records` | Carries the full policy decision, so a server can re-derive nothing and still audit everything. |
| `record_events` | Append-only audit trail. |
| `destructions` | What the reports read. |
| `policies`, `policy_rules` | Versioned; `version` increments on every edit. |
| `app_settings` | Key/value, JSON-encoded values. |

All timestamps are epoch milliseconds. All ids are UUIDv4 strings generated on
the device, so two shops that were offline at the same time never collide.

## Conflict policy to choose before you connect one

The local store is the writer of record for a device. When you add `pull`,
decide per table:

- `inventory_records`, `destructions`, `record_events` — append-mostly; last
  writer wins on `updated_at` is safe in practice because a lot lives on one
  shelf in one shop.
- `policies` / `policy_rules` — head office should win. Compare `version` and
  take the higher one, then call
  `InventoryRepository.recalculateOpenRecords()` so stock on the shelves picks
  up the new handbook immediately.
- `products`, `categories`, `shelves` — last writer wins on `updated_at`.

## If you use Supabase

The schema in `lib/core/database/migrations.dart` is plain SQL and transfers
almost verbatim to PostgreSQL: change `INTEGER` timestamps to `bigint` (or
`timestamptz` with a conversion in the gateway), and add row-level security
policies keyed on a `store_id` column plus the user's role, mirroring
`RolePermissions` in `lib/features/auth/domain/entities/user_role.dart`.

## If you want push notifications from a server

`NotificationGateway` is already the seam. `LocalNotificationGateway` schedules
everything on the device, which is what makes reminders work offline. A
Firebase Cloud Messaging implementation can sit alongside it for messages that
originate on a server; keep the local one for expiry reminders, because those
must fire whether or not the phone has a network.
