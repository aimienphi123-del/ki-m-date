# Hướng dẫn sử dụng cho cửa hàng

## 1. Lần chạy đầu tiên

1. Mở app → tạo **tài khoản quản trị**. Đây là tài khoản có toàn quyền.
2. Vào **Khác → Khu vực và kệ**, khai báo các khu vực (Quầy lạnh, Kho khô…)
   và các kệ trong từng khu vực.
   - Số **thứ tự** chính là thứ tự bạn đi trong cửa hàng. Số nhỏ đi trước.
     Danh sách huỷ hàng ngày và lộ trình kiểm tra sẽ đi theo thứ tự này.
3. Vào **Khác → Cài đặt → Người dùng**, tạo tài khoản cho nhân viên.
4. Vào **Khác → Chính sách huỷ hàng**, xem lại 6 quy tắc mặc định và sửa nếu
   công ty bạn quy định khác.

## 1b. Cho phép thông báo (làm một lần, rất quan trọng)

Lần đầu mở app, Android sẽ hỏi **"Cho phép Expiry Guardian gửi thông báo?"** -
hãy bấm **Cho phép**. Nếu bấm Từ chối, app vẫn đặt lịch nhắc đầy đủ nhưng
**điện thoại sẽ không hiện gì cả**, và bạn sẽ tưởng là không có hàng nào tới hạn.

Nếu đã bấm Từ chối rồi: màn hình **Hôm nay** sẽ hiện một ô cảnh báo màu vàng
"Điện thoại đang chặn thông báo của app" - bấm **Cấp quyền** ngay trên ô đó.

## 1c. Máy tính hủy hàng (Khác → Máy tính hủy hàng)

Dùng khi cầm một sản phẩm trong tay và cần biết **ngày bắt buộc hủy**, chưa cần
nhập vào kho. Có 2 chế độ:

1. **Nhập cả NSX & HSD** — máy tự tính vòng đời rồi ra ngày hủy.
2. **Nhập 1 mốc + thời hạn** — chỉ có HSD thì lùi ra NSX; chỉ có NSX thì tiến ra
   HSD. Có các nút **+1 +2 +5 +10 +20 +50** cộng dồn như máy tính tiền, bấm
   **Xóa** để về 0.

Hai công tắc:

- **Nhập thêm giờ**: chỉ cần cho hàng tính theo giờ. Tắt thì tính theo ngày.
- **Hàng SOP** (bánh bao, xúc xích…): luôn hủy trước mốc in trên bao bì đúng
  khoảng thời gian của quy tắc hàng theo giờ, **bất kể hạn dài bao lâu**. Bật
  công tắc này thì ô thời hạn mờ đi vì nó không còn ảnh hưởng kết quả.

Máy tính hiện rõ **quy tắc nào đang áp dụng** và **vòng đời bao nhiêu ngày**, để
bạn kiểm tra lại được chứ không phải tin suông một con số.

Số liệu lấy từ **Chính sách hủy hàng** đang áp dụng, nên sửa chính sách thì máy
tính đổi theo — không bao giờ có hai kết quả khác nhau giữa máy tính và lịch
nhắc mà app thật sự chạy.

Tính xong, bấm **Dùng 2 ngày này để nhập hàng** là NSX và HSD được điền sẵn sang
phiếu nhập hàng.

Nếu chỉ có HSD mà không biết thời hạn, máy tính sẽ **nói thẳng là không tính
được** và nhắc bạn nhập thêm — chứ không đoán một con số.

## 2. Nhập hàng (3 chạm)

1. Bấm **Quét**. Camera mở ra và **tự đọc mã vạch** - bạn chỉ cần đưa mã vào
   khung, **không cần bấm gì**. Khung viền chuyển sang **màu xanh** là app đang
   quét; khi đọc được, máy **rung nhẹ** một cái rồi tự chuyển bước.
   - Mã vạch bị nhoè, bị xé hoặc hàng không có mã → bấm nút chụp tròn ở giữa,
     hoặc bấm **Nhập mã bằng tay**.
2. App nhận ra sản phẩm:
   - Nếu mã vạch đã có trong danh mục → chuyển thẳng sang màn hình kiểm tra.
   - Nếu chưa có → nhập tên sản phẩm **một lần**. Từ lần sau app tự nhận ra.
3. Nếu mã vạch có sẵn hạn sử dụng (mã GS1 trên thùng, khay thực phẩm tươi),
   app điền luôn. Nếu không, bấm **Chụp hạn sử dụng** để app đọc chữ trên nhãn.
4. Kiểm tra ngày, số lượng, kệ rồi bấm **Lưu lô hàng**.

Từ lần quét thứ hai trở đi, mã vạch đã biết sẽ **tự điền tên, đơn vị, giá và
kệ hàng**, rồi app **mở luôn camera đọc ngày** vì đó là thứ duy nhất còn thiếu.
Bạn sẽ thấy dòng chữ "Đã nhớ sản phẩm này từ lần trước". Nếu không thích tự
chuyển bước, tắt ở **Khác → Cài đặt → Quét**.

Kệ hàng được ghi nhớ như sau: lần đầu nhập một sản phẩm mới, kệ bạn chọn sẽ
được lưu làm kệ mặc định của sản phẩm đó. Sản phẩm đã có kệ mặc định thì giữ
nguyên - một lần xếp tạm chỗ khác sẽ **không** ghi đè kệ quen.

Bước **Chụp hạn sử dụng** cũng tự đọc như bước mã vạch: đưa dòng ngày vào khung
và giữ yên khoảng một giây, app tự nhận. Nó chỉ dừng khi đọc được **đúng một
ngày**, chứ không dừng ở chữ bất kỳ trên nhãn.

Ở màn hình kiểm tra còn có mục **Ảnh mặt sản phẩm (không bắt buộc)**. Chụp mặt
trước hộp/gói hàng để người ca sau nhìn ảnh là nhận ra đúng lô, khỏi phải dò mã.
Bỏ qua cũng được, không ảnh hưởng gì đến việc lưu.

App **không bao giờ tự bịa ngày**. Nếu không đọc được, app nói rõ và bạn nhập tay.

### Mẹo chụp cho ăn ảnh

- Giữ máy chắc tay: app báo "Ảnh bị mờ" nếu rung.
- Thiếu sáng thì bật đèn pin trong app (biểu tượng đèn góc trên).
- Đưa phần in ngày vào giữa khung, càng gần càng tốt.
- **Chạm vào màn hình ngay chỗ chữ cần đọc** để máy lấy nét đúng vào đó. Ngày
  in nhỏ trên hộp lớn là trường hợp cần mẹo này nhất.
- Quét mã vạch thì cứ giữ mã trong khung khoảng một giây, đừng bấm chụp - để
  máy tự đọc dễ hơn nhiều so với chụp một tấm.

## 3. Mỗi sáng

Mở app → tab **Hôm nay**. Danh sách đã được sắp sẵn theo:

**Mức ưu tiên → Khu vực → Kệ → Sản phẩm**

Cầm điện thoại đi theo danh sách, tới đâu bấm nút **Đã huỷ** tới đó.

### Ý nghĩa màu

| Màu | Nghĩa |
|---|---|
| 🟢 Xanh lá | An toàn, chưa cần làm gì |
| 🟡 Vàng | Sắp đến hạn huỷ (mặc định trong 3 ngày) |
| 🟠 Cam | Phải huỷ trong 24 giờ |
| 🔴 Đỏ | Đã tới hạn huỷ — làm ngay |
| ⚫ Xám | Đã quá hạn sử dụng — vi phạm chính sách |

Mỗi màu đều đi kèm biểu tượng và chữ, nên nhân viên khó phân biệt màu vẫn dùng được.

## 4. Huỷ hàng — và xác nhận

Bấm **Đã huỷ** trên dòng sản phẩm:

- Số lượng mặc định là toàn bộ phần còn lại; giảm xuống nếu chỉ huỷ một phần.
- Chọn lý do (mặc định: theo chính sách hạn dùng).
- Chụp ảnh làm bằng chứng nếu quản lý bật yêu cầu này.
- Bấm **Xác nhận đã huỷ**.

App ghi lại: **ai** huỷ, **lúc mấy giờ**, **trên máy nào**, trễ bao nhiêu phút
so với hạn, thiệt hại bao nhiêu.

> **Phải đăng nhập mới huỷ được.** Không có người xác nhận thì app từ chối —
> một lô hàng bị huỷ mà không ai đứng tên là thứ mà quy trình này không cho phép.

Xác nhận xong, app **dừng ngay** mọi nhắc nhở còn lại của lô đó và **đóng cảnh
báo quản lý** nếu có. Bạn sẽ thấy dòng chữ "Đã huỷ N lượt nhắc còn lại".

Huỷ **một phần** thì lô vẫn còn mở và nhắc nhở vẫn tiếp tục cho phần còn lại —
đúng như thực tế trên kệ.

## 5. Chính sách huỷ hàng (chỉ quản lý)

**Khác → Chính sách huỷ hàng**

Mặc định app đi kèm 6 quy tắc:

| Tuổi thọ sản phẩm | Huỷ trước hạn |
|---|---|
| Hàng theo giờ, hoặc ≤ 7 ngày | 2 giờ |
| Trên 7 ngày, dưới 1 tháng | 1 ngày |
| Từ 1 tháng, dưới 6 tháng | 3 ngày |
| Từ 6 tháng, dưới 1 năm | 5 ngày |
| Từ 1 năm, dưới 3 năm | 7 ngày |
| Từ 3 năm trở lên | 1 tháng |

Mọi con số ở trên đều **sửa được**: mốc trên, mốc dưới, có bao gồm mốc hay
không, thời gian huỷ trước hạn, thứ tự ưu tiên, bật/tắt từng quy tắc. Bạn cũng
có thể thêm quy tắc mới.

Sau khi sửa, bấm **Áp dụng cho hàng đang có** để tính lại hạn huỷ cho toàn bộ
lô hàng đang trên kệ. App ghi lại lịch sử tính lại của từng lô.

Phần **Thử tính** cho phép nhập thử một ngày sản xuất và hạn sử dụng để xem
quy tắc nào được áp dụng, trước khi lưu.

App cũng tự kiểm tra chính sách và cảnh báo nếu có khoảng tuổi thọ bị bỏ sót
hoặc hai quy tắc chồng lấn nhau.

## 6. Nhắc nhở — bốn mốc quanh hạn huỷ

**Khác → Cài đặt → Quy trình vận hành → Quy trình nhắc nhở**

Mỗi lô hàng được nhắc theo bốn mốc:

| Mốc | Khi nào | Nội dung |
|---|---|---|
| Cảnh báo sớm | Trước hạn huỷ **2 ngày** | *"Sữa tươi tại Quầy lạnh · A2 phải huỷ sau 2 ngày nữa."* |
| Nhắc lần cuối | Trước hạn huỷ **1 ngày** | *"…phải huỷ trong 1 ngày."* |
| Bắt buộc huỷ | **Đúng lúc** tới hạn | *"…đã tới hạn huỷ. Hãy huỷ và xác nhận."* |
| Nhắc lại | **Mỗi 1 giờ, tối đa 24 lần** | *"…vẫn chưa được xác nhận huỷ (lần nhắc 3)."* |

Mốc cuối **lặp cho tới khi nhân viên xác nhận đã huỷ**. Xác nhận xong là dừng
ngay lập tức.

Cả bốn mốc đều **sửa được**: đổi thời gian, đổi chiều (trước hay sau hạn), đổi
chu kỳ lặp, đổi số lần tối đa, tắt từng mốc, thêm mốc mới, hoặc bấm **Khôi phục
mốc mặc định**.

Ngoài ra:

- **Tóm tắt buổi sáng**: mỗi sáng vào giờ bạn chọn, ví dụ
  *"Bạn có 17 sản phẩm cần huỷ hôm nay."*
- **Giờ yên lặng**: thông báo rơi vào khung này sẽ được dời — tóm tắt và nhắc
  sau hạn dời ra sau, cảnh báo trước hạn dời lên trước (để không bao giờ báo
  muộn hơn hạn).

Android 12 trở lên cần cấp thêm quyền **"Báo thức và nhắc nhở"** thì mới nhắc
đúng phút. Màn hình Thông báo có nút cấp quyền sẵn.

Nhắc nhở hoạt động **hoàn toàn offline** — không cần mạng, không cần server.
Tắt app, khởi động lại máy, vẫn nhắc đúng giờ.

## 6b. Bảng quản lý — khi không ai xác nhận

**Khác → Bảng quản lý** (chỉ Quản lý và Quản trị)

Quá hạn huỷ **24 giờ** mà chưa ai xác nhận, app tự tạo một cảnh báo cho quản lý,
nhắc lại mỗi 12 giờ tối đa 4 lần. Tab **Khác** hiện số cảnh báo đang chờ ngay
trên biểu tượng.

Với mỗi cảnh báo, quản lý có hai lựa chọn:

- **Đã tiếp nhận** — tôi biết rồi và đang xử lý.
- **Quản lý xử lý thay** — đóng cảnh báo mà không huỷ hàng. **Bắt buộc ghi lý
  do**, và cả quyết định lẫn lý do vào thẳng nhật ký kiểm toán.

Quy tắc sửa trong **Quy tắc báo lên**: độ trễ, báo cho vai trò nào, mức nghiêm
trọng, chu kỳ nhắc lại, số lần. Thêm được cấp 2, cấp 3. Tắt hẳn được bằng một
công tắc.

> Một điểm cần biết: thông báo chỉ tới được **chính chiếc máy** đang có quản lý
> đăng nhập. Máy của nhân viên sẽ không kêu vì cảnh báo dành cho quản lý. Nhưng
> cảnh báo vẫn được tạo và vẫn nằm trong Bảng quản lý, nên quản lý mở app là thấy.

## 6c. Nhật ký kiểm toán

**Khác → Nhật ký kiểm toán** (Quản lý và Quản trị)

Mọi thao tác đều được ghi: tạo lô, quét mã, sửa, chuyển kệ, nhắc huỷ, xác nhận
huỷ, báo lên quản lý, quản lý xử lý thay, sửa chính sách, đổi cài đặt, xuất báo
cáo… Mỗi dòng lưu thời điểm, người làm, thiết bị, giá trị cũ và giá trị mới.

**Không ai sửa hay xoá được nhật ký** — kể cả người viết ra app. Mỗi dòng mang
mã băm của dòng trước, nên chỉ cần sửa một dòng là app phát hiện ra ngay. Bấm
biểu tượng khiên ở góc trên để kiểm tra, app sẽ báo *"Nhật ký nguyên vẹn: đã
kiểm tra N bản ghi"* hoặc chỉ đúng bản ghi bị gãy.

## 7. Báo cáo

Tab **Báo cáo**: xem theo ngày / tuần / tháng.

- Số lô đã huỷ, số lượng, thiệt hại
- Tỷ lệ huỷ đúng hạn
- Ngành hàng, kệ, sản phẩm lãng phí nhất
- Xuất file CSV (mở được bằng Excel) qua nút chia sẻ

Nếu sản phẩm chưa nhập giá vốn, app nói rõ thiệt hại chỉ tính được trên bao
nhiêu lô — không tự đoán giá.

### Xuất báo cáo ra file (Khác → Xuất báo cáo)

Sáu mẫu: **huỷ hàng ngày · tuần · tháng · kiểm toán · tồn kho · hàng quá hạn**.

Ba định dạng:

| Định dạng | Dùng khi |
|---|---|
| **PDF** | Gửi cho cấp trên, in ra ký. Dấu tiếng Việt in đúng. |
| **HTML** | Mở bằng trình duyệt; muốn PDF thì In → Lưu thành PDF. |
| **CSV** | Mở bằng Excel để tự tính thêm. |

Chọn mẫu → chọn kỳ báo cáo → chọn định dạng → **Tạo báo cáo**. Xong là hiện
bảng chia sẻ: gửi qua Zalo, lưu vào Drive, gửi email, hoặc copy qua cáp USB.

Bật/tắt được: kèm phần thống kê, kèm ảnh, kèm ô ký tên. Tên công ty và mã cửa
hàng in trên đầu mỗi báo cáo — điền ở **Cài đặt → Chung**.

Mọi báo cáo đã tạo đều nằm trong danh sách **Báo cáo đã tạo** ở cuối màn hình,
chia sẻ lại lúc nào cũng được.

> **Google Docs** có trong danh sách nhưng bản này **chưa nối** — app nói thẳng
> là chưa cấu hình và không cho bấm, thay vì báo "đã xuất" cho một tài liệu chưa
> từng tồn tại. Ba định dạng file ở trên dùng ngay được, không cần tài khoản,
> không cần mạng.

## 8. Dự báo (tab Khác → Dự báo)

- **Lộ trình kiểm tra gợi ý** — đường đi ngắn nhất theo thứ tự kệ, ưu tiên
  chỗ đang quá hạn.
- **Dự báo lãng phí** — tách làm hai phần rõ ràng:
  - *Chắc chắn*: lấy thẳng từ hạn huỷ đã tính của hàng đang trên kệ.
  - *Ước tính*: ngoại suy từ tốc độ huỷ trung bình trong quá khứ.
- **Kệ hay có hàng quá hạn**, **ngành hàng rủi ro cao**, **sản phẩm hay bị quên**.

Khi cửa hàng chưa đủ dữ liệu, app **nói thẳng là chưa đủ** thay vì đưa ra con
số vô nghĩa. Xếp hạng dùng cận dưới khoảng tin cậy 95%, nên một kệ xui xẻo vài
lô không bị đội lên đầu bảng.

## 9. Phân quyền

| | Nhân viên | Quản lý | Quản trị |
|---|:---:|:---:|:---:|
| Quét hàng, xem tồn kho, huỷ hàng | ✅ | ✅ | ✅ |
| Điều chỉnh số lượng, chuyển kệ | | ✅ | ✅ |
| Sửa danh mục, khu vực, kệ | | ✅ | ✅ |
| Sửa chính sách huỷ hàng | | ✅ | ✅ |
| Xem và xuất báo cáo | | ✅ | ✅ |
| Bảng quản lý: tiếp nhận, xử lý thay cảnh báo | | ✅ | ✅ |
| Xem nhật ký kiểm toán | | ✅ | ✅ |
| Quản lý người dùng, cài đặt hệ thống | | | ✅ |
| Xoá toàn bộ dữ liệu vận hành | | | ✅ |

## 10. Dữ liệu để ở đâu

Toàn bộ dữ liệu nằm trong máy điện thoại (SQLite). App chạy được khi hoàn
toàn không có mạng. Báo cáo xuất ra nằm trong thư mục tài liệu của app
(`expiry_guardian/reports`) — chia sẻ ra ngoài bằng nút Chia sẻ.

Mỗi máy có một **mã thiết bị** riêng, sinh ngẫu nhiên lần chạy đầu (không đọc
số máy, không nhận dạng được người dùng). Mã này xuất hiện trong nhật ký kiểm
toán để phân biệt hai máy. Đặt tên dễ nhớ ở **Cài đặt → Thiết bị này**, ví dụ
"Máy quầy 1".

Mọi thay đổi đồng thời được xếp vào hàng đợi đồng bộ. Bản này chưa nối máy
chủ nên hàng đợi chỉ nằm chờ — xem ở **Cài đặt → Đồng bộ**. Khi nào nối máy
chủ, toàn bộ những thay đổi đã ghi offline sẽ được đẩy lên theo đúng thứ tự,
không mất gì.
