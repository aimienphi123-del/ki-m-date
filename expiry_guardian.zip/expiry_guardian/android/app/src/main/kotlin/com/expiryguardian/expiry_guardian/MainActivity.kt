package com.expiryguardian.expiry_guardian

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
