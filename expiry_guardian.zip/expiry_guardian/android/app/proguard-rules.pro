# R8 rules for Expiry Guardian.
#
# google_mlkit_text_recognition declares every script recognizer as compileOnly
# and lets the app pick which ones to ship. This app ships Latin (Vietnamese and
# English labels) and Chinese (imported goods), which are real dependencies in
# build.gradle.kts. The three scripts below are not shipped, and the plugin's
# Java code still references them, so R8 has to be told they are absent on
# purpose - otherwise the release build fails outright.
-dontwarn com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions$Builder

# flutter_local_notifications keeps every scheduled reminder as JSON written
# with Gson 2.8.9, and that Gson ships no R8 rules of its own. Without these,
# R8 strips the generic signature of the `TypeToken<ArrayList<...>>` the plugin
# reads its list back with, and every zonedSchedule() in a release build fails
# with "Missing type parameter" - the reminders are written to the app's table
# and never reach Android. The plugin's own model classes are kept whole so the
# saved JSON still matches them after an update re-obfuscates the app.
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class * extends com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer
-keepclassmembers,allowobfuscation class * {
  @com.google.gson.annotations.SerializedName <fields>;
}
-keep,allowobfuscation,allowshrinking class com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowshrinking class * extends com.google.gson.reflect.TypeToken
-keep class com.dexterous.flutterlocalnotifications.** { *; }
