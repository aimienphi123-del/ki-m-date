# R8 rules for Expiry Guardian.
#
# google_mlkit_text_recognition declares every script recognizer as compileOnly
# and lets the app pick which ones to ship. This app ships Latin (Vietnamese and
# English labels) and Chinese (imported goods), which are real dependencies in
# build.gradle.kts. The three scripts below are not shipped, and the plugin's
# Java code still references them, so R8 has to be told they are absent on
# purpose - otherwise the release build fails outright.
-dontwarn com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions$Builder
-dontwarn com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
-dontwarn com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions$Builder
