#!/usr/bin/env python3
"""Rasterises the Kiểm date logo from its SVG source.

Run this only after editing `kiem_date.svg`; it needs a Chromium binary and
writes the two 1024 px masters that `tool/generate_icons.py` scales down for
every Android density. The masters are committed, so a build never needs a
browser.

    python3 tool/logo/render_logo.py [path/to/chromium]

* `icon_1024.png` - the whole mark on its rounded square, for older launchers
  and for the in-app logo.
* `foreground_1024.png` - the mark alone on transparency, sized for an Android
  adaptive icon: the 1024 design fills the inner 72 of the 108 dp canvas, so
  a circular mask cuts exactly where the design's own circle preview does.
* `notification_1024.png` - the white status-bar silhouette, from
  `kiem_date_notification.svg`.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "kiem_date.svg"

CANDIDATES = [
    "/opt/pw-browsers/chromium-1194/chrome-linux/chrome",
    "chromium",
    "chromium-browser",
    "google-chrome",
]


def find_browser() -> str:
    if len(sys.argv) > 1:
        return sys.argv[1]
    for name in CANDIDATES:
        found = shutil.which(name) or (name if os.path.exists(name) else None)
        if found:
            return found
    sys.exit("render_logo: no Chromium found; pass its path as the argument")


def screenshot(browser: str, html: str, out: Path) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        page = Path(tmp) / "page.html"
        page.write_text(html, encoding="utf-8")
        subprocess.run(
            [
                browser, "--headless=new", "--no-sandbox", "--disable-gpu",
                "--hide-scrollbars", "--force-device-scale-factor=1",
                "--default-background-color=00000000",
                # Taller than the page: headless Chromium takes its own frame
                # out of the window height, which would crop the bottom.
                "--window-size=1024,1400",
                f"--screenshot={out}", page.as_uri(),
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    Image.open(out).crop((0, 0, 1024, 1024)).save(out)


def page(svg: str, radius: str) -> str:
    return (
        "<!doctype html><html><head><style>"
        "html,body{margin:0;background:transparent}"
        f"div{{width:1024px;height:1024px;border-radius:{radius};overflow:hidden}}"
        "svg{width:100%;height:100%;display:block}"
        f"</style></head><body><div>{svg}</div></body></html>"
    )


def main() -> None:
    browser = find_browser()
    svg = SOURCE.read_text(encoding="utf-8")

    screenshot(browser, page(svg, "22.5%"), HERE / "icon_1024.png")

    # The foreground drops the background square (the adaptive icon supplies
    # its own) and widens the view by 108/72, putting the design in the safe
    # zone.
    foreground = re.sub(r"<rect width=\"1024\" height=\"1024\"[^>]*/>\s*", "", svg, count=1)
    foreground = foreground.replace('viewBox="0 0 1024 1024"', 'viewBox="-256 -256 1536 1536"')
    screenshot(browser, page(foreground, "0"), HERE / "foreground_1024.png")

    notification = (HERE / "kiem_date_notification.svg").read_text(encoding="utf-8")
    screenshot(browser, page(notification, "0"), HERE / "notification_1024.png")
    print("render_logo: wrote icon_1024.png, foreground_1024.png and notification_1024.png")


if __name__ == "__main__":
    main()
