#!/usr/bin/env python3
"""Applies Expiry Guardian's Android configuration to a freshly generated
`android/` folder.

The repository does not commit the Android platform folder: CI regenerates it
with `flutter create` so it always matches the Flutter version being used, and
then runs this script to apply the parts that are specific to this app -
permissions, the notification receivers, minSdk, and Java 8+ desugaring.

The script is idempotent: running it twice changes nothing the second time.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ANDROID = ROOT / "android"
APP = ANDROID / "app"

MIN_SDK = 24

# The release signing key.
#
# Android refuses to install an update signed with a different key than the
# installed app - the phone shows "App not installed" and the only way out is to
# uninstall, which deletes the store's whole database. Flutter falls back to the
# *debug* key when no release key is configured, and a fresh CI runner generates
# a brand-new debug key on every single build. So without this, the second APK
# a store ever builds cannot be installed over the first.
#
# The key therefore lives in the repository, and so does its password: hiding
# the password next to the key it opens would be theatre. This is the right
# trade for an app that is sideloaded inside one company; keep the repository
# private and nobody outside can build an update the phones would accept.
KEYSTORE = ANDROID / "keystore" / "expiry-guardian.jks"
KEY_ALIAS = "expiryguardian"
KEY_PASSWORD = "expiryguardian"
NDK_VERSION = "28.2.13676358"
DESUGAR_LIB = "com.android.tools:desugar_jdk_libs:2.1.4"

# google_mlkit_text_recognition ships Latin only and declares every other script
# recognizer as `compileOnly`, so the app has to add the ones it actually calls.
# MlKitTextReader falls back to the Chinese recognizer whenever the Latin pass
# finds no digits, so without this line that fallback throws NoClassDefFoundError
# on a real phone - and R8 refuses to build the release APK at all.
MLKIT_CHINESE = "com.google.mlkit:text-recognition-chinese:16.0.1"

PERMISSIONS = [
    "android.permission.CAMERA",
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.VIBRATE",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.SCHEDULE_EXACT_ALARM",
    "android.permission.USE_EXACT_ALARM",
]

# Permissions a plugin pulls in that this app never exercises. The camera
# plugin declares RECORD_AUDIO because it can record video; CameraCapturePage
# builds its controller with `enableAudio: false`, so the microphone is never
# touched - and a shop-floor employee should not be asked for it.
REMOVED_PERMISSIONS = [
    "android.permission.RECORD_AUDIO",
]

FEATURES = [
    ('android.hardware.camera', 'false'),
    ('android.hardware.camera.autofocus', 'false'),
]

NOTIFICATION_RECEIVERS = """
        <receiver
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"
            android:exported="false" />
        <receiver
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver"
            android:exported="false">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
        <meta-data
            android:name="com.google.mlkit.vision.DEPENDENCIES"
            android:value="barcode,ocr" />
"""


def fail(message: str) -> None:
    print(f"patch_android: ERROR {message}", file=sys.stderr)
    sys.exit(1)


def patch_manifest() -> None:
    path = APP / "src" / "main" / "AndroidManifest.xml"
    if not path.exists():
        fail(f"{path} not found - run `flutter create --platforms=android .` first")

    text = path.read_text(encoding="utf-8")
    original = text

    # tools:node="remove" needs the tools namespace on the manifest root.
    if "xmlns:tools=" not in text:
        text = text.replace(
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android"',
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android"\n'
            '          xmlns:tools="http://schemas.android.com/tools"',
            1,
        )

    additions = []
    for permission in REMOVED_PERMISSIONS:
        if f'android:name="{permission}"' not in text:
            additions.append(
                f'    <uses-permission android:name="{permission}" tools:node="remove" />'
            )
    for permission in PERMISSIONS:
        if f'android:name="{permission}"' not in text:
            additions.append(f'    <uses-permission android:name="{permission}" />')
    for feature, required in FEATURES:
        if f'android:name="{feature}"' not in text:
            additions.append(
                f'    <uses-feature android:name="{feature}" android:required="{required}" />'
            )

    if additions:
        text = text.replace(
            "<manifest",
            "<manifest",
            1,
        )
        insert_at = text.index(">", text.index("<manifest")) + 1
        text = text[:insert_at] + "\n" + "\n".join(additions) + text[insert_at:]

    if "ScheduledNotificationReceiver" not in text:
        text = text.replace("    </application>", NOTIFICATION_RECEIVERS + "    </application>")

    # The launcher label the employee sees under the icon.
    text = re.sub(r'android:label="[^"]*"', 'android:label="Expiry Guardian"', text, count=1)

    if text != original:
        path.write_text(text, encoding="utf-8")
        print(f"patch_android: updated {path.relative_to(ROOT)}")
    else:
        print("patch_android: manifest already up to date")


def patch_gradle() -> None:
    kts = APP / "build.gradle.kts"
    groovy = APP / "build.gradle"
    if kts.exists():
        patch_gradle_kts(kts)
    elif groovy.exists():
        patch_gradle_groovy(groovy)
    else:
        fail("neither android/app/build.gradle.kts nor build.gradle exists")


SIGNING_BLOCK_KTS = """    signingConfigs {
        create("release") {
            val keystore = rootProject.file("keystore/expiry-guardian.jks")
            if (keystore.exists()) {
                storeFile = keystore
                storePassword = "%(password)s"
                keyAlias = "%(alias)s"
                keyPassword = "%(password)s"
            }
        }
    }

""" % {"alias": KEY_ALIAS, "password": KEY_PASSWORD}

SIGNING_BLOCK_GROOVY = """    signingConfigs {
        release {
            def keystoreFile = rootProject.file('keystore/expiry-guardian.jks')
            if (keystoreFile.exists()) {
                storeFile keystoreFile
                storePassword '%(password)s'
                keyAlias '%(alias)s'
                keyPassword '%(password)s'
            }
        }
    }

""" % {"alias": KEY_ALIAS, "password": KEY_PASSWORD}


def patch_gradle_kts(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    original = text

    text = re.sub(r"minSdk\s*=\s*[^\n]+", f"minSdk = {MIN_SDK}", text, count=1)
    text = re.sub(r'ndkVersion\s*=\s*[^\n]+', f'ndkVersion = "{NDK_VERSION}"', text, count=1)

    if "isCoreLibraryDesugaringEnabled" not in text:
        text = re.sub(
            r"(compileOptions\s*\{)",
            r"\1\n        isCoreLibraryDesugaringEnabled = true",
            text,
            count=1,
        )

    if "coreLibraryDesugaring" not in text:
        if re.search(r"\ndependencies\s*\{", text):
            text = re.sub(
                r"(\ndependencies\s*\{)",
                r'\1\n    coreLibraryDesugaring("' + DESUGAR_LIB + r'")',
                text,
                count=1,
            )
        else:
            text += (
                "\n\ndependencies {\n"
                f'    coreLibraryDesugaring("{DESUGAR_LIB}")\n'
                "}\n"
            )

    if MLKIT_CHINESE not in text:
        text = re.sub(
            r"(\ndependencies\s*\{)",
            r'\1\n    implementation("' + MLKIT_CHINESE + r'")',
            text,
            count=1,
        )

    if "proguard-rules.pro" not in text:
        text = text.replace(
            'signingConfig = signingConfigs.getByName("release")',
            'signingConfig = signingConfigs.getByName("release")\n'
            "            proguardFiles(\n"
            '                getDefaultProguardFile("proguard-android-optimize.txt"),\n'
            '                "proguard-rules.pro",\n'
            "            )",
        )

    if 'create("release")' not in text:
        text = re.sub(
            r"(\n    buildTypes\s*\{)",
            "\n" + SIGNING_BLOCK_KTS.rstrip("\n") + r"\1",
            text,
            count=1,
        )
    text = text.replace(
        'signingConfig = signingConfigs.getByName("debug")',
        'signingConfig = signingConfigs.getByName("release")',
    )
    text = text.replace(
        "            // TODO: Add your own signing config for the release build.\n"
        "            // Signing with the debug keys for now, so `flutter run --release` works.\n",
        "            // Signed with the committed release key so every build a store\n"
        "            // makes installs as an update over the previous one.\n",
    )

    if text != original:
        path.write_text(text, encoding="utf-8")
        print(f"patch_android: updated {path.relative_to(ROOT)}")
    else:
        print("patch_android: app/build.gradle.kts already up to date")


def patch_gradle_groovy(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    original = text

    text = re.sub(r"minSdkVersion\s+[^\n]+", f"minSdkVersion {MIN_SDK}", text, count=1)
    text = re.sub(r"minSdk\s*=?\s*[^\n]+", f"minSdk {MIN_SDK}", text, count=1)
    text = re.sub(r'ndkVersion\s*=?\s*[^\n]+', f'ndkVersion "{NDK_VERSION}"', text, count=1)

    if "coreLibraryDesugaringEnabled" not in text:
        text = re.sub(
            r"(compileOptions\s*\{)",
            r"\1\n        coreLibraryDesugaringEnabled true",
            text,
            count=1,
        )

    if "coreLibraryDesugaring " not in text:
        if re.search(r"\ndependencies\s*\{", text):
            text = re.sub(
                r"(\ndependencies\s*\{)",
                r"\1\n    coreLibraryDesugaring '" + DESUGAR_LIB + r"'",
                text,
                count=1,
            )
        else:
            text += (
                "\n\ndependencies {\n"
                f"    coreLibraryDesugaring '{DESUGAR_LIB}'\n"
                "}\n"
            )

    if "signingConfigs" not in text:
        text = re.sub(
            r"(\n    buildTypes\s*\{)",
            "\n" + SIGNING_BLOCK_GROOVY.rstrip("\n") + r"\1",
            text,
            count=1,
        )
    text = text.replace("signingConfig signingConfigs.debug", "signingConfig signingConfigs.release")

    if text != original:
        path.write_text(text, encoding="utf-8")
        print(f"patch_android: updated {path.relative_to(ROOT)}")
    else:
        print("patch_android: app/build.gradle already up to date")


def patch_gradle_properties() -> None:
    path = ANDROID / "gradle.properties"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    wanted = {
        "org.gradle.jvmargs": "-Xmx4G -XX:MaxMetaspaceSize=2G",
        "android.useAndroidX": "true",
        "android.enableJetifier": "true",
    }
    lines = text.splitlines()
    keys = {line.split("=", 1)[0].strip() for line in lines if "=" in line}
    added = [f"{k}={v}" for k, v in wanted.items() if k not in keys]
    if added:
        path.write_text(text.rstrip("\n") + "\n" + "\n".join(added) + "\n", encoding="utf-8")
        print(f"patch_android: updated {path.relative_to(ROOT)}")


def main() -> None:
    if not ANDROID.exists():
        fail("android/ does not exist - run `flutter create --platforms=android .` first")
    if not KEYSTORE.exists():
        print(
            "patch_android: WARNING - "
            f"{KEYSTORE.relative_to(ROOT)} is missing, so this build falls back to "
            "the debug key and will NOT install over an existing copy of the app",
        )
    patch_manifest()
    patch_gradle()
    patch_gradle_properties()
    print("patch_android: done")


if __name__ == "__main__":
    main()
