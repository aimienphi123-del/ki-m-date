// Checks that the engines, once compiled to JavaScript, still answer exactly
// what the Dart test suite pins them to.
//
// The demo page is only worth anything if it behaves like the app. This script
// re-asserts a slice of `flutter test` against the compiled bundle, so a
// dart2js change or a stale demo.js is caught rather than quietly shipped.
//
//   node tool/web_demo/verify.mjs

import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const here = dirname(fileURLToPath(import.meta.url));
globalThis.self = globalThis;
// eslint-disable-next-line no-eval
eval(readFileSync(join(here, 'demo.js'), 'utf8'));

const call = (payload) => JSON.parse(globalThis.expiryGuardianDemo(JSON.stringify(payload)));

let failures = 0;
function check(name, actual, expected) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a === e) {
    console.log(`  ok   ${name}`);
  } else {
    failures++;
    console.log(`  FAIL ${name}\n         expected ${e}\n         actual   ${a}`);
  }
}

const NOW = '2026-09-06T08:00:00';

console.log('policy engine');
{
  const p = call({ op: 'policy' });
  check('six default bands', p.rules.length, 6);
  check('validator finds no gap or overlap', p.issues.length, 0);
  check('basis is manufacturing to expiry', p.basis, 'manufacturingToExpiry');
  check('band lead times (minutes)', p.rules.map((r) => r.leadMinutes), [120, 1440, 4320, 7200, 10080, 43200]);

  // Mirrors inventory_repository_test: a 14 day shelf life lands in the
  // "over 7 days, under 1 month" band and is destroyed one day early.
  const e = call({
    op: 'evaluate',
    expiry: '2026-09-20T00:00:00',
    manufactured: '2026-09-06T00:00:00',
    received: NOW,
    now: NOW,
  });
  check('14 day lot -> 1 day lead', e.leadMinutes, 1440);
  check('14 day lot -> destroy instant', e.destroyAt, '2026-09-19T23:59:59.999');
  check('14 day lot -> end of expiry day', e.expiryInstant, '2026-09-20T23:59:59.999');
  check('14 day lot -> priority', e.priority, 'safe');

  // An hourly lot: two hours before the printed time.
  const h = call({
    op: 'evaluate',
    expiry: '2026-09-06T18:00:00',
    manufactured: '2026-09-06T06:00:00',
    hourly: true,
    received: NOW,
    now: NOW,
  });
  check('hourly lot -> 2 hour lead', h.leadMinutes, 120);
  check('hourly lot -> destroy at 16:00', h.destroyAt, '2026-09-06T16:00:00.000');

  // Already past its deadline.
  const late = call({
    op: 'evaluate',
    expiry: '2026-09-01T00:00:00',
    manufactured: '2026-08-20T00:00:00',
    received: '2026-08-20T08:00:00',
    now: NOW,
  });
  check('overdue lot -> expired priority', late.priority, 'expired');
}

console.log('label parser');
{
  const vi = call({ op: 'label', lines: ['NSX 010326 HSD 010327', 'LO SX AB1234'], now: NOW });
  check('Vietnamese NSX/HSD on one line -> expiry', vi.expiry.value, '2027-03-01T00:00:00.000');
  check('Vietnamese NSX/HSD on one line -> mfg', vi.manufacturing.value, '2026-03-01T00:00:00.000');
  check('batch code', vi.batchCode, 'AB1234');

  const en = call({ op: 'label', lines: ['BEST BEFORE 20 DEC 2026'], now: NOW });
  check('month name after the day', en.expiry.value, '2026-12-20T00:00:00.000');

  const compact = call({ op: 'label', lines: ['20261220'], now: NOW });
  check('compact YYYYMMDD', compact.expiry.value, '2026-12-20T00:00:00.000');

  const monthFirst = call({ op: 'label', lines: ['EXP 03/04/2027'], dayFirst: false, now: NOW });
  check('MM/DD when the store says so', monthFirst.expiry.value, '2027-03-04T00:00:00.000');

  const dayFirst = call({ op: 'label', lines: ['EXP 03/04/2027'], dayFirst: true, now: NOW });
  check('DD/MM by default', dayFirst.expiry.value, '2027-04-03T00:00:00.000');

  const junk = call({ op: 'label', lines: ['SUA TUOI TIET TRUNG', '180ml'], now: NOW });
  check('no date found is said out loud', junk.warnings, ['noDatesFound']);
  check('and nothing is invented', junk.expiry, null);

  // "EXPRESS" must not be mistaken for the EXP keyword. The date is still
  // resolved as the expiry - but by the future-date rule, so the raw candidate
  // stays unlabelled rather than being claimed by a keyword.
  const express = call({ op: 'label', lines: ['EXPRESS DELIVERY 20/12/2026'], now: NOW });
  check('EXPRESS is not read as the EXP keyword', express.candidates[0].kind, 'unknown');
  check('the date is still resolved as the expiry', express.expiry.kind, 'expiry');
}

console.log('GS1 parser');
{
  const g = call({ op: 'gs1', raw: '01089345880630531526092010AB1234', now: NOW });
  check('GTIN', g.gtin, '08934588063053');
  check('best before', g.bestBeforeDate, '2026-09-20T00:00:00.000');
  check('lot', g.batchOrLot, 'AB1234');

  const plain = call({ op: 'gs1', raw: '8934588063053', now: NOW });
  check('a plain barcode yields no GS1 fields', plain.gtin, null);
}

console.log('reminder timeline');
{
  const t = call({ op: 'timeline', destroyAt: '2026-09-10T16:00:00', now: NOW });
  check('27 reminders (early + final + mandatory + 24 chase-ups)', t.reminders.length, 27);
  check('first is two days early', t.reminders[0].at, '2026-09-08T16:00:00.000');
  check('third is the deadline itself', t.reminders[2].at, '2026-09-10T16:00:00.000');
  check('fourth is one hour later', t.reminders[3].at, '2026-09-10T17:00:00.000');
  check('manager alerts', t.escalations.length, 5);
  check('first manager alert is 24h after the deadline', t.escalations[0].at, '2026-09-11T16:00:00.000');
  check('manager alert severity', t.escalations[0].severity, 'critical');
}

console.log(failures === 0 ? '\nAll demo bridge checks passed.' : `\n${failures} check(s) failed.`);
process.exit(failures === 0 ? 0 : 1);
