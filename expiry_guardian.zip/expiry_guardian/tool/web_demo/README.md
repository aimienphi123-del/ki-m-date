# Bàn thử tính năng chạy trên trình duyệt

`demo.dart` là một **cầu nối mỏng**, không phải bản viết lại. Nó gọi thẳng các
lớp mà bản Android đang chạy — `DefaultExpiryPolicyEngine`, `LabelTextParser`,
`Gs1Parser`, `PolicyValidator`, `DefaultNotificationStages`,
`DefaultEscalationRules` — rồi biên dịch sang JavaScript. Sửa quy tắc trong app
thì trang thử cũng đổi theo; không có bản sao logic nào để lệch nhau.

Những thứ trang này **không** làm được vì cần máy thật: camera, cơ sở dữ liệu,
thông báo đặt lịch, xuất file.

## Dựng lại sau khi sửa mã nguồn

```bash
dart compile js -O2 -o tool/web_demo/demo.js tool/web_demo/demo.dart
python3 tool/web_demo/build_page.py      # nhúng demo.js vào file HTML
```

Kết quả: `tool/web_demo/expiry_guardian_demo.html` — một file duy nhất, mở
bằng trình duyệt nào cũng chạy, không cần mạng.

## Kiểm chứng

`tool/web_demo/verify.mjs` chạy cầu nối bằng Node và so kết quả với đúng những
con số mà bộ test Dart đã chốt (`flutter test`). Chạy:

```bash
node tool/web_demo/verify.mjs
```
