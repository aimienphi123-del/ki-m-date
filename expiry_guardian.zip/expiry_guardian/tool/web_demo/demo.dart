/// Exposes Expiry Guardian's real decision engines to a web page.
///
/// This is a **thin bridge, not a reimplementation**. Every answer the demo
/// page shows comes from the same Dart classes the Android app ships:
/// [DefaultExpiryPolicyEngine], [LabelTextParser], [Gs1Parser],
/// [PolicyValidator], [DefaultNotificationStages] and [DefaultEscalationRules],
/// compiled to JavaScript with `dart compile js`. If the app's behaviour
/// changes, this page changes with it - there is no second copy of the rules to
/// drift out of step.
///
/// What it deliberately cannot show: the camera, the database, scheduled
/// notifications and file export all need a real device.
///
/// Build:  dart compile js -O2 -o tool/web_demo/demo.js tool/web_demo/demo.dart
library;

import 'dart:convert';
import 'dart:js_interop';

import 'package:expiry_guardian/core/domain/expiry_precision.dart';
import 'package:expiry_guardian/core/notifications/notification_stage.dart';
import 'package:expiry_guardian/core/utils/clock.dart';
import 'package:expiry_guardian/core/utils/id.dart';
import 'package:expiry_guardian/features/escalation/domain/entities/escalation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/destroy_policy.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_evaluation.dart';
import 'package:expiry_guardian/features/policy/domain/entities/policy_rule.dart';
import 'package:expiry_guardian/features/policy/domain/services/default_policy_factory.dart';
import 'package:expiry_guardian/features/policy/domain/services/expiry_policy_engine.dart';
import 'package:expiry_guardian/features/policy/domain/services/policy_validator.dart';
import 'package:expiry_guardian/features/scan/domain/entities/label_reading.dart';
import 'package:expiry_guardian/features/scan/domain/services/gs1_parser.dart';
import 'package:expiry_guardian/features/scan/domain/services/label_text_parser.dart';

@JS('expiryGuardianDemo')
external set _bridge(JSFunction value);

const DefaultExpiryPolicyEngine _engine = DefaultExpiryPolicyEngine();
const Gs1Parser _gs1 = Gs1Parser();
const PolicyValidator _validator = PolicyValidator();

/// The shipped handbook, built by the same factory that seeds it on a phone.
final DestroyPolicy _policy =
    DefaultPolicyFactory(SequentialIdGenerator('rule'), const SystemClock()).build(policyId: 'demo');

void main() {
  _bridge = ((JSString request) {
    Map<String, Object?> reply;
    try {
      final Map<String, Object?> call =
          jsonDecode(request.toDart) as Map<String, Object?>;
      reply = _dispatch(call['op'] as String? ?? '', call);
    } on Object catch (error) {
      // A demo that swallows its own errors teaches nothing.
      reply = <String, Object?>{'error': error.toString()};
    }
    return jsonEncode(reply).toJS;
  }).toJS;
}

Map<String, Object?> _dispatch(String op, Map<String, Object?> call) {
  return switch (op) {
    'policy' => _describePolicy(),
    'evaluate' => _evaluate(call),
    'label' => _readLabel(call),
    'gs1' => _readBarcode(call),
    'timeline' => _timeline(call),
    _ => <String, Object?>{'error': 'unknown op "$op"'},
  };
}

// ------------------------------------------------------------------ policy

/// The six shipped bands plus the validator's verdict on them.
Map<String, Object?> _describePolicy() {
  return <String, Object?>{
    'name': _policy.name,
    'version': _policy.version,
    'basis': _policy.basis.name,
    'fallbackLeadMinutes': _policy.fallbackLeadTime.inMinutes,
    'rules': <Map<String, Object?>>[
      for (final PolicyRule rule in _policy.allRulesInOrder)
        <String, Object?>{
          'id': rule.id,
          'nameVi': rule.nameVi,
          'nameEn': rule.nameEn,
          'leadMinutes': rule.leadTime.inMinutes,
          'minMinutes': rule.minShelfLife?.inMinutes,
          'minInclusive': rule.minInclusive,
          'maxMinutes': rule.maxShelfLife?.inMinutes,
          'maxInclusive': rule.maxInclusive,
          'hourly': rule.matchesHourlyExpiry,
          'active': rule.isActive,
        },
    ],
    'issues': <Map<String, Object?>>[
      for (final PolicyIssue issue in _validator.validate(_policy))
        <String, Object?>{
          'code': issue.code.name,
          'severity': issue.severity.name,
          'detail': issue.detail,
        },
    ],
  };
}

Map<String, Object?> _evaluate(Map<String, Object?> call) {
  final DateTime expiry = _date(call['expiry']);
  final DateTime? manufactured =
      call['manufactured'] == null ? null : _date(call['manufactured']);
  final DateTime received = call['received'] == null ? _now(call) : _date(call['received']);
  final ExpiryPrecision precision =
      (call['hourly'] as bool? ?? false) ? ExpiryPrecision.hour : ExpiryPrecision.day;

  final PolicyDecision decision = _engine.evaluate(
    _policy,
    PolicyInput(
      expiry: expiry,
      receivedAt: received,
      precision: precision,
      manufacturedAt: manufactured,
    ),
  );

  final DateTime now = _now(call);
  final PriorityAssessment priority = _engine.assess(
    policy: _policy,
    now: now,
    destroyAt: decision.destroyAt,
    expiryInstant: decision.expiryInstant,
  );

  return <String, Object?>{
    'expiryInstant': decision.expiryInstant.toIso8601String(),
    'destroyAt': decision.destroyAt.toIso8601String(),
    'leadMinutes': decision.leadTime.inMinutes,
    'shelfLifeMinutes': decision.shelfLife.inMinutes,
    'basisUsed': decision.basisUsed.name,
    'ruleNameVi': decision.matchedRule?.nameVi,
    'ruleNameEn': decision.matchedRule?.nameEn,
    'ruleId': decision.matchedRule?.id,
    'usedFallback': decision.usedFallbackLeadTime,
    'priority': priority.level.name,
    'minutesUntilDestroy': priority.timeUntilDestroy.inMinutes,
    'minutesUntilExpiry': priority.timeUntilExpiry.inMinutes,
  };
}

// -------------------------------------------------------------------- scan

Map<String, Object?> _readLabel(Map<String, Object?> call) {
  final List<String> lines = <String>[
    for (final Object? line in (call['lines'] as List<Object?>? ?? const <Object?>[]))
      line.toString(),
  ];
  // Vietnamese labels print DD/MM; a US import prints MM/DD. The setting is
  // the same one a manager flips in Cài đặt → Quét.
  final bool dayFirst = call['dayFirst'] as bool? ?? true;

  final LabelReading reading = LabelTextParser(
    config: LabelParserConfig(dayFirst: dayFirst),
  ).parse(lines, now: _now(call));

  Map<String, Object?>? date(LabelDate? value) => value == null
      ? null
      : <String, Object?>{
          'value': value.value.toIso8601String(),
          'kind': value.kind.name,
          'raw': value.rawText,
          'confidence': value.confidence,
          'hasTime': value.hasTime,
          'dayKnown': value.dayKnown,
          'lineIndex': value.lineIndex,
        };

  return <String, Object?>{
    'expiry': date(reading.expiry),
    'manufacturing': date(reading.manufacturing),
    'batchCode': reading.batchCode,
    'warnings': <String>[for (final LabelWarning w in reading.warnings) w.name],
    'candidates': <Map<String, Object?>>[
      for (final LabelDate c in reading.candidates) date(c)!,
    ],
  };
}

Map<String, Object?> _readBarcode(Map<String, Object?> call) {
  final Gs1Data data = _gs1.parse(
    (call['raw'] as String? ?? '').replaceAll('{GS}', Gs1Parser.groupSeparator),
    reference: _now(call),
  );
  return <String, Object?>{
    'gtin': data.gtin,
    'batchOrLot': data.batchOrLot,
    'serial': data.serial,
    'productionDate': data.productionDate?.toIso8601String(),
    'packagingDate': data.packagingDate?.toIso8601String(),
    'bestBeforeDate': data.bestBeforeDate?.toIso8601String(),
    'expirationDate': data.expirationDate?.toIso8601String(),
    'expirationDateTime': data.expirationDateTime?.toIso8601String(),
    'elements': data.rawElements,
  };
}

// ---------------------------------------------------------------- timeline

/// Every reminder and manager alert one lot produces, from the shipped stages
/// and escalation rules.
Map<String, Object?> _timeline(Map<String, Object?> call) {
  final DateTime destroyAt = _date(call['destroyAt']);
  final DateTime now = _now(call);

  final List<NotificationStage> stages =
      DefaultNotificationStages.build(newId: SequentialIdGenerator('stage').newId, now: now);
  final List<EscalationRule> rules =
      DefaultEscalationRules.build(newId: SequentialIdGenerator('esc').newId, now: now);

  final List<Map<String, Object?>> reminders = <Map<String, Object?>>[];
  for (final NotificationStage stage in stages) {
    final List<DateTime> times = stage.occurrencesFor(destroyAt);
    for (int i = 0; i < times.length; i++) {
      reminders.add(<String, Object?>{
        'kind': stage.kind.name,
        'nameVi': stage.nameVi,
        'nameEn': stage.nameEn,
        'at': times[i].toIso8601String(),
        'attempt': i + 1,
        'total': times.length,
        'past': !times[i].isAfter(now),
      });
    }
  }
  reminders.sort((Map<String, Object?> a, Map<String, Object?> b) =>
      (a['at']! as String).compareTo(b['at']! as String),);

  final List<Map<String, Object?>> escalations = <Map<String, Object?>>[];
  for (final EscalationRule rule in rules) {
    final List<DateTime> times = rule.alertTimesFor(destroyAt);
    for (int i = 0; i < times.length; i++) {
      escalations.add(<String, Object?>{
        'nameVi': rule.nameVi,
        'nameEn': rule.nameEn,
        'severity': rule.severity.name,
        'role': rule.notifyRole.name,
        'at': times[i].toIso8601String(),
        'attempt': i + 1,
        'total': times.length,
        'past': !times[i].isAfter(now),
      });
    }
  }

  return <String, Object?>{
    'destroyAt': destroyAt.toIso8601String(),
    'reminders': reminders,
    'escalations': escalations,
  };
}

// ------------------------------------------------------------------ helpers

DateTime _date(Object? value) => DateTime.parse(value! as String);

DateTime _now(Map<String, Object?> call) =>
    call['now'] == null ? DateTime.now() : _date(call['now']);
