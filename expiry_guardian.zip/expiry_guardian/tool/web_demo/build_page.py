#!/usr/bin/env python3
"""Inlines the compiled engines into the demo page.

The page has to be one self-contained file: it is opened straight from a
download folder, and the published version runs under a content policy that
blocks loading scripts from anywhere but a few CDNs. So `demo.js` is pasted
into the page rather than linked.

Run `dart compile js -O2 -o tool/web_demo/demo.js tool/web_demo/demo.dart`
first, then this.
"""

from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE / "page.html"
ENGINE = HERE / "demo.js"
OUT = HERE / "expiry_guardian_demo.html"
MARKER = "/*__DEMO_JS__*/"


def main() -> None:
    for path in (TEMPLATE, ENGINE):
        if not path.exists():
            sys.exit(f"build_page: {path.name} is missing")

    page = TEMPLATE.read_text(encoding="utf-8")
    if MARKER not in page:
        sys.exit(f"build_page: {TEMPLATE.name} no longer contains {MARKER}")

    engine = ENGINE.read_text(encoding="utf-8")
    # dart2js never emits these, but a stray "</script>" inside the inlined
    # source would end the block early and silently break the page.
    if "</script" in engine.lower():
        sys.exit("build_page: the compiled engine contains a closing script tag")

    OUT.write_text(page.replace(MARKER, engine), encoding="utf-8")
    print(f"build_page: wrote {OUT.name} ({OUT.stat().st_size / 1024:.0f} KB)")


if __name__ == "__main__":
    main()
