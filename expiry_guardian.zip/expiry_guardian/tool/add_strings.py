#!/usr/bin/env python3
"""Adds new entries to the two translation tables in
`lib/core/l10n/app_strings.dart` and regenerates the `K` key constants.

Editing the tables by hand is fine for changing wording; this script exists so
that *adding* a key cannot drift between the two languages, and so the `K`
constants always match the tables exactly.

Usage: python3 tool/add_strings.py  (the additions are the NEW dict below)
"""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT / "lib" / "core" / "l10n" / "app_strings.dart"

# key: (vietnamese, english)
NEW: dict[str, tuple[str, str]] = {
    "calc.title": ("Máy tính hủy hàng", "Destruction calculator"),
    "calc.subtitle": (
        "Tính thời điểm bắt buộc hủy từ NSX và HSD, theo đúng chính sách của cửa hàng.",
        "Work out the destroy deadline from the production and expiry dates, using the store's own policy.",
    ),
    "calc.modeBoth": ("1. Nhập cả NSX & HSD", "1. Both NSX and expiry"),
    "calc.modeSpan": ("2. Nhập 1 mốc + thời hạn", "2. One date + shelf life"),
    "calc.useTime": ("Nhập thêm giờ", "Include a time of day"),
    "calc.useTimeHint": (
        "Chỉ cần cho hàng tính theo giờ. Tắt thì tính theo ngày.",
        "Only needed for goods counted in hours. Off means whole days.",
    ),
    "calc.sop": ("Hàng SOP (bánh bao, xúc xích…)", "SOP goods (buns, sausages…)"),
    "calc.sopHint": (
        "Luôn hủy trước mốc in trên bao bì đúng khoảng thời gian của quy tắc hàng theo giờ, bất kể hạn dài bao lâu.",
        "Always destroyed the hourly rule's lead time before the printed moment, however long the shelf life.",
    ),
    "calc.nsx": ("Ngày sản xuất (NSX)", "Production date (NSX)"),
    "calc.hsd": ("Hạn sử dụng in trên bao bì (HSD)", "Expiry printed on the pack (HSD)"),
    "calc.anchorExpiry": ("Có HSD → tìm NSX", "Know the expiry → find NSX"),
    "calc.anchorMfg": ("Có NSX → tìm HSD", "Know NSX → find the expiry"),
    "calc.spanLabel": ("Thời hạn (từ NSX đến HSD)", "Shelf life (NSX to expiry)"),
    "calc.unitHour": ("Giờ", "Hours"),
    "calc.unitDay": ("Ngày", "Days"),
    "calc.unitMonth": ("Tháng", "Months"),
    "calc.unitYear": ("Năm", "Years"),
    "calc.resultDestroy": ("THỜI ĐIỂM BẮT BUỘC PHẢI HỦY", "DESTROY BY"),
    "calc.resultRule": ("Quy tắc áp dụng", "Rule applied"),
    "calc.shelfLife": ("Vòng đời: {days} ngày", "Shelf life: {days} days"),
    "calc.needShelfLife": (
        "Chưa đủ dữ liệu để tính giờ hủy: hãy nhập NSX, hoặc chuyển sang chế độ 2 và nhập thời hạn ghi trên bao bì.",
        "Not enough to work out a destroy time: enter the production date, or switch to mode 2 and give the stated shelf life.",
    ),
    "calc.usedFallback": (
        "Không có quy tắc nào khớp vòng đời này - đang dùng thời gian dự phòng của chính sách.",
        "No rule matches this shelf life - the policy's fallback lead time was used.",
    ),
    "calc.clear": ("Xóa", "Clear"),
    "calc.applyToIntake": ("Dùng 2 ngày này để nhập hàng", "Use these dates for goods-in"),
    "calc.appliedToIntake": (
        "Đã điền NSX và HSD vào phiếu nhập hàng.",
        "The production and expiry dates were filled into goods-in.",
    ),
    "calc.policyNote": (
        "Số liệu lấy từ Chính sách hủy hàng đang áp dụng. Sửa chính sách thì máy tính đổi theo.",
        "Every figure comes from the active destruction policy. Change the policy and this changes with it.",
    ),
}


def parse_map(source: str, name: str) -> dict[str, str]:
    start = source.index(f"const Map<String, String> {name} = <String, String>{{")
    end = source.index("\n};", start)
    body = source[start:end]
    out: dict[str, str] = {}
    for match in re.finditer(r"^  '((?:[^'\\]|\\.)*)': '((?:[^'\\]|\\.)*)',$", body, re.M):
        out[unescape(match.group(1))] = unescape(match.group(2))
    return out


def unescape(value: str) -> str:
    return value.replace(r"\'", "'").replace(r"\$", "$").replace(r"\\", "\\")


def escape(value: str) -> str:
    return value.replace("\\", r"\\").replace("'", r"\'").replace("$", r"\$")


def key_constant(key: str) -> str:
    parts = key.split(".")
    head = parts[0]
    tail = "".join(p[0].upper() + p[1:] for p in parts[1:])
    return (head + tail).replace("-", "")


def emit(vi: dict[str, str], en: dict[str, str]) -> str:
    def table(name: str, values: dict[str, str]) -> str:
        lines = "\n".join(f"  '{escape(k)}': '{escape(v)}'," for k, v in values.items())
        return f"const Map<String, String> {name} = <String, String>{{\n{lines}\n}};"

    constants = "\n".join(
        f"  static const String {key_constant(k)} = '{k}';" for k in vi
    )
    return f'''// GENERATED-BY-HAND but mechanical: one entry per user-visible string.
//
// Wording lives in these two maps and nowhere else, so a store manager can
// change any label by editing one line - no widget code is involved.
// `tool/add_strings.py` adds new keys to both tables at once and regenerates
// the constants below, so the two languages cannot drift apart.

/// Vietnamese (default).
{table("stringsVi", vi)}

/// English.
{table("stringsEn", en)}

/// Compile-time-checked keys. Using [K.todayTitle] instead of the raw string
/// means a typo is a build error rather than a blank label on a phone.
abstract final class K {{
{constants}
}}
'''


def main() -> None:
    source = TARGET.read_text(encoding="utf-8")
    vi = parse_map(source, "stringsVi")
    en = parse_map(source, "stringsEn")
    if not vi or len(vi) != len(en):
        raise SystemExit(f"parse failed: vi={len(vi)} en={len(en)}")

    added = 0
    for key, (vietnamese, english) in NEW.items():
        if key not in vi:
            added += 1
        vi[key] = vietnamese
        en[key] = english

    TARGET.write_text(emit(vi, en), encoding="utf-8")
    print(f"add_strings: {len(vi)} keys total, {added} new")


if __name__ == "__main__":
    main()
