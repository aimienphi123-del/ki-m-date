#!/usr/bin/env python3
"""Draws the Expiry Guardian launcher icon at every Android density.

The mark is drawn from primitives rather than shipped as a binary asset, so it
stays in version control as readable code and can be restyled by changing the
constants below.

Design: a teal shield (the "guardian") with a clock face inside it (the
"expiry"), plus a short hand pointing at the moment stock has to leave the
shelf. Entirely original artwork.

Usage:  python3 tool/generate_icons.py
Requires Pillow. If Pillow is unavailable the script exits quietly, because a
missing custom icon must never break a build - Flutter's default icon is used.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:  # pragma: no cover - optional tooling dependency
    print("generate_icons: Pillow is not installed, keeping the existing icon")
    sys.exit(0)

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "android" / "app" / "src" / "main" / "res"

DENSITIES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

TEAL_DARK = (0, 77, 64, 255)
TEAL = (0, 105, 92, 255)
CREAM = (241, 248, 246, 255)
AMBER = (255, 179, 0, 255)

SUPERSAMPLE = 8


def shield_polygon(size: float) -> list[tuple[float, float]]:
    """A symmetric shield: straight shoulders, curved base."""
    cx = size / 2
    top = size * 0.16
    shoulder = size * 0.34
    bottom = size * 0.88
    half = size * 0.30

    points: list[tuple[float, float]] = [
        (cx - half, top),
        (cx + half, top),
        (cx + half, shoulder),
    ]
    # Right side curving into the point.
    steps = 24
    for i in range(steps + 1):
        t = i / steps
        x = cx + half * (1 - t * t)
        y = shoulder + (bottom - shoulder) * t
        points.append((x, y))
    # Mirror for the left side.
    for i in range(steps, -1, -1):
        t = i / steps
        x = cx - half * (1 - t * t)
        y = shoulder + (bottom - shoulder) * t
        points.append((x, y))
    points.append((cx - half, shoulder))
    return points


def draw_icon(size: int) -> Image.Image:
    canvas = size * SUPERSAMPLE
    image = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)

    # Rounded-square background.
    radius = canvas * 0.22
    draw.rounded_rectangle(
        (0, 0, canvas - 1, canvas - 1),
        radius=radius,
        fill=TEAL,
    )
    # A subtle darker band at the bottom for depth.
    draw.rounded_rectangle(
        (0, canvas * 0.62, canvas - 1, canvas - 1),
        radius=radius,
        fill=TEAL_DARK,
    )
    draw.rounded_rectangle(
        (0, 0, canvas - 1, canvas * 0.70),
        radius=radius,
        fill=TEAL,
    )

    draw.polygon(shield_polygon(canvas), fill=CREAM)

    # Clock face inside the shield.
    cx, cy = canvas / 2, canvas * 0.46
    face = canvas * 0.155
    draw.ellipse(
        (cx - face, cy - face, cx + face, cy + face),
        outline=TEAL_DARK,
        width=int(canvas * 0.030),
    )
    # Hour marks at 12, 3, 6, 9.
    for angle in (0, 90, 180, 270):
        radians = math.radians(angle - 90)
        inner = face * 0.62
        outer = face * 0.86
        draw.line(
            (
                cx + inner * math.cos(radians),
                cy + inner * math.sin(radians),
                cx + outer * math.cos(radians),
                cy + outer * math.sin(radians),
            ),
            fill=TEAL_DARK,
            width=int(canvas * 0.016),
        )
    # Hands: the short one points at the destroy deadline.
    draw.line(
        (cx, cy, cx, cy - face * 0.62),
        fill=TEAL_DARK,
        width=int(canvas * 0.026),
    )
    deadline = math.radians(120 - 90)
    draw.line(
        (
            cx,
            cy,
            cx + face * 0.78 * math.cos(deadline),
            cy + face * 0.78 * math.sin(deadline),
        ),
        fill=AMBER,
        width=int(canvas * 0.030),
    )
    draw.ellipse(
        (cx - canvas * 0.018, cy - canvas * 0.018, cx + canvas * 0.018, cy + canvas * 0.018),
        fill=TEAL_DARK,
    )

    return image.resize((size, size), Image.LANCZOS)


def main() -> None:
    if not RES.exists():
        print(f"generate_icons: {RES} not found - run `flutter create` first")
        sys.exit(0)
    for folder, size in DENSITIES.items():
        target = RES / folder
        target.mkdir(parents=True, exist_ok=True)
        draw_icon(size).save(target / "ic_launcher.png")
        print(f"generate_icons: wrote {(target / 'ic_launcher.png').relative_to(ROOT)} ({size}px)")


if __name__ == "__main__":
    main()
