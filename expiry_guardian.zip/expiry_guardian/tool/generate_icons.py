#!/usr/bin/env python3
"""Writes the Kiểm date launcher icon at every Android density.

Scales the committed masters in `tool/logo/` (see `render_logo.py`) and writes:

* `mipmap-*/ic_launcher.png` - the full icon, for Android 7 and older
  launchers that do not mask icons;
* `mipmap-*/ic_launcher_foreground.png`, `mipmap-anydpi-v26/ic_launcher.xml`
  and the background colour - an adaptive icon, so Android 8+ launchers can
  shape it as a circle, squircle or rounded square without clipping the mark;
* `drawable-*/ic_stat_kiem_date.png` - the white silhouette Android needs for
  the status bar. The launcher icon cannot stand in for it: a full-colour icon
  shows as a white square, and an adaptive one makes Android 8 refuse to post
  the notification at all;
* `raw/keep.xml` - tells resource shrinking to keep that icon, which nothing
  but a string in Dart refers to;
* `assets/images/logo.png` - the same mark for the sign-in screen.

Idempotent, and quiet when Pillow is missing: the PNGs are committed, so a
build without Pillow still ships the right icon.

Usage:  python3 tool/generate_icons.py
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:  # pragma: no cover - optional tooling dependency
    print("generate_icons: Pillow is not installed, keeping the committed icons")
    sys.exit(0)

ROOT = Path(__file__).resolve().parent.parent
LOGO = ROOT / "tool" / "logo"
RES = ROOT / "android" / "app" / "src" / "main" / "res"

# Launcher icons are 48 dp; adaptive-icon layers are 108 dp.
DENSITIES = {
    "mipmap-mdpi": 1.0,
    "mipmap-hdpi": 1.5,
    "mipmap-xhdpi": 2.0,
    "mipmap-xxhdpi": 3.0,
    "mipmap-xxxhdpi": 4.0,
}

# Status-bar icons are 24 dp.
NOTIFICATION_DENSITIES = {
    "drawable-mdpi": 1.0,
    "drawable-hdpi": 1.5,
    "drawable-xhdpi": 2.0,
    "drawable-xxhdpi": 3.0,
    "drawable-xxxhdpi": 4.0,
}

NOTIFICATION_ICON = "ic_stat_kiem_date"

KEEP_XML = """<?xml version="1.0" encoding="utf-8"?>
<!-- The status-bar icon is named only from Dart, so resource shrinking would
     otherwise remove it and every notification would fail to show. -->
<resources xmlns:tools="http://schemas.android.com/tools"
    tools:keep="@drawable/ic_stat_kiem_date" />
"""

ADAPTIVE_XML = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
"""


def background_colour() -> str:
    """The logo's background square, read from the SVG it was drawn in."""
    svg = (LOGO / "kiem_date.svg").read_text(encoding="utf-8")
    match = re.search(r'<rect width="1024" height="1024" fill="(#[0-9A-Fa-f]{6})"', svg)
    if not match:
        sys.exit("generate_icons: kiem_date.svg has no full-size background rect")
    return match.group(1).upper()


def scaled(master: Image.Image, size: int) -> Image.Image:
    return master.resize((size, size), Image.LANCZOS)


def write_if_changed(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.read_text(encoding="utf-8") != text:
        path.write_text(text, encoding="utf-8")


def main() -> None:
    icon = Image.open(LOGO / "icon_1024.png").convert("RGBA")
    foreground = Image.open(LOGO / "foreground_1024.png").convert("RGBA")

    for folder, scale in DENSITIES.items():
        target = RES / folder
        target.mkdir(parents=True, exist_ok=True)
        scaled(icon, round(48 * scale)).save(target / "ic_launcher.png", optimize=True)
        scaled(foreground, round(108 * scale)).save(
            target / "ic_launcher_foreground.png", optimize=True,
        )

    notification = Image.open(LOGO / "notification_1024.png").convert("RGBA")
    for folder, scale in NOTIFICATION_DENSITIES.items():
        target = RES / folder
        target.mkdir(parents=True, exist_ok=True)
        scaled(notification, round(24 * scale)).save(
            target / f"{NOTIFICATION_ICON}.png", optimize=True,
        )
    write_if_changed(RES / "raw" / "keep.xml", KEEP_XML)

    write_if_changed(RES / "mipmap-anydpi-v26" / "ic_launcher.xml", ADAPTIVE_XML)
    write_if_changed(
        RES / "values" / "ic_launcher_background.xml",
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
        f'    <color name="ic_launcher_background">{background_colour()}</color>\n'
        "</resources>\n",
    )

    (ROOT / "assets" / "images").mkdir(parents=True, exist_ok=True)
    scaled(icon, 256).save(ROOT / "assets" / "images" / "logo.png", optimize=True)
    print("generate_icons: wrote the launcher icon, the adaptive icon and assets/images/logo.png")


if __name__ == "__main__":
    main()
